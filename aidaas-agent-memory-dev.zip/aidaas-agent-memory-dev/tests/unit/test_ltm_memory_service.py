import pytest
from src.application.exception import RuntimeException
from src.application.service import ltm_memory_service as ltm_module
from src.core.ltm_config import AppConfig


class FakeMemoryInstance:
    def __init__(self):
        self.add_calls = []
        self.search_calls = []
        self.get_all_calls = []
        self.get_calls = []
        self.update_calls = []
        self.delete_calls = []
        self.delete_all_calls = []
        self.history_calls = []
        self.reset_called = False

        self.add_result = {
            "id": "mem-1",
            "memory": "stored",
            "metadata": {"foo": "bar"},
        }
        self.search_result = [
            {"id": "1", "memory": "first", "metadata": {"tag": "one"}, "score": 0.9},
            {"id": "2", "content": "second"},
        ]
        self.get_all_result = [
            {"id": "1", "memory": "alpha", "metadata": {"tag": "one"}},
            {"content": "beta"},
        ]
        self.get_result = {
            "id": "mem-1",
            "memory": "stored",
            "metadata": {"foo": "bar"},
        }
        self.history_result = {"event": "updated"}
        self.raise_on_add = None

    def add(self, *, messages, **kwargs):
        if self.raise_on_add:
            raise self.raise_on_add
        self.add_calls.append((messages, kwargs))
        return self.add_result

    def search(self, *, query, **kwargs):
        self.search_calls.append((query, kwargs))
        return self.search_result

    def get_all(self, **kwargs):
        self.get_all_calls.append(kwargs)
        return self.get_all_result

    def get(self, memory_id):
        self.get_calls.append(memory_id)
        return self.get_result

    def update(self, *, memory_id, data):
        self.update_calls.append((memory_id, data))

    def delete(self, *, memory_id):
        self.delete_calls.append(memory_id)

    def delete_all(self, **kwargs):
        self.delete_all_calls.append(kwargs)

    def history(self, *, memory_id):
        self.history_calls.append(memory_id)
        return self.history_result

    def reset(self):
        self.reset_called = True


class FakeMemoryManager:
    def __init__(self, memory_instance):
        self.memory_instance = memory_instance
        self.users = set()

    def get_memory_instance(self, app_config):
        self.users.add(app_config.app_id)
        return self.memory_instance

    def check_app_exists(self, app_id):
        return app_id in self.users


class FakeDBManager:
    def __init__(self):
        self.existing_schemas = set()
        self.checked = []

    def check_schema_exists(self, app_id: str) -> bool:
        self.checked.append(app_id)
        return app_id in self.existing_schemas


@pytest.fixture
def service_components(monkeypatch):
    fake_instance = FakeMemoryInstance()
    fake_manager = FakeMemoryManager(fake_instance)
    fake_db = FakeDBManager()

    monkeypatch.setattr(ltm_module, "get_memory_manager", lambda: fake_manager)
    monkeypatch.setattr(ltm_module, "get_postgresql_manager", lambda: fake_db)
    monkeypatch.setattr(ltm_module, "_ltm_service", None)

    service = ltm_module.LTMService()
    return service, fake_instance, fake_manager, fake_db


def _configure_default(service):
    return service.configure(
        AppConfig(
            app_id="app-123",
            api_key="test-key",
            llm_model="gpt-test",
            embedder_model="test-embed",
        )
    )


def test_configure_sets_current_instance(service_components):
    service, instance, manager, db = service_components
    result = _configure_default(service)

    assert result == {
        "message": "Configuration set successfully",
        "app_id": "app-123",
        "schema_created": True,
    }
    assert service._current_memory_instance is instance
    assert service._current_app_config.app_id == "app-123"
    assert manager.check_app_exists("app-123")
    assert db.checked == ["app-123"]


def test_add_memory_wraps_single_result(service_components):
    service, instance, manager, _ = service_components
    _configure_default(service)
    instance.add_result = {"id": "abc", "memory": "value", "metadata": {"kind": "note"}}

    payload = [{"role": "user", "content": "hello"}]
    result = service.add_memory(
        messages=payload,
        metadata={"topic": "greetings"},
        run_id="run-1",
        agent_id="agent-1",
    )

    assert result["results"] == instance.add_result

    messages, kwargs = instance.add_calls[-1]
    assert messages == payload
    assert kwargs.get("agent_id") == "agent-1"
    assert kwargs.get("run_id") == "run-1"
    assert kwargs.get("metadata") == {"topic": "greetings"}


def test_add_memory_propagates_errors(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)
    instance.raise_on_add = RuntimeError("boom")

    with pytest.raises(RuntimeError):
        service.add_memory(messages=[{"role": "user", "content": "hi"}])


def test_search_memories_formats_results(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)

    result = service.search_memories("query", agent_id="agent-7")
    formatted = result["results"]
    assert formatted[0] == {
        "id": "1",
        "content": "first",
        "metadata": {"tag": "one"},
        "score": 0.9,
    }
    assert formatted[1] == {
        "id": "2",
        "content": "second",
        "metadata": {},
        "score": 0.0,
    }
    query, kwargs = instance.search_calls[-1]
    assert query == "query"
    assert kwargs["agent_id"] == "agent-7"
    assert "app_id" not in kwargs


def test_get_all_memories_formats_results(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)

    result = service.get_all_memories(run_id="run-9")
    assert result["results"] == [
        {"id": "1", "content": "alpha", "metadata": {"tag": "one"}},
        {"id": "", "content": "beta", "metadata": {}},
    ]
    kwargs = instance.get_all_calls[-1]
    assert kwargs["run_id"] == "run-9"
    assert "app_id" not in kwargs


def test_get_memory_requires_configuration(service_components):
    service, *_ = service_components
    with pytest.raises(RuntimeException) as exc:
        service.get_memory("mem-1")
    assert "No memory instance configured" in str(exc.value)


def test_get_memory_returns_formatted_result(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)
    instance.get_result = {
        "id": "xyz",
        "memory": "answer",
        "metadata": {"foo": "bar"},
    }

    result = service.get_memory("xyz")
    assert result == {
        "result": {
            "id": "xyz",
            "content": "answer",
            "metadata": {"foo": "bar"},
        }
    }


def test_update_memory_delegates_to_instance(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)

    response = service.update_memory("abc", data="new value")
    assert response == {"result": "Memory updated successfully"}
    assert instance.update_calls == [("abc", "new value")]


def test_delete_memory_delegates_to_instance(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)

    response = service.delete_memory("abc")
    assert response == {"result": "Memory deleted successfully"}
    assert instance.delete_calls == ["abc"]


def test_delete_all_memories_includes_identifiers(service_components):
    pytest.skip(
        "delete_all_memories() is not implemented in LTMService in the new design"
    )


def test_memory_history_wraps_non_list_result(service_components):
    pytest.skip("memory_history() is not implemented in LTMService in the new design")


def test_reset_memory_requires_configuration(service_components):
    service, *_ = service_components
    with pytest.raises(RuntimeException) as exc:
        service.reset_memory()
    assert "No memory instance configured" in str(exc.value)


def test_reset_memory_clears_instance(service_components):
    service, instance, _, _ = service_components
    _configure_default(service)

    response = service.reset_memory()
    assert response == {"result": "All memories reset"}
    assert instance.reset_called is True


def test_get_memory_instance_for_different_user_raises(service_components):
    pytest.skip(
        "Cross-user access via app_id is not supported by get_all_memories() in the new service"
    )
