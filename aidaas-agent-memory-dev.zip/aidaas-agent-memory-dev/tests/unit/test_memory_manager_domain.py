import types

import pytest
from src.core.ltm_config import AppConfig
from src.domain import memory_manager as mm


class FakeDBManager:
    def __init__(self):
        self.create_calls = []
        self.check_calls = []
        self.existing = set()
        self.create_returns = True

    def create_app_schema(self, app_id, embedding_dims):
        self.create_calls.append((app_id, embedding_dims))
        self.existing.add(app_id)
        return self.create_returns

    def check_schema_exists(self, app_id):
        self.check_calls.append(app_id)
        return app_id in self.existing


class DummyMemory:
    calls = []

    @classmethod
    def from_config(cls, config, schema=None):
        cls.calls.append((config, schema))
        return {"schema": schema, "config": config}


@pytest.fixture
def manager(monkeypatch):
    fake_db = FakeDBManager()
    monkeypatch.setattr(mm, "get_postgresql_manager", lambda: fake_db)
    monkeypatch.setattr(mm, "EnhancedMemory", DummyMemory)
    monkeypatch.setattr(mm, "ENHANCED_MEMORY_AVAILABLE", True)
    monkeypatch.setattr(mm, "_memory_manager", None)
    DummyMemory.calls.clear()
    mgr = mm.MemoryManager()
    return mgr, fake_db


def test_get_memory_instance_creates_and_caches(manager):
    mgr, fake_db = manager
    config = AppConfig(
        app_id="user-a", api_key="secret", embedder_model="bge-base-en-v1-5"
    )

    instance = mgr.get_memory_instance(config)

    assert instance["schema"] == "user-a"
    # create_app_schema called with expected embedding dims for base model
    assert fake_db.create_calls == [("user-a", 768)]
    assert DummyMemory.calls[-1][1] == "user-a"

    # Second call should reuse cached instance
    again = mgr.get_memory_instance(config)
    assert again is instance
    assert len(DummyMemory.calls) == 1


def test_ensure_app_schema_handles_existing_schema(manager):
    mgr, fake_db = manager
    fake_db.create_returns = False
    fake_db.existing.add("user-b")

    mgr._ensure_app_schema(
        AppConfig(app_id="user-b", api_key="secret", embedder_model="bge-small-en-v1-5")
    )

    assert fake_db.create_calls[-1] == ("user-b", 384)


def test_remove_memory_instance_and_check(manager):
    mgr, fake_db = manager
    config = AppConfig(app_id="user-c", api_key="secret")

    mgr.get_memory_instance(config)
    mgr.remove_memory_instance("user-c")

    assert "user-c" not in mgr._memory_instances

    exists = mgr.check_app_exists("user-c")
    assert exists is True
    assert fake_db.check_calls == ["user-c"]


def test_get_memory_manager_singleton(monkeypatch, manager):
    _mgr, fake_db = manager
    monkeypatch.setattr(mm, "get_postgresql_manager", lambda: fake_db)
    monkeypatch.setattr(mm, "_memory_manager", None)

    first = mm.get_memory_manager()
    second = mm.get_memory_manager()
    assert first is second
