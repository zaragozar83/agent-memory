import pytest


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_memory_flow_add_get_delete(client, fake_redis):
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "session"
    session_key = f"session:{application_id}:{agent_id}:{user_id}:{session_id}"
    fake_redis.set(session_key, "active")

    add_resp = client.post(
        "/api/v1/stm/memory",
        json={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
            "messages": [{"role": "user", "content": "hello"}],
        },
    )
    assert add_resp.status_code == 200
    assert add_resp.json()["success"] is True

    get_resp = client.get(
        "/api/v1/stm/memory",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert get_resp.status_code == 200
    body = get_resp.json()
    assert body["success"] is True
    memory_items = body["data"]["memory"]
    assert len(memory_items) == 1
    assert memory_items[0]["content"] == "hello"
    assert memory_items[0]["type"] in {"human", "user"}

    delete_resp = client.delete(
        "/api/v1/stm/memory",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert delete_resp.status_code == 200
    assert delete_resp.json()["data"]["status"] == "deleted"

    post_delete_resp = client.get(
        "/api/v1/stm/memory",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert post_delete_resp.status_code == 200
    assert post_delete_resp.json()["data"]["memory"] == []


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_memory_manual_summarize(client, fake_redis):
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "session"
    session_key = f"session:{application_id}:{agent_id}:{user_id}:{session_id}"
    fake_redis.set(session_key, "active")

    for role, content in [("user", "question"), ("assistant", "answer")]:
        resp = client.post(
            "/api/v1/stm/memory",
            json={
                "application_id": application_id,
                "agent_id": agent_id,
                "user_id": user_id,
                "session_id": session_id,
                "messages": [{"role": role, "content": content}],
            },
        )
        assert resp.status_code == 200

    summarize_resp = client.post(
        "/api/v1/stm/memory/summarize",
        json={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert summarize_resp.status_code == 200
    assert summarize_resp.json()["data"]["status"] == "summarized"

    summary_get = client.get(
        "/api/v1/stm/memory",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert summary_get.status_code == 200
    memory_items = summary_get.json()["data"]["memory"]
    assert len(memory_items) == 1
    assert memory_items[0]["type"] == "system"
    assert "Summary" in memory_items[0]["content"]


def test_memory_requires_existing_session(client, fake_redis, patch_chat_history):
    resp = client.get(
        "/api/v1/stm/memory",
        params={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "missing",
        },
    )
    assert resp.status_code == 404
    body = resp.json()
    assert body["success"] is False
    assert "not found" in body["message"].lower()


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_add_memory_returns_500_on_error(client, monkeypatch):
    from src.api.v1.controller import stm_memory as memory_ctrl

    def boom(*_args, **_kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(memory_ctrl, "add_messages", boom)

    resp = client.post(
        "/api/v1/stm/memory",
        json={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "session",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )

    assert resp.status_code == 500
    assert "failed to add memory" in resp.json()["message"].lower()


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_get_memory_reports_service_errors(client, monkeypatch, fake_redis):
    key = "session:app:agent:user:session"
    fake_redis.set(key, "active")

    from src.api.v1.controller import stm_memory as memory_ctrl

    def boom(*_args, **_kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(memory_ctrl, "get_memory", boom)

    resp = client.get(
        "/api/v1/stm/memory",
        params={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "session",
        },
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to retrieve memory" in body["message"].lower()


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_delete_memory_reports_errors(client, monkeypatch, fake_redis):
    key = "session:app:agent:user:session"
    fake_redis.set(key, "active")

    from src.api.v1.controller import stm_memory as memory_ctrl

    def boom(*_args, **_kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(memory_ctrl, "delete_memory", boom)

    resp = client.delete(
        "/api/v1/stm/memory",
        params={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "session",
        },
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to delete memory" in body["message"].lower()


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_summarize_requires_existing_session(client):
    resp = client.post(
        "/api/v1/stm/memory/summarize",
        json={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "missing",
        },
    )
    assert resp.status_code == 404


@pytest.mark.usefixtures("fake_redis", "patch_chat_history")
def test_summarize_reports_errors(client, monkeypatch, fake_redis):
    key = "session:app:agent:user:session"
    fake_redis.set(key, "active")

    from src.api.v1.controller import stm_memory as memory_ctrl

    def boom(*_args, **_kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(memory_ctrl, "manual_summarize", boom)

    resp = client.post(
        "/api/v1/stm/memory/summarize",
        json={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "session",
        },
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to summarize memory" in body["message"].lower()
