"""Tests for boundary crossing summarization logic."""

from unittest.mock import Mock, patch

import pytest
from src.api.v1.request.stm_memory import Message
from src.application.service.stm_memory_service import (
    add_messages,
    should_trigger_boundary_summarization,
)
from src.core.environment_variables import EnvironmentVariables


class TestBoundaryCrossing:
    """Test boundary crossing logic for summarization."""

    def test_should_trigger_boundary_summarization_no_crossing(self):
        """Test that no summarization is triggered when staying within same batch."""
        # Test with test environment batch size (3)
        assert not should_trigger_boundary_summarization(1, 2)  # Both in batch 0 (0-2)
        assert not should_trigger_boundary_summarization(0, 2)  # Both in batch 0

    def test_should_trigger_boundary_summarization_crossing_batch(self):
        """Test summarization triggered when crossing batch boundary."""
        # Test with test environment batch size (3)
        assert should_trigger_boundary_summarization(
            2, 3
        )  # Cross from batch 0 to batch 1
        assert should_trigger_boundary_summarization(
            2, 4
        )  # Cross from batch 0 to batch 1
        assert should_trigger_boundary_summarization(
            0, 3
        )  # Cross from batch 0 to batch 1

    def test_should_trigger_boundary_summarization_crossing_batch(self):
        """Test summarization triggered when crossing batch boundary."""
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        # Cross from batch 0 to batch 1
        assert should_trigger_boundary_summarization(batch_size - 2, batch_size + 2)
        assert should_trigger_boundary_summarization(batch_size - 5, batch_size + 5)
        assert should_trigger_boundary_summarization(batch_size - 1, batch_size)

    def test_should_trigger_boundary_summarization_multiple_boundaries(self):
        """Test summarization triggered when crossing multiple boundaries."""
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        # Cross from batch 0 to batch 2 (skip batch 1)
        assert should_trigger_boundary_summarization(batch_size - 2, batch_size * 2 + 5)

        # Cross from batch 1 to batch 3 (skip batch 2)
        assert should_trigger_boundary_summarization(batch_size + 5, batch_size * 3 + 5)

    def test_should_trigger_boundary_summarization_insufficient_messages(self):
        """Test no summarization when total messages < MEMORY_BATCH_SIZE."""
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        # Even if crossing boundary, need minimum messages
        assert not should_trigger_boundary_summarization(0, batch_size - 1)
        assert not should_trigger_boundary_summarization(1, batch_size - 1)

    def test_should_trigger_boundary_summarization_edge_cases(self):
        """Test edge cases for boundary crossing."""
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        # Exactly at boundary
        assert should_trigger_boundary_summarization(batch_size - 1, batch_size)
        assert should_trigger_boundary_summarization(batch_size * 2 - 1, batch_size * 2)

        # Large jump
        assert should_trigger_boundary_summarization(5, batch_size * 5)

    @patch("src.application.service.stm_memory_service.get_chat_history")
    @patch("src.application.service.stm_memory_service.summarize_and_replace")
    def test_add_messages_triggers_summarization(
        self, mock_summarize, mock_get_history
    ):
        """Test that add_messages triggers summarization when boundary is crossed."""

        # Mock chat history with messages that will cross boundary when we add more
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        initial_count = batch_size - 2  # Start 2 messages before boundary
        mock_history = Mock()
        mock_history.messages = ["msg"] * initial_count
        mock_history.session_id = "test_session"
        mock_get_history.return_value = mock_history

        # Mock the add_message and add_user_message methods
        def mock_add_message(msg):
            mock_history.messages.append(msg)

        def mock_add_user_message(content):
            mock_history.messages.append(f"user: {content}")

        mock_history.add_message = mock_add_message
        mock_history.add_user_message = mock_add_user_message

        # Create messages that will cross boundary
        messages_to_add = 3  # This will cross the boundary
        messages = [
            Message(role="user", content="Message 1"),
            Message(role="user", content="Message 2"),
            Message(role="user", content="Message 3"),
        ]

        # Call add_messages
        add_messages("app", "agent", "user", "session", messages)

        # Verify summarization was triggered
        mock_summarize.assert_called_once_with("app", "agent", "user", "session")

    @patch("src.application.service.stm_memory_service.get_chat_history")
    @patch("src.application.service.stm_memory_service.summarize_and_replace")
    def test_add_messages_no_summarization_same_batch(
        self, mock_summarize, mock_get_history
    ):
        """Test that add_messages doesn't trigger summarization when staying in same batch."""

        # Mock chat history that stays within same batch
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE
        initial_count = batch_size  # Start exactly at batch boundary
        mock_history = Mock()
        mock_history.messages = ["msg"] * initial_count
        mock_history.session_id = "test_session"
        mock_get_history.return_value = mock_history

        def mock_add_user_message(content):
            mock_history.messages.append(f"user: {content}")

        mock_history.add_user_message = mock_add_user_message

        # Add 1 message that stays within same batch (batch_size + 1 stays in batch 1)
        messages = [
            Message(role="user", content="Message 1"),
        ]

        # Call add_messages
        add_messages("app", "agent", "user", "session", messages)

        # Verify summarization was NOT triggered
        mock_summarize.assert_not_called()

    def test_boundary_calculations(self):
        """Test the mathematical correctness of boundary calculations."""
        batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE

        # Test batch assignments
        assert 0 // batch_size == 0  # Messages 0-(batch_size-1) in batch 0
        assert (batch_size - 1) // batch_size == 0
        assert (
            batch_size // batch_size == 1
        )  # Messages batch_size-(2*batch_size-1) in batch 1
        assert (batch_size * 2 - 1) // batch_size == 1
        assert (batch_size * 2) // batch_size == 2  # Messages 2*batch_size- in batch 2

        # Test boundary crossings
        assert (batch_size // batch_size) > ((batch_size - 1) // batch_size)  # 1 > 0
        assert ((batch_size * 2) // batch_size) > (
            (batch_size * 2 - 1) // batch_size
        )  # 2 > 1
        assert ((batch_size * 3) // batch_size) > (
            (batch_size * 2 + 1) // batch_size
        )  # 3 > 2
