import pytest
from src.api.v1.request.stm_memory import Message
from src.application.service import stm_memory_service


@pytest.mark.usefixtures("patch_chat_history")
def test_add_message_ai_with_tool_calls():
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "session"

    message = Message(
        role="ai",
        content="response",
        additional_kwargs={"foo": "bar"},
        tool_calls=[
            {"name": "tool", "id": "1", "type": "function", "arguments": {"arg": 1}},
            {
                "name": "tool2",
                "id": "2",
                "type": "function",
                "args": '{"key": "value"}',
            },
        ],
    )

    stm_memory_service.add_message(
        application_id, agent_id, user_id, session_id, message
    )
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(messages) == 1
    stored = messages[0]
    assert getattr(stored, "type", getattr(stored, "_type", "")) == "ai"
    assert getattr(stored, "additional_kwargs", {}).get("foo") == "bar"
    assert getattr(stored, "tool_calls", [])


@pytest.mark.usefixtures("patch_chat_history")
def test_add_message_triggers_auto_summary():
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "auto"

    # Get the actual batch size used by the service (should be 3 in tests)
    from src.core.environment_variables import EnvironmentVariables

    batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE

    # Add messages up to batch_size - 1 (should not trigger)
    for idx in range(batch_size - 1):
        message = Message(role="user", content=f"message {idx}")
        stm_memory_service.add_message(
            application_id, agent_id, user_id, session_id, message
        )

    # At this point we have batch_size - 1 messages, no summarization yet
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(messages) == batch_size - 1

    # Add 1 more message to reach batch_size and trigger boundary crossing
    message = Message(role="user", content="trigger message")
    stm_memory_service.add_message(
        application_id, agent_id, user_id, session_id, message
    )

    # Now summarization should have been triggered (batch_size - 1 + 1 = batch_size crosses boundary)
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(messages) == 1
    assert getattr(messages[0], "type", getattr(messages[0], "_type", "")) == "system"
    assert "Summary" in messages[0].content


@pytest.mark.usefixtures("patch_chat_history")
def test_delete_memory_clears_history():
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "delete"

    stm_memory_service.add_message(
        application_id,
        agent_id,
        user_id,
        session_id,
        Message(role="user", content="msg"),
    )
    stm_memory_service.delete_memory(application_id, agent_id, user_id, session_id)
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert messages == []


@pytest.mark.usefixtures("patch_chat_history")
def test_add_messages_multiple():
    """Test adding multiple messages at once (avoiding summarization)."""
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "multi"

    # Add only 2 messages to avoid triggering summarization (test batch_size=3)
    messages = [
        Message(role="user", content="Hello"),
        Message(role="ai", content="Hi there!"),
    ]

    stm_memory_service.add_messages(
        application_id, agent_id, user_id, session_id, messages
    )
    stored_messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )

    assert len(stored_messages) == 2
    assert stored_messages[0].content == "Hello"
    assert stored_messages[1].content == "Hi there!"


@pytest.mark.usefixtures("patch_chat_history")
def test_add_messages_boundary_crossing():
    """Test boundary crossing with add_messages."""
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "boundary"

    # Get the actual batch size used by the service
    from src.core.environment_variables import EnvironmentVariables

    batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE

    # Add messages just under the batch size
    initial_count = batch_size - 1
    initial_messages = [
        Message(role="user", content=f"Message {i}") for i in range(initial_count)
    ]
    stm_memory_service.add_messages(
        application_id, agent_id, user_id, session_id, initial_messages
    )

    # Should have initial_count messages, no summarization
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(messages) == initial_count

    # Add enough messages to trigger boundary crossing
    boundary_messages = [
        Message(role="ai", content="Response"),
        Message(role="user", content="Follow up"),
    ]
    stm_memory_service.add_messages(
        application_id, agent_id, user_id, session_id, boundary_messages
    )

    # Should trigger summarization (crossed batch boundary)
    messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(messages) == 1
    assert getattr(messages[0], "type", getattr(messages[0], "_type", "")) == "system"
    assert "Summary" in messages[0].content


@pytest.mark.usefixtures("patch_chat_history")
def test_add_messages_no_boundary_crossing():
    """Test that no summarization occurs when staying within same batch."""
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "no_boundary"

    # Add 2 messages (stays in batch 0: 0-2 messages)
    messages = [
        Message(role="user", content="Hello"),
        Message(role="ai", content="Hi there!"),
    ]
    stm_memory_service.add_messages(
        application_id, agent_id, user_id, session_id, messages
    )

    stored_messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )
    assert len(stored_messages) == 2
    # No system message should be present (no summarization)
    assert all(
        getattr(msg, "type", getattr(msg, "_type", "")) != "system"
        for msg in stored_messages
    )


@pytest.mark.usefixtures("patch_chat_history")
def test_add_messages_with_tool_calls():
    """Test adding messages with tool calls using add_messages (avoiding summarization)."""
    application_id = "app"
    agent_id = "agent"
    user_id = "user"
    session_id = "tools"

    # Add only 2 messages to avoid triggering summarization (test batch_size=3)
    messages = [
        Message(
            role="user",
            content="What's the weather like?",
            additional_kwargs={"location": "detected"},
        ),
        Message(
            role="ai",
            content="Let me check that for you.",
            tool_calls=[
                {
                    "name": "get_weather",
                    "id": "call_123",
                    "args": {"location": "New York"},
                }
            ],
        ),
    ]

    stm_memory_service.add_messages(
        application_id, agent_id, user_id, session_id, messages
    )
    stored_messages = stm_memory_service.get_memory(
        application_id, agent_id, user_id, session_id
    )

    assert len(stored_messages) == 2  # Check user message with additional_kwargs
    user_msg = stored_messages[0]
    assert user_msg.content == "What's the weather like?"
    assert getattr(user_msg, "additional_kwargs", {}).get("location") == "detected"

    # Check AI message with tool calls
    ai_msg_with_tools = stored_messages[1]
    assert ai_msg_with_tools.content == "Let me check that for you."
    tool_calls = getattr(ai_msg_with_tools, "tool_calls", [])
    assert len(tool_calls) > 0

    # Verify tool call details
    tool_call = tool_calls[0]
    assert tool_call["name"] == "get_weather"
    assert tool_call["id"] == "call_123"
    assert tool_call["args"]["location"] == "New York"
