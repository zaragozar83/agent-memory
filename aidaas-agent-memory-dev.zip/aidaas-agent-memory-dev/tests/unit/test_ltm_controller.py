import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from src.api.v1.controller import ltm_memory as ltm_ctrl


class FakeLTMService:
    def __init__(self):
        self.existing_users = {"known"}
        self.add_calls = []
        self.search_calls = []
        self.update_calls = []
        self.delete_calls = []

    def configure(self, app_config):
        app_id = getattr(app_config, "app_id", None)
        if app_id is None and isinstance(app_config, dict):
            app_id = app_config.get("app_id")
        if app_id:
            self.existing_users.add(app_id)
        return {
            "message": "Configuration set successfully",
            "app_id": app_id,
            "schema_created": True,
        }

    def add_memory(self, **kwargs):
        self.add_calls.append(kwargs)
        return {"results": {"results": [{"id": "mem-1", "content": "created"}]}}

    def search_memories(self, **kwargs):
        self.search_calls.append(kwargs)
        return {"results": [{"id": "res-1", "content": "found", "score": 0.9}]}

    def get_all_memories(self, **kwargs):
        return {"results": [{"id": "mem-1", "content": "stored"}]}

    def get_memory(self, memory_id):
        return {"result": {"id": memory_id, "content": "stored"}}

    def update_memory(self, **kwargs):
        self.update_calls.append(kwargs)
        return {"result": "updated"}

    def delete_memory(self, memory_id):
        self.delete_calls.append((memory_id, None))
        return {"result": "deleted"}

    def delete_all_memories(self, **kwargs):
        return {"result": "deleted all"}

    def reset_memory(self):
        return {"result": "reset"}

    def check_app_exists(self, app_id):
        return app_id in self.existing_users


@pytest.fixture
def ltm_client(monkeypatch):
    service = FakeLTMService()
    monkeypatch.setattr(ltm_ctrl, "get_ltm_service", lambda: service)

    app = FastAPI()
    app.include_router(ltm_ctrl.router, prefix="/api/v1")
    return TestClient(app), service


def test_configure_memory_returns_payload(ltm_client):
    client, _ = ltm_client
    body = {
        "app_id": "new-app",
        "api_key": "key",
        "llm_model": "model",
        "embedder_model": "embed",
    }

    response = client.post("/api/v1/ltm/configure", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert "data" in payload and isinstance(payload["data"], dict)
    assert payload["data"]["app_id"] == "new-app"
    assert payload["data"]["schema_created"] is True
    assert payload.get("message") == "Configuration set successfully"


def test_create_memories_requires_identifier(ltm_client):
    client, _ = ltm_client
    body = {"messages": [{"role": "user", "content": "hi"}]}

    response = client.post("/api/v1/ltm/memories", json=body)
    assert response.status_code == 400
    detail = response.json().get("detail")
    assert isinstance(detail, str)
    assert "identifier" in detail.lower()


def test_create_memories_happy_path(ltm_client):
    client, _ = ltm_client

    body = {
        "messages": [{"role": "user", "content": "hello"}],
        "user_id": "u-1",
        "metadata": {"topic": "greeting"},
    }

    response = client.post("/api/v1/ltm/memories", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert isinstance(payload, dict)
    assert "data" in payload and isinstance(payload["data"], dict)
    results = payload["data"].get("results") or []
    assert isinstance(results, list)
    assert len(results) >= 1
    assert results[0]["id"] == "mem-1"


def test_get_memories_requires_identifier(ltm_client):
    client, _ = ltm_client
    # No user_id/agent_id/run_id provided
    response = client.get("/api/v1/ltm/memories")
    assert response.status_code == 400
    detail = response.json().get("detail")
    assert isinstance(detail, str)
    assert "identifier" in detail.lower()


def test_get_memories_returns_data(ltm_client):
    client, _ = ltm_client

    response = client.get(
        "/api/v1/ltm/memories",
        params={"user_id": "u-1", "run_id": "run"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    assert "data" in payload and isinstance(payload["data"], dict)
    results = payload["data"].get("results") or []
    assert isinstance(results, list) and len(results) >= 1
    assert results[0]["id"] == "mem-1"
    assert "content" in results[0]


def test_get_memory_returns_result(ltm_client):
    client, _ = ltm_client
    response = client.get("/api/v1/ltm/memories/mem-1")
    assert response.status_code == 200, response.text

    payload = response.json()
    assert "data" in payload and isinstance(payload["data"], dict)
    result = payload["data"].get("result")
    assert isinstance(result, dict)
    assert result.get("id") == "mem-1"
    assert "content" in result


def test_search_memories_invokes_service(ltm_client):
    client, _ = ltm_client
    body = {"query": "hello"}

    response = client.post("/api/v1/ltm/search", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert "data" in payload and isinstance(payload["data"], dict)
    results = payload["data"].get("results") or []
    assert isinstance(results, list) and len(results) >= 1
    assert results[0].get("id") == "res-1"
    assert "content" in results[0]


def test_update_memory_success(ltm_client):
    client, _ = ltm_client
    # The controller expects updated_memory: str
    body = {"updated_memory": "new"}

    response = client.put("/api/v1/ltm/memories/mem-1", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("data") is None
    assert payload.get("message") == "Memory updated successfully"


def test_delete_memory_success(ltm_client):
    client, _ = ltm_client
    response = client.delete("/api/v1/ltm/memories/mem-1")
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("data") is None
    assert payload.get("message") == "deleted"


def test_reset_memories_returns_message(ltm_client):
    client, _ = ltm_client
    response = client.post("/api/v1/ltm/reset")
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("data") is None
    assert payload.get("message") == "reset"
