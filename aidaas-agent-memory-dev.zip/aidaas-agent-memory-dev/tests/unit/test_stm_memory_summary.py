import pytest
from src.application.service import stm_memory_service


class StickyHistory:
    def __init__(self):
        self.session_id = "memory:app:agent:user:session"
        self.messages = [
            stm_memory_service.HumanMessage(content="hi"),
            stm_memory_service.AIMessage(content="hello"),
        ]
        self.clear_calls = 0

    def clear(self):
        self.clear_calls += 1
        # intentionally do not clear to trigger retry path

    def add_message(self, message):
        self.messages.append(message)


class FreshHistory:
    def __init__(self):
        self.session_id = "memory:app:agent:user:session"
        self.messages = []
        self.cleared = False

    def clear(self):
        self.cleared = True
        self.messages.clear()

    def add_message(self, message):
        self.messages.append(message)


@pytest.mark.usefixtures("fake_redis")
def test_summarize_retries_when_clear_fails(monkeypatch):
    sticky = StickyHistory()
    fresh = FreshHistory()
    histories = [sticky, fresh]

    def fake_get_chat_history(*_args, **_kwargs):
        return histories.pop(0)

    monkeypatch.setattr(stm_memory_service, "get_chat_history", fake_get_chat_history)

    stm_memory_service.summarize_and_replace("app", "agent", "user", "session")

    assert sticky.clear_calls == 1
    assert fresh.cleared is True
    assert len(fresh.messages) == 1
    assert "Summary of" in fresh.messages[0].content
