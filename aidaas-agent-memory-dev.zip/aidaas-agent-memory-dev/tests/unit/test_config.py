import pytest
from src.core.ltm_config import AppConfig, build_mem0_config, get_system_config


@pytest.mark.parametrize(
    "embedder,expected_dims",
    [
        ("text-embedding-3-small", 1024),
        ("bge-large-en-v1-5", 1024),
        ("bge-base-en-v1-5", 768),
        ("bge-m3", 1024),
        ("gte-large", 1024),
        ("bge-small-en-v1-5", 384),
    ],
)
def test_build_mem0_config_sets_embedding_dims(embedder, expected_dims):
    config = build_mem0_config(
        AppConfig(app_id="user", api_key="key", embedder_model=embedder)
    )

    vector_dims = config["vector_store"]["config"]["embedding_model_dims"]
    embedder_dims = config["embedder"]["config"]["embedding_dims"]

    assert vector_dims == expected_dims
    assert embedder_dims == expected_dims
    assert config["app_id"] == "user"
    assert config["llm"]["config"]["api_key"] == "key"


def test_get_system_config_returns_instance():
    system = get_system_config()
    assert system.POSTGRES_HOST
    assert system.LLM_PROVIDER == "vllm"
