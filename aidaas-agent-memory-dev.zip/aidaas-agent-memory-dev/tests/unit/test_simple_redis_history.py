import json

import pytest
from src.application.service import stm_memory_service


class DummyRedis:
    def __init__(self):
        self.storage = {}

    def get(self, key):
        return self.storage.get(key)

    def set(self, key, value, ex=None):
        self.storage[key] = value
        return True

    def delete(self, key):
        self.storage.pop(key, None)
        return 1


def test_simple_history_roundtrip():
    redis_backend = DummyRedis()
    history = stm_memory_service.SimpleRedisChatHistory(
        session_id="memory:app:agent:user:sess",
        ttl=5,
        redis_backend=redis_backend,
    )

    history.add_user_message("hi")
    history.add_ai_message("hello")
    raw = redis_backend.get("memory:app:agent:user:sess")
    assert raw is not None
    payload = json.loads(raw)
    assert payload[0]["type"] == "human"
    assert payload[0]["content"] == "hi"
    assert payload[1]["type"] == "ai"
    assert payload[1]["content"] == "hello"

    # Rehydrate messages from storage
    history2 = stm_memory_service.SimpleRedisChatHistory(
        session_id="memory:app:agent:user:sess",
        ttl=5,
        redis_backend=redis_backend,
    )
    assert len(history2.messages) == 2
    assert history2.messages[0].content == "hi"
    assert history2.messages[1].content == "hello"

    history2.clear()
    assert redis_backend.get("memory:app:agent:user:sess") is None
    assert history2.messages == []


@pytest.mark.usefixtures("fake_redis")
def test_get_chat_history_falls_back(monkeypatch):
    class BoomHistory:
        def __init__(self, *args, **kwargs):
            raise stm_memory_service.RedisModuleVersionError("missing module")

    monkeypatch.setattr(stm_memory_service, "RedisChatMessageHistory", BoomHistory)

    history = stm_memory_service.get_chat_history("app", "agent", "user", "sid")
    assert isinstance(history, stm_memory_service.SimpleRedisChatHistory)


def test_simple_history_handles_malformed_payload(caplog):
    redis_backend = DummyRedis()
    redis_backend.set("memory:app:agent:user:sess", "not-json")

    with caplog.at_level("WARNING"):
        history = stm_memory_service.SimpleRedisChatHistory(
            session_id="memory:app:agent:user:sess",
            redis_backend=redis_backend,
        )

    assert history.messages == []
    assert any("Malformed chat history payload" in msg for msg in caplog.messages)


def test_simple_history_dict_helpers_handle_metadata():
    ai_message = stm_memory_service.AIMessage(
        content="hello",
        additional_kwargs={"foo": "bar"},
        tool_calls=[{"name": "tool", "id": "1", "args": {"x": 1}}],
        name="assistant",
    )

    as_dict = stm_memory_service.SimpleRedisChatHistory._to_dict(ai_message)
    assert as_dict["additional_kwargs"] == {"foo": "bar"}
    assert as_dict["tool_calls"][0]["name"] == "tool"
    assert as_dict["name"] == "assistant"

    restored = stm_memory_service.SimpleRedisChatHistory._from_dict(as_dict)
    assert isinstance(restored, stm_memory_service.AIMessage)
    assert restored.additional_kwargs == {"foo": "bar"}
    assert restored.tool_calls[0]["id"] == "1"
    assert restored.name == "assistant"
