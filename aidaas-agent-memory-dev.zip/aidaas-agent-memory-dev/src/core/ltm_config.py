"""
Core configuration module for Agentic Memory API.
Only exposes user-configurable fields, with all infrastructure settings hardcoded.
"""

import os
from typing import Any, Dict, Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field

from src.core.environment_variables import EnvironmentVariables

# Load environment variables
load_dotenv()


class AppConfig(BaseModel):
    """App-configurable settings exposed via API."""

    app_id: str = Field(..., description="Unique app identifier for schema isolation")
    api_key: str = Field(..., description="API key")
    llm_model: str = Field(default="gpt-oss-20b", description="LLM model to use")
    embedder_model: str = Field(default="bge-m3", description="Embedding model to use")


class SystemConfig:
    """System-wide configuration with hardcoded infrastructure settings."""

    # PostgreSQL settings (hardcoded)
    POSTGRES_HOST = EnvironmentVariables.POSTGRES_HOST
    POSTGRES_PORT = EnvironmentVariables.POSTGRES_PORT
    POSTGRES_DB = EnvironmentVariables.POSTGRES_DB
    POSTGRES_USER = EnvironmentVariables.POSTGRES_USER
    POSTGRES_PASSWORD = EnvironmentVariables.POSTGRES_PASSWORD
    POSTGRES_COLLECTION_NAME = "memories"

    # Vector store settings (hardcoded)
    VECTOR_STORE_PROVIDER = "pgvector"
    EMBEDDING_DIMS = 1024  # Default for bge-m3

    # History store settings (hardcoded)
    HISTORY_STORE_PROVIDER = "postgres"
    HISTORY_TABLE_NAME = "history"

    # LLM settings
    LLM_PROVIDER = "vllm"
    LLM_TEMPERATURE = 0.2
    LLM_BASE_URL = EnvironmentVariables.LLM_BASE_URL
    LLM_MAX_TOKENS = 2000

    # Embedder settings
    EMBEDDER_PROVIDER = "openai"
    LLM_TEMPERATURE = 0.2
    EMBEDDER_BASE_URL = EnvironmentVariables.EMBEDDER_BASE_URL
    LLM_MAX_TOKENS = 2000

    # FastAPI settings
    APP_NAME = "Agentic Memory API"
    APP_VERSION = "1.0.0"
    DEBUG = os.environ.get("DEBUG", "false").lower() == "true"
    HOST = "0.0.0.0"
    PORT = int(os.environ.get("PORT", "8000"))


def build_mem0_config(app_config: AppConfig) -> Dict[str, Any]:
    """
    Build complete mem0 configuration from user config and system settings.

    Args:
        app_config: User-provided configuration

    Returns:
        Complete mem0 configuration dictionary
    """
    system = SystemConfig()

    # Map embedder model to dimensions
    embedding_dims = 1024  # Default for text-embedding-3-small
    if "bge-large-en-v1-5" in app_config.embedder_model:
        embedding_dims = 1024
    elif "bge-base-en-v1-5" in app_config.embedder_model:
        embedding_dims = 768
    elif "bge-m3" in app_config.embedder_model:
        embedding_dims = 1024
    elif "gte-large" in app_config.embedder_model:
        embedding_dims = 1024
    elif "bge-small-en-v1-5" in app_config.embedder_model:
        embedding_dims = 384

    return {
        "version": "v1.1",
        "app_id": app_config.app_id,  # Used for schema extraction
        "vector_store": {
            "provider": system.VECTOR_STORE_PROVIDER,
            "config": {
                "host": system.POSTGRES_HOST,
                "port": system.POSTGRES_PORT,
                "dbname": system.POSTGRES_DB,
                "user": system.POSTGRES_USER,
                "password": system.POSTGRES_PASSWORD,
                "collection_name": system.POSTGRES_COLLECTION_NAME,
                "embedding_model_dims": embedding_dims,
            },
        },
        "history_store": {
            "provider": system.HISTORY_STORE_PROVIDER,
            "config": {
                "host": system.POSTGRES_HOST,
                "port": system.POSTGRES_PORT,
                "dbname": system.POSTGRES_DB,
                "user": system.POSTGRES_USER,
                "password": system.POSTGRES_PASSWORD,
                "table": system.HISTORY_TABLE_NAME,
                # "schema": app_config.app_id,  # Schema isolation per user
            },
        },
        "llm": {
            "provider": system.LLM_PROVIDER,
            "config": {
                "api_key": app_config.api_key,
                "temperature": system.LLM_TEMPERATURE,
                "model": app_config.llm_model,
                "vllm_base_url": system.LLM_BASE_URL,
                "max_tokens": system.LLM_MAX_TOKENS,
            },
        },
        "embedder": {
            "provider": "openai",  # Hardcoded since we only support OpenAI for now
            "config": {
                "api_key": app_config.api_key,
                "model": app_config.embedder_model,
                "openai_base_url": system.EMBEDDER_BASE_URL,
                "embedding_dims": embedding_dims,
            },
        },
    }


def get_system_config() -> SystemConfig:
    """Get system configuration instance."""
    return SystemConfig()
