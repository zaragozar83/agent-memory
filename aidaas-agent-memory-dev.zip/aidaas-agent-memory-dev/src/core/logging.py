import json
import logging
import time
from typing import Any, Dict


def log_request(request, response_status_code, exception=None):
    if request.method == "GET" and "/v1/health" in request.url.path:
        return
    process_time = time.time() - float(request.headers["request-start-time"])
    fields_dict = {
        "time": float("{:.3f}".format(process_time)),
        "httpMethod": request.method,
        "path": request.url.path,
        "parameters": request.url.query,
        "status": response_status_code,
        "exception": exception,
    }
    logging.info(json.dumps(fields_dict))


def get_logging_config(log_level: str) -> Dict[str, Any]:
    logging.info(f"LOG_LEVEL: {log_level}")
    return {
        "version": 1,
        "disable_existing_loggers": True,
        "formatters": {"default": {"format": f"%(asctime)s %(levelname)s %(message)s"}},
        "handlers": {
            "console": {
                "level": log_level,
                "class": "logging.StreamHandler",
                "formatter": "default",
            },
        },
        "loggers": {"": {"handlers": ["console"], "level": log_level}},
    }
