import json
import logging

from langchain.memory import ConversationSummaryBufferMemory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_redis import RedisChatMessageHistory
from redis.exceptions import RedisError

from src.api.v1.request.stm_memory import Message
from src.core.environment_variables import EnvironmentVariables
from src.domain import redis as redis_mod

try:  # redisvl optional runtime dependency
    from redisvl.exceptions import RedisModuleVersionError

except ImportError:  # pragma: no cover - only hit if redisvl not installed

    class RedisModuleVersionError(Exception):
        """Fallback exception when redisvl isn't present."""


# Get memory batch size from environment variables
MEMORY_BATCH_SIZE = EnvironmentVariables.MEMORY_BATCH_SIZE


class SimpleRedisChatHistory(BaseChatMessageHistory):
    """Redis-backed chat history that only requires core Redis features."""

    def __init__(self, session_id: str, ttl: int | None = None, redis_backend=None):
        self.session_id = session_id
        self.ttl = ttl
        self._key = session_id
        self._redis = redis_backend or redis_mod.redis_client
        self.messages = self._load_messages()

    def get_messages(self) -> list[BaseMessage]:
        return self.messages

    def _load_messages(self) -> list[BaseMessage]:
        raw = self._redis.get(self._key)
        if not raw:
            return []
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            logging.warning("Malformed chat history payload for %s", self._key)
            return []
        return [self._from_dict(item) for item in payload]

    def _persist(self) -> None:
        serialized = json.dumps([self._to_dict(msg) for msg in self.messages])
        if self.ttl:
            self._redis.set(self._key, serialized, ex=self.ttl)
        else:
            self._redis.set(self._key, serialized)

    @staticmethod
    def _to_dict(message: BaseMessage) -> dict:
        data = {
            "type": getattr(message, "type", getattr(message, "_type", "system")),
            "content": getattr(message, "content", ""),
        }
        additional = getattr(message, "additional_kwargs", {}) or {}
        if additional:
            data["additional_kwargs"] = additional
        tool_calls = getattr(message, "tool_calls", None)
        if tool_calls:
            data["tool_calls"] = tool_calls
        name = getattr(message, "name", None)
        if name:
            data["name"] = name
        return data

    @staticmethod
    def _from_dict(payload: dict) -> BaseMessage:
        msg_type = payload.get("type", "system").lower()
        content = payload.get("content", "")
        additional_kwargs = payload.get("additional_kwargs", {})
        tool_calls = payload.get("tool_calls")
        kwargs = {"additional_kwargs": additional_kwargs} if additional_kwargs else {}
        name = payload.get("name")
        if name:
            kwargs["name"] = name
        if tool_calls:
            kwargs["tool_calls"] = tool_calls

        if msg_type in {"human", "user"}:
            return HumanMessage(content=content, **kwargs)
        if msg_type in {"ai", "assistant"}:
            return AIMessage(content=content, **kwargs)
        return SystemMessage(content=content, **kwargs)

    def add_message(self, message: BaseMessage) -> None:
        self.messages.append(message)
        self._persist()

    def add_user_message(self, content: str) -> None:
        self.add_message(HumanMessage(content=content))

    def add_ai_message(self, content: str) -> None:
        self.add_message(AIMessage(content=content))

    def clear(self) -> None:
        self._redis.delete(self._key)
        self.messages = []


# Helper to get RedisChatMessageHistory
def get_chat_history(application_id, agent_id, user_id, session_id):
    session_key = f"memory:{application_id}:{agent_id}:{user_id}:{session_id}"
    # Use redis_url from environment variables
    redis_url = EnvironmentVariables.REDIS_URL
    try:
        return RedisChatMessageHistory(
            session_id=session_key,
            redis_url=redis_url,
            ttl=EnvironmentVariables.REDIS_TTL,
        )
    except (RedisModuleVersionError, RedisError) as exc:
        logging.warning(
            "Redis modules unavailable for RediSearch features. Falling back to simple history. Error: %s",
            exc,
        )
        return SimpleRedisChatHistory(
            session_id=session_key,
            ttl=EnvironmentVariables.REDIS_TTL,
            redis_backend=redis_mod.redis_client,
        )


# Add multiple messages with boundary crossing auto-summarization
def add_messages(
    application_id, agent_id, user_id, session_id, messages: list[Message]
):
    try:
        chat_history = get_chat_history(application_id, agent_id, user_id, session_id)

        # Get message count before adding new messages
        message_count_before = len(chat_history.messages)
        logging.info(
            f"Adding {len(messages)} messages. Current count before: {message_count_before} for session {chat_history.session_id}"
        )

        # Add all messages
        for message in messages:
            # Create kwargs for additional fields
            kwargs = {}
            # Add additional_kwargs if provided
            if hasattr(message, "additional_kwargs") and message.additional_kwargs:
                kwargs["additional_kwargs"] = message.additional_kwargs

            # Add the appropriate message type based on the role
            if message.role.lower() == "user":
                if kwargs:
                    chat_history.add_message(
                        HumanMessage(content=message.content, **kwargs)
                    )
                else:
                    chat_history.add_user_message(message.content)
            elif message.role.lower() == "ai" or message.role.lower() == "assistant":
                # Add tool_calls for AI messages if provided
                if hasattr(message, "tool_calls") and message.tool_calls:
                    # Convert tool_calls to LangChain's expected format
                    formatted_tool_calls = []
                    for call in message.tool_calls:
                        # LangChain expects a specific format for tool calls
                        if isinstance(call, dict):
                            # Extract only the supported fields
                            tool_call = {
                                "name": call.get("name", "default_name"),
                                "id": call.get("id", "default_id"),
                                "args": {},
                            }
                            # Handle arguments properly - keep as dict for LangChain compatibility
                            if "arguments" in call and isinstance(
                                call["arguments"], dict
                            ):
                                # Use arguments directly as args
                                tool_call["args"] = call["arguments"]
                            elif "args" in call:
                                # If args is provided as a string, try to parse it
                                if isinstance(call["args"], str):
                                    try:
                                        import json

                                        tool_call["args"] = json.loads(call["args"])
                                    except json.JSONDecodeError:
                                        # If parsing fails, use as is
                                        tool_call["args"] = {}
                                else:
                                    # Use as is if it's already a dict
                                    tool_call["args"] = call["args"]

                            formatted_tool_calls.append(tool_call)

                    if formatted_tool_calls:
                        kwargs["tool_calls"] = formatted_tool_calls

                if kwargs:
                    chat_history.add_message(
                        AIMessage(content=message.content, **kwargs)
                    )
                else:
                    chat_history.add_ai_message(message.content)
            else:
                # Default to system message for other roles
                chat_history.add_message(
                    SystemMessage(content=message.content, **kwargs)
                )

        # Get message count after adding all messages
        message_count_after = len(chat_history.messages)
        logging.info(
            f"Added {len(messages)} messages. New count: {message_count_after} for session {chat_history.session_id}"
        )

        # Boundary crossing logic for summarization
        if should_trigger_boundary_summarization(
            message_count_before, message_count_after
        ):
            logging.info(
                f"Boundary crossed: triggering summarization at {message_count_after} messages"
            )
            summarize_and_replace(application_id, agent_id, user_id, session_id)

    except Exception as e:
        logging.error(f"Error adding messages: {str(e)}")
        logging.exception("Detailed traceback for add_messages error:")
        raise


def should_trigger_boundary_summarization(count_before: int, count_after: int) -> bool:
    """
    Check if we crossed a MEMORY_BATCH_SIZE boundary and should trigger summarization

    Args:
        count_before: Message count before adding new messages
        count_after: Message count after adding new messages

    Returns:
        True if summarization should be triggered, False otherwise
    """
    # Get the current batch size (allows for test overrides)
    current_batch_size = EnvironmentVariables.MEMORY_BATCH_SIZE

    # Need minimum messages to summarize
    if count_after < current_batch_size:
        return False

    # Calculate which batch each count belongs to
    batch_before = count_before // current_batch_size
    batch_after = count_after // current_batch_size

    # Trigger summarization if we crossed into a higher batch
    boundary_crossed = batch_after > batch_before

    if boundary_crossed:
        logging.info(
            f"Boundary crossing detected: batch {batch_before} → {batch_after} "
            f"(messages {count_before} → {count_after}, batch_size={current_batch_size})"
        )

    return boundary_crossed


# Keep the original add_message function for backward compatibility
def add_message(application_id, agent_id, user_id, session_id, message: Message):
    """Add a single message (wrapper around add_messages)"""
    add_messages(application_id, agent_id, user_id, session_id, [message])


# Summarize and replace messages with summary
def summarize_and_replace(application_id, agent_id, user_id, session_id):
    try:
        chat_history = get_chat_history(application_id, agent_id, user_id, session_id)

        # Log the number of messages before summarization
        logging.info(
            f"Attempting to summarize {len(chat_history.messages)} messages for session {chat_history.session_id}"
        )

        # Check if we have enough messages to summarize
        if len(chat_history.messages) < 2:
            logging.info(
                f"Not enough messages to summarize for {chat_history.session_id}"
            )
            return

        # Get OpenAI API key from environment variables
        openai_api_key = EnvironmentVariables.API_KEY
        api_url = EnvironmentVariables.API_URL
        if not openai_api_key:
            logging.warning("OPENAI_API_KEY not set. Using dummy summarization.")
            # Create a dummy summary for development when API key isn't available
            messages_text = "\n".join(
                [f"{m.type}: {m.content}" for m in chat_history.messages]
            )
            summary = f"Summary of {len(chat_history.messages)} messages: {messages_text[:100]}..."
        else:
            # Use LangChain's ConversationSummaryBufferMemory with OpenAI
            llm = ChatOpenAI(
                model=EnvironmentVariables.LLM_MODEL,
                openai_api_base=api_url,
                openai_api_key=openai_api_key,
                temperature=0,
            )
            memory = ConversationSummaryBufferMemory(
                llm=llm, chat_memory=chat_history, max_token_limit=1000
            )

            # Check if we have a system message that might contain a previous summary
            existing_summary = ""
            for msg in chat_history.messages:
                if hasattr(msg, "type") and msg.type == "system":
                    existing_summary = msg.content
                    break

            summary = memory.predict_new_summary(
                messages=chat_history.messages, existing_summary=existing_summary
            )

        # Replace messages with summary
        old_messages = chat_history.messages.copy()
        logging.info(
            f"Clearing {len(old_messages)} messages for {chat_history.session_id}"
        )

        # Make sure to clear all messages
        chat_history.clear()

        # Verify the messages were cleared
        if len(chat_history.messages) > 0:
            logging.warning(
                f"Failed to clear messages. Still have {len(chat_history.messages)} messages."
            )
            # Try again with a more direct approach
            chat_history = get_chat_history(
                application_id, agent_id, user_id, session_id
            )
            chat_history.clear()

        # Add the summary as a system message
        chat_history.add_message(SystemMessage(content=summary))

        # Verify the summary was added properly
        if len(chat_history.messages) != 1:
            logging.warning(
                f"Unexpected message count after summarization: {len(chat_history.messages)}"
            )
        else:
            logging.info(
                f"Successfully summarized {len(old_messages)} messages for {chat_history.session_id}"
            )
    except Exception as e:
        logging.error(f"Error summarizing messages: {str(e)}")
        logging.exception("Detailed traceback for summarization error:")
        # Don't re-raise, to prevent API failures
        # But still log the detailed error


# Get memory (summaries + unsummarized messages)
def get_memory(application_id, agent_id, user_id, session_id):
    try:
        chat_history = get_chat_history(application_id, agent_id, user_id, session_id)
        message_count = len(chat_history.messages)
        logging.info(
            f"Retrieved {message_count} messages for session {chat_history.session_id}"
        )

        # Log message types for debugging
        if message_count > 0:
            message_types = [
                f"{i}: {m.type}" for i, m in enumerate(chat_history.messages)
            ]
            logging.info(f"Message types: {message_types}")

        return chat_history.messages
    except Exception as e:
        logging.error(f"Error getting memory: {e}")
        raise


# Delete memory
def delete_memory(application_id, agent_id, user_id, session_id):
    try:
        chat_history = get_chat_history(application_id, agent_id, user_id, session_id)
        chat_history.clear()
        logging.info(f"Deleted memory for {chat_history.session_id}")
    except Exception as e:
        logging.error(f"Error deleting memory: {e}")
        raise


# Manual summarize API
def manual_summarize(application_id, agent_id, user_id, session_id):
    summarize_and_replace(application_id, agent_id, user_id, session_id)
