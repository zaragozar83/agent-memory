"""
Long-term memory service implementation based on mem0-6 logic.
"""

import logging
from copy import deepcopy
from typing import Any, Dict, List, Optional

from src.application.exception import RuntimeException
from src.core.ltm_config import AppConfig, build_mem0_config
from src.domain.database import get_postgresql_manager
from src.domain.memory_manager import MemoryManager, get_memory_manager


class LTMService:
    """Long-term memory service using mem0 with PostgreSQL backend."""

    def __init__(self):
        self._memory_manager: MemoryManager = get_memory_manager()
        self._db_manager = get_postgresql_manager()
        self._current_app_config: Optional[AppConfig] = None
        self._current_memory_instance = None

    def configure(self, app_config: AppConfig) -> Dict[str, Any]:
        """
        Configure memory for a user.

        Args:
            app_config: User configuration

        Returns:
            Configuration result
        """
        try:
            # Check if schema already exists
            schema_existed = self._db_manager.check_schema_exists(app_config.app_id)

            # Get or create memory instance (this will create schema if needed)
            memory_instance = self._memory_manager.get_memory_instance(app_config)

            # Cache current configuration
            self._current_app_config = app_config
            self._current_memory_instance = memory_instance

            return {
                "message": "Configuration set successfully",
                "app_id": app_config.app_id,
                "schema_created": not schema_existed,
            }

        except Exception as e:
            logging.error(f"Configuration error for app {app_config.app_id}: {e}")
            raise

    def add_memory(
        self,
        messages: List[Dict[str, Any]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Add memories from messages.

        Args:
            messages: List of messages to store
            user_id: User identifier
            agent_id: Agent identifier
            run_id: Run identifier
            metadata: Additional metadata

        Returns:
            Memory creation result
        """
        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        memory_instance = self._current_memory_instance

        # Prepare parameters
        params = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id
        if run_id:
            params["run_id"] = run_id
        if metadata:
            params["metadata"] = metadata

        try:
            result = memory_instance.add(messages=messages, **params)
            return {"results": result}

        except Exception as e:
            logging.error(f"Add memory error: {e}")
            raise

    def search_memories(
        self,
        query: str,
        user_id: Optional[str] = None,
        run_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Search memories.

        Args:
            query: Search query
            user_id: User identifier
            run_id: Run identifier
            agent_id: Agent identifier
            filters: Additional filters

        Returns:
            Search results
        """
        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        memory_instance = self._current_memory_instance

        # Prepare parameters
        params = {}
        if user_id:
            params["user_id"] = user_id
        if run_id:
            params["run_id"] = run_id
        if agent_id:
            params["agent_id"] = agent_id
        if filters:
            params["filters"] = filters

        try:
            result = memory_instance.search(query=query, **params)
            # Convert to standard format
            results = []

            # Handle both dict format {'results': []} and direct list format
            if isinstance(result, dict) and "results" in result:
                # New API format with {'results': []}
                memory_items = result["results"]
            elif isinstance(result, list):
                # Legacy direct list format
                memory_items = result
            else:
                # Unexpected format
                logging.warning(f"Unexpected search result format: {type(result)}")
                memory_items = []

            for item in memory_items:
                if isinstance(item, dict):
                    results.append(
                        {
                            "id": item.get("id", ""),
                            "content": item.get("memory", item.get("content", "")),
                            "metadata": item.get("metadata", {}),
                            "score": item.get("score", 0.0),
                        }
                    )

            return {"results": results}

        except Exception as e:
            logging.error(f"Search memories error: {e}")
            raise

    def get_all_memories(
        self,
        user_id: Optional[str] = None,
        run_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get all memories for identifiers.

        Args:
            user_id: User identifier
            run_id: Run identifier
            agent_id: Agent identifier

        Returns:
            All memories
        """
        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        memory_instance = self._current_memory_instance

        # Prepare parameters
        params = {}
        if user_id:
            params["user_id"] = user_id
        if run_id:
            params["run_id"] = run_id
        if agent_id:
            params["agent_id"] = agent_id

        try:
            result = memory_instance.get_all(**params)
            # Convert to standard format
            results = []

            # Handle both dict format {'results': []} and direct list format
            if isinstance(result, dict) and "results" in result:
                # New API format with {'results': []}
                memory_items = result["results"]
            elif isinstance(result, list):
                # Legacy direct list format
                memory_items = result
            else:
                # Unexpected format
                logging.warning(f"Unexpected get all result format: {type(result)}")
                memory_items = []

            for item in memory_items:
                if isinstance(item, dict):
                    results.append(
                        {
                            "id": item.get("id", ""),
                            "content": item.get("memory", item.get("content", "")),
                            "metadata": item.get("metadata", {}),
                        }
                    )

            return {"results": results}

        except Exception as e:
            logging.error(f"Get all memories error: {e}")
            raise

    def get_memory(self, memory_id: str) -> Dict[str, Any]:
        """
        Get a specific memory by ID.

        Args:
            memory_id: Memory identifier

        Returns:
            Memory details
        """
        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        try:
            result = self._current_memory_instance.get(memory_id)

            # Convert to standard format
            if isinstance(result, dict):
                memory_item = {
                    "id": result.get("id", memory_id),
                    "content": result.get("memory", result.get("content", "")),
                    "metadata": result.get("metadata", {}),
                }
                return {"result": memory_item}

            return {"result": None}

        except Exception as e:
            logging.error(f"Get memory error: {e}")
            raise

    def update_memory(
        self,
        memory_id: str,
        data: Dict[str, Any],  ## Check if this has to be str
    ) -> Dict[str, Any]:
        """
        Update a memory.

        Args:
            memory_id: Memory identifier
            data: Updated memory data

        Returns:
            Update result
        """

        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        memory_instance = self._current_memory_instance

        try:
            memory_instance.update(memory_id=memory_id, data=data)
            return {"result": "Memory updated successfully"}

        except Exception as e:
            logging.error(f"Update memory error: {e}")
            raise Exception(f"Memory update error: Memory may not exist")

    def delete_memory(self, memory_id: str) -> Dict[str, Any]:
        """
        Delete a specific memory.

        Args:
            memory_id: Memory identifier

        Returns:
            Deletion result
        """

        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        memory_instance = self._current_memory_instance

        try:
            memory_instance.delete(memory_id=memory_id)
            return {"result": "Memory deleted successfully"}

        except Exception as e:
            logging.error(f"Delete memory error: {e}")
            raise

    # def delete_all_memories(
    #     self,
    #     app_id: Optional[str] = None,
    #     run_id: Optional[str] = None,
    #     agent_id: Optional[str] = None,
    # ) -> Dict[str, Any]:
    #     """
    #     Delete all memories for identifiers.

    #     Args:
    #         app_id: App identifier (overrides config if provided)
    #         run_id: Run identifier
    #         agent_id: Agent identifier

    #     Returns:
    #         Deletion result
    #     """
    #     memory_instance = self._get_memory_instance_for_user(app_id)

    #     # Prepare parameters
    #     params = {}
    #     if app_id or (self._current_app_config and self._current_app_config.app_id):
    #         params["app_id"] = app_id or self._current_app_config.app_id
    #     if run_id:
    #         params["run_id"] = run_id
    #     if agent_id:
    #         params["agent_id"] = agent_id

    #     try:
    #         memory_instance.delete_all(**params)
    #         return {"message": "All relevant memories deleted"}

    #     except Exception as e:
    #         logging.error(f"Delete all memories error: {e}")
    #         raise

    # def memory_history(
    #     self, memory_id: str, app_id: Optional[str] = None
    # ) -> Dict[str, Any]:
    #     """
    #     Get memory history.

    #     Args:
    #         memory_id: Memory identifier
    #         app_id: User identifier (overrides config if provided)

    #     Returns:
    #         Memory history
    #     """
    #     memory_instance = self._get_memory_instance_for_user(app_id)

    #     try:
    #         result = memory_instance.history(memory_id=memory_id)
    #         return {"history": result if isinstance(result, list) else [result]}

    #     except Exception as e:
    #         logging.error(f"Memory history error: {e}")
    #         raise

    def reset_memory(self) -> Dict[str, Any]:
        """
        Reset all memories.

        Returns:
            Reset result
        """
        if not self._current_memory_instance:
            raise RuntimeException(
                message="Memory instance is not configured.",
                detail="No memory instance configured. Call /configure first.",
                status_code=500,
            )

        try:
            self._current_memory_instance.reset()
            return {"result": "All memories reset"}

        except Exception as e:
            logging.error(f"Reset memory error: {e}")
            raise

    def check_app_exists(self, app_id: str) -> bool:
        """
        Check if user exists (has schema).

        Args:
            app_id: User identifier

        Returns:
            True if user exists
        """
        return self._memory_manager.check_app_exists(app_id)

    def _get_memory_instance_for_user(self, app_id: Optional[str]):
        """
        Get memory instance for a specific user or current config.

        Args:
            app_id: User identifier (optional)

        Returns:
            Memory instance
        """
        # If app_id provided, need to create a temporary instance
        if app_id and (
            not self._current_app_config or self._current_app_config.app_id != app_id
        ):
            # Check if app exists
            if not self._memory_manager.check_app_exists(app_id):
                logging.exception(f"Application {app_id} does not exist")
                raise ValueError(f"Application {app_id} does not exist")

            logging.exception(
                f"No memory instance configured for application {app_id}. Call /configure first."
            )
            raise ValueError(
                f"No memory instance configured for application {app_id}. Call /configure first."
            )

        # Use current instance
        if not self._current_memory_instance:
            logging.exception("No memory instance configured. Call /configure first.")
            raise ValueError("No memory instance configured. Call /configure first.")

        return self._current_memory_instance


# Global service instance
_ltm_service = None


def get_ltm_service() -> LTMService:
    """Get LTM service instance (singleton)."""
    global _ltm_service
    if _ltm_service is None:
        _ltm_service = LTMService()
    return _ltm_service
