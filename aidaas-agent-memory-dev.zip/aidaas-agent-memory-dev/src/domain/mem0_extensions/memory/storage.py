"""
Enhanced storage module that provides PostgreSQL history management capabilities
by extending the base mem0 functionality.
"""

import logging
import sqlite3
import threading
import uuid
from typing import Any, Dict, List, Optional

try:
    import psycopg  # type: ignore

    _PSYCO_PKG = "psycopg3"
except Exception:
    try:
        import psycopg2  # type: ignore

        _PSYCO_PKG = "psycopg2"
    except Exception:  # pragma: no cover - environment w/o postgres client
        psycopg = None  # type: ignore
        psycopg2 = None  # type: ignore
        _PSYCO_PKG = None  # type: ignore

from mem0.memory.storage import SQLiteManager

# logger = logging.getLogger(__name__)


class PostgresHistoryManager:
    """
    PostgreSQL-backed history manager mirroring the SQLiteManager API.

    Expected config keys: host, port, dbname, user, password, table (optional, default 'history').
    """

    def __init__(
        self,
        *,
        host: str,
        port: int,
        dbname: str,
        user: str,
        password: str,
        table: str = "history",
        schema: str = None,
    ):
        if _PSYCO_PKG is None:
            raise ImportError(
                "Neither 'psycopg' nor 'psycopg2' is available to use PostgresHistoryManager"
            )

        self.schema = schema
        if schema:
            self.table = f"{schema}.{table}"
        else:
            self.table = table
        self._lock = threading.Lock()

        if _PSYCO_PKG == "psycopg3":
            self.connection = psycopg.connect(
                host=host, port=port, dbname=dbname, user=user, password=password, autocommit=True  # type: ignore
            )
        else:
            self.connection = psycopg2.connect(  # type: ignore
                host=host, port=port, dbname=dbname, user=user, password=password
            )
            self.connection.autocommit = True  # type: ignore

        self._create_history_table()

    def _execute(self, query: str, params: Optional[tuple] = None):
        with self._lock:
            cur = self.connection.cursor()
            try:
                cur.execute(query, params or ())
                try:
                    return cur.fetchall()
                except Exception:
                    return None
            finally:
                cur.close()

    def _create_history_table(self) -> None:
        create_sql = f"""
        CREATE TABLE IF NOT EXISTS {self.table} (
            id TEXT PRIMARY KEY,
            memory_id TEXT,
            old_memory TEXT,
            new_memory TEXT,
            event TEXT,
            created_at TIMESTAMPTZ,
            updated_at TIMESTAMPTZ,
            is_deleted BOOLEAN,
            actor_id TEXT,
            role TEXT
        )
        """
        self._execute(create_sql)

    def add_history(
        self,
        memory_id: str,
        old_memory: Optional[str],
        new_memory: Optional[str],
        event: str,
        *,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
        is_deleted: int = 0,
        actor_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> None:
        insert_sql = f"""
        INSERT INTO {self.table} (
            id, memory_id, old_memory, new_memory, event,
            created_at, updated_at, is_deleted, actor_id, role
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        # Convert SQLite-style int flag to boolean for Postgres
        is_deleted_bool = bool(is_deleted)

        params = (
            str(uuid.uuid4()),
            memory_id,
            old_memory,
            new_memory,
            event,
            created_at,
            updated_at,
            is_deleted_bool,
            actor_id,
            role,
        )
        # psycopg3 uses %s as well, so the same SQL works
        self._execute(insert_sql, params)

    def get_history(self, memory_id: str) -> List[Dict[str, Any]]:
        select_sql = f"""
        SELECT id, memory_id, old_memory, new_memory, event,
               created_at, updated_at, is_deleted, actor_id, role
        FROM {self.table}
        WHERE memory_id = %s
        ORDER BY created_at ASC, updated_at ASC
        """
        rows = self._execute(select_sql, (memory_id,)) or []
        return [
            {
                "id": r[0],
                "memory_id": r[1],
                "old_memory": r[2],
                "new_memory": r[3],
                "event": r[4],
                "created_at": r[5],
                "updated_at": r[6],
                "is_deleted": bool(r[7]),
                "actor_id": r[8],
                "role": r[9],
            }
            for r in rows
        ]

    def reset(self) -> None:
        drop_sql = f"DROP TABLE IF EXISTS {self.table}"
        self._execute(drop_sql)
        self._create_history_table()

    def close(self) -> None:
        if getattr(self, "connection", None):
            try:
                self.connection.close()
            finally:
                self.connection = None

    def __del__(self):
        self.close()
