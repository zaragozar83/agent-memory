"""
Enhanced PGVector implementation that extends the base mem0 PGVector
to support SSL connections, connection strings, and connection pools.
"""

import json
import logging
from contextlib import contextmanager
from typing import Any, List, Optional

from mem0.vector_stores.pgvector import PGVector
from pydantic import BaseModel

# Try to import psycopg (psycopg3) first, then fall back to psycopg2
try:
    from psycopg.types.json import Json
    from psycopg_pool import ConnectionPool

    PSYCOPG_VERSION = 3
    # logger = logging.getLogger(__name__)
    logging.info(
        "Using psycopg (psycopg3) with ConnectionPool for PostgreSQL connections"
    )
except ImportError:
    try:
        from psycopg2.extras import Json, execute_values
        from psycopg2.pool import ThreadedConnectionPool as ConnectionPool

        PSYCOPG_VERSION = 2
        # logger = logging.getLogger(__name__)
        logging.info(
            "Using psycopg2 with ThreadedConnectionPool for PostgreSQL connections"
        )
    except ImportError:
        raise ImportError(
            "Neither 'psycopg' nor 'psycopg2' library is available. "
            "Please install one of them using 'pip install psycopg[pool]' or 'pip install psycopg2'"
        )

# logger = logging.getLogger(__name__)


class LazyEnhancedPGVector:
    """
    Lazy wrapper for EnhancedPGVector that defers database connection until needed.
    This allows the memory system to be initialized without requiring an immediate database connection.
    """

    def __init__(self, config_dict: dict, schema: str):
        """
        Initialize lazy wrapper.

        Args:
            config_dict: PostgreSQL configuration dictionary
            schema: Database schema name
        """
        self.config_dict = config_dict
        self.schema = schema
        self._actual_vector_store = None
        self._initialized = False

        logging.info(f"Created LazyEnhancedPGVector wrapper with schema: {schema}")

    def _ensure_initialized(self):
        """Ensure the actual EnhancedPGVector is created and initialized."""
        if not self._initialized:
            try:
                logging.info(
                    f"Initializing actual EnhancedPGVector with schema: {self.schema}"
                )

                # Ensure we have required parameters with defaults
                config = self.config_dict.copy()

                # Validate critical parameters
                if not config.get("dbname"):
                    raise ValueError("Database name (dbname) is required")
                if not config.get("user"):
                    # Try to provide a sensible default
                    config["user"] = "postgres"
                if not config.get("password"):
                    config["password"] = ""
                if not config.get("host"):
                    config["host"] = "localhost"
                if not config.get("port"):
                    config["port"] = 5432

                logging.info(
                    f"Using config: dbname={config.get('dbname')}, user={config.get('user')}, host={config.get('host')}, port={config.get('port')}"
                )

                # Create schema if it doesn't exist
                self._ensure_schema_exists(config)

                self._actual_vector_store = EnhancedPGVector(
                    dbname=config.get("dbname"),
                    collection_name=config.get("collection_name", "memories"),
                    embedding_model_dims=config.get("embedding_model_dims", 1024),
                    user=config.get("user"),
                    password=config.get("password"),
                    host=config.get("host"),
                    port=config.get("port"),
                    diskann=config.get("diskann", False),
                    hnsw=config.get("hnsw", True),
                    sslmode=config.get("sslmode", None),
                    connection_string=config.get("connection_string", None),
                    connection_pool=config.get("connection_pool", None),
                    schema=self.schema,
                )

                self._initialized = True
                logging.info(
                    f"✅ Successfully initialized EnhancedPGVector with schema: {self.schema}"
                )

            except Exception as e:
                logging.error(f"Failed to initialize EnhancedPGVector: {e}")
                logging.error(f"Config used: {self.config_dict}")
                raise e

    def _ensure_schema_exists(self, config):
        """Ensure the schema exists in PostgreSQL."""
        if not self.schema:
            return

        try:
            import psycopg2

            # Create temporary connection to create schema
            temp_conn = psycopg2.connect(
                host=config.get("host"),
                port=config.get("port"),
                dbname=config.get("dbname"),
                user=config.get("user"),
                password=config.get("password"),
            )
            temp_conn.autocommit = True

            with temp_conn.cursor() as cur:
                # Create schema if it doesn't exist
                cur.execute(f"CREATE SCHEMA IF NOT EXISTS {self.schema}")
                logging.info(f"Ensured schema {self.schema} exists")

                # Create memories table if it doesn't exist
                collection_name = config.get("collection_name", "memories")
                embedding_dims = config.get("embedding_model_dims", 1024)
                cur.execute(
                    f"""
                    CREATE TABLE IF NOT EXISTS {self.schema}.{collection_name} (
                        id UUID PRIMARY KEY,
                        vector vector({embedding_dims}),
                        payload JSONB
                    )
                """
                )
                logging.info(f"Ensured table {self.schema}.{collection_name} exists")

            temp_conn.close()

        except Exception as e:
            logging.warning(f"Could not ensure schema exists: {e}")
            # Don't fail completely - let the vector store handle it

    def __getattr__(self, name):
        """Delegate all attribute access to the actual vector store after ensuring it's initialized."""
        self._ensure_initialized()
        return getattr(self._actual_vector_store, name)

    def __str__(self):
        return f"LazyEnhancedPGVector(schema={self.schema}, initialized={self._initialized})"

    def __repr__(self):
        return self.__str__()


class OutputData(BaseModel):
    id: Optional[str]
    score: Optional[float]
    payload: Optional[dict]


class EnhancedPGVector(PGVector):
    """
    Enhanced PGVector that supports SSL connections, connection strings, and connection pools.
    """

    def __init__(
        self,
        dbname,
        collection_name,
        embedding_model_dims,
        user=None,
        password=None,
        host=None,
        port=None,
        diskann=False,
        hnsw=True,
        minconn=1,
        maxconn=5,
        sslmode=None,
        connection_string=None,
        connection_pool=None,
        schema=None,
    ):
        """
        Initialize the Enhanced PGVector database.

        Args:
            dbname (str): Database name
            collection_name (str): Collection name
            embedding_model_dims (int): Dimension of the embedding vector
            user (str): Database user
            password (str): Database password
            host (str, optional): Database host
            port (int, optional): Database port
            diskann (bool, optional): Use DiskANN for faster search
            hnsw (bool, optional): Use HNSW for faster search
            minconn (int): Minimum number of connections to keep in the connection pool
            maxconn (int): Maximum number of connections allowed in the connection pool
            sslmode (str, optional): SSL mode for PostgreSQL connection (e.g., 'require', 'prefer', 'disable')
            connection_string (str, optional): PostgreSQL connection string (overrides individual connection parameters)
            connection_pool (Any, optional): psycopg connection pool object (overrides connection string and individual parameters)
            schema (str, optional): PostgreSQL schema name
        """
        # Store schema and enhanced parameters before calling parent
        self.schema = schema
        self.minconn = minconn
        self.maxconn = maxconn
        self.original_collection_name = collection_name

        # Ensure we have valid connection parameters
        # The base PGVector class needs these parameters to be properly set
        if not all([dbname, user, password, host, port]):
            raise ValueError(
                f"Missing required connection parameters: dbname={dbname}, user={user}, host={host}, port={port}"
            )

        # For now, don't modify collection name - we'll handle schema differently
        # The schema should be handled in SQL queries, not in table names
        effective_collection_name = collection_name

        logging.info(
            f"Creating EnhancedPGVector with dbname={dbname}, host={host}, port={port}, user={user}, schema={schema}"
        )

        # Call the parent constructor with base parameters (exclude minconn/maxconn which aren't supported)
        super().__init__(
            dbname=dbname,
            collection_name=effective_collection_name,
            embedding_model_dims=embedding_model_dims,
            user=user,
            password=password,
            host=host,
            port=port,
            diskann=diskann,
            hnsw=hnsw,
            sslmode=sslmode,
            connection_string=connection_string,
            connection_pool=connection_pool,
        )
        """
        Initialize the Enhanced PGVector database.

        Args:
            dbname (str): Database name
            collection_name (str): Collection name
            embedding_model_dims (int): Dimension of the embedding vector
            user (str): Database user
            password (str): Database password
            host (str, optional): Database host
            port (int, optional): Database port
            diskann (bool, optional): Use DiskANN for faster search
            hnsw (bool, optional): Use HNSW for faster search
            minconn (int): Minimum number of connections to keep in the connection pool
            maxconn (int): Maximum number of connections allowed in the connection pool
            sslmode (str, optional): SSL mode for PostgreSQL connection (e.g., 'require', 'prefer', 'disable')
            connection_string (str, optional): PostgreSQL connection string (overrides individual connection parameters)
            connection_pool (Any, optional): psycopg connection pool object (overrides connection string and individual parameters)
            schema (str, optional): PostgreSQL schema name
        """
        # Store schema and enhanced parameters before calling parent
        self.schema = schema
        self.minconn = minconn
        self.maxconn = maxconn
        self.original_collection_name = collection_name

        # For now, don't modify collection name - we'll handle schema differently
        # The schema should be handled in SQL queries, not in table names
        effective_collection_name = collection_name

        # Call the parent constructor with base parameters
        super().__init__(
            dbname=dbname,
            collection_name=effective_collection_name,
            embedding_model_dims=embedding_model_dims,
            user=user,
            password=password,
            host=host,
            port=port,
            diskann=diskann,
            hnsw=hnsw,
            sslmode=sslmode,
            connection_string=connection_string,
            connection_pool=connection_pool,
        )

        # Override connection pool if custom parameters were provided
        if minconn != 1 or maxconn != 5:
            self._setup_enhanced_connection_pool(
                user,
                password,
                host,
                port,
                dbname,
                sslmode,
                connection_string,
                connection_pool,
                minconn,
                maxconn,
            )

        # Check and create collection with schema support
        # NOTE: The parent __init__ already does this, but since we override list_cols() and create_col(),
        # they will automatically use our schema-aware versions

    def _get_table_name(self):
        """Get the fully qualified table name with schema if provided."""
        if self.schema:
            return f"{self.schema}.{self.collection_name}"
        else:
            return self.collection_name

    def create_col(self) -> None:
        """
        Create a new collection (table in PostgreSQL) with schema support.
        Will also initialize vector search index if specified.
        """
        table_name = self._get_table_name()
        with self._get_cursor(commit=True) as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    id UUID PRIMARY KEY,
                    vector vector({self.embedding_model_dims}),
                    payload JSONB
                );
                """
            )
            if self.use_diskann and self.embedding_model_dims < 2000:
                cur.execute("SELECT * FROM pg_extension WHERE extname = 'vectorscale'")
                if cur.fetchone():
                    # Create DiskANN index if extension is installed for faster search
                    cur.execute(
                        f"""
                        CREATE INDEX IF NOT EXISTS {self.collection_name}_diskann_idx
                        ON {table_name}
                        USING diskann (vector);
                        """
                    )
            elif self.use_hnsw:
                cur.execute(
                    f"""
                    CREATE INDEX IF NOT EXISTS {self.collection_name}_hnsw_idx
                    ON {table_name}
                    USING hnsw (vector vector_cosine_ops)
                    """
                )

    def insert(self, vectors: list[list[float]], payloads=None, ids=None) -> None:
        """Insert vectors with schema support."""
        logging.info(
            f"Inserting {len(vectors)} vectors into collection {self._get_table_name()}"
        )
        json_payloads = [json.dumps(payload) for payload in payloads]

        data = [
            (id, vector, payload)
            for id, vector, payload in zip(ids, vectors, json_payloads)
        ]
        table_name = self._get_table_name()

        if PSYCOPG_VERSION == 3:
            with self._get_cursor(commit=True) as cur:
                cur.executemany(
                    f"INSERT INTO {table_name} (id, vector, payload) VALUES (%s, %s, %s)",
                    data,
                )
        else:
            with self._get_cursor(commit=True) as cur:
                from psycopg2.extras import execute_values

                execute_values(
                    cur,
                    f"INSERT INTO {table_name} (id, vector, payload) VALUES %s",
                    data,
                )

    def _setup_enhanced_connection_pool(
        self,
        user,
        password,
        host,
        port,
        dbname,
        sslmode,
        connection_string,
        connection_pool,
        minconn,
        maxconn,
    ):
        """Set up enhanced connection pool with custom parameters."""
        if connection_pool is not None:
            self.connection_pool = connection_pool
            return

        if connection_string:
            if sslmode:
                if "sslmode=" in connection_string:
                    import re

                    connection_string = re.sub(
                        r"sslmode=[^ ]*", f"sslmode={sslmode}", connection_string
                    )
                else:
                    connection_string = f"{connection_string} sslmode={sslmode}"
        else:
            connection_string = f"postgresql://{user}:{password}@{host}:{port}/{dbname}"
            if sslmode:
                connection_string = f"{connection_string} sslmode={sslmode}"

        if PSYCOPG_VERSION == 3:
            self.connection_pool = ConnectionPool(
                conninfo=connection_string,
                min_size=minconn,
                max_size=maxconn,
                open=True,
            )
        else:
            self.connection_pool = ConnectionPool(
                minconn=minconn, maxconn=maxconn, dsn=connection_string
            )

    @contextmanager
    def _get_cursor(self, commit: bool = False):
        """
        Unified context manager to get a cursor from the appropriate pool or direct connection.
        Auto-commits or rolls back based on exception, and returns the connection to the pool.
        """
        if self.connection_pool is not None:
            # Use connection pool (our enhanced version or if one was provided)
            if PSYCOPG_VERSION == 3:
                # psycopg3 auto-manages commit/rollback and pool return
                with self.connection_pool.connection() as conn:
                    with conn.cursor() as cur:
                        try:
                            yield cur
                            if commit:
                                conn.commit()
                        except Exception:
                            conn.rollback()
                            logging.error(
                                "Error in cursor context (psycopg3)", exc_info=True
                            )
                            raise
            else:
                # psycopg2 manual getconn/putconn
                conn = self.connection_pool.getconn()
                cur = conn.cursor()
                try:
                    yield cur
                    if commit:
                        conn.commit()
                except Exception as exc:
                    conn.rollback()
                    logging.error(f"Error occurred: {exc}")
                    raise exc
                finally:
                    cur.close()
                    self.connection_pool.putconn(conn)
        else:
            # Use direct connection (fallback to base PGVector behavior)
            try:
                yield self.cur
                if commit:
                    self.conn.commit()
            except Exception as exc:
                self.conn.rollback()
                logging.error(f"Error occurred with direct connection: {exc}")
                raise exc

    def search(
        self,
        query: str,
        vectors: list[float],
        limit: Optional[int] = 5,
        filters: Optional[dict] = None,
    ) -> List[OutputData]:
        """Search vectors with schema support."""
        table_name = self._get_table_name()

        filter_conditions = []
        filter_params = []

        if filters:
            for k, v in filters.items():
                filter_conditions.append("payload->>%s = %s")
                filter_params.extend([k, str(v)])

        filter_clause = (
            "WHERE " + " AND ".join(filter_conditions) if filter_conditions else ""
        )

        sql_query = f"""
            SELECT id, vector <=> %s::vector AS distance, payload
            FROM {table_name}
            {filter_clause}
            ORDER BY distance
            LIMIT %s
        """

        with self._get_cursor() as cur:
            cur.execute(sql_query, (vectors, *filter_params, limit))
            results = cur.fetchall()

        return [
            OutputData(id=str(r[0]), score=float(r[1]), payload=r[2]) for r in results
        ]

    def delete(self, vector_id: str) -> None:
        """Delete a vector by ID with schema support."""
        table_name = self._get_table_name()
        with self._get_cursor(commit=True) as cur:
            cur.execute(f"DELETE FROM {table_name} WHERE id = %s", (vector_id,))

    def update(
        self,
        vector_id: str,
        vector: Optional[list[float]] = None,
        payload: Optional[dict] = None,
    ) -> None:
        """Update a vector with schema support."""
        if not vector and not payload:
            return

        table_name = self._get_table_name()
        updates = []
        params = []

        if vector:
            updates.append("vector = %s")
            params.append(vector)

        if payload:
            updates.append("payload = %s")
            if PSYCOPG_VERSION == 3:
                from psycopg.types.json import Json

                params.append(Json(payload))
            else:
                from psycopg2.extras import Json

                params.append(Json(payload))

        params.append(vector_id)

        with self._get_cursor(commit=True) as cur:
            cur.execute(
                f"UPDATE {table_name} SET {', '.join(updates)} WHERE id = %s", params
            )

    def get(self, vector_id: str) -> OutputData:
        """Get a vector by ID with schema support."""
        table_name = self._get_table_name()
        with self._get_cursor() as cur:
            cur.execute(
                f"SELECT id, vector, payload FROM {table_name} WHERE id = %s",
                (vector_id,),
            )
            result = cur.fetchone()
            if not result:
                return None
            return OutputData(id=str(result[0]), score=None, payload=result[2])

    def delete_col(self) -> None:
        """Delete a collection with schema support."""
        table_name = self._get_table_name()
        with self._get_cursor(commit=True) as cur:
            cur.execute(f"DROP TABLE IF EXISTS {table_name}")

    def col_info(self) -> dict[str, Any]:
        """Get information about a collection with schema support."""
        table_name = self._get_table_name()
        schema_clause = (
            f"table_schema = '{self.schema}'"
            if self.schema
            else "table_schema = 'public'"
        )

        with self._get_cursor() as cur:
            cur.execute(
                f"""
                SELECT
                    table_name,
                    (SELECT COUNT(*) FROM {table_name}) as row_count,
                    (SELECT pg_size_pretty(pg_total_relation_size('{table_name}'))) as total_size
                FROM information_schema.tables
                WHERE {schema_clause} AND table_name = %s
            """,
                (self.collection_name,),
            )
            result = cur.fetchone()
        return {"name": result[0], "count": result[1], "size": result[2]}

    def list_cols(self) -> List[str]:
        """List all collections with schema support."""
        schema_clause = (
            f"table_schema = '{self.schema}'"
            if self.schema
            else "table_schema = 'public'"
        )

        with self._get_cursor() as cur:
            cur.execute(
                f"SELECT table_name FROM information_schema.tables WHERE {schema_clause}"
            )
            return [row[0] for row in cur.fetchall()]

    def list(
        self, filters: Optional[dict] = None, limit: Optional[int] = 100
    ) -> List[List[OutputData]]:
        """
        List all vectors in a collection with schema support.

        Args:
            filters (Dict, optional): Filters to apply to the list.
            limit (int, optional): Number of vectors to return. Defaults to 100.

        Returns:
            List[List[OutputData]]: List of vectors (wrapped in a list for compatibility).
        """
        filter_conditions = []
        filter_params = []

        if filters:
            for k, v in filters.items():
                filter_conditions.append("payload->>%s = %s")
                filter_params.extend([k, str(v)])

        filter_clause = (
            "WHERE " + " AND ".join(filter_conditions) if filter_conditions else ""
        )

        # Use schema-qualified table name instead of just collection_name
        table_name = self._get_table_name()

        query = f"""
            SELECT id, vector, payload
            FROM {table_name}
            {filter_clause}
            LIMIT %s
        """

        with self._get_cursor() as cur:
            cur.execute(query, (*filter_params, limit))
            results = cur.fetchall()

        result_list = [
            OutputData(id=str(r[0]), score=None, payload=r[2]) for r in results
        ]
        return [result_list]
