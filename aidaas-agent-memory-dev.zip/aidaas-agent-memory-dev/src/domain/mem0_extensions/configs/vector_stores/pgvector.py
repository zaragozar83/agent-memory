from typing import Any, Dict, Optional

from mem0.configs.vector_stores.pgvector import PGVectorConfig as BasePGVectorConfig
from pydantic import ConfigDict, Field, model_validator


class EnhancedPGVectorConfig(BasePGVectorConfig):
    """
    Enhanced PGVector Configuration that extends the base PGVectorConfig
    to support SSL connections, connection strings, and connection pools.
    """

    # Allow extra fields to handle schema and other future fields
    model_config = ConfigDict(extra="allow")

    # New SSL and connection options
    sslmode: Optional[str] = Field(
        None,
        description="SSL mode for PostgreSQL connection (e.g., 'require', 'prefer', 'disable')",
    )
    connection_string: Optional[str] = Field(
        None,
        description="PostgreSQL connection string (overrides individual connection parameters)",
    )
    connection_pool: Optional[Any] = Field(
        None,
        description="psycopg connection pool object (overrides connection string and individual parameters)",
    )

    def __init__(self, **kwargs):
        """Custom init to handle schema and other extra fields."""
        # Extract extra fields that aren't part of the base model
        extra_fields = {}
        base_field_names = set(BasePGVectorConfig.model_fields.keys()) | {
            "sslmode",
            "connection_string",
            "connection_pool",
        }

        for key, value in list(kwargs.items()):
            if key not in base_field_names:
                extra_fields[key] = kwargs.pop(key)

        # Initialize base class with known fields
        super().__init__(**kwargs)

        # Add extra fields as attributes
        for key, value in extra_fields.items():
            setattr(self, key, value)

    def model_dump(self, **kwargs) -> Dict[str, Any]:
        """Custom model dump to include extra fields."""
        data = super().model_dump(**kwargs)

        # Add any extra attributes that were set during init
        # But exclude internal pydantic fields
        exclude_attrs = {
            "model_config",
            "model_fields",
            "model_computed_fields",
            "model_extra",
            "model_fields_set",
            "__dict__",
            "__class__",
            "__module__",
            "__annotations__",
            "__doc__",
        }

        for attr_name in dir(self):
            if (
                not attr_name.startswith("_")
                and attr_name not in data
                and attr_name not in exclude_attrs
            ):
                attr_value = getattr(self, attr_name)
                if not callable(attr_value) and not attr_name.startswith("model_"):
                    data[attr_name] = attr_value

        return data

    @model_validator(mode="before")
    def check_auth_and_connection(cls, values):
        # If connection_pool is provided, skip validation of individual connection parameters
        if values.get("connection_pool") is not None:
            return values

        # If connection_string is provided, skip validation of individual connection parameters
        if values.get("connection_string") is not None:
            return values

        # Otherwise, validate individual connection parameters
        user, password = values.get("user"), values.get("password")
        host, port = values.get("host"), values.get("port")
        if not user and not password:
            raise ValueError(
                "Both 'user' and 'password' must be provided when not using connection_string."
            )
        if not host and not port:
            raise ValueError(
                "Both 'host' and 'port' must be provided when not using connection_string."
            )
        return values

    @model_validator(mode="before")
    @classmethod
    def validate_extra_fields(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        allowed_fields = set(cls.model_fields.keys())
        input_fields = set(values.keys())
        extra_fields = input_fields - allowed_fields
        if extra_fields:
            raise ValueError(
                f"Extra fields not allowed: {', '.join(extra_fields)}. Please input only the following fields: {', '.join(allowed_fields)}"
            )
        return values
