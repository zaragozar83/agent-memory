from typing import Any, Dict, Optional, Union

from mem0.configs.base import MemoryConfig as BaseMemoryConfig
from mem0.configs.base import VectorStoreConfig
from mem0.configs.vector_stores.pgvector import PGVectorConfig
from pydantic import ConfigDict, Field, model_validator

from .vector_stores.pgvector import EnhancedPGVectorConfig


class EnhancedVectorStoreConfig(VectorStoreConfig):
    """
    Enhanced Vector Store Configuration that supports enhanced PGVector config.
    """

    model_config = ConfigDict(extra="allow")

    @model_validator(mode="after")
    def validate_and_create_config(self) -> "EnhancedVectorStoreConfig":
        """Override the parent validation to use enhanced configs."""
        provider = self.provider
        config = self.config

        if provider not in self._provider_configs:
            raise ValueError(f"Unsupported vector store provider: {provider}")

        # For pgvector, use our enhanced config class
        if provider == "pgvector":
            config_class = EnhancedPGVectorConfig
        else:
            # For other providers, use the original logic
            module = __import__(
                f"mem0.configs.vector_stores.{provider}",
                fromlist=[self._provider_configs[provider]],
            )
            config_class = getattr(module, self._provider_configs[provider])

        if config is None:
            config = {}

        if not isinstance(config, dict):
            if not isinstance(config, config_class):
                raise ValueError(f"Invalid config type for provider {provider}")
            return self

        # Check if path is needed and missing
        if (
            "path" not in config
            and hasattr(config_class, "__annotations__")
            and "path" in config_class.__annotations__
        ):
            config["path"] = f"/tmp/{provider}"

        self.config = config_class(**config)
        return self


class EnhancedMemoryConfig(BaseMemoryConfig):
    """
    Enhanced Memory Configuration that extends the base MemoryConfig
    to support PostgreSQL history store configuration and enhanced vector stores.
    """

    # Override vector_store to use enhanced config
    vector_store: EnhancedVectorStoreConfig = Field(
        description="Configuration for the vector store",
        default_factory=EnhancedVectorStoreConfig,
    )

    # Optional history store override. Example:
    # {"provider": "postgres", "config": {"host": "localhost", "port": 5432, "dbname": "postgres", "user": "postgres", "password": "postgres"}}
    history_store: Optional[Dict[str, Any]] = Field(
        description="Optional configuration for history store backend (defaults to SQLite)",
        default=None,
    )
