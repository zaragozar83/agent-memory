"""
Enhanced factory implementations that extend mem0's factory classes
to support enhanced configurations and PostgreSQL backends.
"""

from typing import Dict, Optional, Union

from mem0.utils.factory import VectorStoreFactory as BaseVectorStoreFactory
from pydantic import BaseModel

from ..configs.vector_stores.pgvector import EnhancedPGVectorConfig
from ..vector_stores.pgvector import EnhancedPGVector


class EnhancedVectorStoreFactory(BaseVectorStoreFactory):
    """
    Enhanced VectorStoreFactory that supports the enhanced PGVector implementation.
    """

    # Enhanced provider mappings
    provider_to_class = {
        **BaseVectorStoreFactory.provider_to_class,  # Include all base providers
        "pgvector": (
            "mem0_extensions.vector_stores.pgvector.EnhancedPGVector",
            EnhancedPGVectorConfig,
        ),
    }

    @classmethod
    def create(
        cls,
        provider_name: str,
        config: Optional[Union[BaseModel, Dict]] = None,
        **kwargs,
    ):
        """
        Create a vector store instance with enhanced configuration support.

        Args:
            provider_name (str): The provider name (e.g., 'pgvector')
            config: Configuration object or dict
            **kwargs: Additional configuration parameters

        Returns:
            Configured vector store instance
        """
        if provider_name == "pgvector":
            # Use enhanced PGVector implementation
            if config is None:
                config = EnhancedPGVectorConfig(**kwargs)
            elif isinstance(config, dict):
                config.update(kwargs)
                config = EnhancedPGVectorConfig(**config)

            return EnhancedPGVector(
                dbname=config.dbname,
                collection_name=config.collection_name,
                embedding_model_dims=config.embedding_model_dims,
                user=config.user,
                password=config.password,
                host=config.host,
                port=config.port,
                diskann=config.diskann,
                hnsw=config.hnsw,
                minconn=config.minconn,
                maxconn=config.maxconn,
                sslmode=getattr(config, "sslmode", None),
                connection_string=getattr(config, "connection_string", None),
                connection_pool=getattr(config, "connection_pool", None),
                schema=(
                    config.model_dump().get("schema", None)
                    if hasattr(config, "model_dump")
                    else getattr(config, "schema", None)
                ),
            )
        else:
            # Fall back to base factory for other providers
            return super().create(provider_name, config, **kwargs)
