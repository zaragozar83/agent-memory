"""
Enhanced Memory implementation that extends the base mem0 Memory class
to support PostgreSQL history store and enhanced configurations.
"""

import logging
from typing import Any, Dict, List, Optional

from mem0 import Memory
from mem0.configs.base import MemoryConfig
from mem0.memory.storage import SQLiteManager

from .configs.base import EnhancedMemoryConfig
from .memory.storage import PostgresHistoryManager

# logger = logging.getLogger(__name__)


class EnhancedMemory(Memory):
    """
    Enhanced Memory class that extends mem0.Memory to support:
    - PostgreSQL history store backend
    - Enhanced vector store configurations
    - Custom factory implementations
    """

    def __init__(
        self,
        config: Optional[EnhancedMemoryConfig] = None,
        schema: Optional[str] = None,
    ):
        """
        Initialize Enhanced Memory with PostgreSQL history store support.

        Args:
            config: Enhanced memory configuration
            schema: Database schema name for multi-tenant support
        """
        # Use enhanced config if provided, otherwise create default
        if config is None:
            config = EnhancedMemoryConfig()

        # Initialize the base Memory class first (this creates the standard vector store)
        super().__init__(config)

        # Store schema for later use
        self.schema = schema

        # Preserve the original collection name before base class init
        # (base class overwrites it to "mem0migrations" for telemetry)
        original_collection_name = config.vector_store.config.collection_name

        logging.info(f"🔧 EnhancedMemory init - schema: {schema}")
        logging.info(f"🔧 Vector store provider: {config.vector_store.provider}")
        logging.info(f"🔧 Original collection name: {original_collection_name}")

        # Restore the original collection name
        config.vector_store.config.collection_name = original_collection_name

        # Now replace the vector store with our enhanced version if schema is provided
        if schema and config.vector_store.provider == "pgvector":

            try:
                logging.info(
                    f"Replacing vector store with schema-aware EnhancedPGVector: {schema}"
                )
                logging.info(
                    f"Current vector store type: {type(self.vector_store).__name__}"
                )

                # Create our enhanced vector store using the same config as the base one
                enhanced_vector_store = self._create_enhanced_pgvector(
                    config.vector_store.config, schema
                )

                # Replace the vector store
                self.vector_store = enhanced_vector_store

                logging.info(
                    f"Successfully replaced vector store with EnhancedPGVector"
                )
                logging.info(f"Vector store type: {type(self.vector_store).__name__}")
                if hasattr(self.vector_store, "schema"):
                    logging.info(f"Vector store schema: {self.vector_store.schema}")

                # Ensure the enhanced vector store is properly initialized
                if hasattr(self.vector_store, "_ensure_initialized"):
                    logging.info("Initializing enhanced vector store...")
                    self.vector_store._ensure_initialized()

            except Exception as e:
                logging.error(f"Failed to create enhanced vector store: {e}")
                logging.error(
                    "Continuing with standard vector store (no schema isolation)"
                )
                import traceback

                logging.error(f"Traceback: {traceback.format_exc()}")
        else:
            logging.info(
                f"🚫 Skipping vector store replacement - schema: {schema}, provider: {config.vector_store.provider}"
            )

        # Replace history manager with PostgreSQL if configured
        if config.history_store and config.history_store.get("provider") == "postgres":
            self._setup_postgres_history(config.history_store, schema)

    def _create_enhanced_pgvector(self, vector_config, schema: str):
        """
        Create an EnhancedPGVector with schema support.
        This creates the enhanced PGVector directly instead of using a lazy wrapper.

        Args:
            vector_config: PGVector configuration
            schema: Database schema name

        Returns:
            EnhancedPGVector instance
        """
        try:
            # Import the enhanced PGVector directly
            from .vector_stores.pgvector import EnhancedPGVector

            # Convert config to dict if it's a Pydantic model
            if hasattr(vector_config, "model_dump"):
                config_dict = vector_config.model_dump()
            else:
                config_dict = vector_config

            logging.info(f"Creating EnhancedPGVector directly with schema: {schema}")
            logging.info(f"Config: {config_dict}")

            # Create EnhancedPGVector directly with schema
            enhanced_vector_store = EnhancedPGVector(
                dbname=config_dict.get("dbname", "postgres"),
                collection_name=config_dict.get("collection_name", "memories"),
                embedding_model_dims=config_dict.get("embedding_model_dims", 1536),
                user=config_dict.get("user", "postgres"),
                password=config_dict.get("password", ""),
                host=config_dict.get("host", "localhost"),
                port=config_dict.get("port", 5432),
                diskann=config_dict.get("diskann", False),
                hnsw=config_dict.get("hnsw", True),
                sslmode=config_dict.get("sslmode", None),
                connection_string=config_dict.get("connection_string", None),
                connection_pool=config_dict.get("connection_pool", None),
                schema=schema,  # This is the key parameter for schema isolation
            )

            logging.info(f"Successfully created EnhancedPGVector with schema: {schema}")

            return enhanced_vector_store

        except Exception as e:
            logging.error(f"Error creating EnhancedPGVector: {e}")
            import traceback

            logging.error(f"Traceback: {traceback.format_exc()}")
            raise

    def _setup_postgres_history(
        self, history_store_config: Dict[str, Any], schema: Optional[str] = None
    ):
        """
        Set up PostgreSQL history manager.

        Args:
            history_store_config: PostgreSQL configuration
            schema: Database schema name
        """
        try:
            pg_config = history_store_config.get("config", {})

            # Create PostgreSQL history manager
            self.db = PostgresHistoryManager(
                host=pg_config.get("host", "localhost"),
                port=pg_config.get("port", 5432),
                dbname=pg_config.get("dbname", "postgres"),
                user=pg_config.get("user", "postgres"),
                password=pg_config.get("password", "postgres"),
                table=pg_config.get("table", "history"),
                schema=schema or pg_config.get("schema", None),
            )

            logging.info("Enhanced Memory initialized with PostgreSQL history store")

        except Exception as e:
            logging.error(f"Failed to setup PostgreSQL history store: {e}")
            logging.info("Falling back to SQLite history store")
            # Keep the default SQLite manager from base class

    @classmethod
    def from_config(
        cls, config_dict: Dict[str, Any], schema: Optional[str] = None
    ) -> "EnhancedMemory":
        """
        Create Enhanced Memory instance from configuration dictionary.

        Args:
            config_dict: Configuration dictionary
            schema: Database schema name (typically app_id for multi-tenancy)

        Returns:
            Enhanced Memory instance
        """
        logging.info(f"EnhancedMemory.from_config called with schema: {schema}")
        logging.info(f"Config dict keys: {list(config_dict.keys())}")
        if "vector_store" in config_dict:
            logging.info(
                f"Vector store provider: {config_dict['vector_store'].get('provider', 'unknown')}"
            )

        config = EnhancedMemoryConfig(**config_dict)

        # Extract schema from app_id if not provided explicitly
        if schema is None:
            # First try to get from app_id field
            schema = config_dict.get("app_id", None)

            # If still None and pgvector, try to extract from vector store config
            if schema is None and config.vector_store.provider == "pgvector":
                config_dict_extracted = config.vector_store.config.model_dump()
                schema = config_dict_extracted.get("schema", None)

        logging.info(f"Final schema for memory instance: {schema}")

        return cls(config, schema=schema)
