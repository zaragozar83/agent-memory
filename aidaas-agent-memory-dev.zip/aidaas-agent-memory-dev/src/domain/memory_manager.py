"""
Enhanced Memory integration for the agentic-memory project.
Integrates mem0-6 enhanced memory functionality with the new architecture.
"""

import logging
from copy import deepcopy
from typing import Any, Dict, List, Optional

from src.core.ltm_config import AppConfig, build_mem0_config
from src.domain.database import get_postgresql_manager

# Import our enhanced memory extensions
try:
    from src.domain.mem0_extensions.enhanced_memory import EnhancedMemory

    ENHANCED_MEMORY_AVAILABLE = True
    logging.info("Successfully imported EnhancedMemory from mem0_extensions")

except ImportError as e:
    logging.warning(f"Enhanced Memory extensions not available: {e}")
    logging.warning("Falling back to basic Memory implementation")

    # Fallback to basic Memory if enhanced version not available
    raise ImportError("Enhanced Memory extensions not available")


class MemoryManager:
    """
    Memory manager that handles dynamic configuration and schema management.
    """

    def __init__(self):
        self._memory_instances: Dict[str, EnhancedMemory] = {}
        self._db_manager = get_postgresql_manager()

    def get_memory_instance(self, app_config: AppConfig) -> EnhancedMemory:
        """
        Get or create memory instance for a app.

        Args:
            app_config: App configuration

        Returns:
            EnhancedMemory instance configured for the app
        """
        app_id = app_config.app_id

        # Check if we already have an instance for this user
        if app_id in self._memory_instances:
            return self._memory_instances[app_id]

        # Ensure user schema exists
        self._ensure_app_schema(app_config)

        # Build mem0 configuration
        mem0_config = build_mem0_config(app_config)

        # Create memory instance with schema isolation
        try:
            memory_instance = EnhancedMemory.from_config(mem0_config, schema=app_id)
            self._memory_instances[app_id] = memory_instance

            logging.info(f"Created memory instance for app: {app_id}")
            logging.info(f"Enhanced memory available: {ENHANCED_MEMORY_AVAILABLE}")

            return memory_instance

        except Exception as e:
            logging.error(f"Failed to create memory instance for user {app_id}: {e}")
            raise

    def _ensure_app_schema(self, app_config: AppConfig):
        """
        Ensure user schema exists in PostgreSQL.

        Args:
            app_config: User configuration
        """
        app_id = app_config.app_id

        # Map embedder model to dimensions
        embedding_dims = 1024  # Default for bge-m3
        if "bge-large-en-v1-5" in app_config.embedder_model:
            embedding_dims = 1024
        elif "bge-base-en-v1-5" in app_config.embedder_model:
            embedding_dims = 768
        elif "bge-m3" in app_config.embedder_model:
            embedding_dims = 1024
        elif "gte-large" in app_config.embedder_model:
            embedding_dims = 1024
        elif "bge-small-en-v1-5" in app_config.embedder_model:
            embedding_dims = 384

        # Create schema if it doesn't exist
        try:
            created = self._db_manager.create_app_schema(app_id, embedding_dims)
            if created:
                logging.info(f"Created new schema for app: {app_id}")
            else:
                logging.info(f"Schema already exists for app: {app_id}")
        except Exception as e:
            logging.error(f"Failed to ensure schema for app {app_id}: {e}")
            raise

    def remove_memory_instance(self, app_id: str):
        """
        Remove cached memory instance for a user.

        Args:
            app_id: User identifier
        """
        if app_id in self._memory_instances:
            del self._memory_instances[app_id]
            logging.info(f"Removed cached memory instance for user: {app_id}")

    def check_app_exists(self, app_id: str) -> bool:
        """
        Check if user schema exists.

        Args:
            app_id: User identifier

        Returns:
            True if user schema exists
        """
        return self._db_manager.check_schema_exists(app_id)


# Global memory manager instance
_memory_manager = None


def get_memory_manager() -> MemoryManager:
    """Get memory manager instance (singleton)."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
