"""
PostgreSQL database connection and schema management for multi-tenant support.
"""

import logging
from contextlib import contextmanager
from typing import Generator, Optional

try:  # Allows tests without PostgreSQL extras installed
    import psycopg2

    _POSTGRES_AVAILABLE = True
except ImportError:
    psycopg2 = None
    _POSTGRES_AVAILABLE = False

from src.core.ltm_config import SystemConfig


class PostgreSQLManager:
    """PostgreSQL connection manager with schema isolation support."""

    def __init__(self):
        self.config = SystemConfig()

    def get_connection_params(self) -> dict:
        """Get PostgreSQL connection parameters."""
        return {
            "host": self.config.POSTGRES_HOST,
            "port": self.config.POSTGRES_PORT,
            "dbname": self.config.POSTGRES_DB,
            "user": self.config.POSTGRES_USER,
            "password": self.config.POSTGRES_PASSWORD,
        }

    @contextmanager
    def get_connection(self):
        """Get a PostgreSQL connection context manager."""
        if not _POSTGRES_AVAILABLE:
            raise RuntimeError(
                "psycopg2 dependency not installed. Install database extras or set POSTGRES fixtures."
            )
        conn_params = self.get_connection_params()
        conn = None
        try:
            conn = psycopg2.connect(**conn_params)
            yield conn
        except Exception as e:
            logging.error(f"Database connection error: {e}")
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                conn.close()

    def check_schema_exists(self, app_id: str) -> bool:
        """
        Check if schema exists for a user.

        Args:
            app_id: App identifier (schema name)

        Returns:
            True if schema exists, False otherwise
        """
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT schema_name FROM information_schema.schemata WHERE schema_name = %s",
                    (app_id,),
                )
                return cur.fetchone() is not None

    def create_app_schema(self, app_id: str, embedding_dims: int = 1024) -> bool:
        """
        Create schema and tables for a new user.

        Args:
            app_id: User identifier (schema name)
            embedding_dims: Vector embedding dimensions

        Returns:
            True if schema was created, False if it already existed
        """
        if self.check_schema_exists(app_id):
            logging.info(f"Schema {app_id} already exists")
            return False

        try:
            with self.get_connection() as conn:
                conn.autocommit = True
                with conn.cursor() as cur:
                    # Create schema
                    logging.info(f"Creating schema: {app_id}")
                    cur.execute(f"CREATE SCHEMA {app_id}")

                    # Create memories table (for pgvector)
                    logging.info(f"Creating memories table in schema: {app_id}")
                    cur.execute(
                        f"""
                        CREATE TABLE {app_id}.memories (
                            id UUID PRIMARY KEY,
                            vector vector({embedding_dims}),
                            payload JSONB
                        )
                    """
                    )

                    # Create history table
                    logging.info(f"Creating history table in schema: {app_id}")
                    cur.execute(
                        f"""
                        CREATE TABLE {app_id}.history (
                            id TEXT PRIMARY KEY,
                            memory_id TEXT,
                            old_memory TEXT,
                            new_memory TEXT,
                            event TEXT,
                            created_at TIMESTAMPTZ,
                            updated_at TIMESTAMPTZ,
                            is_deleted BOOLEAN,
                            actor_id TEXT,
                            role TEXT
                        )
                    """
                    )

                    logging.info(
                        f"Successfully created schema and tables for user: {app_id}"
                    )

            return True

        except Exception as e:
            logging.error(f"Failed to create schema for user {app_id}: {e}")
            raise

    def delete_app_schema(self, app_id: str) -> bool:
        """
        Delete schema and all tables for a user.

        Args:
            app_id: User identifier (schema name)

        Returns:
            True if schema was deleted, False if it didn't exist
        """
        if not self.check_schema_exists(app_id):
            logging.info(f"Schema {app_id} does not exist")
            return False

        try:
            with self.get_connection() as conn:
                conn.autocommit = True
                with conn.cursor() as cur:
                    logging.info(f"Dropping schema: {app_id}")
                    cur.execute(f"DROP SCHEMA {app_id} CASCADE")
                    logging.info(f"Successfully deleted schema for user: {app_id}")

            return True

        except Exception as e:
            logging.error(f"Failed to delete schema for user {app_id}: {e}")
            raise


# Global PostgreSQL manager instance
_postgresql_manager = None


def get_postgresql_manager() -> PostgreSQLManager:
    """Get PostgreSQL manager instance (singleton)."""
    global _postgresql_manager
    if _postgresql_manager is None:
        _postgresql_manager = PostgreSQLManager()
    return _postgresql_manager
