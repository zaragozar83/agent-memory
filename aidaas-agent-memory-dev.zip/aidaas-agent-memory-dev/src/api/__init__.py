from src.api.v1.controller import routers as v1_routers

routers = {"v1": v1_routers}
