import logging

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse

from src.api.v1.response.common import RestResponse
from src.application.exception import RuntimeException


def log_request(request: Request, status_code: int, message: str):
    """Log the request details"""
    logging.error(
        f"Request: {request.method} {request.url} - Status: {status_code} - Error: {message}"
    )


def set_exception_handlers(app: FastAPI):
    @app.exception_handler(Exception)
    def exception_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=RestResponse(
                message=f"Internal Server Error - {str(exc)}", success=False
            ).model_dump(),
        )
        log_request(request, status.HTTP_500_INTERNAL_SERVER_ERROR, str(exc))
        return json_response

    @app.exception_handler(RuntimeException)
    def runtime_exception_handler(request: Request, exc: RuntimeException):
        json_response = JSONResponse(
            status_code=exc.status_code,
            headers={"Error-Message": exc.message},
            content=RestResponse(message=exc.message, success=False).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_405_METHOD_NOT_ALLOWED)
    def custom_405_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
            content=RestResponse(
                message=f"Method Not Allowed",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_404_NOT_FOUND)
    def custom_404_handler(request: Request, exc: HTTPException):
        json_response = JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content=RestResponse(
                message=getattr(exc, "detail", "") or "Not Found",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_403_FORBIDDEN)
    def custom_403_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content=RestResponse(
                message=f"Not authenticated",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_401_UNAUTHORIZED)
    def custom_401_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content=RestResponse(
                message=f"Not Authorized",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_400_BAD_REQUEST)
    def custom_400_handler(request: Request, exc: Exception):
        detail = getattr(exc, "detail", "")
        json_response = JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=RestResponse(
                message=(detail if detail != "" else f"Bad Request - Invalid Input"),
                success=False,
            ).model_dump(),
        )
        return json_response
