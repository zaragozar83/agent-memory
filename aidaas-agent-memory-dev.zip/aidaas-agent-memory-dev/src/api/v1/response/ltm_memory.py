"""
Long-term memory response models.
"""

from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


class MemoryItem(BaseModel):
    """Individual memory item."""

    id: str = Field(..., description="Memory identifier")
    content: str = Field(..., description="Memory content")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Memory metadata"
    )
    score: Optional[float] = Field(default=None, description="Relevance score")


class CreateMemoryResponse(BaseModel):
    """Response model for memory creation."""

    results: List[Dict[str, Any]] = Field(..., description="Created memory results")

    # For compatibility with mem0 format
    class Config:
        extra = "allow"


class GetMemoriesResponse(BaseModel):
    """Response model for getting memories."""

    results: List[MemoryItem] = Field(..., description="List of memories")

    class Config:
        extra = "allow"


class SearchMemoriesResponse(BaseModel):
    """Response model for memory search."""

    results: List[MemoryItem] = Field(..., description="Search results")

    class Config:
        extra = "allow"


class GetMemoryResponse(BaseModel):
    """Response model for getting a specific memory."""

    result: Optional[MemoryItem] = Field(default=None, description="Memory item")

    class Config:
        extra = "allow"


class UpdateMemoryResponse(BaseModel):
    """Response model for memory update."""

    result: str = Field(..., description="Update status message")

    class Config:
        extra = "allow"


class DeleteMemoryResponse(BaseModel):
    """Response model for memory deletion."""

    result: str = Field(..., description="Deletion status message")

    class Config:
        extra = "allow"


class MemoryHistoryResponse(BaseModel):
    """Response model for memory history."""

    history: List[Dict[str, Any]] = Field(..., description="Memory history")

    class Config:
        extra = "allow"


class ConfigureResponse(BaseModel):
    """Response model for configuration."""

    app_id: str = Field(..., description="Configured App ID")
    schema_created: bool = Field(..., description="Whether schema was newly created")


class ResetMemoryResponse(BaseModel):
    """Response model for memory reset."""

    result: str = Field(..., description="Reset status message")


class ErrorResponse(BaseModel):
    """Error response model."""

    detail: str = Field(..., description="Error message")
    error_type: Optional[str] = Field(default=None, description="Error type")

    class Config:
        extra = "allow"
