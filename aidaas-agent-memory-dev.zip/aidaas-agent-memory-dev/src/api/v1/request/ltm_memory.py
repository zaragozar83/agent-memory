"""
Long-term memory request models based on mem0-6 API structure.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Message(BaseModel):
    """Message model for conversation history."""

    role: str = Field(..., description="Role of the message (user or assistant)")
    content: str = Field(..., description="Message content")


class MemoryCreateRequest(BaseModel):
    """Request model for creating memories."""

    messages: List[Message] = Field(..., description="List of messages to store")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )


class SearchRequest(BaseModel):
    """Request model for searching memories."""

    query: str = Field(..., description="Search query")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    filters: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional search filters"
    )


class UpdateMemoryRequest(BaseModel):
    """Request model for updating a memory."""

    updated_memory: str = Field(..., description="Updated memory content")


class ConfigureRequest(BaseModel):
    """Request model for configuring memory settings."""

    app_id: str = Field(..., description="Unique application identifier")
    api_key: str = Field(..., description="OpenAI API key")
    llm_model: str = Field(default="gpt-4o", description="LLM model to use")
    embedder_model: str = Field(
        default="text-embedding-3-small", description="Embedding model to use"
    )


class GetMemoriesRequest(BaseModel):
    """Request model for getting memories."""

    app_id: Optional[str] = Field(
        default=None, description="Application identifier (optional if in config)"
    )
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")


class DeleteMemoriesRequest(BaseModel):
    """Request model for deleting all memories."""

    app_id: Optional[str] = Field(
        default=None, description="Application identifier (optional if in config)"
    )
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
