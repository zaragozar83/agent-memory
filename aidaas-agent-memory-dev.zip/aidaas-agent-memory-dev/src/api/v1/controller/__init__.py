from src.api.v1.controller.health import router as health_router
from src.api.v1.controller.ltm_memory import router as ltm_memory_router
from src.api.v1.controller.session import router as session_router
from src.api.v1.controller.stm_memory import router as stm_memory_router

routers = [session_router, stm_memory_router, ltm_memory_router, health_router]

__all__ = [
    "routers",
    "session_router",
    "stm_memory_router",
    "ltm_memory_router",
    "health_router",
]
