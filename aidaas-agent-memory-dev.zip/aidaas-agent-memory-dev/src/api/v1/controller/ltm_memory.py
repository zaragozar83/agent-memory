"""
Long-term memory FastAPI controller based on mem0-6 API structure.
"""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

from src.api.v1.request.ltm_memory import (
    ConfigureRequest,
    MemoryCreateRequest,
    SearchRequest,
    UpdateMemoryRequest,
)
from src.api.v1.response.common import RestResponse
from src.api.v1.response.ltm_memory import (
    ConfigureResponse,
    CreateMemoryResponse,
    GetMemoriesResponse,
    GetMemoryResponse,
    SearchMemoriesResponse,
    UpdateMemoryResponse,
)
from src.application.exception import RuntimeException
from src.application.service.ltm_memory_service import get_ltm_service
from src.core.ltm_config import AppConfig

router = APIRouter(
    prefix="/ltm",
    tags=["Long-Term Memory"],
)


@router.post(
    "/configure",
    response_model=RestResponse[ConfigureResponse],
    summary="Configure Memory",
)
def configure_memory(request: ConfigureRequest):
    """
    Configure memory for a Application.
    Creates application schema and tables if they don't exist.
    """
    try:
        ltm_service = get_ltm_service()

        # Convert request to AppConfig
        app_config = AppConfig(
            app_id=request.app_id,
            api_key=request.api_key,
            llm_model=request.llm_model,
            embedder_model=request.embedder_model,
        )

        result = ltm_service.configure(app_config)

        config_response = ConfigureResponse(
            app_id=result["app_id"],
            schema_created=result["schema_created"],
        )

        return RestResponse(
            data=config_response,
            message=result.get("message"),
            success=True,
            errors=None,
        )

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in configure memory:")
        raise RuntimeException(
            message="Error occurred in configure memory", status_code=500, detail=str(e)
        )


@router.post(
    "/memories",
    response_model=RestResponse[CreateMemoryResponse],
    summary="Create memories",
)
def create_memories(request: MemoryCreateRequest):
    """Store new memories from conversation messages."""
    try:
        ltm_service = get_ltm_service()

        # Convert messages to dict format
        messages = [message.model_dump() for message in request.messages]

        # Check if at least one identifier is provided
        if not any([request.user_id, request.agent_id, request.run_id]):
            raise RuntimeException(
                status_code=400,
                detail="At least one identifier (user_id, agent_id, run_id) is required.",
            )

        result = ltm_service.add_memory(
            messages=messages,
            user_id=request.user_id,
            agent_id=request.agent_id,
            run_id=request.run_id,
            metadata=request.metadata,
        )
        create_memory_response = CreateMemoryResponse(
            results=(
                result.get("results").get("results") if result.get("results") else []
            ),
        )

        if create_memory_response.results:
            return RestResponse(
                data=create_memory_response, message="Memories created successfully"
            )
        else:
            return RestResponse(
                data=create_memory_response,
                message="No memories created! Similar Memory might already exist.",
            )

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in create memories:")
        raise RuntimeException(
            status_code=500,
            detail=str(e),
            message="Error occurred while creating memories.",
        )


@router.get(
    "/memories",
    response_model=RestResponse[GetMemoriesResponse],
    summary="Get memories",
)
def get_memories(
    user_id: Optional[str] = Query(None, description="User identifier"),
    run_id: Optional[str] = Query(None, description="Run identifier"),
    agent_id: Optional[str] = Query(None, description="Agent identifier"),
):
    """Retrieve stored memories."""
    try:
        ltm_service = get_ltm_service()

        # Check if at least one identifier is provided
        if not any([user_id, run_id, agent_id]):
            raise RuntimeException(
                status_code=400,
                detail="At least one identifier (user_id, agent_id, run_id) is required.",
            )

        result = ltm_service.get_all_memories(
            user_id=user_id, run_id=run_id, agent_id=agent_id
        )

        get_memories_response = GetMemoriesResponse(
            results=result.get("results") if result.get("results") else [],
        )

        if not get_memories_response.results:
            raise RuntimeException(
                message="No memories found", status_code=404, detail="No memories found"
            )

        return RestResponse(
            data=get_memories_response, message="Memories retrieved successfully"
        )

    except RuntimeException:
        raise

    except Exception as e:
        logging.exception("Error in get memories:")
        raise RuntimeException(
            message="Error occurred while retrieving memories",
            status_code=500,
            detail=str(e),
        )


@router.get(
    "/memories/{memory_id}",
    response_model=RestResponse[GetMemoryResponse],
    summary="Get a memory",
)
def get_memory(memory_id: str):
    """Retrieve a specific memory by ID."""
    try:
        ltm_service = get_ltm_service()
        result = ltm_service.get_memory(memory_id)

        get_memory_response = GetMemoryResponse(
            result=result.get("result") if result.get("result") else None
        )

        if not get_memory_response.result:
            raise RuntimeException(
                message="Memory not found", status_code=404, detail="Memory not found"
            )
        return RestResponse(
            data=get_memory_response, message="Memory retrieved successfully"
        )

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in get memory:")
        raise RuntimeException(
            message="Error occurred while retrieving memory",
            status_code=500,
            detail=str(e),
        )


@router.post(
    "/search",
    response_model=RestResponse[SearchMemoriesResponse],
    summary="Search memories",
)
def search_memories(request: SearchRequest):
    """Search for memories based on a query."""
    try:
        ltm_service = get_ltm_service()

        result = ltm_service.search_memories(
            query=request.query,
            user_id=request.user_id,
            run_id=request.run_id,
            agent_id=request.agent_id,
            filters=request.filters,
        )

        search_response = SearchMemoriesResponse(
            results=result.get("results") if result.get("results") else [],
        )

        if not search_response.results:
            raise RuntimeException(
                message="No memories found", status_code=404, detail="No memories found"
            )

        return RestResponse(
            data=search_response, message="Memories retrieved successfully"
        )

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in searching memories:")
        raise RuntimeException(
            message="Error in search memories", status_code=500, detail=str(e)
        )


@router.put(
    "/memories/{memory_id}", response_model=RestResponse, summary="Update a memory"
)
def update_memory(memory_id: str, request: UpdateMemoryRequest):
    """Update an existing memory with new content."""
    try:
        ltm_service = get_ltm_service()

        result = ltm_service.update_memory(
            memory_id=memory_id, data=request.updated_memory
        )

        update_memory_response = UpdateMemoryResponse(
            result=result.get("result") if result.get("result") else None
        )

        if not update_memory_response.result:
            raise RuntimeException(
                message="Memory not found", status_code=404, detail="Memory not found"
            )

        return RestResponse(data=None, message="Memory updated successfully")

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in Update memories:")
        raise RuntimeException(
            message="Error in updating memories", status_code=500, detail=str(e)
        )


@router.delete(
    "/memories/{memory_id}", response_model=RestResponse, summary="Delete a memory"
)
def delete_memory(memory_id: str):
    """Delete a specific memory by ID."""
    try:
        ltm_service = get_ltm_service()

        result = ltm_service.delete_memory(memory_id)
        return RestResponse(data=None, message=result.get("result"))

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in delete memory:")
        raise RuntimeException(
            status_code=500,
            detail=str(e),
            message="Error occurred while deleting memory. Memory may not be found.",
        )


@router.post("/reset", response_model=RestResponse, summary="Reset all memories")
def reset_memories():
    """Completely reset stored memories."""
    try:
        ltm_service = get_ltm_service()
        result = ltm_service.reset_memory()

        return RestResponse(data=None, message=result.get("result"))

    except RuntimeException as e:
        raise

    except Exception as e:
        logging.exception("Error in reset memories:")
        raise RuntimeException(
            message="Error in reset memories", status_code=500, detail=str(e)
        )
