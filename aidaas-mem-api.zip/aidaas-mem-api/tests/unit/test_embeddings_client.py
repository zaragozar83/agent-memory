import pytest

from src.application.clients.embeddings import LocalEmbeddingClient, build_embedding_client
from src.core import config


@pytest.mark.asyncio
async def test_build_embedding_client_local_environment(monkeypatch):
    config.get_settings.cache_clear()
    monkeypatch.setenv("ENVIRONMENT", "LOCAL")
    monkeypatch.delenv("EMBEDDING_BASE_URL", raising=False)
    monkeypatch.delenv("EMBEDDING_API_KEY", raising=False)
    monkeypatch.delenv("EMBEDDING_MODEL", raising=False)

    try:
        client = build_embedding_client()
        assert isinstance(client, LocalEmbeddingClient)
        vector = await client.embed("local embedding example")
        settings = config.get_settings()
        assert len(vector) == settings.embedding_dimension
        assert any(value != 0.0 for value in vector)
    finally:
        config.get_settings.cache_clear()


@pytest.mark.asyncio
async def test_local_embedding_client_empty_text_returns_zero_vector():
    client = LocalEmbeddingClient(dimension=12)
    vector = await client.embed("")
    assert vector == [0.0] * 12


def test_build_embedding_client_missing_config(monkeypatch):
    config.get_settings.cache_clear()
    monkeypatch.setenv("ENVIRONMENT", "PROD")
    monkeypatch.setenv("EMBEDDING_BASE_URL", "")
    monkeypatch.setenv("EMBEDDING_API_KEY", "")
    monkeypatch.setenv("EMBEDDING_MODEL", "")

    try:
        client = build_embedding_client()
        from src.application.clients.embeddings import NullEmbeddingClient

        assert isinstance(client, NullEmbeddingClient)
    finally:
        config.get_settings.cache_clear()


@pytest.mark.asyncio
async def test_http_embedding_client_happy_path(monkeypatch):
    responses = []

    class FakeResponse:
        def __init__(self, json_data):
            self._json = json_data

        def raise_for_status(self):
            return None

        def json(self):
            return self._json

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def post(self, url, json, headers):
            responses.append({"url": url, "json": json, "headers": headers})
            return FakeResponse({"data": [{"embedding": [0.1, 0.2, 0.3]}]})

    monkeypatch.setenv("EMBEDDING_BASE_URL", "http://embedding.local")
    monkeypatch.setenv("EMBEDDING_API_KEY", "token")
    monkeypatch.setenv("EMBEDDING_MODEL", "test-model")
    monkeypatch.setenv("ENVIRONMENT", "PROD")
    config.get_settings.cache_clear()
    monkeypatch.setattr("src.application.clients.embeddings.httpx.AsyncClient", FakeClient)

    try:
        client = build_embedding_client()
        vector = await client.embed("hello")  # type: ignore[call-arg]
        assert vector == [0.1, 0.2, 0.3]
        assert responses and responses[0]["url"].endswith("/v1/embeddings")
    finally:
        config.get_settings.cache_clear()
