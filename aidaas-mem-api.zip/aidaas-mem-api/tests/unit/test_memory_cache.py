from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone

import pytest

from src.domain.entities.memory import MemoryEntity
from src.domain.redis.memory_cache import MemoryCache


class FakeRedis:
    """Minimal async Redis stub covering the commands MemoryCache uses."""

    def __init__(self) -> None:
        self.sorted_sets: dict[str, dict[str, float]] = defaultdict(dict)
        self.hashes: dict[str, dict[str, str]] = defaultdict(dict)

    async def zadd(self, key: str, mapping: dict[str, float]) -> int:
        self.sorted_sets[key].update(mapping)
        return len(mapping)

    async def hset(self, key: str, mapping: dict[str, str]) -> int:
        self.hashes[key].update(mapping)
        return len(mapping)

    async def expire(self, key: str, ttl: int) -> bool:  # pragma: no cover - included for interface parity
        return True

    async def zrevrange(self, key: str, start: int, end: int) -> list[bytes]:
        items = sorted(self.sorted_sets.get(key, {}).items(), key=lambda pair: pair[1], reverse=True)
        slice_end = end + 1 if end != -1 else None
        return [member.encode("utf-8") for member, _ in items[start:slice_end]]

    async def hmget(self, key: str, *fields: str) -> list[str | None]:
        return [self.hashes.get(key, {}).get(field) for field in fields]

    async def zrange(self, key: str, start: int, end: int) -> list[bytes]:
        items = sorted(self.sorted_sets.get(key, {}).items(), key=lambda pair: pair[1])
        slice_end = end + 1 if end != -1 else None
        return [member.encode("utf-8") for member, _ in items[start:slice_end]]

    async def zrem(self, key: str, *members: str) -> int:
        removed = 0
        for member in members:
            removed += 1 if self.sorted_sets.get(key, {}).pop(member, None) is not None else 0
        return removed

    async def hdel(self, key: str, *fields: str) -> int:
        removed = 0
        for field in fields:
            removed += 1 if self.hashes.get(key, {}).pop(field, None) is not None else 0
        return removed


def _memory(content: str, created_at: datetime) -> MemoryEntity:
    return MemoryEntity(
        agent_id="agent-1",
        user_id="user-1",
        session_id="session-1",
        content=content,
        created_at=created_at,
        updated_at=created_at,
    )


@pytest.mark.asyncio
async def test_add_and_get_recent_memories():
    redis = FakeRedis()
    cache = MemoryCache(redis, timeout_seconds=1)
    now = datetime.now(tz=timezone.utc)

    await cache.add_memory(_memory("first", now - timedelta(seconds=1)))
    await cache.add_memory(_memory("second", now))

    recent = await cache.get_recent_memories("agent-1", "user-1", session_id="session-1")

    assert [memory.content for memory in recent] == ["second", "first"]


@pytest.mark.asyncio
async def test_add_memory_trims_to_limit():
    redis = FakeRedis()
    cache = MemoryCache(redis, timeout_seconds=1)
    now = datetime.now(tz=timezone.utc)

    for index in range(3):
        await cache.add_memory(_memory(f"item-{index}", now + timedelta(seconds=index)), limit=2)

    recent = await cache.get_recent_memories("agent-1", "user-1", session_id="session-1")
    assert [memory.content for memory in recent] == ["item-2", "item-1"]
    data_key = MemoryCache._data_key("agent-1", "user-1", "session-1")
    assert "item-0" not in redis.hashes[data_key]


@pytest.mark.asyncio
async def test_remove_memory_purges_sorted_set_and_hash():
    redis = FakeRedis()
    cache = MemoryCache(redis, timeout_seconds=1)
    now = datetime.now(tz=timezone.utc)
    memory = _memory("removable", now)
    await cache.add_memory(memory)

    await cache.remove_memory(memory)

    recent = await cache.get_recent_memories("agent-1", "user-1", session_id="session-1")
    assert recent == []
    assert not redis.sorted_sets[MemoryCache._key("agent-1", "user-1", "session-1")]
    assert not redis.hashes[MemoryCache._data_key("agent-1", "user-1", "session-1")]
