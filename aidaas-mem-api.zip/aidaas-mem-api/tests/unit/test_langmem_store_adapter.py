from __future__ import annotations

import pytest
from langgraph.store.base import GetOp, ListNamespacesOp, MatchCondition, PutOp, SearchOp
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.application.clients.langmem_store import PgVectorLangGraphStore, _apply_namespace_filters
from src.domain.postgres.base import Base
from tests.fakes import FakeEmbeddingClient


@pytest.fixture
async def store() -> tuple[PgVectorLangGraphStore, AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    store = PgVectorLangGraphStore(
        session_factory,
        FakeEmbeddingClient(vector_map={"hello": [1.0, 0.0], "query": [0.5, 0.5]}),
    )
    async with session_factory() as session:
        yield store, session

    await engine.dispose()


@pytest.mark.asyncio
async def test_abatch_handles_put_get_search_and_list(store: tuple[PgVectorLangGraphStore, AsyncSession]):
    store, _session = store
    ops = [
        PutOp(namespace=("tenant", "agent"), key="mem-1", value={"kind": "Memory", "content": "hello"}),
        GetOp(namespace=("tenant", "agent"), key="mem-1"),
        SearchOp(namespace_prefix=("tenant",), query="query", limit=5),
        ListNamespacesOp(),
    ]

    results = await store.abatch(ops)

    assert results[0] is None  # PutOp returns None
    retrieved = results[1]
    assert retrieved.value["content"] == "hello"
    search_results = results[2]
    assert search_results and search_results[0].key == "mem-1"
    namespaces = results[3]
    assert ("tenant", "agent") in namespaces


def test_apply_namespace_filters_supports_match_conditions_and_depth():
    namespaces = [
        ("tenant", "alpha", "x"),
        ("tenant", "alpha", "y"),
        ("tenant", "beta"),
        ("other", "alpha"),
    ]
    op = ListNamespacesOp(
        match_conditions=(MatchCondition(match_type="prefix", path=("tenant", "alpha")),),
        max_depth=2,
        limit=10,
        offset=0,
    )

    filtered = _apply_namespace_filters(namespaces, op)

    assert filtered == [("tenant", "alpha"), ("tenant", "alpha")]
