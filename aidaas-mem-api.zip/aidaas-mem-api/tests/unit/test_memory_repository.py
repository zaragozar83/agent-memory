from __future__ import annotations

from datetime import datetime, timedelta, timezone
import sqlite3

import pytest
from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.domain.entities.memory import DEFAULT_SESSION_ID, MemoryEntity
from src.domain.postgres.base import Base
from src.domain.postgres.models import MemoryModel
from src.domain.postgres.repository import MemoryRepository


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        yield session

    await engine.dispose()


def _memory(
    *,
    agent_id: str = "agent-1",
    user_id: str = "user-1",
    session_id: str | None = DEFAULT_SESSION_ID,
    kind: str = "memory",
    content: str = "content",
    metadata: dict | None = None,
) -> MemoryEntity:
    return MemoryEntity(
        agent_id=agent_id,
        user_id=user_id,
        session_id=session_id,
        kind=kind,
        content=content,
        metadata=metadata or {},
    )


@pytest.mark.asyncio
async def test_create_and_get_round_trip(session: AsyncSession):
    repo = MemoryRepository(session)
    created = await repo.create(_memory(metadata={"topic": "greeting"}))

    fetched = await repo.get(created.id)

    assert fetched is not None
    assert fetched.session_id == DEFAULT_SESSION_ID
    assert fetched.metadata.get("topic") == "greeting"


@pytest.mark.asyncio
async def test_update_changes_content_and_kind(session: AsyncSession):
    if sqlite3.sqlite_version_info < (3, 35, 0):
        pytest.skip("SQLite version lacks RETURNING support needed by update()")
    repo = MemoryRepository(session)
    created = await repo.create(_memory(content="original"))
    created.content = "updated"
    created.kind = "note"

    updated = await repo.update(created)

    assert updated is not None
    assert updated.content == "updated"
    assert updated.kind == "note"


@pytest.mark.asyncio
async def test_search_by_metadata_supports_exact_and_contains(session: AsyncSession):
    repo = MemoryRepository(session)
    await repo.create(_memory(content="dell poweredge", metadata={"topic": "Dell Server"}))
    await repo.create(_memory(content="laptop", metadata={"topic": "Laptop"}))

    exact = await repo.search_by_metadata(agent_id="agent-1", metadata={"topic": "Laptop"}, limit=5, user_id="user-1")
    contains = await repo.search_by_metadata(
        agent_id="agent-1", metadata={"topic": "dell"}, limit=5, user_id="user-1", match_mode="contains"
    )

    assert [item.content for item in exact] == ["laptop"]
    assert [item.content for item in contains] == ["dell poweredge"]


@pytest.mark.asyncio
async def test_list_recent_orders_by_created_at(session: AsyncSession):
    repo = MemoryRepository(session)
    older = await repo.create(_memory(content="older"))
    newer = await repo.create(_memory(content="newer"))

    base_time = datetime.now(tz=timezone.utc)
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == older.id).values(created_at=base_time - timedelta(minutes=5))
    )
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == newer.id).values(created_at=base_time + timedelta(minutes=5))
    )
    await session.commit()

    recent = await repo.list_recent("agent-1", "user-1", limit=2, session_id=DEFAULT_SESSION_ID)

    assert [item.content for item in recent] == ["newer", "older"]


@pytest.mark.asyncio
async def test_list_window_filters_by_range(session: AsyncSession):
    repo = MemoryRepository(session)
    before = await repo.create(_memory(content="before"))
    inside = await repo.create(_memory(content="inside"))
    after = await repo.create(_memory(content="after"))

    base_time = datetime.now(tz=timezone.utc)
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == before.id).values(created_at=base_time - timedelta(minutes=10))
    )
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == inside.id).values(created_at=base_time + timedelta(minutes=1))
    )
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == after.id).values(created_at=base_time + timedelta(minutes=10))
    )
    await session.commit()

    results = await repo.list_window(
        agent_id="agent-1",
        user_id="user-1",
        session_id=DEFAULT_SESSION_ID,
        start=base_time,
        end=base_time + timedelta(minutes=5),
    )

    assert [item.content for item in results] == ["inside"]


@pytest.mark.asyncio
async def test_get_memories_to_cleanup_returns_expired(session: AsyncSession):
    repo = MemoryRepository(session)
    expired = await repo.create(_memory(content="expired"))
    future = await repo.create(_memory(content="future"))

    now = datetime.now()
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == expired.id).values(valid_until=now - timedelta(days=1), summary_id="s1")
    )
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == future.id).values(valid_until=now + timedelta(days=1), summary_id="s2")
    )
    await session.commit()

    candidates = await repo.get_memories_to_cleanup()

    assert [item.content for item in candidates] == ["expired"]


@pytest.mark.asyncio
async def test_get_last_summary_returns_latest_summary(session: AsyncSession):
    repo = MemoryRepository(session)
    first = await repo.create(_memory(content="old summary", kind="summary", metadata={"kind": "summary"}))
    second = await repo.create(_memory(content="new summary", kind="summary", metadata={"kind": "summary"}))

    base_time = datetime.now(tz=timezone.utc)
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == first.id).values(created_at=base_time - timedelta(minutes=5))
    )
    await session.execute(
        update(MemoryModel).where(MemoryModel.id == second.id).values(created_at=base_time + timedelta(minutes=5))
    )
    await session.commit()

    result = await repo.get_last_summary("agent-1", "user-1", session_id=DEFAULT_SESSION_ID)

    assert result is not None
    assert result.content == "new summary"
