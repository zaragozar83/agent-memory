from dataclasses import dataclass, field

import pytest
from langgraph.store.base import SearchItem

from src.application.clients.langmem import LangMemStoreClient, build_langmem_client
from src.core.config import get_settings
from src.domain.entities.memory import MemoryEntity


def test_sanitize_label_drops_domain_and_converts_dots():
    assert LangMemStoreClient._sanitize_label("user.name@example.com") == "user_name"


def test_sanitize_label_falls_back_to_default_when_empty():
    assert LangMemStoreClient._sanitize_label("@@@") == "default"


@dataclass
class StubStore:
    calls: list[tuple[tuple[str, ...], str, dict]] = field(default_factory=list)

    async def aput(self, namespace: tuple[str, ...], key: str, value: dict) -> None:
        self.calls.append((namespace, key, value))

    async def adelete(self, namespace: tuple[str, ...], key: str) -> None:  # pragma: no cover - not used
        raise NotImplementedError

    async def asearch(self, *args, **kwargs):  # pragma: no cover - not used
        raise NotImplementedError


class StubSearchStore:
    def __init__(self):
        self.deletes: list[tuple[tuple[str, ...], str]] = []

    async def aput(self, *args, **kwargs):  # pragma: no cover - not used
        return None

    async def adelete(self, namespace: tuple[str, ...], key: str) -> None:
        self.deletes.append((namespace, key))

    async def asearch(self, namespace_prefix: tuple[str, ...], query: str, limit: int):
        # Mix valid and invalid entries plus a different session to ensure filtering
        return [
            SearchItem(namespace=(*namespace_prefix, "default"), key="match-1", value={"content": {"memory_id": "m1", "session_id": "default"}}, score=0.9, created_at=None, updated_at=None),  # type: ignore[arg-type]
            SearchItem(namespace=(*namespace_prefix, "other"), key="match-2", value={"content": {"memory_id": "m2", "session_id": "other"}}, score=0.5, created_at=None, updated_at=None),  # type: ignore[arg-type]
            {"bad": "entry"},
        ]


@pytest.mark.asyncio
async def test_store_memory_uses_metadata_kind():
    store = StubStore()
    client = LangMemStoreClient(store)  # type: ignore[arg-type]
    memory = MemoryEntity(
        agent_id="agent-demo",
        user_id="user@example.com",
        session_id="default",
        kind="summary",
        content="summary content",
        metadata={"kind": "summary", "trigger_reason": "manual"},
    )

    await client.store_memory(memory)

    assert store.calls, "expected store to be invoked"
    _, _, payload = store.calls[0]
    assert payload["kind"] == "summary"
    assert payload["content"]["metadata"]["kind"] == "summary"


@pytest.mark.asyncio
async def test_store_memory_defaults_kind_when_missing():
    store = StubStore()
    client = LangMemStoreClient(store)  # type: ignore[arg-type]
    memory = MemoryEntity(
        agent_id="agent-demo",
        user_id="user@example.com",
        session_id="default",
        content="standard memory",
        metadata={},
    )

    await client.store_memory(memory)

    _, _, payload = store.calls[0]
    assert payload["kind"] == "memory"


@pytest.mark.asyncio
async def test_search_memories_filters_session_and_valid_entries():
    store = StubSearchStore()
    client = LangMemStoreClient(store)  # type: ignore[arg-type]

    results = await client.search_memories(
        agent_id="agent-demo",
        user_id="user@example.com",
        session_id="default",
        query="hello",
        limit=5,
    )

    assert len(results) == 1
    assert results[0].memory_id == "m1"
    assert results[0].score == 0.9


def test_build_langmem_client_uses_embedding_client(monkeypatch):
    captured = {}

    class StubStore:
        def __init__(self, session_factory, embedding_client):
            captured["session_factory"] = session_factory
            captured["embedding_client"] = embedding_client

        async def aput(self, *args, **kwargs):
            return None

        async def adelete(self, *args, **kwargs):
            return None

        async def asearch(self, *args, **kwargs):
            return []

    def stub_session_factory():
        return "session-factory"

    monkeypatch.setenv("LANGMEM_NAMESPACE", "custom")
    get_settings.cache_clear()
    monkeypatch.setattr("src.application.clients.langmem.get_session_factory", stub_session_factory)
    monkeypatch.setattr("src.application.clients.langmem.PgVectorLangGraphStore", StubStore)

    client = build_langmem_client(embedding_client="embed-client")  # type: ignore[arg-type]

    assert client.enabled
    assert captured["session_factory"] == "session-factory"
    assert captured["embedding_client"] == "embed-client"
