from datetime import datetime, timedelta

import pytest

from src.application.dto import CreateMemoryInput
from src.application.exceptions import SummaryGenerationError, SummaryWindowEmptyError
from src.application.services.memory_service import MemoryService
from src.application.services.summary_manager import SummaryManager
from tests.fakes import FakeEmbeddingClient, FakeLangMemClient, FakeLLMClient, FakeMemoryCache, FakeMemoryRepository

AGENT_ID = "agent-auto"
USER_ID = "user@example.com"
SESSION_ID = "default"


def _payload(content: str) -> CreateMemoryInput:
    return CreateMemoryInput(
        agent_id=AGENT_ID,
        user_id=USER_ID,
        session_id=SESSION_ID,
        content=content,
        metadata={"topic": "conversation"},
    )


@pytest.mark.asyncio
async def test_summary_created_when_count_threshold_met():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- callout\n- next steps"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        count_threshold=2,
        token_threshold=10_000,
        time_threshold_seconds=3_600,
        enabled=True,
    )

    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("First update"))
    second = await service.create_memory(_payload("Second update"))

    summaries = [memory for memory in repository._store.values() if memory.kind == "summary"]
    assert len(summaries) == 1
    summary = summaries[0]

    assert "callout" in summary.content
    assert summary.metadata["memory_count"] == 2
    assert set(summary.metadata["source_memory_ids"]) == {first.id, second.id}
    assert summary.metadata["trigger_reason"] == "count"
    assert summary.kind == "summary"
    assert langmem.stored_ids.count(summary.id) == 1

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until is not None


@pytest.mark.asyncio
async def test_summary_created_when_token_threshold_met():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- summary token"])  # single response

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        count_threshold=5,
        token_threshold=5,
        time_threshold_seconds=3_600,
        enabled=True,
    )

    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("Short"))
    await service.create_memory(_payload("A much longer update that should exceed the token estimate promptly."))

    summaries = [memory for memory in repository._store.values() if memory.kind == "summary"]
    assert summaries
    assert summaries[0].metadata["trigger_reason"] == "tokens"
    assert summaries[0].kind == "summary"


@pytest.mark.asyncio
async def test_summary_created_when_time_threshold_met():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- time based summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        count_threshold=50,
        token_threshold=10_000,
        time_threshold_seconds=1,
        enabled=True,
    )

    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("Earlier event"))
    # Pretend the first memory happened long ago
    first.created_at = first.created_at - timedelta(minutes=10)

    await service.create_memory(_payload("Follow-up"))

    summaries = [memory for memory in repository._store.values() if memory.kind == "summary"]
    assert summaries
    assert summaries[0].metadata["trigger_reason"] == "time"
    assert summaries[0].kind == "summary"

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until is not None


@pytest.mark.asyncio
async def test_manual_refresh_generates_summary_metadata():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- manual summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("Manual first"))
    second = await service.create_memory(_payload("Manual second"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
    )

    assert summary.metadata["trigger_reason"] == "manual"
    assert summary.metadata["manual"] is True
    assert summary.metadata["memory_count"] == 2
    assert summary.metadata["source_memory_ids"] == [first.id, second.id]
    assert summary.kind == "summary"
    assert summary.id in langmem.stored_ids

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until is not None


@pytest.mark.asyncio
async def test_manual_refresh_honors_window_limit():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- limited summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("Conversation 1"))
    mid = await service.create_memory(_payload("Conversation 2"))
    last = await service.create_memory(_payload("Conversation 3"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
        window_limit=2,
    )

    assert summary.metadata["memory_count"] == 2
    assert summary.metadata["manual_window_limit"] == 2
    assert summary.metadata["source_memory_ids"] == [mid.id, last.id]
    assert summary.kind == "summary"

    updated_mid = await repository.get(mid.id)
    assert updated_mid.valid_until is not None


@pytest.mark.asyncio
async def test_manual_refresh_allows_regeneration_without_new_memories():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- initial summary", "- regenerated summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("Initial context"))
    await service.create_memory(_payload("More context"))

    first_summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
    )

    regenerated = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
    )

    assert regenerated.metadata["trigger_reason"] == "manual"
    assert regenerated.metadata["previous_summary_id"] == first_summary.id
    assert regenerated.metadata.get("manual_full_history") is True


@pytest.mark.asyncio
async def test_manual_refresh_marks_all_sessions_when_session_missing():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("History memory"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=None,
    )

    assert summary.metadata["manual_all_sessions"] is True


@pytest.mark.asyncio
async def test_manual_refresh_marks_all_users_when_user_missing():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all users summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("User memory"))
    other_payload = CreateMemoryInput(
        agent_id=AGENT_ID,
        user_id="other@example.com",
        session_id=SESSION_ID,
        content="Other user memory",
        metadata={"topic": "alt"},
    )
    await service.create_memory(other_payload)

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=None,
        session_id=None,
    )

    assert summary.metadata["manual_all_users"] is True


@pytest.mark.asyncio
async def test_manual_refresh_raises_when_no_memories_exist():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- unused"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )

    with pytest.raises(SummaryWindowEmptyError):
        await summary_manager.refresh_summary(
            agent_id=AGENT_ID,
            store_user_id=USER_ID,
            scope_user_id=USER_ID,
            session_id=SESSION_ID,
        )


@pytest.mark.asyncio
async def test_manual_refresh_raises_when_llm_returns_empty():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["   "])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_payload("Needs summary"))

    with pytest.raises(SummaryGenerationError):
        await summary_manager.refresh_summary(
            agent_id=AGENT_ID,
            store_user_id=USER_ID,
            scope_user_id=USER_ID,
            session_id=SESSION_ID,
        )


@pytest.mark.asyncio
async def test_manual_refresh_with_no_retention_policy():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("History memory"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID, store_user_id=USER_ID, scope_user_id=USER_ID, session_id=None, retention_days=-1
    )

    assert summary.metadata["manual_all_sessions"] is True

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until is None


@pytest.mark.asyncio
async def test_manual_refresh_with_zero_retention_days():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("History memory"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID, store_user_id=USER_ID, scope_user_id=USER_ID, session_id=None, retention_days=0
    )

    assert summary.metadata["manual_all_sessions"] is True

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until < datetime.now()


@pytest.mark.asyncio
async def test_manual_refresh_with_custom_retention_policy():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("History memory"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID, store_user_id=USER_ID, scope_user_id=USER_ID, session_id=None, retention_days=5
    )

    assert summary.metadata["manual_all_sessions"] is True

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until.date() == (datetime.now() + timedelta(days=5)).date()


@pytest.mark.asyncio
async def test_manual_refresh_with_default_retention_policy():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
        default_retention_days=10,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    first = await service.create_memory(_payload("History memory"))

    summary = await summary_manager.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=None,
    )

    assert summary.metadata["manual_all_sessions"] is True

    updated_first = await repository.get(first.id)
    assert updated_first.valid_until.date() == (datetime.now() + timedelta(days=10)).date()
