import pytest
from fastapi import FastAPI
from fastapi.routing import APIRoute

from src.api.app import create_app


@pytest.mark.asyncio
async def test_app_includes_expected_routes():
    app = create_app()
    assert isinstance(app, FastAPI)

    paths = {route.path for route in app.routes if isinstance(route, APIRoute)}
    assert "/memories" in paths
    assert "/health" in paths
