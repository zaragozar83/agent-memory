from dataclasses import dataclass

import pytest

from src.application.clients.langmem import LangMemSearchResult
from src.application.dto import CreateMemoryInput, UpdateMemoryInput
from src.application.exceptions import (
    LangMemIntegrationError,
    MemoryNotFoundError,
    SummaryGenerationError,
    SummaryWindowEmptyError,
)
from src.application.services.memory_service import MemoryService
from src.application.services.summary_manager import SummaryManager
from src.domain.entities.memory import DEFAULT_SESSION_ID, DEFAULT_USER_ID
from tests.fakes import FakeEmbeddingClient, FakeLangMemClient, FakeLLMClient, FakeMemoryCache, FakeMemoryRepository

AGENT_ID = "agent-1"
USER_ID = "user@example.com"
SESSION_ID = DEFAULT_SESSION_ID


@dataclass(slots=True)
class ServiceContext:
    service: MemoryService
    repository: FakeMemoryRepository
    cache: FakeMemoryCache
    embeddings: FakeEmbeddingClient
    langmem: FakeLangMemClient


@pytest.fixture
def service_context() -> ServiceContext:
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    service = MemoryService(repository, cache, embeddings, langmem)
    return ServiceContext(service, repository, cache, embeddings, langmem)


def _make_payload(
    content: str = "hello world",
    metadata: dict | None = None,
    session: str = SESSION_ID,
) -> CreateMemoryInput:
    return CreateMemoryInput(
        agent_id=AGENT_ID,
        user_id=USER_ID,
        session_id=session,
        content=content,
        metadata=metadata or {"topic": "greeting"},
    )


@pytest.mark.asyncio
async def test_create_memory_persists_and_caches(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())

    stored = await service_context.repository.get(created.id)
    assert stored is not None
    assert created.kind == "memory"
    assert stored.kind == "memory"

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == created.id
    assert created.embedding is not None
    assert service_context.embeddings.recorded_texts[0] == "hello world"
    assert created.id in service_context.langmem.stored_ids


@pytest.mark.asyncio
async def test_create_memory_defaults_identifiers_when_missing(service_context: ServiceContext):
    created = await service_context.service.create_memory(
        CreateMemoryInput(agent_id=AGENT_ID, content="no identifiers")
    )

    assert created.user_id == DEFAULT_USER_ID
    assert created.session_id == DEFAULT_SESSION_ID
    assert created.kind == "memory"

    cached = await service_context.cache.get_recent_memories(AGENT_ID, DEFAULT_USER_ID, session_id=DEFAULT_SESSION_ID)
    assert cached and cached[0].id == created.id


@pytest.mark.asyncio
async def test_get_memory_returns_existing(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())

    fetched = await service_context.service.get_memory(created.id)
    assert fetched.id == created.id


@pytest.mark.asyncio
async def test_get_memory_raises_when_missing(service_context: ServiceContext):
    with pytest.raises(MemoryNotFoundError):
        await service_context.service.get_memory("missing-id")


@pytest.mark.asyncio
async def test_update_memory_refreshes_cache(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())

    updated = await service_context.service.update_memory(created.id, UpdateMemoryInput(content="updated"))

    assert updated.content == "updated"
    assert updated.kind == "memory"

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached[0].content == "updated"
    assert cached[0].kind == "memory"
    assert updated.embedding is not None
    assert "updated" in service_context.embeddings.recorded_texts
    assert created.id in service_context.langmem.stored_ids


@pytest.mark.asyncio
async def test_update_memory_allows_kind_change(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())

    updated = await service_context.service.update_memory(created.id, UpdateMemoryInput(kind="note"))

    assert updated.kind == "note"

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].kind == "note"


@pytest.mark.asyncio
async def test_delete_memory_removes_from_cache(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())

    await service_context.service.delete_memory(created.id)

    assert await service_context.repository.get(created.id) is None

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached == []
    assert created.id in service_context.langmem.deleted_ids


@pytest.mark.asyncio
async def test_list_recent_memories_prefers_cache(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload(content="cached"))

    # Simulate repository outage to ensure cache satisfies the request
    service_context.repository.clear()

    recent = await service_context.service.list_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)

    assert len(recent) == 1
    assert recent[0].id == created.id
    assert recent[0].kind == "memory"


@pytest.mark.asyncio
async def test_list_recent_memories_without_session_returns_all_sessions(service_context: ServiceContext):
    await service_context.service.create_memory(_make_payload(content="session a", session="session-a"))
    await service_context.service.create_memory(_make_payload(content="session b", session="session-b"))

    recent = await service_context.service.list_recent_memories(AGENT_ID, USER_ID, session_id=None)

    assert len(recent) == 2
    assert {memory.session_id for memory in recent} == {"session-a", "session-b"}


@pytest.mark.asyncio
async def test_list_recent_memories_without_user_returns_all_users(service_context: ServiceContext):
    await service_context.service.create_memory(_make_payload(content="primary"))
    await service_context.service.create_memory(
        CreateMemoryInput(
            agent_id=AGENT_ID,
            content="secondary",
            user_id="other@example.com",
            session_id="session-other",
            metadata={"topic": "other"},
        )
    )

    recent = await service_context.service.list_recent_memories(AGENT_ID, None, session_id=None)

    assert len(recent) == 2
    assert {memory.user_id for memory in recent} == {USER_ID, "other@example.com"}
    assert {memory.kind for memory in recent} == {"memory"}


@pytest.mark.asyncio
async def test_list_recent_memories_filters_by_kind(service_context: ServiceContext):
    await service_context.service.create_memory(_make_payload(content="default"))
    await service_context.service.create_memory(
        CreateMemoryInput(
            agent_id=AGENT_ID,
            content="plan",
            user_id=USER_ID,
            kind="plan",
            metadata={"topic": "plan"},
            session_id=SESSION_ID,
        )
    )

    filtered = await service_context.service.list_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID, kind="plan")

    assert len(filtered) == 1
    assert filtered[0].content == "plan"
    assert filtered[0].kind == "plan"


@pytest.mark.asyncio
async def test_search_memories_uses_embeddings(service_context: ServiceContext):
    service_context.embeddings.vector_map.update(
        {
            "hello world": [1.0, 0.0, 0.0],
            "another memory": [0.5, 0.5, 0.5],
            "hello": [1.0, 0.0, 0.0],
        }
    )
    first = await service_context.service.create_memory(_make_payload("hello world"))
    await service_context.service.create_memory(_make_payload("another memory"))

    result = await service_context.service.search_memories(
        AGENT_ID, USER_ID, query="hello", limit=2, session_id=SESSION_ID
    )

    assert len(result) == 2
    assert result[0]["memory"]["id"] == first.id
    assert result[0]["score"] > result[1]["score"]
    assert {item["memory"]["kind"] for item in result} == {"memory"}


@pytest.mark.asyncio
async def test_search_memories_prefers_langmem_results(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload("langmem only"))
    service_context.langmem.search_queue.append([LangMemSearchResult(memory_id=created.id, score=0.87)])

    # Simulate cache eviction prior to search
    service_context.cache._store.clear()

    result = await service_context.service.search_memories(
        AGENT_ID, USER_ID, query="ignored", limit=1, session_id=SESSION_ID
    )

    assert len(result) == 1
    assert result[0]["memory"]["id"] == created.id
    assert result[0]["score"] == 0.87
    assert service_context.langmem.search_requests[0]["agent_id"] == AGENT_ID
    assert service_context.langmem.search_requests[0]["session_id"] == SESSION_ID
    assert result[0]["memory"]["kind"] == "memory"

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == created.id


@pytest.mark.asyncio
async def test_search_memories_without_user_queries_all(service_context: ServiceContext):
    service_context.embeddings.vector_map.update(
        {
            "primary-memory": [1.0, 0.0, 0.0],
            "other-memory": [1.0, 0.0, 0.0],
            "shared": [1.0, 0.0, 0.0],
        }
    )

    await service_context.service.create_memory(_make_payload("primary-memory"))
    await service_context.service.create_memory(
        CreateMemoryInput(
            agent_id=AGENT_ID,
            user_id="other@example.com",
            session_id="other-session",
            content="other-memory",
            metadata={"topic": "other"},
        )
    )

    result = await service_context.service.search_memories(AGENT_ID, None, query="shared", limit=5, session_id=None)

    assert len(result) == 2
    assert {item["memory"]["user_id"] for item in result} == {USER_ID, "other@example.com"}
    assert {item["memory"]["kind"] for item in result} == {"memory"}


@pytest.mark.asyncio
async def test_search_memories_without_session_queries_all_sessions(service_context: ServiceContext):
    service_context.embeddings.vector_map.update(
        {
            "session-a-note": [1.0, 0.0, 0.0],
            "session-b-note": [1.0, 0.0, 0.0],
            "session-query": [1.0, 0.0, 0.0],
        }
    )

    await service_context.service.create_memory(_make_payload("session-a-note", session="session-a"))
    await service_context.service.create_memory(_make_payload("session-b-note", session="session-b"))

    result = await service_context.service.search_memories(
        AGENT_ID,
        USER_ID,
        query="session-query",
        limit=5,
        session_id=None,
    )

    assert len(result) == 2
    assert {item["memory"]["session_id"] for item in result} == {"session-a", "session-b"}
    assert {item["memory"]["kind"] for item in result} == {"memory"}


@pytest.mark.asyncio
async def test_search_memories_filters_by_kind(service_context: ServiceContext):
    service_context.embeddings.vector_map.update(
        {
            "summary note": [1.0, 0.0, 0.0],
            "regular note": [0.0, 1.0, 0.0],
            "summary query": [1.0, 0.0, 0.0],
        }
    )

    await service_context.service.create_memory(_make_payload("regular note"))
    summary = await service_context.service.create_memory(
        CreateMemoryInput(
            agent_id=AGENT_ID,
            user_id=USER_ID,
            session_id=SESSION_ID,
            kind="summary",
            content="summary note",
            metadata={"topic": "recap"},
        )
    )

    results = await service_context.service.search_memories(
        AGENT_ID,
        USER_ID,
        query="summary query",
        limit=5,
        session_id=SESSION_ID,
        kind="summary",
    )

    assert results
    assert [item["memory"]["id"] for item in results] == [summary.id]
    assert {item["memory"]["kind"] for item in results} == {"summary"}


@pytest.mark.asyncio
async def test_search_memories_by_metadata_filters_by_key(service_context: ServiceContext):
    matching = await service_context.service.create_memory(
        _make_payload(metadata={"correlation_id": "12345", "topic": "support"})
    )
    await service_context.service.create_memory(_make_payload(metadata={"correlation_id": "67890"}))

    results = await service_context.service.search_memories_by_metadata(
        agent_id=AGENT_ID,
        metadata={"correlation_id": "12345"},
        user_id=USER_ID,
        session_id=SESSION_ID,
        limit=5,
    )

    assert len(results) == 1
    assert results[0]["memory"]["id"] == matching.id
    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and matching.id in {item.id for item in cached}


@pytest.mark.asyncio
async def test_search_memories_by_metadata_contains_ranks_best_match(service_context: ServiceContext):
    best = await service_context.service.create_memory(
        _make_payload(metadata={"correlation_id": "case-002", "topic": "support"})
    )
    partial = await service_context.service.create_memory(
        _make_payload(metadata={"correlation_id": "case-123", "topic": "support"})
    )

    results = await service_context.service.search_memories_by_metadata(
        agent_id=AGENT_ID,
        metadata={"correlation_id": "case"},
        user_id=USER_ID,
        session_id=None,
        limit=5,
        match_mode="contains",
    )

    assert results
    assert results[0]["memory"]["id"] in {best.id, partial.id}
    assert results[0]["score"] >= results[-1]["score"]


@pytest.mark.asyncio
async def test_create_memory_rolls_back_when_langmem_fails(service_context: ServiceContext):
    service_context.langmem.fail_store = True

    with pytest.raises(LangMemIntegrationError):
        await service_context.service.create_memory(_make_payload())

    assert service_context.repository._store == {}
    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached == []


@pytest.mark.asyncio
async def test_update_memory_reverts_when_langmem_fails(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())
    service_context.langmem.fail_store = True

    with pytest.raises(LangMemIntegrationError):
        await service_context.service.update_memory(created.id, UpdateMemoryInput(content="should fail"))

    stored = await service_context.repository.get(created.id)
    assert stored is not None
    assert stored.content == "hello world"


@pytest.mark.asyncio
async def test_search_memories_embedding_results_refresh_cache(
    service_context: ServiceContext,
):
    service_context.embeddings.vector_map.update(
        {
            "primary": [1.0, 0.0, 0.0],
            "secondary": [0.1, 0.1, 0.1],
            "primary query": [1.0, 0.0, 0.0],
        }
    )
    primary = await service_context.service.create_memory(_make_payload("primary"))
    await service_context.service.create_memory(_make_payload("secondary"))

    # Evict cache to ensure search repopulates it
    service_context.cache._store.clear()

    results = await service_context.service.search_memories(
        AGENT_ID, USER_ID, query="primary query", limit=1, session_id=SESSION_ID
    )

    assert results[0]["memory"]["id"] == primary.id

    cached = await service_context.cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == primary.id
    assert cached[0].kind == "memory"


@pytest.mark.asyncio
async def test_delete_memory_keeps_record_when_langmem_fails(service_context: ServiceContext):
    created = await service_context.service.create_memory(_make_payload())
    service_context.langmem.fail_delete = True

    with pytest.raises(LangMemIntegrationError):
        await service_context.service.delete_memory(created.id)

    assert await service_context.repository.get(created.id) is not None


@pytest.mark.asyncio
async def test_search_memories_raises_when_langmem_fails(service_context: ServiceContext):
    await service_context.service.create_memory(_make_payload())
    service_context.langmem.fail_search = True

    with pytest.raises(LangMemIntegrationError):
        await service_context.service.search_memories(AGENT_ID, USER_ID, query="hello", limit=1, session_id=SESSION_ID)


@pytest.mark.asyncio
async def test_refresh_summary_requires_summary_manager(service_context: ServiceContext):
    with pytest.raises(SummaryGenerationError):
        await service_context.service.refresh_summary(
            agent_id=AGENT_ID,
            store_user_id=USER_ID,
            scope_user_id=USER_ID,
        )


@pytest.mark.asyncio
async def test_refresh_summary_creates_manual_summary():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- service summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("alpha context"))
    latest = await service.create_memory(_make_payload("beta context"))

    summary = await service.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
        window_limit=1,
    )

    assert summary.metadata["trigger_reason"] == "manual"
    assert summary.metadata["manual_window_limit"] == 1
    assert summary.metadata["source_memory_ids"] == [latest.id]
    assert summary.kind == "summary"
    assert summary.id in langmem.stored_ids

    cached = await cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == summary.id
    assert cached[0].kind == "summary"


@pytest.mark.asyncio
async def test_refresh_summary_rebuilds_when_no_new_memories():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- first summary", "- refreshed summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("start"))
    await service.create_memory(_make_payload("continue"))

    first_summary = await service.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
    )
    assert first_summary.kind == "summary"

    refreshed = await service.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=SESSION_ID,
    )

    assert refreshed.metadata["previous_summary_id"] == first_summary.id
    assert refreshed.metadata.get("manual_full_history") is True
    assert refreshed.kind == "summary"


@pytest.mark.asyncio
async def test_refresh_summary_raises_when_no_memories_exist():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- none"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    with pytest.raises(SummaryWindowEmptyError):
        await service.refresh_summary(
            agent_id=AGENT_ID,
            store_user_id=USER_ID,
            scope_user_id=USER_ID,
            session_id=SESSION_ID,
        )


@pytest.mark.asyncio
async def test_refresh_summary_all_sessions_when_session_missing():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all sessions service summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(
        _make_payload(
            "shopping conversation",
            metadata={"topic": "shopping", "role": "user"},
            session="shopping",
        )
    )
    await service.create_memory(
        _make_payload(
            "assistant suggestion",
            metadata={"topic": "shopping", "role": "assistant"},
            session="shopping",
        )
    )

    summary = await service.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=USER_ID,
        session_id=None,
    )

    assert summary.metadata["manual_all_sessions"] is True
    assert summary.kind == "summary"


@pytest.mark.asyncio
async def test_refresh_summary_all_users_when_user_missing():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all users service summary"])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("primary user note"))
    await service.create_memory(
        CreateMemoryInput(
            agent_id=AGENT_ID,
            user_id="other@example.com",
            session_id="alt-session",
            content="second user note",
            metadata={"topic": "alt"},
        )
    )

    summary = await service.refresh_summary(
        agent_id=AGENT_ID,
        store_user_id=USER_ID,
        scope_user_id=None,
        session_id=None,
    )

    assert summary.metadata["manual_all_users"] is True
    assert summary.kind == "summary"


@pytest.mark.asyncio
async def test_refresh_summary_propagates_generation_error():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["   "])

    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("needs summary"))

    with pytest.raises(SummaryGenerationError):
        await service.refresh_summary(
            agent_id=AGENT_ID,
            store_user_id=USER_ID,
            scope_user_id=USER_ID,
            session_id=SESSION_ID,
        )


@pytest.mark.asyncio
async def test_get_memories_to_cleanup_when_empty():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all users service summary"])
    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )

    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("start"))
    await service.create_memory(_make_payload("continue"))

    mem_to_cleanup = await service.get_memories_to_cleanup()

    assert mem_to_cleanup == []


@pytest.mark.asyncio
async def test_get_memories_to_cleanup_after_summarization():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- all users service summary"])
    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )

    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    await service.create_memory(_make_payload("start"))
    await service.create_memory(_make_payload("continue"))

    await summary_manager.refresh_summary(
        agent_id=AGENT_ID, store_user_id=USER_ID, scope_user_id=USER_ID, session_id=None, retention_days=0
    )

    mem_to_cleanup = await service.get_memories_to_cleanup()

    assert len(mem_to_cleanup) == 2
    assert mem_to_cleanup[0].content == "start"
