from __future__ import annotations

from dataclasses import dataclass

import pytest
from langgraph.checkpoint.memory import MemorySaver

from src.application.clients.llm import NullLLMClient
from src.application.langgraph.agent import MemoryAgentState, build_memory_agent
from src.application.services.memory_service import MemoryService
from src.domain.entities.memory import DEFAULT_SESSION_ID
from tests.fakes import FakeEmbeddingClient, FakeLangMemClient, FakeMemoryCache, FakeMemoryRepository


@dataclass(slots=True)
class LangGraphContext:
    service: MemoryService
    repository: FakeMemoryRepository
    cache: FakeMemoryCache
    embeddings: FakeEmbeddingClient
    langmem: FakeLangMemClient


@pytest.fixture
def langgraph_context() -> LangGraphContext:
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    service = MemoryService(repository, cache, embeddings, langmem)
    return LangGraphContext(service, repository, cache, embeddings, langmem)


@pytest.mark.asyncio
async def test_memory_agent_persists_and_recalls(langgraph_context: LangGraphContext):
    agent = build_memory_agent(
        langgraph_context.service,
        checkpointer=MemorySaver(),
        llm_client=NullLLMClient(),
    )

    initial_state: MemoryAgentState = {
        "agent_id": "agent-1",
        "user_id": "user@example.com",
        "session_id": DEFAULT_SESSION_ID,
        "message": "Tell me something memorable",
        "limit": 3,
    }

    result = await agent.ainvoke(
        initial_state,
        config={"configurable": {"thread_id": "thread-1"}},
    )

    assert "response" in result and result["response"]
    assert len(result.get("messages", [])) == 2

    stored = await langgraph_context.repository.list_recent(
        agent_id="agent-1",
        user_id="user@example.com",
        limit=10,
        session_id=DEFAULT_SESSION_ID,
    )
    assert len(stored) == 2
    assert any(mem.metadata.get("role") == "assistant" for mem in stored)
