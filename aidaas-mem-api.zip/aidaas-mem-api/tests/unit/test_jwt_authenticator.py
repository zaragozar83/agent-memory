from __future__ import annotations

import anyio
import jwt
import pytest

from src.application.security import jwt as jwt_module
from src.application.security.jwt import AuthenticationError, JWTAuthenticator
from src.core.config import Settings


def _make_settings(**overrides: object) -> Settings:
    """Build a Settings object that ignores environment overrides for deterministic tests."""

    return Settings.model_construct(**overrides)


def _make_token(payload: dict[str, object], secret: str = "unit-secret", algorithm: str = "HS256") -> str:
    return jwt.encode(payload, secret, algorithm=algorithm)


def test_authenticate_returns_subject_and_scopes() -> None:
    settings = _make_settings(auth_local_jwt_secret="unit-secret", auth_required_scopes="mem:read mem:write")
    authenticator = JWTAuthenticator(settings)
    token = _make_token({"sub": "agent-42", "scope": "mem:read mem:write extra"}, secret="unit-secret")

    identity = anyio.run(authenticator.authenticate, token)

    assert identity.agent_id == "agent-42"
    assert identity.scopes == ("mem:read", "mem:write", "extra")


def test_authenticate_enforces_required_scopes() -> None:
    settings = _make_settings(auth_local_jwt_secret="unit-secret", auth_required_scopes="mem:write")
    authenticator = JWTAuthenticator(settings)
    token = _make_token({"sub": "agent-007", "scope": ["mem:read"]}, secret="unit-secret")

    with pytest.raises(AuthenticationError):
        anyio.run(authenticator.authenticate, token)


def test_authenticate_requires_subject_claim() -> None:
    settings = _make_settings(auth_local_jwt_secret="unit-secret")
    authenticator = JWTAuthenticator(settings)
    token = _make_token({"scope": "mem:read"}, secret="unit-secret")

    with pytest.raises(AuthenticationError):
        anyio.run(authenticator.authenticate, token)


def test_authenticate_allows_unsigned_tokens_when_enabled() -> None:
    settings = _make_settings(auth_local_jwt_secret="", auth_allow_unsigned_local=True)
    authenticator = JWTAuthenticator(settings)
    token = _make_token({"sub": "unsigned-agent"}, secret="ignored")

    identity = anyio.run(authenticator.authenticate, token)

    assert identity.agent_id == "unsigned-agent"
    assert identity.scopes == ()


def test_jwks_client_created_for_asymmetric_algorithms(monkeypatch: pytest.MonkeyPatch) -> None:
    class DummyPyJWKClient:
        def __init__(self, url: str) -> None:
            self.url = url

    monkeypatch.setattr(jwt_module, "PyJWKClient", DummyPyJWKClient)
    settings = _make_settings(auth_jwt_algorithm="RS256", auth_jwks_url="https://example.com/jwks.json")
    authenticator = JWTAuthenticator(settings)

    assert isinstance(authenticator._jwks_client, DummyPyJWKClient)
