from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.domain.postgres.base import Base
from src.domain.postgres.langmem_repository import LangMemStoreRepository
from tests.fakes import FakeEmbeddingClient


@pytest.fixture
async def repository() -> tuple[LangMemStoreRepository, AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        repo = LangMemStoreRepository(
            session,
            FakeEmbeddingClient(
                vector_map={
                    "hello": [1.0, 0.0],
                    "updated": [0.0, 1.0],
                    "query": [0.5, 0.5],
                    "alpha": [1.0, 1.0],
                }
            ),
            timeout_seconds=5,
        )
        yield repo, session

    await engine.dispose()


@pytest.mark.asyncio
async def test_upsert_and_get_round_trip(repository: tuple[LangMemStoreRepository, AsyncSession]):
    repo, _session = repository
    await repo.upsert(("tenant", "agent"), "mem-1", {"kind": "Memory", "content": "hello"})
    created = await repo.get(("tenant", "agent"), "mem-1")
    original_content = created.content if created else ""
    await repo.upsert(("tenant", "agent"), "mem-1", {"kind": "Memory", "content": "updated", "summary_id": "sum-1"})
    updated = await repo.get(("tenant", "agent"), "mem-1")

    assert created is not None and updated is not None
    assert original_content != updated.content
    assert updated.summary_id == "sum-1"
    assert updated.embedding is not None


@pytest.mark.asyncio
async def test_search_ranks_by_similarity(repository: tuple[LangMemStoreRepository, AsyncSession]):
    repo, _session = repository
    await repo.upsert(("tenant", "x"), "alpha", {"kind": "Memory", "content": "alpha"})
    await repo.upsert(("tenant", "x"), "hello", {"kind": "Memory", "content": "hello"})
    await repo.upsert(("tenant", "x"), "updated", {"kind": "Memory", "content": "updated"})

    results = await repo.search(("tenant",), query="query", limit=2)

    keys = [record.key for record, _score in results]
    assert keys[0] == "alpha"
    assert len(keys) == 2


@pytest.mark.asyncio
async def test_search_without_query_returns_unscored_items(repository: tuple[LangMemStoreRepository, AsyncSession]):
    repo, _session = repository
    await repo.upsert(("tenant", "namespace"), "plain", {"kind": "Memory", "content": {"text": "structured"}})

    results = await repo.search(("tenant",), query=None, limit=5)

    assert len(results) == 1
    record, score = results[0]
    assert score is None
    assert record.key == "plain"


@pytest.mark.asyncio
async def test_delete_removes_record(repository: tuple[LangMemStoreRepository, AsyncSession]):
    repo, _session = repository
    await repo.upsert(("tenant", "agent"), "mem-1", {"kind": "Memory", "content": "hello"})
    await repo.delete(("tenant", "agent"), "mem-1")

    assert await repo.get(("tenant", "agent"), "mem-1") is None


@pytest.mark.asyncio
async def test_list_namespaces_returns_unique_paths(repository: tuple[LangMemStoreRepository, AsyncSession]):
    repo, _session = repository
    await repo.upsert(("tenant", "a"), "one", {"kind": "Memory", "content": "hello"})
    await repo.upsert(("tenant", "b"), "two", {"kind": "Memory", "content": "world"})

    namespaces = await repo.list_namespaces()

    assert ("tenant", "a") in namespaces
    assert ("tenant", "b") in namespaces
