import os
from datetime import datetime, timedelta, timezone

import jwt
import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from src.api.dependencies import get_memory_service
from src.api.routers.memories import router
from src.application.services.memory_service import MemoryService
from src.application.services.summary_manager import SummaryManager
from src.domain.entities.memory import DEFAULT_SESSION_ID, DEFAULT_USER_ID
from tests.fakes import FakeEmbeddingClient, FakeLangMemClient, FakeLLMClient, FakeMemoryCache, FakeMemoryRepository

AGENT_ID = "agent-x"
USER_ID = "user@example.com"
SESSION_ID = DEFAULT_SESSION_ID
TEST_SECRET = "test-secret"


def _build_token(agent_id: str = AGENT_ID, expires_in: int = 3600) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": agent_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=expires_in)).timestamp()),
    }
    secret = os.getenv("AUTH_LOCAL_JWT_SECRET", TEST_SECRET)
    algorithm = os.getenv("AUTH_JWT_ALGORITHM", "HS256")
    return jwt.encode(payload, secret, algorithm=algorithm)


def _auth_headers(agent_id: str = AGENT_ID) -> dict[str, str]:
    token = _build_token(agent_id)
    return {"Authorization": f"Bearer {token}"}


def _make_app():
    repository = FakeMemoryRepository()
    cache = FakeMemoryCache()
    embeddings = FakeEmbeddingClient()
    langmem = FakeLangMemClient()
    llm = FakeLLMClient(responses=["- router summary"] * 10)
    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=embeddings,
        langmem_client=langmem,
        llm_client=llm,
        enabled=False,
    )
    service = MemoryService(repository, cache, embeddings, langmem, summary_manager=summary_manager)

    app = FastAPI()
    app.include_router(router)

    async def override_memory_service():
        yield service

    app.dependency_overrides[get_memory_service] = override_memory_service
    return app, repository, cache, embeddings, langmem, llm


@pytest_asyncio.fixture
async def api_client():
    app, repository, cache, embeddings, langmem, llm = _make_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client, repository, cache, embeddings, langmem, llm


def _build_payload(content: str = "stored memory", session: str = SESSION_ID, kind: str | None = None) -> dict:
    payload = {
        "agent_id": AGENT_ID,
        "user_id": USER_ID,
        "session_id": session,
        "content": content,
        "metadata": {"topic": "test"},
    }
    if kind is not None:
        payload["kind"] = kind
    return payload


@pytest.mark.asyncio
async def test_request_without_token_returns_401(api_client):
    client, *_ = api_client

    response = await client.get(
        "/memories",
        params={"agent_id": AGENT_ID, "user_id": USER_ID, "session_id": SESSION_ID},
    )

    assert response.status_code == 401
    assert response.json()["detail"] == "Missing bearer token"


@pytest.mark.asyncio
async def test_create_memory_forbidden_when_agent_mismatch(api_client):
    client, *_ = api_client

    response = await client.post("/memories", json=_build_payload(), headers=_auth_headers("other-agent"))

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_create_memory_endpoint(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    response = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    assert response.status_code == 201
    memory_id = response.json()["id"]
    assert response.json()["kind"] == "memory"

    stored = await repository.get(memory_id)
    assert stored is not None
    assert stored.kind == "memory"

    cached = await cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == memory_id
    assert stored.embedding is not None


@pytest.mark.asyncio
async def test_create_memory_defaults_identifiers_when_missing(api_client):
    client, repository, cache, *_ = api_client
    payload = {
        "agent_id": AGENT_ID,
        "content": "fallback identifiers",
        "metadata": {"topic": "defaults"},
    }

    response = await client.post("/memories", json=payload, headers=_auth_headers())

    assert response.status_code == 201
    body = response.json()
    assert body["user_id"] == DEFAULT_USER_ID
    assert body["session_id"] == DEFAULT_SESSION_ID
    assert body["kind"] == "memory"

    stored = await repository.get(body["id"])
    assert stored is not None
    assert stored.user_id == DEFAULT_USER_ID
    assert stored.session_id == DEFAULT_SESSION_ID
    assert stored.kind == "memory"

    cached = await cache.get_recent_memories(AGENT_ID, DEFAULT_USER_ID, session_id=DEFAULT_SESSION_ID)
    assert cached and cached[0].id == body["id"]


@pytest.mark.asyncio
async def test_create_memory_endpoint_returns_503_when_langmem_fails(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client
    langmem.fail_store = True

    response = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    assert response.status_code == 503
    assert response.json()["detail"] == "Unable to synchronize memory with LangMem"
    assert repository._store == {}


@pytest.mark.asyncio
async def test_get_memory_endpoint(api_client):
    client, *_ = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    response = await client.get(f"/memories/{memory_id}", headers=_auth_headers())
    assert response.status_code == 200
    assert response.json()["id"] == memory_id


@pytest.mark.asyncio
async def test_get_memory_forbidden_for_other_agent(api_client):
    client, *_ = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    response = await client.get(f"/memories/{memory_id}", headers=_auth_headers("other-agent"))

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_get_memory_endpoint_returns_not_found(api_client):
    client, *_ = api_client

    response = await client.get("/memories/missing-id", headers=_auth_headers())
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_list_memories_endpoint(api_client):
    client, *_ = api_client
    await client.post("/memories", json=_build_payload(), headers=_auth_headers())

    response = await client.get(
        "/memories",
        params={"agent_id": AGENT_ID, "user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["session_id"] == SESSION_ID
    assert payload[0]["kind"] == "memory"


@pytest.mark.asyncio
async def test_list_memories_without_user_returns_all_users(api_client):
    client, *_ = api_client
    await client.post("/memories", json=_build_payload("primary user note"), headers=_auth_headers())
    other_payload = _build_payload("secondary user note")
    other_payload["user_id"] = "secondary@example.com"
    await client.post("/memories", json=other_payload, headers=_auth_headers())

    response = await client.get("/memories", params={"agent_id": AGENT_ID}, headers=_auth_headers())

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert {item["user_id"] for item in payload} == {USER_ID, "secondary@example.com"}
    assert {item["kind"] for item in payload} == {"memory"}


@pytest.mark.asyncio
async def test_list_memories_without_session_returns_all_user_sessions(api_client):
    client, *_ = api_client
    await client.post("/memories", json=_build_payload("session a note", session="session-a"), headers=_auth_headers())
    await client.post("/memories", json=_build_payload("session b note", session="session-b"), headers=_auth_headers())

    response = await client.get(
        "/memories",
        params={"agent_id": AGENT_ID, "user_id": USER_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert {item["session_id"] for item in payload} == {"session-a", "session-b"}
    assert {item["kind"] for item in payload} == {"memory"}


@pytest.mark.asyncio
async def test_list_memories_filters_by_kind(api_client):
    client, *_ = api_client
    await client.post("/memories", json=_build_payload("default memory"), headers=_auth_headers())
    await client.post(
        "/memories",
        json=_build_payload("plan memory", kind="plan"),
        headers=_auth_headers(),
    )

    response = await client.get(
        "/memories",
        params={"agent_id": AGENT_ID, "kind": "plan"},
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["kind"] == "plan"
    assert payload[0]["content"] == "plan memory"


@pytest.mark.asyncio
async def test_update_memory_endpoint(api_client):
    client, *_ = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    response = await client.patch(
        f"/memories/{memory_id}",
        json={"content": "updated"},
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    assert response.json()["content"] == "updated"
    assert response.json()["kind"] == "memory"


@pytest.mark.asyncio
async def test_update_memory_allows_kind_change(api_client):
    client, repository, *_ = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    response = await client.patch(
        f"/memories/{memory_id}",
        json={"kind": "note"},
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    assert response.json()["kind"] == "note"

    stored = await repository.get(memory_id)
    assert stored is not None
    assert stored.kind == "note"


@pytest.mark.asyncio
async def test_update_memory_endpoint_returns_503_when_langmem_fails(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    langmem.fail_store = True
    response = await client.patch(
        f"/memories/{memory_id}",
        json={"content": "updated"},
        headers=_auth_headers(),
    )

    assert response.status_code == 503
    assert response.json()["detail"] == "Unable to synchronize memory with LangMem"
    stored = await repository.get(memory_id)
    assert stored is not None
    assert stored.content == "stored memory"


@pytest.mark.asyncio
async def test_delete_memory_endpoint(api_client):
    client, *_ = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    delete_resp = await client.delete(f"/memories/{memory_id}", headers=_auth_headers())
    assert delete_resp.status_code == 204

    get_resp = await client.get(f"/memories/{memory_id}", headers=_auth_headers())
    assert get_resp.status_code == 404


@pytest.mark.asyncio
async def test_delete_memory_endpoint_returns_503_when_langmem_fails(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client
    create_resp = await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    memory_id = create_resp.json()["id"]

    langmem.fail_delete = True
    response = await client.delete(f"/memories/{memory_id}", headers=_auth_headers())

    assert response.status_code == 503
    assert response.json()["detail"] == "Unable to remove memory from LangMem"
    assert await repository.get(memory_id) is not None


@pytest.mark.asyncio
async def test_search_memories_endpoint(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    embeddings.vector_map.update(
        {
            "stored memory": [1.0, 0.0, 0.0],
            "other note": [0.0, 1.0, 0.0],
            "search term": [1.0, 0.0, 0.0],
        }
    )

    await client.post("/memories", json=_build_payload("stored memory"), headers=_auth_headers())
    await client.post("/memories", json=_build_payload("other note"), headers=_auth_headers())

    response = await client.post(
        "/memories/search",
        json={
            "agent_id": AGENT_ID,
            "user_id": USER_ID,
            "session_id": SESSION_ID,
            "query": "search term",
            "limit": 1,
        },
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["memory"]["content"] == "stored memory"
    assert payload[0]["score"] > 0.9
    assert payload[0]["memory"]["kind"] == "memory"


@pytest.mark.asyncio
async def test_search_memories_endpoint_returns_503_when_langmem_fails(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    await client.post("/memories", json=_build_payload(), headers=_auth_headers())
    langmem.fail_search = True

    response = await client.post(
        "/memories/search",
        json={
            "agent_id": AGENT_ID,
            "user_id": USER_ID,
            "session_id": SESSION_ID,
            "query": "any",
            "limit": 1,
        },
        headers=_auth_headers(),
    )

    assert response.status_code == 503
    assert response.json()["detail"] == "Unable to search memories via LangMem"


@pytest.mark.asyncio
async def test_search_memories_without_user_queries_all_users(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    embeddings.vector_map.update(
        {
            "primary note": [1.0, 0.0, 0.0],
            "secondary note": [1.0, 0.0, 0.0],
            "shared": [1.0, 0.0, 0.0],
        }
    )

    await client.post("/memories", json=_build_payload("primary note"), headers=_auth_headers())
    other_payload = _build_payload("secondary note")
    other_payload["user_id"] = "other@example.com"
    await client.post("/memories", json=other_payload, headers=_auth_headers())

    response = await client.post(
        "/memories/search",
        json={"agent_id": AGENT_ID, "query": "shared", "limit": 5},
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert {item["memory"]["user_id"] for item in payload} == {USER_ID, "other@example.com"}
    assert {item["memory"]["kind"] for item in payload} == {"memory"}


@pytest.mark.asyncio
async def test_search_memories_by_metadata_endpoint(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    first = _build_payload("first")
    first["metadata"]["correlation_id"] = "12345"
    await client.post("/memories", json=first, headers=_auth_headers())
    other = _build_payload("second")
    other["metadata"]["correlation_id"] = "67890"
    await client.post("/memories", json=other, headers=_auth_headers())

    response = await client.post(
        "/memories/search/metadata",
        json={
            "agent_id": AGENT_ID,
            "user_id": USER_ID,
            "session_id": SESSION_ID,
            "metadata": {"correlation_id": "12345"},
            "limit": 5,
        },
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["memory"]["metadata"]["correlation_id"] == "12345"


@pytest.mark.asyncio
async def test_search_memories_by_metadata_contains_endpoint(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    first = _build_payload("first")
    first["metadata"]["correlation_id"] = "case-002"
    await client.post("/memories", json=first, headers=_auth_headers())
    second = _build_payload("second")
    second["metadata"]["correlation_id"] = "case-123"
    await client.post("/memories", json=second, headers=_auth_headers())

    response = await client.post(
        "/memories/search/metadata",
        json={
            "agent_id": AGENT_ID,
            "metadata": {"correlation_id": "case"},
            "match_mode": "contains",
            "limit": 5,
        },
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert all("case" in item["memory"]["metadata"]["correlation_id"] for item in payload)


@pytest.mark.asyncio
async def test_search_memories_endpoint_filters_by_kind(api_client):
    client, repository, cache, embeddings, langmem, _llm = api_client

    embeddings.vector_map.update(
        {
            "summary entry": [1.0, 0.0, 0.0],
            "summary query": [1.0, 0.0, 0.0],
            "regular entry": [0.0, 1.0, 0.0],
        }
    )

    await client.post("/memories", json=_build_payload("regular entry"), headers=_auth_headers())
    await client.post(
        "/memories",
        json=_build_payload("summary entry", kind="summary"),
        headers=_auth_headers(),
    )

    response = await client.post(
        "/memories/search",
        json={
            "agent_id": AGENT_ID,
            "user_id": USER_ID,
            "session_id": SESSION_ID,
            "query": "summary query",
            "limit": 5,
            "kind": "summary",
        },
        headers=_auth_headers(),
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["memory"]["kind"] == "summary"
    assert payload[0]["memory"]["content"] == "summary entry"


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_creates_summary(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client
    llm.responses = ["- router summary result"]

    await client.post("/memories", json=_build_payload("alpha"), headers=_auth_headers())
    await client.post("/memories", json=_build_payload("beta"), headers=_auth_headers())

    response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 201
    summary_id = response.json()["id"]
    assert response.json()["kind"] == "summary"

    stored = await repository.get(summary_id)
    assert stored is not None
    assert stored.kind == "summary"
    assert stored.metadata["trigger_reason"] == "manual"
    assert stored.metadata["manual"] is True
    assert langmem.stored_ids.count(summary_id) == 1

    cached = await cache.get_recent_memories(AGENT_ID, USER_ID, session_id=SESSION_ID)
    assert cached and cached[0].id == summary_id


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_allows_regeneration(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client
    llm.responses = ["- first summary", "- regenerated summary"]

    await client.post("/memories", json=_build_payload("start"), headers=_auth_headers())

    first_response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )
    assert first_response.status_code == 201
    first_id = first_response.json()["id"]
    assert first_response.json()["kind"] == "summary"

    second_response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )
    assert second_response.status_code == 201
    assert second_response.json()["kind"] == "summary"
    assert second_response.json()["metadata"]["previous_summary_id"] == first_id


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_returns_503_when_llm_response_empty(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client
    llm.responses = ["   "]

    await client.post("/memories", json=_build_payload("needs summary"), headers=_auth_headers())

    response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 503
    assert "Manual summary refresh produced empty content." in response.json()["detail"]


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_returns_conflict_when_no_memories(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client

    response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID, "session_id": SESSION_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 409
    assert "No memories available" in response.json()["detail"]


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_all_sessions_when_session_missing(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client
    llm.responses = ["- all sessions summary"]

    await client.post("/memories", json=_build_payload("shopping note", session="shopping"), headers=_auth_headers())
    await client.post("/memories", json=_build_payload("default note"), headers=_auth_headers())

    response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={"user_id": USER_ID},
        headers=_auth_headers(),
    )

    assert response.status_code == 201
    payload = response.json()
    assert payload["kind"] == "summary"
    assert payload["metadata"]["manual_all_sessions"] is True


@pytest.mark.asyncio
async def test_refresh_summary_endpoint_all_users_when_user_missing(api_client):
    client, repository, cache, embeddings, langmem, llm = api_client
    llm.responses = ["- all users summary"]

    await client.post("/memories", json=_build_payload("primary user note"), headers=_auth_headers())
    other_payload = _build_payload("other user note")
    other_payload["user_id"] = "other@example.com"
    await client.post("/memories", json=other_payload, headers=_auth_headers())

    response = await client.post(
        f"/memories/{AGENT_ID}/summary/refresh",
        json={},
        headers=_auth_headers(),
    )

    assert response.status_code == 201
    payload = response.json()
    assert payload["kind"] == "summary"
    assert payload["user_id"] == "*"
    assert payload["metadata"]["manual_all_users"] is True
    assert payload["metadata"]["manual_all_sessions"] is True
