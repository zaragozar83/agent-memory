from src.api.app import app as api_app
from src import main


def test_main_exports_fastapi_app():
    assert main.app is api_app
