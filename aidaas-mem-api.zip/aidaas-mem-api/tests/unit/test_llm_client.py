from __future__ import annotations

import pytest

from src.application.clients import llm
from src.application.clients.llm import NullLLMClient, build_llm_client


def test_build_llm_client_defaults_to_null(monkeypatch):
    monkeypatch.setenv("EMBEDDING_BASE_URL", "")
    monkeypatch.setenv("EMBEDDING_API_KEY", "")
    llm.get_settings.cache_clear()

    client = build_llm_client()

    assert isinstance(client, NullLLMClient)


@pytest.mark.asyncio
async def test_null_llm_client_echoes_last_user_message():
    client = NullLLMClient()

    response = await client.generate(messages=[{"role": "user", "content": "hello"}])

    assert "hello" in response


@pytest.mark.asyncio
async def test_http_llm_client_happy_path(monkeypatch):
    class FakeResponse:
        def __init__(self, payload):
            self._payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self._payload

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def post(self, url, json, headers):
            return FakeResponse(
                {
                    "choices": [
                        {
                            "message": {"content": "response text"},
                        }
                    ]
                }
            )

    monkeypatch.setenv("EMBEDDING_BASE_URL", "http://llm.local")
    monkeypatch.setenv("EMBEDDING_API_KEY", "token")
    monkeypatch.setenv("LLM_MODEL", "model-x")
    llm.get_settings.cache_clear()
    monkeypatch.setattr("src.application.clients.llm.httpx.AsyncClient", FakeClient)

    try:
        client = llm.HttpLLMClient(
            base_url="http://llm.local",
            api_key="token",
            model="model-x",
            timeout_seconds=5.0,
            default_max_tokens=50,
        )
        result = await client.generate(messages=[{"role": "user", "content": "hi"}])
        assert result == "response text"
    finally:
        llm.get_settings.cache_clear()
