from __future__ import annotations

import asyncio

import pytest

from src.utils.asyncio import await_with_timeout
from src.utils.text import estimate_tokens


@pytest.mark.asyncio
async def test_await_with_timeout_respects_deadline():
    async def sleepy(delay: float) -> str:
        await asyncio.sleep(delay)
        return "done"

    assert await await_with_timeout(sleepy(0.01), timeout=0.2) == "done"

    with pytest.raises(asyncio.TimeoutError):
        await await_with_timeout(sleepy(0.2), timeout=0.05)


def test_estimate_tokens_handles_whitespace_and_length():
    assert estimate_tokens("") == 0
    assert estimate_tokens("   ") == 0
    assert estimate_tokens("1234") == 1
    assert estimate_tokens("12345") == 2
    assert estimate_tokens("hello world") == 3
