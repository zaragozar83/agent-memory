import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from src.api.routers.health import router as health_router


@pytest.mark.asyncio
async def test_health_endpoint_returns_up_status():
    app = FastAPI()
    app.include_router(health_router)

    transport = ASGITransport(app=app)

    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "up", "message": "API is up and running."}
