import pytest

from src.core.config import get_settings


@pytest.fixture(autouse=True)
def configure_auth_environment(monkeypatch):
    """Ensure tests always use local JWT settings with no external calls."""

    monkeypatch.setenv("AUTH_JWT_ALGORITHM", "HS256")
    monkeypatch.setenv("AUTH_LOCAL_JWT_SECRET", "test-secret")
    monkeypatch.setenv("AUTH_ALLOW_UNSIGNED_LOCAL", "0")
    monkeypatch.setenv("AUTH_JWKS_URL", "")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture(autouse=True)
def disable_pyjwk_client(monkeypatch):
    """Block PyJWKClient so no JWKS network lookups occur during tests."""

    from src.application.security import jwt as jwt_module
    from src.application.security.jwt import AuthenticationError

    class StubPyJWKClient:  # pragma: no cover - defensive stub
        def __init__(self, *args, **kwargs) -> None:
            raise AuthenticationError("JWKS lookup disabled in tests")

    monkeypatch.setattr(jwt_module, "PyJWKClient", StubPyJWKClient)
    yield
