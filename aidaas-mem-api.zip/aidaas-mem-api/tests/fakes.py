from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Iterable, List, Sequence, Tuple

from src.application.clients.langmem import LangMemSearchResult
from src.application.exceptions import LangMemIntegrationError
from src.domain.entities.memory import DEFAULT_SESSION_ID, MemoryEntity, MemorySearchHit


class FakeMemoryRepository:
    """In-memory repository used for fast unit tests."""

    def __init__(self) -> None:
        self._store: dict[str, MemoryEntity] = {}

    async def create(self, memory: MemoryEntity) -> MemoryEntity:
        self._store[memory.id] = memory
        return memory

    async def get(self, memory_id: str) -> MemoryEntity | None:
        return self._store.get(memory_id)

    def _matching(
        self,
        agent_id: str,
        user_id: str | None,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> list[MemoryEntity]:
        target_session = self._normalize_session(session_id) if session_id is not None else None
        normalized_kind = kind.lower() if kind is not None else None
        results = [
            memory
            for memory in self._store.values()
            if memory.agent_id == agent_id
            and (user_id is None or memory.user_id == user_id)
            and (target_session is None or memory.session_id == target_session)
            and (normalized_kind is None or memory.kind == normalized_kind)
        ]
        results.sort(key=lambda item: item.created_at, reverse=True)
        return results

    async def list_recent(
        self,
        agent_id: str,
        user_id: str | None,
        limit: int = 20,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> list[MemoryEntity]:
        results = self._matching(agent_id, user_id, session_id, kind)
        return results[:limit]

    async def update(self, memory: MemoryEntity) -> MemoryEntity | None:
        if memory.id not in self._store:
            return None
        self._store[memory.id] = memory
        return memory

    async def delete(self, memory_id: str) -> bool:
        return self._store.pop(memory_id, None) is not None

    async def update_memory_retention_metadata(
        self, summary: MemoryEntity, valid_until: datetime | None, window: Sequence[MemoryEntity]
    ) -> bool:
        for memory in window:
            memory.summary_id = summary.summary_id
            memory.valid_until = valid_until
            self._store[memory.id] = memory
        return True

    async def rollback_update_memory_retention_metadata(self, window: Sequence[MemoryEntity]):
        return None

    async def get_memories_to_cleanup(self):
        results = [
            memory
            for memory in self._store.values()
            if (memory.valid_until is not None and memory.valid_until < datetime.now())
        ]
        return results

    def clear(self) -> None:
        self._store.clear()

    async def list_for_search(
        self,
        agent_id: str,
        user_id: str | None,
        limit: int,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> list[MemoryEntity]:
        return await self.list_recent(agent_id, user_id, limit, session_id, kind)

    async def get_last_summary(
        self,
        agent_id: str,
        user_id: str | None,
        session_id: str | None = None,
    ) -> MemoryEntity | None:
        for memory in sorted(
            self._matching(agent_id, user_id, session_id, "summary"),
            key=lambda item: item.created_at,
            reverse=True,
        ):
            return memory
        return None

    async def list_window(
        self,
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        start: datetime | None,
        end: datetime | None,
    ) -> list[MemoryEntity]:
        results = []
        for memory in sorted(
            self._matching(agent_id, user_id, session_id),
            key=lambda item: item.created_at,
        ):
            if memory.kind == "summary":
                continue
            if start is not None and memory.created_at <= start:
                continue
            if end is not None and memory.created_at > end:
                continue
            results.append(memory)
        return results

    async def search_by_embedding(
        self,
        *,
        agent_id: str,
        user_id: str | None,
        query_embedding: list[float],
        limit: int,
        session_id: str | None = None,
        min_similarity: float | None = None,
        kind: str | None = None,
    ) -> list[MemorySearchHit]:
        results = []
        for memory in self._matching(agent_id, user_id, session_id, kind):
            if not memory.embedding:
                continue
            similarity = self._cosine_similarity(query_embedding, memory.embedding)
            if similarity is None:
                continue
            if min_similarity is not None and similarity < min_similarity:
                continue
            results.append(MemorySearchHit(memory=memory, similarity=similarity))
        results.sort(key=lambda hit: hit.similarity, reverse=True)
        return results[:limit]

    @staticmethod
    def _cosine_similarity(vector_a: list[float], vector_b: list[float]) -> float | None:
        if len(vector_a) != len(vector_b):
            return None
        dot = sum(a * b for a, b in zip(vector_a, vector_b))
        norm_a = sum(a * a for a in vector_a) ** 0.5
        norm_b = sum(b * b for b in vector_b) ** 0.5
        denom = norm_a * norm_b
        if denom == 0:
            return None
        return dot / denom

    @staticmethod
    def _normalize_session(session_id: str | None) -> str:
        return session_id or DEFAULT_SESSION_ID

    async def search_by_metadata(
        self,
        *,
        agent_id: str,
        metadata: dict,
        limit: int,
        user_id: str | None = None,
        session_id: str | None = None,
        kind: str | None = None,
        match_mode: str = "exact",
    ) -> list[MemoryEntity]:
        if not metadata or limit <= 0:
            return []

        mode = (match_mode or "exact").strip().lower()
        results = []
        for memory in self._matching(agent_id, user_id, session_id, kind):
            meta = memory.metadata or {}
            if mode == "contains":
                if all(str(meta.get(key, "")).lower().find(str(value).lower()) != -1 for key, value in metadata.items()):
                    results.append(memory)
            else:
                if all(meta.get(key) == value for key, value in metadata.items()):
                    results.append(memory)
        return results[:limit]


class FakeMemoryCache:
    """Simple in-memory cache that mimics the Redis-backed cache API."""

    def __init__(self) -> None:
        self._store: Dict[Tuple[str, str, str], List[MemoryEntity]] = {}

    @staticmethod
    def _normalize_session(session_id: str | None) -> str:
        return session_id or DEFAULT_SESSION_ID

    def _key(self, memory: MemoryEntity) -> tuple[str, str, str]:
        return (
            memory.agent_id,
            memory.user_id,
            self._normalize_session(memory.session_id),
        )

    def _key_from_parts(
        self,
        agent_id: str,
        user_id: str,
        session_id: str | None = None,
    ) -> tuple[str, str, str]:
        return (agent_id, user_id, self._normalize_session(session_id))

    async def add_memory(self, memory: MemoryEntity, limit: int = 50) -> None:
        key = self._key(memory)
        memories = [item for item in self._store.get(key, []) if item.id != memory.id]
        memories.append(memory)
        memories.sort(key=lambda item: item.created_at, reverse=True)
        self._store[key] = memories[:limit]

    async def get_recent_memories(
        self,
        agent_id: str,
        user_id: str,
        limit: int = 20,
        session_id: str | None = None,
    ) -> list[MemoryEntity]:
        key = self._key_from_parts(agent_id, user_id, session_id)
        memories = self._store.get(key, [])
        return memories[:limit]

    async def remove_memory(self, memory: MemoryEntity) -> None:
        key = self._key(memory)
        if key not in self._store:
            return
        self._store[key] = [item for item in self._store[key] if item.id != memory.id]
        if not self._store[key]:
            self._store.pop(key, None)

    async def refresh(self, memory: MemoryEntity, limit: int = 50) -> None:
        await self.add_memory(memory, limit)

    async def refresh_many(self, memories: Iterable[MemoryEntity], limit: int = 50) -> None:
        for memory in memories:
            await self.refresh(memory, limit)


@dataclass
class FakeEmbeddingClient:
    """Deterministic embedding client for tests."""

    recorded_texts: list[str] = field(default_factory=list)
    vector_map: dict[str, list[float]] = field(default_factory=dict)

    async def embed(self, text: str) -> list[float] | None:
        self.recorded_texts.append(text)
        if text in self.vector_map:
            return self.vector_map[text]
        # simple deterministic fallback based on text length
        length = float(len(text))
        if length == 0:
            return [0.0]
        return [length, length / 2, length / 3]


@dataclass
class FakeLangMemClient:
    """LangMem stand-in that records interactions without external calls."""

    stored_ids: list[str] = field(default_factory=list)
    deleted_ids: list[str] = field(default_factory=list)
    search_requests: list[dict] = field(default_factory=list)
    search_queue: list[list[LangMemSearchResult]] = field(default_factory=list)
    fail_store: bool = False
    fail_delete: bool = False
    fail_search: bool = False

    @property
    def enabled(self) -> bool:
        return True

    async def store_memory(self, memory: MemoryEntity) -> None:
        if self.fail_store:
            self.fail_store = False
            raise LangMemIntegrationError("Unable to synchronize memory with LangMem")
        self.stored_ids.append(memory.id)

    async def delete_memory(self, memory: MemoryEntity) -> None:
        if self.fail_delete:
            self.fail_delete = False
            raise LangMemIntegrationError("Unable to remove memory from LangMem")
        self.deleted_ids.append(memory.id)

    async def search_memories(
        self,
        *,
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        query: str,
        limit: int,
    ) -> list[LangMemSearchResult]:
        if user_id is None:
            return []
        if self.fail_search:
            self.fail_search = False
            raise LangMemIntegrationError("Unable to search memories via LangMem")
        self.search_requests.append(
            {
                "agent_id": agent_id,
                "user_id": user_id,
                "session_id": session_id,
                "query": query,
                "limit": limit,
            }
        )
        if self.search_queue:
            return self.search_queue.pop(0)
        return []

    async def update_memory_retention_metadata(
        self, summary: MemoryEntity, valid_until: datetime | None, window: Sequence[MemoryEntity]
    ) -> bool:
        return True


@dataclass
class FakeLLMClient:
    """LLM stub that returns canned outputs for testing."""

    responses: list[str] = field(default_factory=list)

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        if self.responses:
            return self.responses.pop(0)
        return messages[-1]["content"] if messages else ""
