# AGENTS.md — mem-api
This document is for AI coding agents (e.g. OpenAI Codex). It explains how to work safely in this repo.

## Mission
Build a FastAPI-based Python service that exposes agentic memory operations.

The service lets agent(s) create, read, update, delete, and evolve "memories":

* short-term / recent context (Redis cache)
* long-term / durable memory (PostgreSQL via SQLAlchemy)
* higher-level semantic / behavioral memory (local embeddings + cosine search)

We want clean layering and testability so we can scale or swap storage later.

## Tech stack
* Python 3.12.11
* FastAPI for the HTTP API
* Pydantic v2 + pydantic-settings for request/response models and config
* SQLAlchemy 2.x async + asyncpg for Postgres
* Redis (async) for short-term memory / caching
* structlog for structured JSON logs
* Azure OpenAI-compatible embedding API for semantic recall

## Runtime layout / boundaries
### src/api
FastAPI layer only.
* `routers/`: define routes and HTTP endpoints.
* `schemas/`: Pydantic request/response models.

Rules:
* Routers MUST only do request/response validation, mapping, and calling into the application layer.
* Routers SHOULD NOT talk directly to Postgres, Redis, or embedding services.

### src/application
Application / orchestration layer.
* `clients/`: adapters for external services (embeddings, LangMem, future integrations).
* `services/`: business workflows.
* `factories/`: add only when a DDD-style factory is the clearest way to construct aggregates or complex value objects.
* Introduce a facade only when an adapter must coordinate multiple services or external systems; otherwise call services directly from the API layer.

This layer coordinates repositories, Redis, and the embedding client.

Rules:
* Application is where we define "what happens" when we ingest, recall, summarize, delete, etc.
* Application is allowed to call `src/domain/postgres`, `src/domain/redis`, and the embedding client.
* LangMem is a required integration; the application uses `LangMemClient` (in `clients/langmem.py`) to mirror durable memories and to fan out semantic search queries before falling back to local embeddings.
* LangGraph agents should reuse the application layer via `src/application/langgraph/agent.py`, which provides a ready-made `StateGraph` wired to `MemoryService`, the pgvector-backed LangMem store adapter, and an LLM responder that reuses the same API credentials as the embedding client (defaults to `gpt-oss-20b` when `LLM_MODEL` is unset).
* Application is responsible for logging meaningful events (agent_id, session_id, etc.).
* Do not add empty factory modules; introduce factories only when object creation logic warrants the pattern.

### src/domain
Domain layer. For now, we are also placing persistence-related code here.

* `src/domain/postgres`
  * SQLAlchemy async models
  * async DB session / engine setup
  * repository classes for persistent memory in Postgres

* `src/domain/redis`
  * Redis async client
  * helper functions for short-term / recent memory access

### src/core
Cross-cutting concerns:
* `config.py`: central pydantic-settings `Settings` class that reads `.env`
* `logging.py`: structlog setup

Rules:
* All env/config access should go through `Settings` in `src/core/config.py`, not `os.environ` scattered around.

### src/utils
Small shared helpers (ID generation, timestamps, lightweight utilities).
No database calls, no network calls here.

### tests
pytest tests. See Testing section for strict rules.

## Env & config
Environment variables live in `.env` and are loaded ONLY via `src/core/config.py` using pydantic-settings.

Guidelines:
* If you need a new env var, add it as a field in `Settings` and document it in `.env.example`.
* Never hardcode secrets or tokens directly in code.
* Nothing outside `src/core/config.py` should read environment variables directly.
* Embedding configuration requires setting `EMBEDDING_BASE_URL`, authentication strategy (`EMBEDDING_AUTH_STRATEGY`), and either `EMBEDDING_DEPLOYMENT` (Azure path) or `EMBEDDING_MODEL` (OpenAI-style path).
* `ENVIRONMENT` defaults to `LOCAL`, which keeps embedding generation offline. Set it to another value (e.g. `PROD`) when you need to hit the external embedding service.
* Use `make seed` to populate a few demo memories for manual testing; `make seed-reset` removes them. These targets call the running API over HTTP (default `http://localhost:8000`); override with `SEED_BASE_URL` if the service is bound elsewhere.

## Logging
All runtime logging must use structlog, not `print()`.

* Logger config lives in `src/core/logging.py`.
* Output should be structured JSON with ISO8601 timestamp and log level.
* Add contextual info like `agent_id`, `session_id`, etc. when logging memory operations.

Routers should generally not log business events.
Application layer should log important events (e.g. "memory saved", "recent context retrieved").

## API design rules
* All endpoints live under `src/api/routers`.
* Request/response models live under `src/api/schemas`.
* Routers call services in `src/application`, not repositories directly. Add a facade only when there is meaningful orchestration beyond a service call.
* Responses should be typed with Pydantic models.
* All public handlers and services should be `async def`.
* Prefer small, focused routers (e.g. `memories.py`, `health.py`) instead of one huge router file.
* Classes and files should be segregated by responsibility.

## Memory model & semantics
We treat "memory" as agent knowledge or context that evolves over time. We currently handle it in three tiers:

1. **Short-term memory**
   * Very recent context (the last N interactions, current working state).
   * Backed by Redis via code under `src/domain/redis`.
   * Optimized for fast recall during an ongoing interaction (low latency, small rolling window).
   * Does not have to be perfectly durable.

2. **Long-term / durable memory**
   * Canonical record and audit trail.
   * Backed by Postgres via code under `src/domain/postgres`.
   * Suitable for CRUD: create, read, update, delete.
   * Used for deterministic queries, analytics, compliance (“what did the agent know / say on <timestamp>”).

3. **Semantic / behavioral memory**
   * Backed by locally stored embeddings (generated via Azure OpenAI-compatible API). LangMem mirrors these memories through the LangGraph store adapter so semantic recall can use LangMem’s APIs while remaining on in-prem infrastructure.
   * Used for semantic recall, personalization, summarization, behavioral adaptation.
   * Embeddings are written alongside the memory record and cosine-searched in-process. LangMem search results are always preferred; local cosine search remains the fallback.

## Testing expectations
All tests live under `tests/`.

We have strict requirements for tests:

1. **Tests must run fully in-memory.**
   * No Postgres container.
   * No Redis container.
   * No external services.
   * No docker-compose.

2. **Postgres stand-in for tests:**
   * When testing repository / persistence logic, use an in-memory SQLite database (`sqlite+aiosqlite:///:memory:` or equivalent) created just for the test.
   * Codex: it's acceptable if some Postgres-only features (e.g. PG UUID type, indexes, constraints) are not fully exercised by SQLite in tests. That’s fine.
   * Tests should create the tables in-memory at setup and drop them at teardown.

3. **Redis stand-in for tests:**
   * For Redis usage, tests should use an in-memory stub or fake (Python dict / list in memory), not a real Redis server.

4. **Embedding service in tests:**
   * Calls to the embedding API must be faked. Do not require network.

5. **What to assert:**
   * Router tests: request/response shape, status codes.
   * Application tests: that services call the right repo/cache methods with expected arguments and return expected data. If a facade exists for specialized orchestration, test its behavior separately.
   * Basic “happy path” coverage is enough at this stage.

Codex: never introduce docker or container dependencies into tests. Tests must be lightweight and must pass with only Python + SQLite in memory.

## Security / safety notes
* Do not commit secrets.

If you add new env vars or new external integrations, you MUST update:
* `src/core/config.py`
* `.env.example`
* README.md file if it changes architecture or strategy.
