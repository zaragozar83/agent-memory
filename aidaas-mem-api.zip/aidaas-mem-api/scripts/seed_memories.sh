#!/usr/bin/env bash
set -euo pipefail

MODE="seed"
BASE_URL="${SEED_BASE_URL:-http://localhost:8000}"
AGENT_ID="${SEED_AGENT_ID:-agent-local}"
USER_ID="${SEED_USER_ID:-user.local@example.com}"
TIMEOUT_SECONDS="${SEED_TIMEOUT:-15}"
JWT_TOKEN="${SEED_BEARER_TOKEN:-}"

usage() {
  cat <<'EOF'
Usage: seed_memories.sh [--reset] [--base-url URL] [--timeout SECONDS]

Populates (default) or removes (--reset) the sample memories by calling the public API.
Environment overrides:
  SEED_BASE_URL      Base URL for the API (default http://localhost:8000)
  SEED_AGENT_ID      Agent header, defaults to agent-local
  SEED_USER_ID       User header, defaults to user@example.com
  SEED_TIMEOUT       Seconds to wait for the API before aborting (default 15)
  SEED_BEARER_TOKEN  Provide a pre-generated JWT (Authorization header). If unset the script
                     mints one using AUTH_LOCAL_JWT_SECRET (defaults to local-secret) when the
                     algorithm is HS*.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --reset)
      MODE="reset"
      shift
      ;;
    --base-url)
      BASE_URL="${2%/}"
      shift 2
      ;;
    --timeout)
      TIMEOUT_SECONDS="$2"
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

BASE_URL="${BASE_URL%/}"

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
TOKEN_SCRIPT="$SCRIPT_DIR/generate_local_token.sh"

if [[ -z "$JWT_TOKEN" ]]; then
  JWT_SECRET="${AUTH_LOCAL_JWT_SECRET:-local-secret}"
  JWT_ALGORITHM="${AUTH_JWT_ALGORITHM:-HS256}"
  if [[ -n "$JWT_SECRET" && "$JWT_ALGORITHM" == HS* ]]; then
    if [[ ! -x "$TOKEN_SCRIPT" ]]; then
      echo "[seed] Token helper $TOKEN_SCRIPT is missing or not executable" >&2
      exit 1
    fi
    if ! JWT_TOKEN=$("$TOKEN_SCRIPT" "$AGENT_ID"); then
      echo "[seed] Failed to generate JWT token" >&2
      exit 1
    fi
  else
    echo "[seed] Provide SEED_BEARER_TOKEN or configure AUTH_LOCAL_JWT_SECRET with an HS* algorithm" >&2
    exit 1
  fi
fi

AUTH_HEADER="Authorization: Bearer $JWT_TOKEN"

CONVERSATION=(
  "shopping|User: I am shopping for a Dell gaming notebook that can handle modern games smoothly. Can you help?|{\"topic\":\"gaming-laptop\",\"role\":\"user\",\"intent\":\"purchase\"}"
  "shopping|Assistant: Happy to help. Do you have a screen size preference or a target budget for the laptop?|{\"topic\":\"gaming-laptop\",\"role\":\"assistant\",\"focus\":\"qualify\"}"
  "shopping|User: I prefer a 15 inch system under 1800 dollars with at least an RTX 4070 and a 144Hz display.|{\"topic\":\"gaming-laptop\",\"role\":\"user\",\"requirements\":\"15-inch, <=1800, RTX 4070, 144Hz\"}"
  "shopping|Assistant: The Dell G16 with an RTX 4070 meets that spec for around 1699 dollars and ships with a 165Hz display.|{\"topic\":\"gaming-laptop\",\"role\":\"assistant\",\"recommendation\":\"Dell G16 RTX 4070\"}"
  "shopping|User: I stream on Twitch sometimes. Will the thermals stay stable during long sessions?|{\"topic\":\"gaming-laptop\",\"role\":\"user\",\"concern\":\"thermals\"}"
  "shopping|Assistant: Reviews note the G16 stays cool in performance mode but the fans are loud in turbo. I can compare Alienware M16 or Legion options if needed.|{\"topic\":\"gaming-laptop\",\"role\":\"assistant\",\"next_step\":\"compare-alternatives\"}"
  "shopping|User: Please send financing and extended warranty details so I can plan the purchase.|{\"topic\":\"gaming-laptop\",\"role\":\"user\",\"request\":\"financing\"}"
  "shopping|Assistant: I will prepare a spec sheet, 12 month financing examples, and the Dell Premium Support Plus warranty pricing.|{\"topic\":\"gaming-laptop\",\"role\":\"assistant\",\"action\":\"prepare-followup\"}"
)

escape_json() {
  local value=$1
  value=${value//\\/\\\\}
  value=${value//\"/\\\"}
  value=${value//$'\n'/\\n}
  value=${value//$'\r'/\\r}
  value=${value//$'\t'/\\t}
  printf '%s' "$value"
}

extract_id() {
  local json=$1
  local content=$2
  local sanitized_json
  sanitized_json=$(printf '%s' "$json" | tr -d '\n')
  local marker="\"content\":\"$(escape_json "$content")\""
  if [[ "$sanitized_json" != *"$marker"* ]]; then
    return 1
  fi
  local before=${sanitized_json%%"$marker"*}
  local id_marker="\"memory\":{\"id\":\""
  if [[ "$before" != *"$id_marker"* ]]; then
    return 1
  fi
  before=${before##*"$id_marker"}
  local id=${before%%\"*}
  printf '%s' "$id"
}

wait_for_api() {
  local deadline=$((SECONDS + TIMEOUT_SECONDS))
  while (( SECONDS <= deadline )); do
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/docs" || true)
    if [[ "$status" != "000" ]]; then
      return 0
    fi
    sleep 1
  done
  echo "[seed] API at $BASE_URL not reachable after ${TIMEOUT_SECONDS}s" >&2
  exit 1
}

search_memory_id() {
  local session=$1
  local content=$2
  local payload
  payload=$(printf '{"agent_id":"%s","user_id":"%s","session_id":"%s","query":"%s","limit":5}' \
    "$AGENT_ID" "$USER_ID" "$(escape_json "$session")" "$(escape_json "$content")")
  local response
response=$(curl -sSf -X POST "$BASE_URL/memories/search" \
  -H 'Content-Type: application/json' \
  -H "$AUTH_HEADER" \
  -d "$payload")
extract_id "$response" "$content" || true
}

create_memory() {
  local session=$1
  local content=$2
  local metadata=$3
  local payload
  payload=$(printf '{"agent_id":"%s","user_id":"%s","session_id":"%s","content":"%s","metadata":%s}' \
    "$AGENT_ID" "$USER_ID" "$session" "$(escape_json "$content")" "$metadata")
  curl -sSf -X POST "$BASE_URL/memories" \
    -H 'Content-Type: application/json' \
    -H "$AUTH_HEADER" \
    -d "$payload" > /dev/null
}

delete_memory() {
  local memory_id=$1
  curl -sSf -X DELETE "$BASE_URL/memories/$memory_id" \
    -H "$AUTH_HEADER" \
    > /dev/null
}

wait_for_api

case "$MODE" in
  seed)
    for entry in "${CONVERSATION[@]}"; do
      IFS='|' read -r session content metadata <<<"$entry"
      id=$(search_memory_id "$session" "$content")
      if [[ -n "${id:-}" ]]; then
        echo "[seed] existing memory $id for $AGENT_ID/$USER_ID ($session) — skipping"
      else
        create_memory "$session" "$content" "$metadata"
        id=$(search_memory_id "$session" "$content")
        echo "[seed] created memory for $AGENT_ID/$USER_ID ($session)"
      fi
    done
    ;;
  reset)
    for entry in "${CONVERSATION[@]}"; do
      IFS='|' read -r session content metadata <<<"$entry"
      id=$(search_memory_id "$session" "$content")
      if [[ -z "${id:-}" ]]; then
        echo "[seed] no memory to delete for $AGENT_ID/$USER_ID ($session) with content '$content'"
        continue
      fi
      delete_memory "$id"
      echo "[seed] deleted memory $id for $AGENT_ID/$USER_ID ($session)"
    done
    ;;
esac
