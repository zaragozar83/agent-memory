#!/usr/bin/env bash
set -euo pipefail

SCRIPT_NAME=$(basename "$0")

usage() {
  cat <<'EOF'
Generate a local HS256 JWT for testing the mem-api service.

Usage: generate_local_token.sh [AGENT_ID] [--ttl SECONDS]

Environment overrides:
  AUTH_JWT_ALGORITHM     Signing algorithm (must start with HS, default HS256).
  AUTH_LOCAL_JWT_SECRET  Shared secret used for signing (default local-secret).
  TOKEN_TTL_SECONDS      Lifetime in seconds (default 3600).

Examples:
  ./scripts/generate_local_token.sh agent-local
  AUTH_LOCAL_JWT_SECRET=dev-secret ./scripts/generate_local_token.sh agent-x --ttl 900
EOF
}

AGENT_ID=""
TTL="${TOKEN_TTL_SECONDS:-3600}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --help|-h)
      usage
      exit 0
      ;;
    --ttl)
      TTL="$2"
      shift 2
      ;;
    --ttl=*)
      TTL="${1#*=}"
      shift
      ;;
    *)
      if [[ -z "$AGENT_ID" ]]; then
        AGENT_ID="$1"
        shift
      else
        echo "[$SCRIPT_NAME] Unexpected argument: $1" >&2
        usage
        exit 1
      fi
      ;;
  esac
done

ALGORITHM="${AUTH_JWT_ALGORITHM:-HS256}"
SECRET="${AUTH_LOCAL_JWT_SECRET:-local-secret}"

if [[ -z "$AGENT_ID" ]]; then
  AGENT_ID="${AUTH_AGENT_ID:-agent-local}"
fi

if [[ -z "$SECRET" ]]; then
  echo "[$SCRIPT_NAME] AUTH_LOCAL_JWT_SECRET must be set" >&2
  exit 1
fi

if [[ $ALGORITHM != HS* ]]; then
  echo "[$SCRIPT_NAME] This helper only supports HS* algorithms (got $ALGORITHM)" >&2
  exit 1
fi

python - "$AGENT_ID" "$TTL" "$ALGORITHM" "$SECRET" <<'PY'
import sys
import time

import jwt

agent_id, ttl, algorithm, secret = sys.argv[1:]

try:
    ttl_seconds = int(ttl)
    if ttl_seconds <= 0:
        raise ValueError
except ValueError:  # pragma: no cover - validated in shell
    print("TTL must be a positive integer", file=sys.stderr)
    sys.exit(1)

now = int(time.time())
payload = {
    "sub": agent_id,
    "iat": now,
    "exp": now + ttl_seconds,
}

token = jwt.encode(payload, secret, algorithm=algorithm)
if isinstance(token, bytes):
    token = token.decode()
print(token)
PY
