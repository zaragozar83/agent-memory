# mem-api

FastAPI service that layers short-term, long-term, and semantic memories for autonomous agents.

## Setup

Install all runtime and development dependencies with:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

The Postgres service relies on the `pgvector` extension to store embeddings. 
The provided `docker-compose.dbs.yml` uses the `pgvector/pgvector:pg16` image and the
application bootstrap (`init_db`) issues `CREATE EXTENSION IF NOT EXISTS vector`
the first time it connects.

## Project Layout

```
.
├── Makefile
├── docker-compose.dbs.yml
├── src
│   ├── api/           # FastAPI routers, schemas, dependencies
│   ├── application/   # Facades, services, embedding/semantic orchestration
│   ├── core/          # App configuration and logging setup
│   └── domain/        # Postgres models/repos and Redis cache helpers
└── tests              # In-memory/isolated pytest suite
```

## Runtime Overview

- **Postgres (pgvector)** holds long-term memories and their embeddings. The API writes summaries and user/assistant turns here via SQLAlchemy’s async layer.
- **Redis** caches the most recent memories per `(agent_id, user_id, session_id)` for quick reads; cache misses fall back to Postgres and each write refreshes the cache entry.
- **Semantic search pipeline** first asks LangMem (via the `PgVectorLangGraphStore`) for vector matches; if LangMem has nothing, the service embeds the query with the configured embedding client and performs a local cosine search across Postgres candidates.
- **LangMem integration** mirrors stored memories into `langmem_memories`, enabling shared LangGraph agents to recall or search using the same data without going through the HTTP API.
- **Summary manager** watches conversation windows and, when thresholds hit or when `/memories/{agent_id}/summary/refresh` is called, generates LLM summaries, persists them like any other memory, updates Redis, and mirrors them to LangMem. It also updates the summary id and retention policy on summarized memories. these metadata can be used by a cleanup job to prune or archive data safely.

## Makefile Commands

```bash
make db-up      # start Postgres + Redis containers
make db-down    # stop the containers
make db-restart # convenience: db-down then db-up
make db-reset   # drop containers and volumes for a clean slate
make db-logs    # follow database container logs
make format     # run ruff (with --fix) and black
make lint       # run ruff checks
make test       # execute pytest suite
make seed       # load sample memories via scripts/seed_memories.sh
make seed-reset # remove seeded memories
make token      # print a local HS256 bearer token for agent-local
```

## FastAPI Endpoints

| Endpoint | Purpose | Storage Touchpoints |
| --- | --- | --- |
| `POST /memories` | Persist a new memory | Postgres write (with embedding) → Redis cache seed |
| `GET /memories/{memory_id}` | Fetch a single durable record | Postgres read |
| `GET /memories` | List recent context for an agent | Redis read with Postgres backfill |
| `PATCH /memories/{memory_id}` | Update memory content/metadata | Postgres update (embedding refresh) → Redis refresh |
| `DELETE /memories/{memory_id}` | Remove a memory | Postgres delete → Redis eviction |
| `POST /memories/search` | Semantic search across memories (supports optional `kind` filter) | Embed query → cosine scoring over recent Postgres memories |
| `POST /memories/{agent_id}/summary/refresh` | Manually regenerate a summary window | LLM summary → Postgres write → Redis refresh → LangMem sync |

### Semantic Search Controls

- `EMBEDDING_DIMENSION` (default `1024`) selects the dimensionality for stored
  vectors.
- `SEMANTIC_SEARCH_CANDIDATES` (default `100`) caps how many vector hits we pull
  back from Postgres before truncating to the request’s limit.
- `SEMANTIC_SEARCH_SIMILARITY_THRESHOLD` (optional) filters out vectors below a
  cosine-similarity threshold (0.0–1.0).
- `LLM_MODEL` / `LLM_MAX_TOKENS` configure the LangGraph responder’s chat
  completion model (shares the same base URL and API key as embeddings).
  If `LLM_MODEL` is blank the agent defaults to `gpt-oss-20b`.

## Configuration

Environment variables are managed through `src/core/config.py`; copy `.env.example` to `.env` and adjust connection details plus embedding service credentials (base URL, deployment/model, auth strategy) as needed. LangMem shares the same Postgres DSN (`DATABASE_DSN`) via the pgvector-backed store adapter.

`OPERATION_TIMEOUT_SECONDS` caps outbound datastore and embedding calls (default 30s) so failing services do not stall request handling or tests indefinitely.

- `DATABASE_SCHEMA` the SQLAlchemy metadata to a non-default schema (for example `dev_agent_memory`). The bootstrap automatically sets the Postgres `search_path` and creates the schema if it does not exist.
- Managed Redis instances that require TLS can be configured with `REDIS_SSL_CERT_REQS` (`required`, `optional`, or `none`) and `REDIS_SSL_CHECK_HOSTNAME`. `REDIS_TTL` controls how long cached recent memories stay alive (default 3600 seconds).

### Authentication

- `AUTH_JWKS_URL` — JWKS endpoint from your identity provider (leave blank in local dev).
- `AUTH_JWT_ALGORITHM` — Signing algorithm (e.g. `RS256` in prod, `HS256` locally).
- `AUTH_LOCAL_JWT_SECRET` — Shared secret for HS* tokens in local/dev environments (defaults to `local-secret`).
- `AUTH_ALLOW_UNSIGNED_LOCAL` — Set to `false` outside local environments; when `true` the validator can decode unsigned tokens (handy for manual testing).
- `AUTH_REQUIRED_SCOPES` — Optional space-delimited list that, when populated, must exist in the token’s `scope` claim.

Automatic summarization is controlled via:

- `AUTO_SUMMARY_ENABLED` (default `true`) toggles auto-rollups entirely.
- `SUMMARY_COUNT_THRESHOLD` (default `20`) triggers a summary after this many unsummarized memories.
- `SUMMARY_TOKEN_THRESHOLD` (default `2400`) triggers when the estimated total tokens since the last summary exceeds the limit.
- `SUMMARY_TIME_THRESHOLD_SECONDS` (default `900`) triggers when this much time passes between summaries.
- `DEFAULT_RETENTION_DAYS` (default `30`) default memory retention in days

By default `ENVIRONMENT=LOCAL`, which activates a deterministic in-process embedding generator so no external HTTP calls are made during development or unit tests. Override to another value (for example `PROD`) when you want to hit the configured embedding service.

## Local Seeding & Sample Requests

Ensure the FastAPI app is running (default `http://localhost:8000`). Then populate the database with a few demo memories (used by the examples below) by running:

```bash
make seed
```

To remove the seeded entries, run:

```bash
make seed-reset
```

Both targets accept a different base URL via `SEED_BASE_URL`, e.g. `SEED_BASE_URL=http://127.0.0.1:9000 make seed`. The script waits briefly for the API to respond before seeding. The seeded conversation includes enough recent memories to exercise manual summary refreshes via the API (`POST /memories/{agent_id}/summary/refresh`).

With the service running, call the API with an `Authorization: Bearer <jwt>` header. For local development:

1. Copy `.env.example` to `.env` (or export `AUTH_LOCAL_JWT_SECRET`) so the API and tooling share the same HS256 secret (`local-secret` by default).
2. Mint a token with `make token`, the helper script, or via the Swagger UI. The `make` target prints a ready-to-use value; the script route looks like:

```bash
TOKEN=$(./scripts/generate_local_token.sh agent-local)
# The helper respects AUTH_JWT_ALGORITHM, AUTH_LOCAL_JWT_SECRET, and TOKEN_TTL_SECONDS.

# Create a memory
curl -X POST http://localhost:8000/memories \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
        "agent_id": "agent-local",
        "user_id": "user@example.com",
        "session_id": "default",
        "content": "Draft the release notes for v1.2.",
        "metadata": {"topic": "release"}
      }'

# List recent memories (default session)
curl "http://localhost:8000/memories?agent_id=agent-local&user_id=user@example.com&session_id=default&limit=10" \
  -H "Authorization: Bearer $TOKEN"

# Capture the ID from the create/list response, e.g.
export MEMORY_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# Retrieve a single memory
curl http://localhost:8000/memories/$MEMORY_ID \
  -H "Authorization: Bearer $TOKEN"

# Update that memory
curl -X PATCH http://localhost:8000/memories/$MEMORY_ID \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"content": "Release notes drafted and awaiting review."}'

# Search memories (optionally filter by kind)
curl -X POST http://localhost:8000/memories/search \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
        "agent_id": "agent-local",
        "user_id": "user@example.com",
        "session_id": "default",
        "query": "release notes",
        "kind": "memory",
        "limit": 3
      }'

# Manually refresh a summary window
curl -X POST http://localhost:8000/memories/agent-local/summary/refresh \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
        "user_id": "user@example.com",
        "session_id": "default"
      }'

# Delete the memory
curl -X DELETE http://localhost:8000/memories/$MEMORY_ID \
  -H "Authorization: Bearer $TOKEN"
```

Swagger option: open `http://localhost:8000/docs`, click **Authorize**, paste `Bearer <token>` (including the word `Bearer`), and all subsequent requests from the Swagger UI will include it.

## LangGraph Agent Demo

The module `src/application/langgraph/agent.py` exposes `build_memory_agent`, a
LangGraph `StateGraph` that uses the `MemoryService` for persistence and recall
while checkpointing state with `MemorySaver` (you can inject a different
checkpointer if needed).

```python
import asyncio
from langgraph.checkpoint.memory import MemorySaver

from src.application.langgraph.agent import build_memory_agent
from src.application.services.memory_service import MemoryService

# Wire MemoryService using your preferred dependency injection pattern.
service: MemoryService = ...

agent = build_memory_agent(
    service,
    checkpointer=MemorySaver(),  # swap for build_langgraph_store() in prod
)

async def run_turn(message: str):
    result = await agent.ainvoke(
        {
            "agent_id": "agent-1",
            "user_id": "user@example.com",
            "session_id": "default",
            "message": message,
        },
        config={"configurable": {"thread_id": "demo-thread"}},
    )
    return result["response"]

asyncio.run(run_turn("hello"))
```

Providing your own responder callable lets you plug in any LLM; by default the
agent calls the configured chat-completions endpoint (falling back to an echo
responder if no LLM configuration is present).
