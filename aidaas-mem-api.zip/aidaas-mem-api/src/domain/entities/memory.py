from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

DEFAULT_USER_ID = "default"
DEFAULT_SESSION_ID = "default"
DEFAULT_MEMORY_KIND = "memory"


def _now() -> datetime:
    return datetime.now(tz=timezone.utc)


@dataclass(slots=True)
class MemoryEntity:
    id: str = field(default_factory=lambda: str(uuid4()))
    agent_id: str = ""
    user_id: str = DEFAULT_USER_ID
    session_id: str | None = DEFAULT_SESSION_ID
    kind: str = DEFAULT_MEMORY_KIND
    content: str = ""
    summary_id: str = ""
    metadata: dict[str, Any] | None = field(default_factory=dict)
    embedding: list[float] | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)
    valid_until: datetime | None = None

    def touch(self) -> None:
        self.updated_at = _now()


@dataclass(slots=True)
class MemorySearchHit:
    memory: MemoryEntity
    similarity: float
