from collections.abc import AsyncGenerator
from typing import Optional
from urllib.parse import urlparse

from redis import asyncio as redis_async
from redis.asyncio import Redis

from src.core.config import get_settings

_redis_client: Optional[Redis] = None


def build_redis() -> Redis:
    """Create a Redis client instance."""

    settings = get_settings()
    timeout = settings.operation_timeout_seconds
    redis_url = settings.redis_url
    parsed = urlparse(redis_url)

    redis_kwargs: dict[str, object] = {
        "decode_responses": True,
        "socket_timeout": timeout,
        "socket_connect_timeout": timeout,
    }

    using_tls = parsed.scheme == "rediss"
    if using_tls:
        if settings.redis_ssl_cert_reqs:
            redis_kwargs["ssl_cert_reqs"] = settings.redis_ssl_cert_reqs.strip().lower()
        if settings.redis_ssl_check_hostname is not None:
            redis_kwargs["ssl_check_hostname"] = settings.redis_ssl_check_hostname

    return redis_async.from_url(
        redis_url,
        **redis_kwargs,
    )


async def get_redis_client() -> AsyncGenerator[Redis, None]:
    """FastAPI dependency yielding a Redis client."""

    global _redis_client

    if _redis_client is None:
        _redis_client = build_redis()

    try:
        yield _redis_client
    finally:
        # Connection pooling keeps the client open; cleanup handled on app shutdown.
        pass


async def close_redis() -> None:
    """Close the Redis client if it exists."""

    global _redis_client

    if _redis_client is not None:
        await _redis_client.close()
        _redis_client = None
