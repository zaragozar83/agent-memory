from __future__ import annotations

import json
from datetime import datetime
from typing import Iterable

from redis.asyncio import Redis

from src.core.config import get_settings
from src.utils.asyncio import await_with_timeout

from ..entities.memory import DEFAULT_SESSION_ID, MemoryEntity


class MemoryCache:
    """Redis-backed cache for recent memories."""

    def __init__(self, redis_client: Redis, timeout_seconds: float | None = None):
        self._redis = redis_client
        settings = get_settings()
        configured_timeout = settings.operation_timeout_seconds
        if timeout_seconds is not None and timeout_seconds > 0:
            self._timeout = min(timeout_seconds, configured_timeout)
        else:
            self._timeout = configured_timeout
        self._ttl = max(1, settings.redis_ttl_seconds)

    @staticmethod
    def _session_ref(session_id: str | None) -> str:
        return session_id or DEFAULT_SESSION_ID

    @classmethod
    def _key(cls, agent_id: str, user_id: str, session_id: str | None = None) -> str:
        session_ref = cls._session_ref(session_id)
        return f"memories:{agent_id}:{user_id}:{session_ref}"

    @classmethod
    def _data_key(cls, agent_id: str, user_id: str, session_id: str | None = None) -> str:
        return f"{cls._key(agent_id, user_id, session_id)}:data"

    async def add_memory(self, memory: MemoryEntity, limit: int = 50) -> None:
        key = self._key(memory.agent_id, memory.user_id, memory.session_id)
        data_key = self._data_key(memory.agent_id, memory.user_id, memory.session_id)
        payload = json.dumps(
            {
                "id": memory.id,
                "agent_id": memory.agent_id,
                "user_id": memory.user_id,
                "session_id": memory.session_id,
                "kind": memory.kind,
                "content": memory.content,
                "metadata": memory.metadata or {},
                "created_at": memory.created_at.isoformat(),
                "updated_at": memory.updated_at.isoformat(),
            }
        )
        score = memory.created_at.timestamp()
        await await_with_timeout(self._redis.zadd(key, {memory.id: score}), self._timeout)
        await await_with_timeout(self._redis.hset(data_key, mapping={memory.id: payload}), self._timeout)
        await await_with_timeout(self._redis.expire(key, self._ttl), self._timeout)
        await await_with_timeout(self._redis.expire(data_key, self._ttl), self._timeout)
        await self._trim_to_limit(key, data_key, limit)

    async def get_recent_memories(
        self,
        agent_id: str,
        user_id: str,
        limit: int = 20,
        session_id: str | None = None,
    ) -> list[MemoryEntity]:
        key = self._key(agent_id, user_id, session_id)
        data_key = self._data_key(agent_id, user_id, session_id)
        ids = await await_with_timeout(self._redis.zrevrange(key, 0, limit - 1), self._timeout)
        if not ids:
            return []
        decoded_ids = [self._decode(item) for item in ids]
        payloads = await await_with_timeout(self._redis.hmget(data_key, *decoded_ids), self._timeout)
        return [self._deserialize(payload) for payload in payloads if payload]

    async def remove_memory(self, memory: MemoryEntity) -> None:
        key = self._key(memory.agent_id, memory.user_id, memory.session_id)
        data_key = self._data_key(memory.agent_id, memory.user_id, memory.session_id)
        await await_with_timeout(self._redis.zrem(key, memory.id), self._timeout)
        await await_with_timeout(self._redis.hdel(data_key, memory.id), self._timeout)

    async def refresh(self, memory: MemoryEntity, limit: int = 50) -> None:
        await self.add_memory(memory, limit=limit)

    async def refresh_many(self, memories: Iterable[MemoryEntity], limit: int = 50) -> None:
        for memory in memories:
            await self.refresh(memory, limit)

    def _deserialize(self, payload: str | bytes) -> MemoryEntity:
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")
        data = json.loads(payload)
        return MemoryEntity(
            id=data["id"],
            agent_id=data["agent_id"],
            user_id=data["user_id"],
            session_id=data.get("session_id") or DEFAULT_SESSION_ID,
            kind=(data.get("kind") or "memory").lower(),
            content=data["content"],
            metadata=data.get("metadata") or {},
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )

    @staticmethod
    def _decode(value: str | bytes) -> str:
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return value

    async def _trim_to_limit(self, key: str, data_key: str, limit: int) -> None:
        if limit <= 0:
            return
        overflow = await await_with_timeout(self._redis.zrange(key, 0, -limit - 1), self._timeout)
        if not overflow:
            return
        ids = [self._decode(value) for value in overflow]
        await await_with_timeout(self._redis.zrem(key, *ids), self._timeout)
        await await_with_timeout(self._redis.hdel(data_key, *ids), self._timeout)
