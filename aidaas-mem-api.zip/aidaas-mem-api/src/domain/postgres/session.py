from collections.abc import AsyncGenerator
from typing import Any, Optional

from sqlalchemy import text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from ...core.config import get_settings
from .base import Base

try:
    from asyncpg.exceptions import InsufficientPrivilegeError as _AsyncpgPrivilegeError
except Exception:
    _AsyncpgPrivilegeError = None

_engine: Optional[AsyncEngine] = None
_session_factory: Optional[async_sessionmaker[AsyncSession]] = None


def build_engine() -> AsyncEngine:
    """Create a new async SQLAlchemy engine."""

    settings = get_settings()
    database_dsn = settings.database_dsn
    schema = settings.database_schema
    timeout = settings.operation_timeout_seconds
    url = make_url(database_dsn)
    connect_args: dict[str, Any] = {}

    if url.drivername.startswith("postgresql"):
        connect_args = {"timeout": timeout, "command_timeout": timeout}
        if schema:
            search_path = f"{schema},public"
            connect_args["server_settings"] = {"search_path": search_path}
    elif url.drivername.startswith("sqlite"):
        connect_args = {"timeout": timeout}

    Base.metadata.schema = schema or None

    engine = create_async_engine(
        database_dsn,
        echo=False,
        future=True,
        connect_args=connect_args,
        pool_timeout=timeout,
    )
    return engine


def get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        _engine = build_engine()
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(get_engine(), expire_on_commit=False, class_=AsyncSession)
    return _session_factory


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that provides an async session."""

    session_factory = get_session_factory()
    async with session_factory() as session:
        yield session


async def init_db() -> None:
    """Initialize database schema."""

    engine = get_engine()
    settings = get_settings()
    schema = settings.database_schema

    async def _execute_optional(statement: str) -> None:
        async with engine.connect() as conn:
            try:
                await conn.execute(text(statement))
            except Exception as exc:  # pragma: no cover - defensive for managed DBs
                privilege_error = _AsyncpgPrivilegeError and isinstance(exc, _AsyncpgPrivilegeError)
                denied = "permission denied" in str(exc).lower()
                if not (privilege_error or denied):
                    raise
                await conn.rollback()
            else:
                await conn.commit()

    if engine.dialect.name == "postgresql" and schema:
        safe_schema = schema.replace('"', '""')
        await _execute_optional(f'CREATE SCHEMA IF NOT EXISTS "{safe_schema}"')

    if engine.dialect.name == "postgresql":
        await _execute_optional("CREATE EXTENSION IF NOT EXISTS vector")

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def dispose_engine() -> None:
    """Dispose of the engine; useful for testing."""

    global _engine, _session_factory

    if _session_factory is not None:
        _session_factory = None

    if _engine is not None:
        await _engine.dispose()
        _engine = None
