from __future__ import annotations

import json
from collections.abc import Iterable, Sequence
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.application.clients.embeddings import EmbeddingClient

from .models import LangMemMemoryModel


def _namespace_hash(namespace: tuple[str, ...]) -> str:
    return json.dumps(list(namespace), separators=(",", ":"))


def _cosine_similarity(vector_a: Sequence[float] | None, vector_b: Sequence[float] | None) -> float | None:
    if vector_a is None or vector_b is None:
        return None
    if len(vector_a) == 0 or len(vector_b) == 0:
        return None
    if len(vector_a) != len(vector_b):
        return None
    dot = sum(float(a) * float(b) for a, b in zip(vector_a, vector_b))
    norm_a = sum(float(a) * float(a) for a in vector_a) ** 0.5
    norm_b = sum(float(b) * float(b) for b in vector_b) ** 0.5
    denom = norm_a * norm_b
    if denom == 0:
        return None
    return dot / denom


class LangMemStoreRepository:
    """Repository translating LangGraph store operations to Postgres."""

    def __init__(
        self,
        session: AsyncSession,
        embedding_client: EmbeddingClient,
        timeout_seconds: float,
    ) -> None:
        self._session = session
        self._embedding_client = embedding_client

    async def upsert(
        self,
        namespace: tuple[str, ...],
        key: str,
        value: dict[str, Any],
    ) -> None:
        record = await self._get_record(namespace, key)
        now = datetime.utcnow()
        content = value.get("content")
        summary_id = value.get("summary_id", None)
        valid_until = value.get("valid_until", None)
        kind = value.get("kind", "Memory")
        embedding = await self._embed_content(content)

        if record is None:
            record = LangMemMemoryModel(
                namespace_hash=_namespace_hash(namespace),
                key=key,
                namespace_path=list(namespace),
                kind=str(kind),
                content=content,
                summary_id=summary_id,
                embedding=embedding,
                valid_until=valid_until,
            )
            self._session.add(record)
        else:
            record.kind = str(kind)
            record.content = content
            record.summary_id = summary_id
            record.embedding = embedding
            record.valid_until = valid_until
            record.updated_at = now

        await self._session.flush()

    async def delete(self, namespace: tuple[str, ...], key: str) -> None:
        record = await self._get_record(namespace, key)
        if record is not None:
            await self._session.delete(record)

    async def get(self, namespace: tuple[str, ...], key: str) -> LangMemMemoryModel | None:
        return await self._get_record(namespace, key)

    async def search(
        self,
        namespace_prefix: tuple[str, ...],
        query: str | None,
        limit: int,
    ) -> list[tuple[LangMemMemoryModel, float | None]]:
        stmt = select(LangMemMemoryModel)
        result = await self._session.execute(stmt)
        records: Iterable[LangMemMemoryModel] = result.scalars().all()

        filtered: list[LangMemMemoryModel] = []
        for record in records:
            ns = tuple(record.namespace_path)
            if ns[: len(namespace_prefix)] == namespace_prefix:
                filtered.append(record)

        if not query:
            return [(record, None) for record in filtered[:limit]]

        query_embedding = await self._embed_text(query)
        if query_embedding is None:
            return [(record, None) for record in filtered[:limit]]

        scored: list[tuple[float, LangMemMemoryModel]] = []
        for record in filtered:
            if record.embedding is None:
                continue
            score = _cosine_similarity(query_embedding, record.embedding)
            if score is None:
                continue
            scored.append((score, record))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [(record, score) for score, record in scored[:limit]]

    async def list_namespaces(self) -> list[tuple[str, ...]]:
        stmt = select(LangMemMemoryModel.namespace_path).distinct()
        result = await self._session.execute(stmt)
        entries = result.scalars().all()
        return [tuple(entry) for entry in entries]

    async def _get_record(self, namespace: tuple[str, ...], key: str) -> LangMemMemoryModel | None:
        stmt = select(LangMemMemoryModel).where(
            LangMemMemoryModel.namespace_hash == _namespace_hash(namespace),
            LangMemMemoryModel.key == key,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def _embed_content(self, content: Any) -> list[float] | None:
        if content is None:
            return None
        if isinstance(content, str):
            text = content
        else:
            text = json.dumps(content, ensure_ascii=False, sort_keys=True)
        return await self._embed_text(text)

    async def _embed_text(self, text: str) -> list[float] | None:
        if not text:
            return None
        embedding = await self._embedding_client.embed(text)
        if embedding is None:
            return None
        return [float(value) for value in embedding]
