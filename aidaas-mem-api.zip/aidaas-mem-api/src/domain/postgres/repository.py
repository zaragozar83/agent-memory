# src/domain/postgres/repository.py

from __future__ import annotations

from collections.abc import Sequence
from contextlib import asynccontextmanager
from datetime import datetime

from sqlalchemy import and_, cast, delete, select, update
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import Select
from sqlalchemy import String

from src.core.config import get_settings

from ..entities.memory import DEFAULT_SESSION_ID, MemoryEntity, MemorySearchHit
from .models import MemoryModel


class MemoryRepository:
    def __init__(self, session: AsyncSession, timeout_seconds: float | None = None):
        self._session = session
        settings = get_settings()
        configured_timeout = settings.operation_timeout_seconds
        self._timeout = min(timeout_seconds, configured_timeout) if (timeout_seconds or 0) > 0 else configured_timeout

    async def create(self, memory: MemoryEntity) -> MemoryEntity:
        model = MemoryModel(
            id=memory.id,
            agent_id=memory.agent_id,
            user_id=memory.user_id,
            session_id=memory.session_id or DEFAULT_SESSION_ID,
            kind=memory.kind,
            summary_id=memory.summary_id,
            content=memory.content,
            metadata_json=memory.metadata,
            embedding=memory.embedding,
        )
        async with self._transaction():
            self._session.add(model)
        await self._session.refresh(model)
        return self._to_entity(model)

    async def get(self, memory_id: str) -> MemoryEntity | None:
        query = select(MemoryModel).where(MemoryModel.id == memory_id)
        result = await self._session.execute(query)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_recent(
        self,
        agent_id: str,
        user_id: str | None,
        limit: int = 20,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> Sequence[MemoryEntity]:
        query = self._base_query(agent_id, user_id, session_id, kind)
        query = query.order_by(MemoryModel.created_at.desc()).limit(limit)

        result = await self._session.execute(query)
        models = result.scalars().all()
        return [self._to_entity(m) for m in models]

    async def search_by_embedding(
        self,
        *,
        agent_id: str,
        user_id: str | None,
        query_embedding: Sequence[float],
        limit: int,
        session_id: str | None = None,
        min_similarity: float | None = None,
        kind: str | None = None,
    ) -> Sequence[MemorySearchHit]:
        if limit <= 0:
            return []

        distance_expr = MemoryModel.embedding.cosine_distance(query_embedding)

        query: Select[tuple[MemoryModel]] = (
            select(MemoryModel, distance_expr.label("distance"))
            .where(MemoryModel.embedding.isnot(None))
            .where(MemoryModel.agent_id == agent_id)
        )

        if user_id is not None:
            query = query.where(MemoryModel.user_id == user_id)

        if session_id is not None:
            query = query.where(MemoryModel.session_id == session_id)
        if kind is not None:
            query = query.where(MemoryModel.kind == kind)

        if min_similarity is not None:
            max_distance = 1.0 - min_similarity
            if max_distance < 0:
                return []
            query = query.where(distance_expr <= max_distance)

        query = query.order_by(distance_expr.asc()).limit(limit)

        result = await self._session.execute(query)
        hits: list[MemorySearchHit] = []
        for model, distance in result.all():
            if distance is None:
                continue
            similarity = 1.0 - float(distance)
            hits.append(MemorySearchHit(memory=self._to_entity(model), similarity=similarity))
        return hits

    async def update(self, memory: MemoryEntity) -> MemoryEntity | None:
        stmt = (
            update(MemoryModel)
            .where(MemoryModel.id == memory.id)
            .values(
                content=memory.content,
                metadata_json=memory.metadata,
                session_id=memory.session_id or DEFAULT_SESSION_ID,
                kind=memory.kind,
                embedding=memory.embedding,
            )
            .returning(MemoryModel)
        )
        async with self._transaction():
            result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def update_memory_retention_metadata(
        self, summary: MemoryEntity, valid_until: datetime | None, window: Sequence[MemoryEntity]
    ) -> bool:
        stmt = (
            update(MemoryModel)
            .where(MemoryModel.id.in_([mem.id for mem in window]))
            .values(summary_id=summary.id, valid_until=valid_until)
        )
        async with self._transaction():
            result = await self._session.execute(stmt)
        return (result.rowcount or 0) > 0

    async def rollback_update_memory_retention_metadata(self, window: Sequence[MemoryEntity]):
        stmt = (
            update(MemoryModel)
            .where(MemoryModel.id.in_([mem.id for mem in window]))
            .values(summary_id=None, valid_until=None)
        )
        async with self._transaction():
            result = await self._session.execute(stmt)
        return (result.rowcount or 0) > 0

    async def delete(self, memory_id: str) -> bool:
        stmt = delete(MemoryModel).where(MemoryModel.id == memory_id)
        async with self._transaction():
            result = await self._session.execute(stmt)
        return (result.rowcount or 0) > 0

    async def search_by_metadata(
        self,
        *,
        agent_id: str,
        metadata: dict,
        limit: int,
        user_id: str | None = None,
        session_id: str | None = None,
        kind: str | None = None,
        match_mode: str = "exact",
    ) -> Sequence[MemoryEntity]:
        if limit <= 0 or not metadata:
            return []

        query = self._base_query(agent_id, user_id, session_id, kind)
        query = query.where(MemoryModel.metadata_json.isnot(None))
        bind = self._session.get_bind()
        is_postgres = bind is not None and bind.dialect.name == "postgresql"
        mode = (match_mode or "exact").strip().lower()
        if mode == "contains":
            if is_postgres:
                clauses = []
                for key, value in metadata.items():
                    field = cast(MemoryModel.metadata_json[key], String)
                    clauses.append(field.ilike(f"%{value}%"))
                if clauses:
                    query = query.where(and_(*clauses))
        else:
            if is_postgres:
                query = query.where(cast(MemoryModel.metadata_json, JSONB).op("@>")(cast(metadata, JSONB)))
            else:
                query = query.where(MemoryModel.metadata_json.contains(metadata))

        query = query.order_by(MemoryModel.created_at.desc()).limit(limit if mode != "contains" or is_postgres else limit * 3)

        result = await self._session.execute(query)
        models = result.scalars().all()
        entities = [self._to_entity(m) for m in models]

        if mode == "contains" and not is_postgres:
            filtered: list[MemoryEntity] = []
            for entity in entities:
                meta = entity.metadata or {}
                if all(str(meta.get(key, "")).lower().find(str(value).lower()) != -1 for key, value in metadata.items()):
                    filtered.append(entity)
            return filtered[:limit]

        return entities

    def _to_entity(self, model: MemoryModel) -> MemoryEntity:
        return MemoryEntity(
            id=model.id,
            user_id=model.user_id,
            agent_id=model.agent_id,
            session_id=model.session_id or DEFAULT_SESSION_ID,
            kind=(model.kind or "memory").lower(),
            content=model.content,
            summary_id=model.summary_id,
            metadata=model.metadata_json or {},
            embedding=model.embedding,
            created_at=model.created_at,
            updated_at=model.updated_at,
            valid_until=model.valid_until,
        )

    async def list_for_search(
        self,
        agent_id: str,
        user_id: str | None,
        limit: int,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> Sequence[MemoryEntity]:
        query = self._base_query(agent_id, user_id, session_id, kind)
        query = query.order_by(MemoryModel.created_at.desc()).limit(limit)

        result = await self._session.execute(query)
        models = result.scalars().all()
        return [self._to_entity(m) for m in models]

    async def get_last_summary(
        self,
        agent_id: str,
        user_id: str | None,
        session_id: str | None = None,
    ) -> MemoryEntity | None:
        query = self._base_query(agent_id, user_id, session_id, "summary")
        query = query.order_by(MemoryModel.created_at.desc()).limit(50)

        result = await self._session.execute(query)
        models = result.scalars().all()
        for model in models:
            if (model.metadata_json or {}).get("kind") == "summary":
                return self._to_entity(model)
        return None

    async def get_memories_to_cleanup(self) -> Sequence[MemoryEntity]:
        current_datetime = datetime.now()
        query = select(MemoryModel)
        query = query.where(MemoryModel.valid_until < current_datetime).where(MemoryModel.summary_id.isnot(None))

        result = await self._session.execute(query)
        models = result.scalars().all()
        return [self._to_entity(m) for m in models]

    async def list_window(
        self,
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        start: datetime | None,
        end: datetime | None,
    ) -> Sequence[MemoryEntity]:
        query = self._base_query(agent_id, user_id, session_id, None)
        if start is not None:
            query = query.where(MemoryModel.created_at > start)
        if end is not None:
            query = query.where(MemoryModel.created_at <= end)
        query = query.order_by(MemoryModel.created_at.asc())

        result = await self._session.execute(query)
        models = result.scalars().all()
        return [self._to_entity(m) for m in models if m.kind != "summary"]

    @staticmethod
    def _base_query(
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        kind: str | None,
    ) -> Select[tuple[MemoryModel]]:
        query = select(MemoryModel).where(MemoryModel.agent_id == agent_id)
        if user_id is not None:
            query = query.where(MemoryModel.user_id == user_id)
        if session_id is not None:
            query = query.where(MemoryModel.session_id == session_id)
        if kind is not None:
            query = query.where(MemoryModel.kind == kind)
        return query

    @asynccontextmanager
    async def _transaction(self):
        current_tx = self._session.get_transaction()

        if current_tx is None:
            async with self._session.begin():
                yield
            return

        if current_tx.nested:
            async with self._session.begin_nested():
                yield
            return

        try:
            yield
            await self._session.commit()
        except Exception:
            await self._session.rollback()
            raise
