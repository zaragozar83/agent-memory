"""Lightweight text utilities used across the application layer."""

from __future__ import annotations

import math


def estimate_tokens(text: str) -> int:
    """Return a rough token estimate for the given text.

    We approximate tokens by assuming ~4 characters per token, a common rule-of-thumb
    for GPT-style models. The result is intentionally conservative to avoid
    under-counting when enforcing summarization thresholds.
    """

    if not text:
        return 0
    normalized = text.strip()
    if not normalized:
        return 0
    return max(1, math.ceil(len(normalized) / 4))


__all__ = ["estimate_tokens"]
