from __future__ import annotations

import asyncio
from collections.abc import Awaitable
from typing import TypeVar

T = TypeVar("T")


async def await_with_timeout(awaitable: Awaitable[T], timeout: float | None) -> T:
    """Await the given awaitable, enforcing a timeout when configured."""
    if timeout is None or timeout <= 0:
        return await awaitable
    return await asyncio.wait_for(awaitable, timeout=timeout)
