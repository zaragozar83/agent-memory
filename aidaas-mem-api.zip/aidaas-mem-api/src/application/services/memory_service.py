from __future__ import annotations

from dataclasses import asdict
from typing import Iterable, Sequence

from src.application.clients.embeddings import EmbeddingClient
from src.application.clients.langmem import LangMemClient, LangMemSearchResult
from src.core.config import get_settings
from src.core.logging import get_logger
from src.domain.entities.memory import DEFAULT_MEMORY_KIND, DEFAULT_SESSION_ID, DEFAULT_USER_ID, MemoryEntity
from src.domain.postgres.repository import MemoryRepository
from src.domain.redis.memory_cache import MemoryCache

from ..dto import CreateMemoryInput, UpdateMemoryInput
from ..exceptions import LangMemIntegrationError, MemoryNotFoundError, SummaryGenerationError, SummaryWindowEmptyError
from .summary_manager import SummaryManager

logger = get_logger(__name__)


class MemoryService:
    """Application service orchestrating memory storage and retrieval."""

    def __init__(
        self,
        repository: MemoryRepository,
        cache: MemoryCache,
        embedding_client: EmbeddingClient,
        langmem_client: LangMemClient,
        summary_manager: SummaryManager | None = None,
    ) -> None:
        self._repository = repository
        self._cache = cache
        self._embedding_client = embedding_client
        self._langmem_client = langmem_client
        self._summary_manager = summary_manager
        settings = get_settings()
        self._search_candidate_limit = settings.semantic_search_candidate_limit
        self._similarity_threshold = settings.semantic_search_similarity_threshold

    async def create_memory(self, data: CreateMemoryInput) -> MemoryEntity:
        embedding = await self._embedding_client.embed(data.content) if data.content else None
        session_id = self._resolve_session(data.session_id)
        user_id = self._resolve_user(data.user_id)
        kind = self._resolve_kind(data.kind)
        memory = MemoryEntity(
            agent_id=data.agent_id,
            user_id=user_id,
            session_id=session_id,
            kind=kind,
            content=data.content,
            metadata=data.metadata,
            embedding=embedding,
        )
        stored = await self._repository.create(memory)
        await self._cache.add_memory(stored)
        try:
            await self._langmem_client.store_memory(stored)
        except LangMemIntegrationError as exc:
            await self._cache.remove_memory(stored)
            await self._repository.delete(stored.id)
            logger.error(
                "memory_create_failed_langmem",
                memory_id=stored.id,
                agent_id=stored.agent_id,
                user_id=stored.user_id,
                session_id=stored.session_id,
            )
            raise exc
        logger.info(
            "memory_created",
            memory_id=stored.id,
            agent_id=stored.agent_id,
            user_id=stored.user_id,
            session_id=stored.session_id,
        )
        if self._summary_manager is not None:
            await self._summary_manager.handle_new_memory(stored)
        return stored

    async def get_memory(self, memory_id: str) -> MemoryEntity:
        memory = await self._repository.get(memory_id)
        if memory is None:
            raise MemoryNotFoundError(memory_id)
        return memory

    async def get_memories_to_cleanup(self):
        memories = await self._repository.get_memories_to_cleanup()
        return memories

    async def list_recent_memories(
        self,
        agent_id: str,
        user_id: str | None,
        limit: int = 20,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> Sequence[MemoryEntity]:
        normalized_user = None if user_id is None else self._resolve_user(user_id)
        normalized_session = None if session_id is None else self._resolve_session(session_id)
        normalized_kind = None if kind is None else self._resolve_kind(kind)

        if normalized_user is None or normalized_session is None or normalized_kind is not None:
            return await self._repository.list_recent(
                agent_id, normalized_user, limit, normalized_session, normalized_kind
            )

        cached = await self._cache.get_recent_memories(agent_id, normalized_user, limit, normalized_session)
        if cached:
            return cached
        memories = await self._repository.list_recent(
            agent_id, normalized_user, limit, normalized_session, normalized_kind
        )
        for memory in memories:
            await self._cache.add_memory(memory)
        return memories

    async def refresh_summary(
        self,
        *,
        agent_id: str,
        store_user_id: str,
        scope_user_id: str | None = None,
        session_id: str | None = None,
        window_limit: int | None = None,
        retention_days: int | None = None,
    ) -> MemoryEntity:
        if self._summary_manager is None:
            raise SummaryGenerationError("Summary manager is not configured.")

        logger.info(
            "summary_manual_refresh_requested",
            agent_id=agent_id,
            scope_user=scope_user_id or "*",
            session_id=session_id or "*",
            window_limit=window_limit,
            store_user=store_user_id,
        )

        try:
            summary = await self._summary_manager.refresh_summary(
                agent_id=agent_id,
                store_user_id=store_user_id,
                scope_user_id=scope_user_id,
                session_id=session_id,
                window_limit=window_limit,
                retention_days=retention_days,
            )
        except SummaryWindowEmptyError as exc:
            logger.warning(
                "summary_manual_refresh_window_empty",
                agent_id=agent_id,
                scope_user=scope_user_id or "*",
                session_id=session_id or "*",
                store_user=store_user_id,
            )
            raise exc
        except SummaryGenerationError as exc:
            logger.error(
                "summary_manual_refresh_generation_failed",
                agent_id=agent_id,
                scope_user=scope_user_id or "*",
                session_id=session_id or "*",
                store_user=store_user_id,
            )
            raise exc
        except LangMemIntegrationError as exc:
            logger.error(
                "summary_manual_refresh_sync_failed",
                agent_id=agent_id,
                scope_user=scope_user_id or "*",
                session_id=session_id or "*",
                store_user=store_user_id,
            )
            raise exc

        logger.info(
            "summary_manual_refresh_completed",
            agent_id=summary.agent_id,
            user_id=summary.user_id,
            session_id=summary.session_id,
            summary_id=summary.id,
        )
        return summary

    async def update_memory(self, memory_id: str, data: UpdateMemoryInput) -> MemoryEntity:
        memory = await self._repository.get(memory_id)
        if memory is None:
            raise MemoryNotFoundError(memory_id)

        original_state = MemoryEntity(**asdict(memory))

        if data.content is not None:
            memory.content = data.content
            memory.embedding = await self._embedding_client.embed(data.content)
        if data.metadata is not None:
            memory.metadata = data.metadata
        if data.session_id is not None:
            memory.session_id = self._resolve_session(data.session_id)
        if data.kind is not None:
            memory.kind = self._resolve_kind(data.kind)

        memory.touch()
        updated = await self._repository.update(memory)
        if updated is None:
            raise MemoryNotFoundError(memory_id)

        await self._cache.add_memory(updated)
        try:
            await self._langmem_client.store_memory(updated)
        except LangMemIntegrationError as exc:
            await self._repository.update(original_state)
            await self._cache.add_memory(original_state)
            logger.error(
                "memory_update_failed_langmem",
                memory_id=memory_id,
                agent_id=updated.agent_id,
                user_id=updated.user_id,
                session_id=updated.session_id,
            )
            raise exc
        logger.info(
            "memory_updated",
            memory_id=updated.id,
            agent_id=updated.agent_id,
            user_id=updated.user_id,
            session_id=updated.session_id,
        )
        return updated

    async def delete_memory(self, memory_id: str) -> None:
        memory = await self._repository.get(memory_id)
        if memory is None:
            raise MemoryNotFoundError(memory_id)

        try:
            await self._langmem_client.delete_memory(memory)
        except LangMemIntegrationError as exc:
            logger.error(
                "memory_delete_failed_langmem",
                memory_id=memory_id,
                agent_id=memory.agent_id,
                user_id=memory.user_id,
                session_id=memory.session_id,
            )
            raise exc

        deleted = await self._repository.delete(memory_id)
        if not deleted:
            try:
                await self._langmem_client.store_memory(memory)
            except LangMemIntegrationError:
                logger.critical(
                    "memory_delete_inconsistent",
                    memory_id=memory_id,
                    agent_id=memory.agent_id,
                    user_id=memory.user_id,
                    session_id=memory.session_id,
                )
            raise MemoryNotFoundError(memory_id)

        await self._cache.remove_memory(memory)
        logger.info(
            "memory_deleted",
            memory_id=memory_id,
            agent_id=memory.agent_id,
            user_id=memory.user_id,
            session_id=memory.session_id,
        )

    async def search_memories(
        self,
        agent_id: str,
        user_id: str | None,
        query: str,
        limit: int = 5,
        session_id: str | None = None,
        kind: str | None = None,
    ) -> Sequence[dict]:
        limit = max(1, limit)
        normalized_user = None if user_id is None else self._resolve_user(user_id)
        normalized_session = None if session_id is None else self._resolve_session(session_id)
        normalized_kind = None if kind is None else self._resolve_kind(kind)
        logger.info(
            "memory_search",
            agent_id=agent_id,
            user_id=normalized_user or "*",
            query=query,
            limit=limit,
            session_id=normalized_session or "*",
            kind=normalized_kind or "*",
        )
        langmem_results: Sequence[LangMemSearchResult] = []
        if normalized_user is not None and normalized_kind in (None, DEFAULT_MEMORY_KIND, "summary"):
            try:
                langmem_results = await self._langmem_client.search_memories(
                    agent_id=agent_id,
                    user_id=normalized_user,
                    session_id=normalized_session,
                    query=query,
                    limit=limit,
                )
            except LangMemIntegrationError as exc:
                logger.error(
                    "memory_search_failed_langmem",
                    agent_id=agent_id,
                    user_id=normalized_user,
                    session_id=normalized_session or "*",
                )
                raise exc

        enriched = await self._collect_langmem_results(langmem_results, limit, normalized_kind)
        if enriched:
            return enriched

        query_embedding = await self._embedding_client.embed(query)
        if query_embedding:
            hits = await self._repository.search_by_embedding(
                agent_id=agent_id,
                user_id=normalized_user,
                query_embedding=query_embedding,
                limit=self._search_candidate_limit,
                session_id=normalized_session,
                min_similarity=self._similarity_threshold,
                kind=normalized_kind,
            )
            if hits:
                top_hits = hits[:limit]
                await self._refresh_cache(hit.memory for hit in top_hits)
                return [self._to_search_result(hit.similarity, hit.memory) for hit in top_hits]

        candidates = await self._repository.list_for_search(
            agent_id,
            normalized_user,
            self._search_candidate_limit,
            normalized_session,
            normalized_kind,
        )

        query_lower = query.lower()
        filtered = [
            memory
            for memory in candidates
            if query_lower in memory.content.lower()
            or any(query_lower in str(value).lower() for value in (memory.metadata or {}).values())
        ][:limit]
        await self._refresh_cache(filtered)
        return [self._to_search_result(1.0, memory) for memory in filtered]

    async def search_memories_by_metadata(
        self,
        *,
        agent_id: str,
        metadata: dict,
        limit: int = 20,
        user_id: str | None = None,
        session_id: str | None = None,
        kind: str | None = None,
        match_mode: str = "exact",
    ) -> Sequence[dict]:
        limit = max(1, limit)
        normalized_user = None if user_id is None else self._resolve_user(user_id)
        normalized_session = None if session_id is None else self._resolve_session(session_id)
        normalized_kind = None if kind is None else self._resolve_kind(kind)
        mode = (match_mode or "exact").strip().lower()
        if mode not in {"exact", "contains"}:
            mode = "exact"
        metadata_keys = sorted(metadata.keys())
        logger.info(
            "memory_search_metadata",
            agent_id=agent_id,
            user_id=normalized_user or "*",
            session_id=normalized_session or "*",
            kind=normalized_kind or "*",
            metadata_keys=metadata_keys,
            limit=limit,
            match_mode=mode,
        )

        matched = await self._repository.search_by_metadata(
            agent_id=agent_id,
            metadata=metadata,
            limit=limit,
            user_id=normalized_user,
            session_id=normalized_session,
            kind=normalized_kind,
            match_mode=mode,
        )
        if not matched:
            return []
        await self._refresh_cache(matched)

        results: list[dict] = []
        for memory in matched:
            score = 1.0
            if mode == "contains":
                meta = memory.metadata or {}
                scores = []
                for key, value in metadata.items():
                    candidate = str(meta.get(key, "")).lower()
                    query_value = str(value).lower()
                    scores.append(self._substring_score(candidate, query_value))
                score = min(scores) if scores else 1.0
            results.append(self._to_search_result(score, memory))

        results.sort(key=lambda item: item["score"], reverse=True)
        return results[:limit]

    @staticmethod
    def _substring_score(candidate: str, query: str) -> float:
        if not query:
            return 0.0
        if not candidate:
            return 0.0
        cand_lower = candidate.lower()
        query_lower = query.lower()
        if query_lower == cand_lower:
            return 1.0
        if query_lower not in cand_lower:
            return 0.0
        return min(1.0, len(query_lower) / max(len(cand_lower), len(query_lower)))

    async def _collect_langmem_results(
        self,
        results: Sequence[LangMemSearchResult],
        limit: int,
        expected_kind: str | None,
    ) -> list[dict]:
        if not results:
            return []
        collected: list[dict] = []
        to_refresh: list[MemoryEntity] = []
        for item in results[:limit]:
            memory = await self._repository.get(item.memory_id)
            if memory is None:
                continue
            if expected_kind is not None and memory.kind != expected_kind:
                continue
            score = 1.0 if item.score is None else item.score
            collected.append(self._to_search_result(score, memory))
            to_refresh.append(memory)
        if to_refresh:
            await self._refresh_cache(to_refresh)
        return collected

    @staticmethod
    def _to_search_result(score: float, memory: MemoryEntity) -> dict:
        payload = asdict(memory)
        payload.pop("embedding", None)
        return {"memory": payload, "score": score}

    @staticmethod
    def _resolve_session(session_id: str | None) -> str:
        return session_id or DEFAULT_SESSION_ID

    @staticmethod
    def _resolve_user(user_id: str | None) -> str:
        return user_id or DEFAULT_USER_ID

    @staticmethod
    def _resolve_kind(kind: str | None) -> str:
        value = (kind or DEFAULT_MEMORY_KIND).strip().lower()
        return value or DEFAULT_MEMORY_KIND

    async def _refresh_cache(self, memories: Sequence[MemoryEntity] | Iterable[MemoryEntity]) -> None:
        for memory in memories:
            await self._cache.refresh(memory)
