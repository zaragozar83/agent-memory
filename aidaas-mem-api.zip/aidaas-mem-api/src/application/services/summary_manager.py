from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Sequence

from src.application.clients.embeddings import EmbeddingClient
from src.application.clients.langmem import LangMemClient
from src.application.clients.llm import LLMClient
from src.application.exceptions import LangMemIntegrationError, SummaryGenerationError, SummaryWindowEmptyError
from src.core.config import get_settings
from src.core.logging import get_logger
from src.domain.entities.memory import DEFAULT_SESSION_ID, MemoryEntity
from src.domain.postgres.repository import MemoryRepository
from src.domain.redis.memory_cache import MemoryCache
from src.utils.text import estimate_tokens

logger = get_logger(__name__)


@dataclass(slots=True)
class SummaryTrigger:
    reason: str
    window_start: datetime
    window_end: datetime
    memory_count: int
    token_count: int


@dataclass(slots=True)
class SummaryWindowStats:
    start: datetime
    end: datetime
    count: int
    tokens: int


class SummaryManager:
    """Coordinates automatic summarization of conversation windows."""

    def __init__(
        self,
        *,
        repository: MemoryRepository,
        cache: MemoryCache,
        embedding_client: EmbeddingClient,
        langmem_client: LangMemClient,
        llm_client: LLMClient,
        count_threshold: int | None = None,
        token_threshold: int | None = None,
        time_threshold_seconds: int | None = None,
        enabled: bool | None = None,
        default_retention_days: int | None = None,
    ) -> None:
        settings = get_settings()
        self._repository = repository
        self._cache = cache
        self._embedding_client = embedding_client
        self._langmem_client = langmem_client
        self._llm_client = llm_client
        self._count_threshold = count_threshold or settings.summary_count_threshold
        self._token_threshold = token_threshold or settings.summary_token_threshold
        self._time_threshold_seconds = time_threshold_seconds or settings.summary_time_threshold_seconds
        self._enabled = settings.auto_summary_enabled if enabled is None else enabled
        self._default_retention_days = (
            settings.default_retention_days if default_retention_days is None else default_retention_days
        )

    async def handle_new_memory(self, memory: MemoryEntity) -> None:
        if not self._enabled:
            return
        if self._is_summary(memory):
            return

        window, trigger = await self._evaluate_window(memory)
        if trigger is None or not window:
            return

        summary_text = await self._generate_summary(memory, window)
        if not summary_text:
            logger.warning(
                "summary_generation_empty",
                agent_id=memory.agent_id,
                user_id=memory.user_id,
                session_id=memory.session_id,
                reason=trigger.reason,
            )
            return

        stats = self._gather_window_stats(window)
        metadata = self._build_summary_metadata(
            window=window,
            stats=stats,
            trigger_reason=trigger.reason,
            window_end_override=memory.created_at,
        )
        await self._persist_summary(
            agent_id=memory.agent_id,
            user_id=memory.user_id,
            session_id=memory.session_id,
            content=summary_text,
            metadata=metadata,
            trigger_reason=trigger.reason,
            window=window,
        )

    async def _evaluate_window(self, memory: MemoryEntity) -> tuple[Sequence[MemoryEntity], SummaryTrigger | None]:
        last_summary = await self._repository.get_last_summary(memory.agent_id, memory.user_id, memory.session_id)
        start = last_summary.created_at if last_summary else None
        window = await self._repository.list_window(
            memory.agent_id, memory.user_id, memory.session_id, start, memory.created_at
        )
        if not window:
            return window, None

        stats = self._gather_window_stats(window)
        baseline = last_summary.created_at if last_summary else stats.start
        elapsed = (memory.created_at - baseline).total_seconds()

        reason = None
        if stats.count >= self._count_threshold:
            reason = "count"
        elif stats.tokens >= self._token_threshold:
            reason = "tokens"
        elif elapsed >= self._time_threshold_seconds:
            reason = "time"

        trigger = (
            SummaryTrigger(
                reason=reason,
                window_start=stats.start,
                window_end=memory.created_at,
                memory_count=stats.count,
                token_count=stats.tokens,
            )
            if reason
            else None
        )
        return window, trigger

    async def refresh_summary(
        self,
        *,
        agent_id: str,
        store_user_id: str,
        scope_user_id: str | None,
        session_id: str | None,
        window_limit: int | None = None,
        retention_days: int | None = None,
    ) -> MemoryEntity:
        last_summary = await self._repository.get_last_summary(agent_id, scope_user_id, session_id)
        start = last_summary.created_at if last_summary else None
        window = await self._repository.list_window(agent_id, scope_user_id, session_id, start, None)
        used_full_history = False
        if not window and last_summary is not None:
            window = await self._repository.list_window(agent_id, scope_user_id, session_id, None, None)
            used_full_history = bool(window)
        if not window:
            logger.warning(
                "summary_manual_refresh_empty",
                agent_id=agent_id,
                scope_user=scope_user_id or "*",
                session_id=session_id,
            )
            raise SummaryWindowEmptyError("No memories available for manual summary refresh.")

        if window_limit is not None and window_limit > 0 and window_limit < len(window):
            window = window[-window_limit:]

        anchor = window[-1]
        stats = self._gather_window_stats(window)
        summary_text = await self._generate_summary(anchor, window)
        if not summary_text:
            logger.warning(
                "summary_generation_empty",
                agent_id=agent_id,
                scope_user=scope_user_id or "*",
                session_id=session_id,
                reason="manual",
            )
            raise SummaryGenerationError("Manual summary refresh produced empty content.")

        extra_metadata: dict[str, Any] = {"manual": True}
        if window_limit is not None and window_limit > 0:
            extra_metadata["manual_window_limit"] = window_limit
        if last_summary:
            extra_metadata["previous_summary_id"] = last_summary.id
        if used_full_history:
            extra_metadata["manual_full_history"] = True
        if scope_user_id is None:
            extra_metadata["manual_all_users"] = True
        if session_id is None:
            extra_metadata["manual_all_sessions"] = True

        metadata = self._build_summary_metadata(
            window=window,
            stats=stats,
            trigger_reason="manual",
            window_end_override=anchor.created_at,
            extra=extra_metadata,
        )

        return await self._persist_summary(
            agent_id=agent_id,
            user_id=store_user_id,
            session_id=session_id or DEFAULT_SESSION_ID,
            content=summary_text,
            metadata=metadata,
            trigger_reason="manual",
            window=window,
            retention_days=retention_days,
        )

    async def _generate_summary(self, memory: MemoryEntity, window: Sequence[MemoryEntity]) -> str:
        prompt_lines = [
            (
                "Create a concise summary of the following agent memories. "
                "Focus on actionable facts, preferences, or commitments."
            ),
            "Use bullet points and keep the summary under 120 words.",
            """
            Memories:
            """.strip(),
        ]
        for item in window:
            metadata = item.metadata or {}
            label = metadata.get("topic") or metadata.get("type") or "memory"
            prompt_lines.append(f"- [{item.created_at.isoformat()}] ({label}) {item.content}")
        prompt_lines.append(
            """
            Desired format:
            - Bullet 1
            - Bullet 2
            """.strip()
        )

        messages = [
            {
                "role": "system",
                "content": "You summarize agent memories into concise bullet points without inventing facts.",
            },
            {"role": "user", "content": "\n".join(prompt_lines)},
        ]

        try:
            summary = await self._llm_client.generate(messages=messages, temperature=0.0)
        except Exception as exc:  # pragma: no cover - defensive
            logger.error(
                "summary_generation_failed",
                agent_id=memory.agent_id,
                user_id=memory.user_id,
                session_id=memory.session_id,
                error=str(exc),
            )
            return ""
        return summary.strip()

    @staticmethod
    def _gather_window_stats(window: Sequence[MemoryEntity]) -> SummaryWindowStats:
        return SummaryWindowStats(
            start=window[0].created_at,
            end=window[-1].created_at,
            count=len(window),
            tokens=sum(estimate_tokens(item.content) for item in window),
        )

    @staticmethod
    def _build_summary_metadata(
        *,
        window: Sequence[MemoryEntity],
        stats: SummaryWindowStats,
        trigger_reason: str,
        window_end_override: datetime | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        window_end = window_end_override or stats.end
        metadata: dict[str, Any] = {
            "kind": "summary",
            "trigger_reason": trigger_reason,
            "window_start": stats.start.isoformat(),
            "window_end": window_end.isoformat(),
            "memory_count": stats.count,
            "token_count": stats.tokens,
            "source_memory_ids": [item.id for item in window],
        }
        if extra:
            metadata.update(extra)
        return metadata

    async def _persist_summary(
        self,
        *,
        agent_id: str,
        user_id: str,
        session_id: str,
        content: str,
        metadata: dict[str, Any],
        trigger_reason: str,
        window: Sequence[MemoryEntity],
        retention_days: int | None = None,
    ) -> MemoryEntity:
        embedding = await self._embedding_client.embed(content)
        summary_memory = MemoryEntity(
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            kind="summary",
            content=content,
            metadata=metadata,
            embedding=embedding,
        )

        stored = await self._repository.create(summary_memory)
        await self._cache.add_memory(stored)

        # Update summary id and retention date
        current_date = datetime.now()
        memory_retention_days = self._default_retention_days if retention_days is None else retention_days
        valid_until = current_date + timedelta(days=memory_retention_days) if memory_retention_days >= 0 else None

        await self._repository.update_memory_retention_metadata(summary=stored, valid_until=valid_until, window=window)

        try:
            await self._langmem_client.store_memory(stored)
            await self._langmem_client.update_memory_retention_metadata(
                summary=stored, window=window, valid_until=valid_until
            )
        except LangMemIntegrationError:
            await self._cache.remove_memory(stored)
            await self._repository.delete(stored.id)
            await self._repository.rollback_update_memory_retention_metadata(window)
            logger.error(
                "summary_sync_failed_langmem",
                agent_id=agent_id,
                user_id=user_id,
                session_id=session_id,
                memory_id=stored.id,
            )
            raise

        logger.info(
            "summary_created",
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            summary_id=stored.id,
            trigger=trigger_reason,
        )
        return stored

    @staticmethod
    def _is_summary(memory: MemoryEntity) -> bool:
        return memory.kind == "summary"


__all__ = ["SummaryManager", "SummaryTrigger"]
