from __future__ import annotations

import asyncio
import math
from dataclasses import dataclass
from typing import Any, Protocol, cast

import httpx

from src.core.config import get_settings
from src.core.logging import get_logger
from src.utils.asyncio import await_with_timeout

logger = get_logger(__name__)


class EmbeddingClient(Protocol):
    async def embed(self, text: str) -> list[float] | None:
        """Return an embedding vector for a single piece of text."""


@dataclass
class HttpEmbeddingClient:
    """Embedding client for a HuggingFace/Azure-compatible `/v1/embeddings` endpoint."""

    base_url: str
    api_key: str
    model: str
    timeout_seconds: float
    batch_size: int = 8

    async def embed(self, text: str) -> list[float] | None:
        embeddings = await self._embed_batch([text])
        return embeddings[0] if embeddings else None

    async def _embed_batch(self, inputs: list[str]) -> list[list[float]]:
        if not inputs:
            return []

        url = f"{self.base_url}/v1/embeddings"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload: dict[str, Any] = {"model": self.model, "input": inputs}

        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            attempt = 0
            retries = 3
            backoff = 0.5
            cap = 10.0
            while True:
                attempt += 1
                try:
                    response = await await_with_timeout(
                        client.post(url, json=payload, headers=headers),
                        self.timeout_seconds,
                    )
                    response.raise_for_status()
                    data: dict[str, Any] = response.json()
                    embeddings: list[list[float]] = []
                    for item in data.get("data", []):
                        embedding = item.get("embedding")
                        if not isinstance(embedding, list):
                            raise ValueError("Embedding payload must include a list of floats.")
                        if embedding:
                            first_value = embedding[0]
                            if not isinstance(first_value, float):
                                raise ValueError("Embedding payload must include a list of floats.")
                        embeddings.append(cast(list[float], embedding))
                    return embeddings
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code >= 500 and attempt <= retries:
                        await asyncio.sleep(min(cap, backoff * (2 ** (attempt - 1))))
                        continue
                    raise
                except httpx.RequestError:
                    if attempt <= retries:
                        await asyncio.sleep(min(cap, backoff * (2 ** (attempt - 1))))
                        continue
                    raise


class NullEmbeddingClient:
    """No-op embedding client used when configuration is missing."""

    async def embed(self, text: str) -> list[float] | None:  # pragma: no cover - trivial
        return None


@dataclass
class LocalEmbeddingClient:
    """Deterministic, in-process embedding generator used for LOCAL environments."""

    dimension: int

    async def embed(self, text: str) -> list[float] | None:
        if self.dimension <= 0:
            return None
        vector = [0.0] * self.dimension
        if text:
            payload = text.encode("utf-8")
            for index, byte in enumerate(payload):
                vector[index % self.dimension] += float(byte)
            norm = math.sqrt(sum(value * value for value in vector))
            if norm > 0:
                vector = [value / norm for value in vector]
        return vector


def build_embedding_client() -> EmbeddingClient:
    settings = get_settings()
    if settings.environment.upper() == "LOCAL":
        logger.info("Using LocalEmbeddingClient because ENVIRONMENT=LOCAL")
        return LocalEmbeddingClient(dimension=settings.embedding_dimension)

    base_url = settings.embedding_base_url.rstrip("/")
    if not base_url:
        logger.warning("Embedding configuration missing; semantic search disabled")
        return NullEmbeddingClient()
    if not settings.embedding_api_key:
        logger.warning("Embedding API key missing; semantic search disabled")
        return NullEmbeddingClient()
    if not settings.embedding_model:
        logger.warning("Embedding model missing; semantic search disabled")
        return NullEmbeddingClient()

    return HttpEmbeddingClient(
        base_url=base_url,
        api_key=settings.embedding_api_key,
        model=settings.embedding_model,
        timeout_seconds=settings.operation_timeout_seconds,
        batch_size=settings.embedding_batch_size,
    )
