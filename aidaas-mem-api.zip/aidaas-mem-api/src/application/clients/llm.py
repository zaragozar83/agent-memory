"""Minimal chat-completions client used by LangGraph responders."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Protocol

import httpx

from src.core.config import get_settings
from src.core.logging import get_logger
from src.utils.asyncio import await_with_timeout

logger = get_logger(__name__)


class LLMClient(Protocol):
    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str: ...


@dataclass(slots=True)
class HttpLLMClient:
    base_url: str
    api_key: str
    model: str
    timeout_seconds: float
    default_max_tokens: int

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        url = f"{self.base_url}/v1/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens or self.default_max_tokens,
        }

        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            attempt = 0
            retries = 3
            backoff = 0.5
            cap = 8.0
            while True:
                attempt += 1
                try:
                    response = await await_with_timeout(
                        client.post(url, json=payload, headers=headers),
                        self.timeout_seconds,
                    )
                    response.raise_for_status()
                    data = response.json()
                    choices = data.get("choices") or []
                    if not choices:
                        raise ValueError("LLM response missing choices")
                    message = choices[0].get("message") or {}
                    content = message.get("content")
                    if not isinstance(content, str):
                        raise ValueError("LLM response missing assistant content")
                    return content
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code >= 500 and attempt <= retries:
                        await asyncio.sleep(min(cap, backoff * (2 ** (attempt - 1))))
                        continue
                    raise
                except httpx.RequestError:
                    if attempt <= retries:
                        await asyncio.sleep(min(cap, backoff * (2 ** (attempt - 1))))
                        continue
                    raise


class NullLLMClient:
    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:  # pragma: no cover - trivial
        last_user = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), "")
        return f"Echoing your request: {last_user}" if last_user else "Echoing your request."


def build_llm_client() -> LLMClient:
    settings = get_settings()
    base_url = settings.embedding_base_url.rstrip("/")
    api_key = settings.embedding_api_key
    model = settings.llm_model or "gpt-oss-20b"

    if not base_url or not api_key:
        logger.warning("LLM configuration missing; defaulting to echo responder")
        return NullLLMClient()

    return HttpLLMClient(
        base_url=base_url,
        api_key=api_key,
        model=model,
        timeout_seconds=settings.operation_timeout_seconds,
        default_max_tokens=settings.llm_max_tokens,
    )


__all__ = ["LLMClient", "build_llm_client"]
