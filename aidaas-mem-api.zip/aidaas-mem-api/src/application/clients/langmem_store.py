from __future__ import annotations

from collections.abc import Iterable

from langgraph.store.base import (
    BaseStore,
    GetOp,
    Item,
    ListNamespacesOp,
    MatchCondition,
    Op,
    PutOp,
    Result,
    SearchItem,
    SearchOp,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.application.clients.embeddings import EmbeddingClient
from src.core.config import get_settings
from src.domain.postgres.langmem_repository import LangMemStoreRepository
from src.utils.asyncio import await_with_timeout


class PgVectorLangGraphStore(BaseStore):
    """LangGraph store adapter backed by the project's Postgres layer."""

    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        embedding_client: EmbeddingClient,
    ) -> None:
        self._session_factory = session_factory
        self._embedding_client = embedding_client
        self._settings = get_settings()

    def batch(self, ops: Iterable[Op]) -> list[Result]:  # pragma: no cover - sync path unused
        raise NotImplementedError("Synchronous store operations are not supported.")

    async def abatch(self, ops: Iterable[Op]) -> list[Result]:
        async with self._session_factory() as session:
            repo = LangMemStoreRepository(
                session,
                embedding_client=self._embedding_client,
                timeout_seconds=self._settings.operation_timeout_seconds,
            )
            results: list[Result] = []
            for op in ops:
                if isinstance(op, GetOp):
                    record = await repo.get(op.namespace, op.key)
                    if record is None:
                        results.append(None)
                    else:
                        results.append(
                            Item(
                                namespace=tuple(record.namespace_path),
                                key=record.key,
                                value={"kind": record.kind, "content": record.content},
                                created_at=record.created_at,
                                updated_at=record.updated_at,
                            )
                        )
                elif isinstance(op, PutOp):
                    if op.value is None:
                        await repo.delete(op.namespace, op.key)
                        results.append(None)
                    else:
                        await repo.upsert(op.namespace, op.key, op.value)
                        results.append(None)
                elif isinstance(op, SearchOp):
                    records = await repo.search(op.namespace_prefix, op.query, op.limit)
                    items: list[SearchItem] = [
                        SearchItem(
                            namespace=tuple(record.namespace_path),
                            key=record.key,
                            value={"kind": record.kind, "content": record.content},
                            created_at=record.created_at,
                            updated_at=record.updated_at,
                            score=score,
                        )
                        for record, score in records
                    ]
                    results.append(items)
                elif isinstance(op, ListNamespacesOp):
                    namespaces = await repo.list_namespaces()
                    filtered = _apply_namespace_filters(namespaces, op)
                    results.append(filtered)
                else:  # pragma: no cover - defensive path
                    raise NotImplementedError(f"Unsupported operation: {op}")
            await await_with_timeout(session.commit(), self._settings.operation_timeout_seconds)
            return results


def _apply_namespace_filters(namespaces: list[tuple[str, ...]], op: ListNamespacesOp) -> list[tuple[str, ...]]:
    if not op.match_conditions:
        candidates = namespaces
    else:
        candidates = []
        for namespace in namespaces:
            if _matches_conditions(namespace, op.match_conditions):
                candidates.append(namespace)

    if op.max_depth is not None:
        candidates = [namespace[: op.max_depth] for namespace in candidates]

    start = op.offset
    end = op.offset + op.limit if op.limit else None
    return candidates[start:end]


def _matches_conditions(namespace: tuple[str, ...], conditions: tuple[MatchCondition, ...]) -> bool:
    for condition in conditions:
        if condition.match_type == "prefix":
            if namespace[: len(condition.path)] != condition.path:
                return False
        elif condition.match_type == "suffix":
            if namespace[-len(condition.path) :] != condition.path:
                return False
        else:  # pragma: no cover - defensive
            return False
    return True


__all__ = ["PgVectorLangGraphStore"]
