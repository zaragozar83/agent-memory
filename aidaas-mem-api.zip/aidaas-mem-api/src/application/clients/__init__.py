"""Client helpers used by the application layer."""
