from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Sequence

from langgraph.store.base import SearchItem

from src.application.clients.embeddings import EmbeddingClient, build_embedding_client
from src.application.clients.langmem_store import PgVectorLangGraphStore
from src.application.exceptions import LangMemIntegrationError
from src.core.config import get_settings
from src.core.logging import get_logger
from src.domain.entities.memory import DEFAULT_SESSION_ID, MemoryEntity
from src.domain.postgres.session import get_session_factory

logger = get_logger(__name__)


@dataclass(slots=True)
class LangMemSearchResult:
    memory_id: str
    score: float | None
    raw: dict[str, Any] | None = None


class LangMemClient:
    @property
    def enabled(self) -> bool:
        raise NotImplementedError

    async def store_memory(self, memory: MemoryEntity) -> None:
        raise NotImplementedError

    async def delete_memory(self, memory: MemoryEntity) -> None:
        raise NotImplementedError

    async def update_memory_retention_metadata(
        self, summary: MemoryEntity, valid_until: datetime | None, window: Sequence[MemoryEntity]
    ) -> bool:
        raise NotImplementedError

    async def search_memories(
        self,
        *,
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        query: str,
        limit: int,
    ) -> Sequence[LangMemSearchResult]:
        raise NotImplementedError


class LangMemStoreClient(LangMemClient):
    def __init__(self, store: PgVectorLangGraphStore) -> None:
        self._store = store
        self._settings = get_settings()

    @property
    def enabled(self) -> bool:
        return True

    async def store_memory(self, memory: MemoryEntity) -> None:
        namespace = self._memory_namespace(memory)
        metadata = memory.metadata or {}
        kind = str(metadata.get("kind") or memory.kind or "memory").strip().lower()
        value = {
            "kind": kind,
            "content": {
                "memory_id": memory.id,
                "agent_id": memory.agent_id,
                "user_id": memory.user_id,
                "session_id": memory.session_id,
                "content": memory.content,
                "metadata": metadata,
            },
        }
        try:
            await self._store.aput(namespace, memory.id, value)
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.error("LangMem store_memory failed", exc_info=exc)
            raise LangMemIntegrationError("Unable to synchronize memory with LangMem") from exc

    async def delete_memory(self, memory: MemoryEntity) -> None:
        try:
            await self._store.adelete(self._memory_namespace(memory), memory.id)
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.error("LangMem delete_memory failed", exc_info=exc)
            raise LangMemIntegrationError("Unable to remove memory from LangMem") from exc

    async def update_memory_retention_metadata(
        self, summary: MemoryEntity, valid_until: datetime | None, window: Sequence[MemoryEntity]
    ) -> bool:
        try:
            namespace = self._memory_namespace(summary)
            for memory in window:
                value = {
                    "kind": memory.kind,
                    "content": {
                        "memory_id": memory.id,
                        "agent_id": memory.agent_id,
                        "user_id": memory.user_id,
                        "session_id": memory.session_id,
                        "content": memory.content,
                        "summary_id": summary.id,
                        "metadata": memory.metadata,
                        "valid_until": valid_until.isoformat(),
                    },
                }
                await self._store.aput(namespace, memory.id, value)
        except Exception as exc:
            logger.error("LangMem update_memory_metadata failed", exc_info=exc)
            raise LangMemIntegrationError("Unable to update memory from LangMem") from exc

    async def search_memories(
        self,
        *,
        agent_id: str,
        user_id: str | None,
        session_id: str | None,
        query: str,
        limit: int,
    ) -> Sequence[LangMemSearchResult]:
        if user_id is None:
            return []

        ns_prefix = self._namespace_prefix(agent_id, user_id)
        try:
            items = await self._store.asearch(ns_prefix, query=query, limit=limit)
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.error("LangMem search failed", exc_info=exc)
            raise LangMemIntegrationError("Unable to search memories via LangMem") from exc

        results: list[LangMemSearchResult] = []
        session_ref = self._session_ref(session_id) if session_id is not None else None
        for item in items:
            if not isinstance(item, SearchItem):
                continue
            payload = item.value.get("content") if isinstance(item.value, dict) else None
            if not isinstance(payload, dict):
                continue
            payload_session = self._session_ref(payload.get("session_id"))
            if session_ref is not None and payload_session != session_ref:
                continue
            memory_id = payload.get("memory_id") or item.key
            if not isinstance(memory_id, str):
                continue
            results.append(
                LangMemSearchResult(
                    memory_id=memory_id,
                    score=item.score,
                    raw=item.value,
                )
            )
        return results

    def _memory_namespace(self, memory: MemoryEntity) -> tuple[str, ...]:
        base_ns = self._namespace_prefix(memory.agent_id, memory.user_id)
        return (*base_ns, self._session_ref(memory.session_id))

    def _namespace_prefix(self, agent_id: str, user_id: str) -> tuple[str, ...]:
        root = self._sanitize_label(self._settings.langmem_namespace or "memories")
        return (root, self._sanitize_label(agent_id), self._sanitize_label(user_id))

    @staticmethod
    def _session_ref(session_id: str | None) -> str:
        return LangMemStoreClient._sanitize_label(session_id or DEFAULT_SESSION_ID)

    @staticmethod
    def _sanitize_label(value: str) -> str:
        local_part = value.split("@", 1)[0]
        local_part = local_part.replace(".", "_")
        cleaned = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in local_part)
        return cleaned or "default"


def build_langmem_client(
    embedding_client: EmbeddingClient | None = None,
) -> LangMemClient:
    client = embedding_client or build_embedding_client()
    session_factory = get_session_factory()
    store = PgVectorLangGraphStore(session_factory, client)
    return LangMemStoreClient(store)


__all__ = ["LangMemClient", "LangMemSearchResult", "build_langmem_client"]
