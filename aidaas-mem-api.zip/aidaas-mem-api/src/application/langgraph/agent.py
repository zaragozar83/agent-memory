"""LangGraph agent wiring that reuses the application's memory service."""

from __future__ import annotations

import inspect
from typing import Any, Awaitable, Callable, Sequence, TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph

from src.application.clients.llm import LLMClient, build_llm_client
from src.application.dto import CreateMemoryInput
from src.application.services.memory_service import MemoryService


class MemoryAgentState(TypedDict, total=False):
    agent_id: str
    user_id: str
    session_id: str | None
    message: str
    metadata: dict[str, Any]
    limit: int
    messages: list[dict[str, Any]]
    recall: Sequence[dict]
    response: str
    stored_memory_id: str
    response_memory_id: str


ResponderFn = Callable[[str, Sequence[dict], MemoryAgentState], Awaitable[str] | str]


def build_memory_agent(
    service: MemoryService,
    responder: ResponderFn | None = None,
    *,
    namespace: str | None = None,
    checkpointer: Any | None = None,
    llm_client: LLMClient | None = None,
):
    """Return a LangGraph compiled graph that persists via pgvector.

    Parameters
    ----------
    service:
        The application-layer ``MemoryService`` used to persist and recall
        memories.
    responder:
        Callable that produces the assistant's response given the incoming
        message and recalled context.  If ``None``, a trivial echo responder is
        used.
    namespace:
        Optional override for the LangGraph checkpointer namespace.  Defaults to
        the value from settings.
    checkpointer:
        Optional pre-instantiated LangGraph checkpointer.  Useful for tests
        where a real Postgres instance is not available.
    """

    store = checkpointer or MemorySaver()
    graph = StateGraph(MemoryAgentState)

    graph.add_node("ingest", _build_ingest_node(service))
    graph.add_node("recall", _build_recall_node(service))
    graph.add_node("respond", _build_respond_node(service, responder or _build_llm_responder(llm_client)))

    graph.set_entry_point("ingest")
    graph.add_edge("ingest", "recall")
    graph.add_edge("recall", "respond")
    graph.add_edge("respond", END)

    return graph.compile(checkpointer=store)


def _build_ingest_node(service: MemoryService):
    async def _node(state: MemoryAgentState) -> MemoryAgentState:
        message = state.get("message")
        if not message:
            raise ValueError("LangGraph state missing required 'message' text")

        agent_id = _require(state, "agent_id")
        user_id = _require(state, "user_id")

        payload = CreateMemoryInput(
            agent_id=agent_id,
            user_id=user_id,
            session_id=state.get("session_id"),
            content=message,
            metadata={"role": "user", **(state.get("metadata") or {})},
        )
        memory = await service.create_memory(payload)

        updated = dict(state)
        updated["stored_memory_id"] = memory.id
        messages = list(state.get("messages", []))
        messages.append({"role": "user", "content": memory.content, "memory_id": memory.id})
        updated["messages"] = messages
        return updated

    return _node


def _build_recall_node(service: MemoryService):
    async def _node(state: MemoryAgentState) -> MemoryAgentState:
        query = state.get("message")
        if not query:
            raise ValueError("LangGraph state missing 'message' for recall phase")

        agent_id = _require(state, "agent_id")
        user_id = _require(state, "user_id")
        limit = int(state.get("limit") or 5)

        results = await service.search_memories(
            agent_id=agent_id,
            user_id=user_id,
            query=query,
            limit=limit,
            session_id=state.get("session_id"),
        )

        updated = dict(state)
        updated["recall"] = results
        return updated

    return _node


def _build_respond_node(service: MemoryService, responder: ResponderFn):
    async def _node(state: MemoryAgentState) -> MemoryAgentState:
        query = state.get("message") or ""
        recall = state.get("recall", [])
        response = await _invoke_responder(responder, query, recall, state)

        updated = dict(state)
        updated["response"] = response

        agent_id = _require(state, "agent_id")
        user_id = _require(state, "user_id")

        if response:
            payload = CreateMemoryInput(
                agent_id=agent_id,
                user_id=user_id,
                session_id=state.get("session_id"),
                content=response,
                metadata={"role": "assistant"},
            )
            memory = await service.create_memory(payload)
            updated["response_memory_id"] = memory.id
            messages = list(updated.get("messages", []))
            messages.append({"role": "assistant", "content": response, "memory_id": memory.id})
            updated["messages"] = messages

        return updated

    return _node


async def _invoke_responder(responder: ResponderFn, query: str, recall: Sequence[dict], state: MemoryAgentState) -> str:
    result = responder(query, recall, state)
    if inspect.isawaitable(result):
        return await result  # type: ignore[return-value]
    return str(result)


def _build_llm_responder(client: LLMClient | None) -> ResponderFn:
    llm = client or build_llm_client()

    async def _responder(query: str, recall: Sequence[dict], state: MemoryAgentState) -> str:
        fragments = []
        for idx, item in enumerate(recall):
            memory_payload = item.get("memory") if isinstance(item, dict) else None
            content = memory_payload.get("content") if isinstance(memory_payload, dict) else None
            if isinstance(content, str) and content:
                fragments.append(f"Memory {idx + 1}: {content}")
        prompt_context = "\n\n".join(fragments)
        system_prompt = (
            "You are an assistant helping autonomous agents maintain short conversational turns. "
            "Use the provided memories when relevant and keep responses concise."
        )
        user_message = f"Current query: {query}\n\nRelevant memories:\n{prompt_context}" if prompt_context else query
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]
        return await llm.generate(messages=messages)

    return _responder


def _require(state: MemoryAgentState, key: str) -> Any:
    if key not in state or state[key] is None:  # type: ignore[index]
        raise ValueError(f"LangGraph state missing required '{key}'")
    return state[key]  # type: ignore[index]


__all__ = ["build_memory_agent", "MemoryAgentState", "ResponderFn"]
