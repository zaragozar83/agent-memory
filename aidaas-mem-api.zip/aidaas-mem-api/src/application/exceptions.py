class MemoryNotFoundError(Exception):
    """Raised when requested memory is not found."""


class LangMemIntegrationError(Exception):
    """Raised when LangMem operations fail and the request must abort."""


class SummaryWindowEmptyError(Exception):
    """Raised when no memories are available for summary generation."""


class SummaryGenerationError(Exception):
    """Raised when summary generation completes without usable content."""
