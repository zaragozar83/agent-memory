from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import anyio
import jwt
from jwt import PyJWKClient

from src.core.config import Settings


class AuthenticationError(Exception):
    """Raised when a bearer token cannot be authenticated."""


@dataclass(slots=True)
class AuthenticatedIdentity:
    agent_id: str
    scopes: tuple[str, ...] = ()


class JWTAuthenticator:
    """Validate JWT bearer tokens and derive the calling agent identity."""

    def __init__(self, settings: Settings) -> None:
        self._algorithm = settings.auth_jwt_algorithm.upper()
        self._jwks_url = settings.auth_jwks_url
        self._local_secret = settings.auth_local_jwt_secret
        self._allow_unsigned_local = settings.auth_allow_unsigned_local
        self._required_scopes = self._parse_required_scopes(settings.auth_required_scopes)
        self._jwks_client = self._build_jwks_client()

    async def authenticate(self, token: str) -> AuthenticatedIdentity:
        """Decode the JWT, ensuring it is valid and returning the agent identity."""

        claims = await self._decode(token)
        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject.strip():
            raise AuthenticationError("Token missing subject claim")

        scopes = self._parse_scopes(claims.get("scope"))
        self._validate_scopes(scopes)

        return AuthenticatedIdentity(agent_id=subject, scopes=scopes)

    def _build_jwks_client(self) -> PyJWKClient | None:
        if self._uses_asymmetric_keys and self._jwks_url:
            return PyJWKClient(self._jwks_url)
        return None

    @property
    def _uses_asymmetric_keys(self) -> bool:
        return self._algorithm.startswith("RS") or self._algorithm.startswith("ES")

    async def _decode(self, token: str) -> dict[str, Any]:
        try:
            if self._jwks_client is not None:
                signing_key = await anyio.to_thread.run_sync(self._jwks_client.get_signing_key_from_jwt, token)
                return jwt.decode(
                    token,
                    signing_key.key,
                    algorithms=[self._algorithm],
                    options={"verify_aud": False},
                )

            if self._algorithm.startswith("HS") and self._local_secret:
                return jwt.decode(
                    token,
                    self._local_secret,
                    algorithms=[self._algorithm],
                    options={"verify_aud": False},
                )

            if self._allow_unsigned_local:
                return jwt.decode(token, options={"verify_signature": False, "verify_aud": False})

        except jwt.ExpiredSignatureError as exc:
            raise AuthenticationError("Token expired") from exc
        except jwt.InvalidTokenError as exc:
            raise AuthenticationError("Invalid token") from exc

        raise AuthenticationError("No signing configuration available")

    @staticmethod
    def _parse_scopes(scope_claim: Any) -> tuple[str, ...]:
        if isinstance(scope_claim, str):
            return tuple(scope for scope in scope_claim.split() if scope)
        if isinstance(scope_claim, (list, tuple)):
            return tuple(str(scope) for scope in scope_claim if scope)
        return ()

    @staticmethod
    def _parse_required_scopes(raw: str | None) -> tuple[str, ...]:
        if not raw:
            return ()
        return tuple(scope for scope in raw.split() if scope)

    def _validate_scopes(self, scopes: tuple[str, ...]) -> None:
        if not self._required_scopes:
            return

        missing = [scope for scope in self._required_scopes if scope not in scopes]
        if missing:
            raise AuthenticationError("Token missing required scopes")
