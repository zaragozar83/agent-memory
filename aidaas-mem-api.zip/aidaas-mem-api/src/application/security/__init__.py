"""Application-level security primitives."""
