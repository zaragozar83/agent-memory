from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class CreateMemoryInput:
    agent_id: str
    content: str
    user_id: str | None = None
    session_id: str | None = None
    kind: str | None = None
    metadata: dict[str, Any] | None = field(default_factory=dict)


@dataclass(slots=True)
class UpdateMemoryInput:
    content: str | None = None
    session_id: str | None = None
    kind: str | None = None
    metadata: dict[str, Any] | None = None
