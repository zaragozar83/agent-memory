from __future__ import annotations

from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.postgres.repository import MemoryRepository
from src.domain.redis.memory_cache import MemoryCache

from ..clients.embeddings import build_embedding_client
from ..clients.langmem import LangMemClient, build_langmem_client
from ..clients.llm import build_llm_client
from ..services.memory_service import MemoryService
from ..services.summary_manager import SummaryManager

_embedding_client = build_embedding_client()
_langmem_client: LangMemClient | None = None
_llm_client = build_llm_client()


def _get_langmem_client() -> LangMemClient:
    global _langmem_client
    if _langmem_client is None:
        _langmem_client = build_langmem_client(_embedding_client)
    return _langmem_client


def build_memory_service(session: AsyncSession, redis_client: Redis) -> MemoryService:
    repository = MemoryRepository(session)
    cache = MemoryCache(redis_client)
    langmem_client = _get_langmem_client()
    summary_manager = SummaryManager(
        repository=repository,
        cache=cache,
        embedding_client=_embedding_client,
        langmem_client=langmem_client,
        llm_client=_llm_client,
    )
    return MemoryService(
        repository,
        cache,
        _embedding_client,
        langmem_client,
        summary_manager=summary_manager,
    )
