import logging
from typing import Any

import structlog

from .config import get_settings

_configured = False


def configure_logging() -> None:
    """Configure structlog for JSON logging."""

    global _configured

    if _configured:
        return

    settings = get_settings()
    timestamper = structlog.processors.TimeStamper(fmt="iso")
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)

    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        timestamper,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.JSONRenderer(),
    ]

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        cache_logger_on_first_use=True,
    )

    logging.basicConfig(level=log_level, format="%(message)s")
    _configured = True


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Return a configured structlog logger."""

    configure_logging()
    logger = structlog.get_logger(name)
    return logger.new() if name else logger


def add_log_context(**context: Any) -> None:
    """Bind additional context to the current logging context."""

    structlog.contextvars.bind_contextvars(**context)
