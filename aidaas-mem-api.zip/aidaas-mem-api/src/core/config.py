from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application configuration loaded from environment variables."""

    database_dsn: str = Field("postgresql+asyncpg://mem_user:mem_pass@localhost:5432/mem_db", alias="DATABASE_DSN")
    database_schema: str | None = Field(default=None, alias="DATABASE_SCHEMA")
    environment: str = Field("LOCAL", alias="ENVIRONMENT")
    redis_url: str = Field("redis://localhost:6379/0", alias="REDIS_URL")
    redis_ssl_cert_reqs: str | None = Field(default=None, alias="REDIS_SSL_CERT_REQS")
    redis_ssl_check_hostname: bool | None = Field(default=None, alias="REDIS_SSL_CHECK_HOSTNAME")
    redis_ttl_seconds: int = Field(3600, alias="REDIS_TTL", ge=60, le=7 * 24 * 60 * 60)
    log_level: str = Field("INFO", alias="LOG_LEVEL")
    operation_timeout_seconds: float = Field(30.0, alias="OPERATION_TIMEOUT_SECONDS", gt=0, le=30.0)

    auth_jwks_url: str | None = Field(default=None, alias="AUTH_JWKS_URL")
    auth_jwt_algorithm: str = Field("HS256", alias="AUTH_JWT_ALGORITHM")
    auth_local_jwt_secret: str = Field("local-secret", alias="AUTH_LOCAL_JWT_SECRET")
    auth_allow_unsigned_local: bool = Field(False, alias="AUTH_ALLOW_UNSIGNED_LOCAL")
    auth_required_scopes: str | None = Field(default=None, alias="AUTH_REQUIRED_SCOPES")

    embedding_base_url: str = Field("", alias="EMBEDDING_BASE_URL")
    embedding_api_key: str = Field("", alias="EMBEDDING_API_KEY")
    embedding_model: str = Field("", alias="EMBEDDING_MODEL")
    embedding_dimension: int = Field(1024, alias="EMBEDDING_DIMENSION", ge=8, le=10000)
    embedding_batch_size: int = Field(8, alias="EMBEDDING_BATCH_SIZE", ge=1, le=64)
    llm_model: str = Field("", alias="LLM_MODEL")
    llm_max_tokens: int = Field(1024, alias="LLM_MAX_TOKENS", ge=128, le=32768)
    semantic_search_candidate_limit: int = Field(100, alias="SEMANTIC_SEARCH_CANDIDATES", ge=1, le=1000)
    semantic_search_similarity_threshold: float | None = Field(
        default=None,
        alias="SEMANTIC_SEARCH_SIMILARITY_THRESHOLD",
        ge=0.0,
        le=1.0,
    )
    langmem_namespace: str = Field("default", alias="LANGMEM_NAMESPACE")
    langmem_database_dsn: str | None = Field(None, alias="LANGMEM_DATABASE_DSN")
    auto_summary_enabled: bool = Field(True, alias="AUTO_SUMMARY_ENABLED")
    summary_count_threshold: int = Field(20, alias="SUMMARY_COUNT_THRESHOLD", ge=1, le=500)
    summary_token_threshold: int = Field(2400, alias="SUMMARY_TOKEN_THRESHOLD", ge=128, le=20000)
    summary_time_threshold_seconds: int = Field(900, alias="SUMMARY_TIME_THRESHOLD_SECONDS", ge=60, le=86400)

    default_retention_days: int = Field(30, alias="DEFAULT_RETENTION_DAYS", ge=1, le=300)

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    """Return cached settings instance."""

    return Settings()  # type: ignore[arg-type]
