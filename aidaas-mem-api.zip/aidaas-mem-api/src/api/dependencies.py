from dataclasses import dataclass

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession

from src.application.factories.memory_factory import build_memory_service
from src.application.security.jwt import AuthenticationError, JWTAuthenticator
from src.application.services.memory_service import MemoryService
from src.core.config import Settings, get_settings
from src.domain.postgres.session import get_session
from src.domain.redis.redis import get_redis_client


@dataclass(slots=True)
class RequestIdentity:
    agent_id: str
    scopes: tuple[str, ...] = ()


_bearer_scheme = HTTPBearer(auto_error=False)


def get_jwt_authenticator(settings: Settings = Depends(get_settings)) -> JWTAuthenticator:
    return JWTAuthenticator(settings=settings)


async def get_request_identity(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    authenticator: JWTAuthenticator = Depends(get_jwt_authenticator),
) -> RequestIdentity:
    if credentials is None or not credentials.credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")

    try:
        identity = await authenticator.authenticate(credentials.credentials)
    except AuthenticationError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc

    return RequestIdentity(agent_id=identity.agent_id, scopes=identity.scopes)


async def get_memory_service(
    session: AsyncSession = Depends(get_session),
    redis_client: Redis = Depends(get_redis_client),
) -> MemoryService:
    return build_memory_service(session, redis_client)
