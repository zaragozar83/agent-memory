from fastapi import FastAPI

from src.core.logging import configure_logging
from src.domain.postgres.session import dispose_engine, init_db
from src.domain.redis.redis import close_redis

from .routers.health import router as health_router
from .routers.memories import router as memories_router


def create_app() -> FastAPI:
    configure_logging()
    app = FastAPI(
        title="AI DaaS - Mem API",
        version="0.2.2",
        root_path="/aidaas/mem",
        redirect_slashes=False)
    app.include_router(health_router)
    app.include_router(memories_router)

    @app.on_event("startup")
    async def on_startup() -> None:
        await init_db()

    @app.on_event("shutdown")
    async def on_shutdown() -> None:
        await close_redis()
        await dispose_engine()

    return app


app = create_app()
