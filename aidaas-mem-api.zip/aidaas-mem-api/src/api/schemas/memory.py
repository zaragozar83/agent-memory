from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field
from typing_extensions import Literal


class MemoryCreateRequest(BaseModel):
    agent_id: str = Field(..., min_length=1)
    user_id: str | None = Field(default=None, min_length=1)
    session_id: str | None = Field(default=None, min_length=1)
    kind: str | None = Field(default=None, min_length=1)
    content: str = Field(..., min_length=1)
    metadata: dict[str, Any] | None = None


class MemoryUpdateRequest(BaseModel):
    content: str | None = Field(default=None, min_length=1)
    session_id: str | None = Field(default=None, min_length=1)
    kind: str | None = Field(default=None, min_length=1)
    metadata: dict[str, Any] | None = None


class MemorySearchRequest(BaseModel):
    agent_id: str = Field(..., min_length=1)
    user_id: str | None = Field(default=None, min_length=1)
    session_id: str | None = Field(default=None, min_length=1)
    kind: str | None = Field(default=None, min_length=1)
    query: str = Field(..., min_length=1)
    limit: int = Field(default=5, ge=1, le=50)


class MemoryMetadataSearchRequest(BaseModel):
    agent_id: str = Field(..., min_length=1)
    user_id: str | None = Field(default=None, min_length=1)
    session_id: str | None = Field(default=None, min_length=1)
    kind: str | None = Field(default=None, min_length=1)
    metadata: dict[str, Any] = Field(..., min_length=1)
    limit: int = Field(default=20, ge=1, le=100)
    match_mode: Literal["exact", "contains"] = Field(default="exact")


class MemoryResponse(BaseModel):
    id: str
    agent_id: str
    user_id: str
    kind: str
    session_id: str | None = None
    content: str
    metadata: dict[str, Any] | None = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SummaryRefreshRequest(BaseModel):
    user_id: str | None = Field(default=None, min_length=1)
    session_id: str | None = Field(default=None, min_length=1)
    window_limit: int | None = Field(default=None, ge=1, le=200)
