from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = Field(..., description="Current service availability status.")
    message: str = Field(..., description="Human readable status description.")
