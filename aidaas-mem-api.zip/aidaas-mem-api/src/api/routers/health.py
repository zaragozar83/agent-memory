from fastapi import APIRouter, status

from ..schemas.health import HealthResponse

router = APIRouter(prefix="/health", tags=["health"])


@router.get(
    "",
    status_code=status.HTTP_200_OK,
    response_model=HealthResponse,
)
async def health() -> HealthResponse:
    """Lightweight readiness endpoint."""

    return HealthResponse(status="up", message="API is up and running.")
