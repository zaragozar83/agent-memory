from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from src.application.dto import CreateMemoryInput, UpdateMemoryInput
from src.application.exceptions import (
    LangMemIntegrationError,
    MemoryNotFoundError,
    SummaryGenerationError,
    SummaryWindowEmptyError,
)
from src.application.services.memory_service import MemoryService

from ..dependencies import RequestIdentity, get_memory_service, get_request_identity
from ..schemas.memory import (
    MemoryCreateRequest,
    MemoryMetadataSearchRequest,
    MemoryResponse,
    MemorySearchRequest,
    MemoryUpdateRequest,
    SummaryRefreshRequest,
)

router = APIRouter(prefix="/memories", tags=["memories"])


@router.post(
    "",
    response_model=MemoryResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_memory(
    payload: MemoryCreateRequest,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> MemoryResponse:
    if payload.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    try:
        memory = await service.create_memory(CreateMemoryInput(**payload.model_dump()))
    except LangMemIntegrationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    return MemoryResponse.model_validate(memory)


@router.get(
    "/{memory_id}",
    response_model=MemoryResponse,
)
async def get_memory(
    memory_id: str,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> MemoryResponse:
    try:
        memory = await service.get_memory(memory_id)
    except MemoryNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    if memory.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    return MemoryResponse.model_validate(memory)


@router.get(
    "",
    response_model=list[MemoryResponse],
)
async def list_recent_memories(
    agent_id: str = Query(..., min_length=1),
    user_id: str | None = Query(default=None, min_length=1),
    session_id: str | None = Query(default=None, min_length=1),
    kind: str | None = Query(default=None, min_length=1),
    limit: int = Query(default=20, ge=1, le=100),
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> list[MemoryResponse]:
    if agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    memories = await service.list_recent_memories(agent_id, user_id, limit, session_id, kind)
    return [MemoryResponse.model_validate(memory) for memory in memories]


@router.patch(
    "/{memory_id}",
    response_model=MemoryResponse,
)
async def update_memory(
    memory_id: str,
    payload: MemoryUpdateRequest,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> MemoryResponse:
    try:
        existing = await service.get_memory(memory_id)
    except MemoryNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    if existing.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    try:
        memory = await service.update_memory(memory_id, UpdateMemoryInput(**payload.model_dump()))
    except LangMemIntegrationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except MemoryNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return MemoryResponse.model_validate(memory)


@router.delete(
    "/{memory_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
async def delete_memory(
    memory_id: str,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> Response:
    try:
        memory = await service.get_memory(memory_id)
    except MemoryNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    if memory.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    try:
        await service.delete_memory(memory_id)
    except LangMemIntegrationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except MemoryNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/search",
    response_model=list[dict[str, Any]],
)
async def search_memories(
    payload: MemorySearchRequest,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> list[dict[str, Any]]:
    if payload.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    try:
        results = await service.search_memories(
            agent_id=payload.agent_id,
            user_id=payload.user_id,
            session_id=payload.session_id,
            query=payload.query,
            limit=payload.limit,
            kind=payload.kind,
        )
    except LangMemIntegrationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    return list(results)


@router.post(
    "/search/metadata",
    response_model=list[dict[str, Any]],
)
async def search_memories_by_metadata(
    payload: MemoryMetadataSearchRequest,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> list[dict[str, Any]]:
    if payload.agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    results = await service.search_memories_by_metadata(
        agent_id=payload.agent_id,
        metadata=payload.metadata,
        limit=payload.limit,
        user_id=payload.user_id,
        session_id=payload.session_id,
        kind=payload.kind,
        match_mode=payload.match_mode,
    )
    return list(results)


@router.post(
    "/{agent_id}/summary/refresh",
    response_model=MemoryResponse,
    status_code=status.HTTP_201_CREATED,
)
async def refresh_summary(
    agent_id: str,
    payload: SummaryRefreshRequest,
    service: MemoryService = Depends(get_memory_service),
    identity: RequestIdentity = Depends(get_request_identity),
) -> MemoryResponse:
    if agent_id != identity.agent_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
    try:
        summary = await service.refresh_summary(
            agent_id=agent_id,
            store_user_id=payload.user_id or "*",
            scope_user_id=payload.user_id,
            session_id=payload.session_id,
            window_limit=payload.window_limit,
        )
    except SummaryWindowEmptyError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except SummaryGenerationError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
    except LangMemIntegrationError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc

    return MemoryResponse.model_validate(summary)
