import os


class EnvironmentVariables:
    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO")
    # Auth API settings
    AUTH_API_AUTHENTICATION_PATH: str = os.environ.get(
        "AUTH_API_AUTHENTICATION_PATH", "/v1/api_key/validate"
    )
    AUTH_API_AUTHORIZATION_PATH: str = os.environ.get(
        "AUTH_API_AUTHORIZATION_PATH", "/v1/permission/validate"
    )
    AUTH_API_URL: str = os.environ.get("AUTH_API_URL", "changeme")
    AUTH_API_TIMEOUT: int = int(os.environ.get("AUTH_API_TIMEOUT", 10))

    INTENT_API_URL: str = os.environ.get("INTENT_API_URL", "changeme")
    INTENT_API_TIMEOUT: int = int(os.environ.get("INTENT_API_TIMEOUT", 10))
    INTENT_API_SEARCH_PATH: str = os.environ.get(
        "INTENT_API_SEARCH_PATH", "/v1/intent/search"
    )

    # Embeddings API settings
    GEN_AI_GATEWAY_URL = os.environ.get("GEN_AI_GATEWAY_URL", "changeme")
    ADMIN_KEY: str = os.environ.get("ADMIN_KEY", "changeme")

    # Database settings
    PGVECTOR_DB_URL: str = os.environ.get("PGVECTOR_DB_URL", "sqlite://")

    # Catalog_api settings
    CATALOG_API_URL: str = os.environ.get("CATALOG_API_URL", "changeme")
    CATALOG_API_FIND_DATASET = os.environ.get(
        "CATALOG_API_FIND_DATASET", "/v1/datasets"
    )
    CATALOG_API_TIMEOUT: int = int(os.environ.get("CATALOG_API_TIMEOUT", 10))

    # Caching settings
    AUTH_CACHE_TTL: int = int(os.environ.get("AUTH_CACHE_TTL", 300))
    CATALOG_CACHE_TTL: int = int(os.environ.get("CATALOG_CACHE_TTL", 300))

    # Neo4j settings
    NEO4J_URI: str = os.environ.get("NEO4J_URI", "changeme")
    NEO4J_PORT: int = int(os.environ.get("NEO4J_PORT", 7687))
    NEO4J_USERNAME: str = os.environ.get("NEO4J_USERNAME", "changeme")
    NEO4J_PASSWORD: str = os.environ.get("NEO4J_PASSWORD", "changeme")
    NEO4J_DATABASE: str = os.environ.get("NEO4J_DATABASE", "changeme")
    NEO4J_ADDRESS_MAP: list = os.environ.get(
        "NEO4J_ADDRESS_MAP",
        "changeme",
    ).split(",")
    NEO4J_DRIVER_TIMEOUT: int = int(os.environ.get("NEO4J_DRIVER_TIMEOUT", 5))

    # Multi-Threading settings
    MAX_THREADS: int = int(os.environ.get("MAX_THREADS", 16))
    MEAN_THREADS: int = int(os.environ.get("MEAN_THREADS", 8))
    DEFAULT_THREADS: int = int(os.environ.get("DEFAULT_THREADS", 4))

    # Duplicate filter
    FETCH_K_TIMES: int = int(os.environ.get("FETCH_K_TIMES", 5))

    # Datasets to use space columns filtering
    DATASETS_TO_USE_SPACE_COLUMNS: list = os.environ.get(
        "DATASETS_TO_USE_SPACE_COLUMNS", ""
    ).split(",")
