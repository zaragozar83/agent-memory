from src.api.v1.controller.health import router as health_router
from src.api.v1.controller.search import router as search_router

routers = [health_router, search_router]
