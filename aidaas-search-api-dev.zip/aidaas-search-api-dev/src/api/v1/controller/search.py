import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from src.api.v1.factory.document_response import DocumentResponseFactory
from src.api.v1.request.graph import GraphRequest
from src.api.v1.request.hybrid import HybridRequest
from src.api.v1.request.text import TextSearchRequest
from src.api.v1.request.vector import VectorRequest
from src.api.v1.response.document import DocumentResponse
from src.api.v1.response.rest import RestResponse
from src.application.facade.catalog_api import CatalogApiFacade
from src.application.service.auth import AuthService
from src.application.service.graph_search import GraphSearchService
from src.application.service.hybrid_search import HybridSearchService
from src.application.service.text_search import TextSearchService
from src.application.service.vector_search import VectorSearchService
from src.application.utils.headers_credentials import (
    HTTPAIAAuthorization,
    HTTPAIAAuthorizationCredentials,
)
from src.domain.database import get_db

# Router for search operations.
router = APIRouter(
    tags=["Search"],
)

# Create a dependency that validates the API key or principal list.
bearer_auth = HTTPAIAAuthorization(scheme_name="daas_api_key")


@router.post(
    "/vector",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[List[DocumentResponse]],
    responses={
        401: {"description": "Unauthorized", "model": RestResponse},
        404: {"description": "DatasetNotFound", "model": RestResponse},
    },
    name="Similarity search based on a pre-populated dataset in PGVector",
)
def vector_search(
    vector_request: VectorRequest,
    credentials: HTTPAIAAuthorizationCredentials = Depends(bearer_auth),
    max_results: Optional[int] = Query(10, alias="maxResults", ge=1, le=100),
    db: Session = Depends(get_db),
) -> RestResponse[List[DocumentResponse]]:
    """
    Convert user query to embeddings and perform similarity search based on a pre-populated dataset in PGVector.
    If no results match the search criteria, an empty list is returned.

    Args:\n
        query: str
            The query string.
        dataset_id: str
            The dataset ID.
        distance_function: DistanceFunctionEnum["cosine_distance", "l2_distance", "inner_product"]
            The distance function to be used for similarity search.
            The available options are: cosine_distance, l2_distance, and inner_product.
            Default is cosine_distance.
        distance_threshold: float
            The maximum distance threshold for the similarity search.
            From 0 to 1.
            e.g. if the distance_threshold is 0.4, only search results that are within 0.4 distance from the query will be returned.
        metadata: Optional[dict]
            "metadata" is the field that stores default generated metadata.
            The dictionary of {"key":"value"} pair to be used as filter in the "metadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            For "namespaces", the filter syntax is {"namespaces_operator": "and", "namespaces": [{"space_key": "value1"}, {"space_key": "value2"}, ...]}
            The "namespaces_operator": "and" or "or". If no operator is provided, "and" is used by default.
            e.g. {"datasource_url": "s3://bucket/folder/file.txt"}
        cmetadata: Optional[dict]
            "cmetadata" is the custom metadata field.
            The dictionary of {"key":"value"} pair to be used as filter in the "cmetadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            e.g. {"product": "PowerEdge"}
        language: Optional[str]
            The main language of the documents. Supported 97 languages(ISO 639-1 codes): af, am, an, ar, as, az, be, bg, bn, br, bs, ca, cs,
            cy, da, de, dz, el, en, eo, es, et, eu, fa, fi, fo, fr, ga, gl, gu, he, hi, hr, ht, hu, hy, id, is, it, ja, jv, ka, kk, km,
            kn, ko, ku, ky, la, lb, lo, lt, lv, mg, mk, ml, mn, mr, ms, mt, nb, ne, nl, nn, no, oc, or, pa, pl, ps, pt, qu, ro, ru, rw,
            se, si, sk, sl, sq, sr, sv, sw, ta, te, th, tl, tr, ug, uk, ur, vi, vo, wa, xh, zh, zu
        include_neighbors: int. Defaults to 0.
            The number of neighbor chunks to include in the search results. If greater than zero, after the search results are
            returned, for each returned chunk, the N previous and next chunks will also be returned.
        ignore_indexes: Optional[bool]
            Intended for scenarios requiring exhaustive recall, performance comparison, or debugging of index behavior.
            If True, ignore the indexes in the search results.
            Defaults to False.
        intent_spaces_limit: Optional[int]
            The number of intent spaces to filter in the search results. If no value is provided, intents spaces will not be filtered.
    Returns:\n
        The search results with the score as the distance between the query and the result.

    Scores:\n
        "cosine_distance" and "l2_distance" values from 0 to 1.
        - 0 >> the most similar
        - 1 >> the least similar.

        "inner_product" values from -1 to 1.
        - 1: The vectors are identical.
        - 0: The vectors are orthogonal (perpendicular) to each other.
        - -1: The vectors are diametrically opposed (point in exactly opposite directions).

    Raises:\n
        HTTPException: 401
            Unauthorized: The API key is invalid or the dataset ID is not authorized.
        HTTPException: 404
            DatasetNotFound: The dataset ID is not found.
    """

    logging.debug(
        f"Received vector search request with content: max_results={max_results} {vector_request}"
    )

    dataset_info = CatalogApiFacade.get_dataset_info(vector_request.dataset_id)

    if dataset_info.enable_file_level_permissions:
        principal = AuthService.authorize_file_level_permissions(
            credentials=credentials
        )
        vector_request.metadata = vector_request.metadata or {}
        vector_request.metadata["permissions"] = principal
    else:
        AuthService.authorize(
            credentials=credentials,
            dataset_id=vector_request.dataset_id,
        )

    results = VectorSearchService.similarity_search(
        db=db,
        query=vector_request.query,
        application_id=dataset_info.application_id,
        model=dataset_info.model,
        dimension=dataset_info.dimension,
        datasource_name=dataset_info.datasource_name,
        max_results=max_results,
        dataset_id=vector_request.dataset_id,
        distance_function=vector_request.distance_function,
        include_neighbors=vector_request.include_neighbors,
        distance_threshold=vector_request.distance_threshold,
        metadata=vector_request.metadata,
        cmetadata=vector_request.cmetadata,
        language=vector_request.language,
        ignore_indexes=vector_request.ignore_indexes,
        intent_spaces_limit=vector_request.intent_spaces_limit,
    )

    return RestResponse(data=DocumentResponseFactory.responses_from_dtos(results))


@router.post(
    "/text",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[List[DocumentResponse]],
    responses={
        401: {"description": "Unauthorized", "model": RestResponse},
        404: {"description": "DatasetNotFound", "model": RestResponse},
    },
    name="Full text search based on a pre-populated dataset in PGVector",
)
def text_search(
    text_search_request: TextSearchRequest,
    credentials: HTTPAIAAuthorizationCredentials = Depends(bearer_auth),
    max_results: Optional[int] = Query(10, alias="maxResults", ge=1, le=100),
    db: Session = Depends(get_db),
) -> RestResponse[List[DocumentResponse]]:
    """
    Convert user query to embeddings, and perform a full text search based on a pre-populated dataset in PGVector.
    Searches textual data from the "document" column, based on the presence of specific words or phrases within the text.
    Higher score values indicate higher similarity.
    If no results match the search criteria, an empty list is returned.

    Args:\n
        query: str
            The query string.
        dataset_id: str
            The dataset ID.
        metadata: Optional[dict]
            "metadata" is the field that stores default generated metadata.
            The dictionary of {"key":"value"} pair to be used as filter in the "metadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            e.g. {"datasource_url": "s3://bucket/folder/file.txt"}
        cmetadata: Optional[dict]
            "cmetadata" is the custom metadata field.
            The dictionary of {"key":"value"} pair to be used as filter in the "cmetadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            e.g. {"product": "PowerEdge"}
        parsing_function: Optional[str]
            "parsing_function" is the function used to control how the input query is parsed into a tsquery.
            The parsing_function allows consumers of the API to fine-tune text interpretation, supporting more advanced
            use cases such as exact phrase matching or search engine-style queries.
            The default value is "plainto_tsquery".
            If a value is provided for this parameter, it will use the specified function to parse the query.
            Supported Functions: ["plainto_tsquery","to_tsquery","phraseto_tsquery","websearch_to_tsquery"]
        include_cmetadata: Optional[bool]
            An optional parameter to control whether to include the cmetadata of the documents in the search execution.
            If False, only the document chunk fields will be used and scored in the search.
            If True, the search will include and score both the cmetadata and document chunk fields, enhancing result relevance.
            Root Mean Square (RMS) technique is used to combine the scores of the two fields.
            Defaults to False.

    Returns:\n
        The search results with the score as the distance between the query and the result.

    Scores:\n
        Higher score values indicate higher similarity.

    Raises:\n
        HTTPException: 401
            Unauthorized: The API key is invalid or the dataset ID is not authorized.
        HTTPException: 404
            DatasetNotFound: The dataset ID is not found.
    """

    logging.debug(
        f"Received text search request with content: max_results={max_results} {text_search_request}"
    )

    dataset_info = CatalogApiFacade.get_dataset_info(text_search_request.dataset_id)

    if dataset_info.enable_file_level_permissions:
        principal = AuthService.authorize_file_level_permissions(
            credentials=credentials
        )
        text_search_request.metadata = text_search_request.metadata or {}
        text_search_request.metadata["permissions"] = principal
    else:
        AuthService.authorize(
            credentials=credentials,
            dataset_id=text_search_request.dataset_id,
        )

    results = TextSearchService.text_search(
        db=db,
        dataset_id=text_search_request.dataset_id,
        query=text_search_request.query,
        application_id=dataset_info.application_id,
        datasource_name=dataset_info.datasource_name,
        metadata=text_search_request.metadata,
        cmetadata=text_search_request.cmetadata,
        max_results=max_results,
        parsing_function=text_search_request.parsing_function,
        include_cmetadata=text_search_request.include_cmetadata,
    )

    return RestResponse(data=DocumentResponseFactory.responses_from_dtos(results))


@router.post(
    "/hybrid",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[List[DocumentResponse]],
    responses={
        401: {"description": "Unauthorized", "model": RestResponse},
        404: {"description": "DatasetNotFound", "model": RestResponse},
    },
    name="Perform hybrid search using vector search and full-text search for datasets",
)
def hybrid_search(
    hybrid_request: HybridRequest,
    credentials: HTTPAIAAuthorizationCredentials = Depends(bearer_auth),
    max_results: Optional[int] = Query(10, alias="maxResults", ge=1, le=100),
    db: Session = Depends(get_db),
) -> RestResponse[List[DocumentResponse]]:
    """
    Convert user query to embeddings, and perform hybrid search using vector search and full-text search.
    Based on "vector_weight", the search results are reranked and combined.
    If no results match the search criteria, an empty list is returned.

    Args:\n
        query: str
            The query string.
        dataset_id: str
            The dataset ID.
        ranking_function: RankingFunctionEnum
            A required parameter used to control the ranking of the search results.
            Supported functions: ["weighted_average", "reciprocal_rank_fusion"]
        distance_function: DistanceFunctionEnum["cosine_distance", "l2_distance", "inner_product"]
            The distance function to be used for similarity search.
            The available options are: cosine_distance, l2_distance, and inner_product.
            Default is cosine_distance.
        distance_threshold: float
            The maximum distance threshold for the similarity search.
            From 0 to 1.
            e.g. if the distance_threshold is 0.4, only search results that are within 0.4 distance from the query will be returned.
        vector_weight: float
            The weight to be given to the vector search.
            The final scores will be reranked and ordered based on this weight.
            From 0 to 1. Recommended value is 0.5.
        metadata: Optional[dict]
            "metadata" is the field that stores default generated metadata.
            The dictionary of {"key":"value"} pair to be used as filter in the "metadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            e.g. {"datasource_url": "s3://bucket/folder/file.txt"}
        cmetadata: Optional[dict]
            "cmetadata" is the custom metadata field.
            The dictionary of {"key":"value"} pair to be used as filter in the "cmetadata" field.
            If values are provided for this filter, there will be only results that match the exact same key-value pair.
            e.g. {"product": "PowerEdge"}
        parsing_function: Optional[str]
            "parsing_function" is the function used to control how the input query is parsed into a tsquery.
            The parsing_function allows consumers of the API to fine-tune text interpretation, supporting more advanced
            use cases such as exact phrase matching or search engine-style queries.
            An empty string can be provided to use the default parsing function. The default value is "plainto_tsquery".
            If a value is provided for this parameter, it will use the specified function to parse the query.
            Supported Functions: ["plainto_tsquery","to_tsquery","phraseto_tsquery","websearch_to_tsquery"]
        k: Optional[int]
            The "k" parameter affects the cutoff used in RRF scoring. Its configurability provides more control over ranking behavior
            when utilizing the ranking_function parameter "reciprocal_rank_fusion".
            If the ranking_function "weighted_average" is used, the k parameter is ignored.
            Must be a Positive Integer. Default is 60.
        ignore_indexes: Optional[bool]
            Intended for scenarios requiring exhaustive recall, performance comparison, or debugging of index behavior.
            If True, ignore the indexes in the search results.
            Defaults to False.
        include_cmetadata: Optional[bool]
            An optional parameter to control whether to include the cmetadata of the documents in the search execution.
            If False, only the document chunk fields will be used and scored in the search.
            If True, the search will include and score both the cmetadata and document chunk fields, enhancing result relevance.
            Root Mean Square (RMS) technique is used to combine the scores of the two fields.
            Defaults to False.

    Returns:\n
        The search results mixing full text search and vector search, based on their final scores.

    Scores:\n
        Values from 0 to 1. Higher score values indicate higher similarity.

    Raises:\n
        HTTPException: 401
            Unauthorized: The API key is invalid or the dataset ID is not authorized.
        HTTPException: 404
            DatasetNotFound: The dataset ID is not found.
    """

    logging.debug(
        f"Received hybrid search request with content: max_results={max_results} {hybrid_request}"
    )

    dataset_info = CatalogApiFacade.get_dataset_info(hybrid_request.dataset_id)

    if dataset_info.enable_file_level_permissions:
        principal = AuthService.authorize_file_level_permissions(
            credentials=credentials
        )
        hybrid_request.metadata = hybrid_request.metadata or {}
        hybrid_request.metadata["permissions"] = principal
    else:
        AuthService.authorize(
            credentials=credentials,
            dataset_id=hybrid_request.dataset_id,
        )

    results = HybridSearchService.hybrid_search(
        db=db,
        hybrid_request=hybrid_request,
        max_results=max_results,
        application_id=dataset_info.application_id,
        model=dataset_info.model,
        datasource_name=dataset_info.datasource_name,
        dimension=dataset_info.dimension,
    )

    return RestResponse(data=DocumentResponseFactory.responses_from_dtos(results))


@router.post(
    "/graph",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[List],
    name="Graph Search in Neo4j DB using similarity search",
)
def graph_search(
    graph_request: GraphRequest,
    credentials: HTTPAIAAuthorizationCredentials = Depends(bearer_auth),
    max_results: Optional[int] = Query(1, alias="maxResults", ge=1, le=10),
) -> RestResponse:
    """
    Perform a graph search in the Neo4j database using similarity search.
    Retrieves relavant graph data while it uses embeddings, entities and relationships to search.
    If no results match the search criteria, an empty list is returned.

    Args:\n
        query: str
            The query string.
        dataset_id: str
            The dataset ID.
        score_threshold: float
            The maximum distance threshold for the similarity search.
            From 0 to 1.
            e.g. if the distance_threshold is 0.4, only search results that are within 0.4 distance from the query will be returned.
        embedded_node_label: Optional[str]
            The node label to be given to the graph search to retrieve the chunks for Structured Data.
            eg. embedded_node_label: "Scenario" represents the node label "Scenario" (Case sensitive) in the graph.
            Keep this empty if the dataset is not structured data. Unstrucutured data uses 'Chunk" as node label by default.
        entities: Optional[List[str]]
            The list of entities to be given to the graph search to retrieve the chunks.
        relationships: Optional[List[str]]
            The list of relationships to be given to the graph search to retrieve the chunks.
        chunks: Optional[List[str]]
            A list of chunk_ids. Results will be filtered by these chunk_ids.

    Returns:\n
        GraphResponse: The search results with the score.

    Scores:\n
        Values from 0 to 1. Higher score values indicate higher similarity.

    Raises:\n
        HTTPException: 401
            Unauthorized: The API key is invalid or the dataset ID is not authorized.
        HTTPException: 404
            DatasetNotFound: The dataset ID is not found.

    """

    dataset_info = CatalogApiFacade.get_dataset_info(graph_request.dataset_id)

    AuthService.authorize(
        credentials=credentials,
        dataset_id=graph_request.dataset_id,
    )

    response_data = GraphSearchService.graph_search(
        graph_request=graph_request, max_results=max_results, dataset_info=dataset_info
    )
    return RestResponse(data=response_data.result, message="Chunks Retrieved")
