from fastapi import APIRouter, status

from src.api.v1.response import HealthResponse, RestResponse

router = APIRouter(
    prefix="/health",
    tags=["health"],
)


UP_STATUS = "up"
UP_MESSAGE = "API is up and running."


@router.get(
    "",
    summary="Health Check",
    description="This endpoint is used to check if the API is up and running. "
    "This is a public endpoint and does not require any authentication.",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[HealthResponse],
)
async def health():
    """
    Health Check

    :return: A successful response with the API status.
    """
    return RestResponse(
        data=HealthResponse(status=UP_STATUS),
        message=UP_MESSAGE,
    )
