import uuid
from typing import List

from fastapi import status
from pydantic import BaseModel, Field, field_validator

from src.application.exception import RuntimeException


class GraphRequest(BaseModel):
    query: str
    dataset_id: str
    score_threshold: float = Field(default=0.6, ge=0, le=1)
    embedded_node_label: str | None = Field(None)
    entities: List[str] | None = Field(None)
    relationships: List[str] | None = Field(None)
    chunks: List[str] | None = Field(None)

    @field_validator("query")
    @classmethod
    def validate_query(cls, v):

        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Query string could not be empty",
            )
        return v

    @field_validator("dataset_id")
    @classmethod
    def validate_dataset_id(cls, v):
        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Dataset_id string could not be empty",
            )
        try:
            uuid.UUID(v)
        except ValueError:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Invalid dataset_id, it should be a GUID",
            )
        return v
