import re
import uuid
from typing import Optional

from fastapi import status
from pydantic import BaseModel, field_validator

from src.application.enum.distance_function import DistanceFunctionEnum
from src.application.exception import RuntimeException


class VectorRequest(BaseModel):
    query: str
    dataset_id: str
    distance_function: DistanceFunctionEnum
    distance_threshold: float | None = 0.5
    intent_spaces_limit: int | None = None
    metadata: Optional[dict] = None
    cmetadata: Optional[dict] = None
    language: Optional[str] = None
    include_neighbors: int = 0
    ignore_indexes: Optional[bool] = False

    @field_validator("query")
    @classmethod
    def validate_query(cls, v):
        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Query string could not be empty",
            )
        return v

    @field_validator("dataset_id")
    @classmethod
    def validate_dataset_id(cls, v):
        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Dataset_id string could not be empty",
            )
        try:
            uuid.UUID(v)
        except ValueError:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Invalid dataset_id, it should be a GUID",
            )
        return v

    @field_validator("distance_function")
    @classmethod
    def validate_distance_function(cls, v):
        if not v:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Distance Function string could not be empty",
            )
        return v

    @field_validator("language")
    @classmethod
    def validate_language(cls, v):
        if len(v) != 2 or not re.match(r"^[a-zA-Z]{2}$", v):
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Invalid language, it should be 2 characters",
            )
        return v

    @field_validator("include_neighbors")
    @classmethod
    def validate_include_neighbors_function(cls, v):
        if not 0 <= v <= 10:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Number of neighbors to include must be between 0 and 10",
            )
        return v

    @field_validator("intent_spaces_limit")
    @classmethod
    def validate_intent_spaces_limit(cls, intent_spaces_limit: int):
        if not 0 <= intent_spaces_limit <= 15:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Number of intent spaces must be between 0 and 15",
            )
        return intent_spaces_limit

    @field_validator("metadata")
    @classmethod
    def validate_metadata(cls, metadata: dict):
        if not metadata:
            return metadata

        namespaces_operator = metadata.get("namespaces_operator")
        if namespaces_operator and namespaces_operator not in ["and", "or"]:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Namespaces operator in metadata must be 'and' or 'or'",
            )
        return metadata
