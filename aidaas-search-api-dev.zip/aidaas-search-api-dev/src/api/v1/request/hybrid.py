import uuid
from typing import Optional

from fastapi import status
from pydantic import BaseModel, Field, field_validator

from src.application.enum.distance_function import DistanceFunctionEnum
from src.application.enum.ranking_function import RankingFunctionEnum
from src.application.exception import RuntimeException


class HybridRequest(BaseModel):
    query: str
    dataset_id: str
    ranking_function: RankingFunctionEnum = RankingFunctionEnum.WEIGHTED_AVERAGE
    distance_function: DistanceFunctionEnum
    distance_threshold: float | None = None
    vector_weight: float = Field(..., ge=0, le=1)
    metadata: Optional[dict] = None
    cmetadata: Optional[dict] = None
    parsing_function: Optional[str] = "plainto_tsquery"
    k: Optional[int] = Field(default=60, ge=0, strict=True)
    ignore_indexes: Optional[bool] = False
    include_cmetadata: Optional[bool] = False

    @field_validator("query")
    @classmethod
    def validate_query(cls, v):
        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Query string could not be empty",
            )
        return v

    @field_validator("dataset_id")
    @classmethod
    def validate_dataset_id(cls, v):
        if not v.strip():
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Dataset_id string could not be empty",
            )
        try:
            uuid.UUID(v)
        except ValueError:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Invalid dataset_id, it should be a GUID",
            )
        return v

    @field_validator("distance_function")
    @classmethod
    def validate_distance_function(cls, v):
        if not v:
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Distance Function string could not be empty",
            )
        return v

    @field_validator("parsing_function")
    @classmethod
    def validate_parsing_function(cls, v):
        valid_values = [
            "plainto_tsquery",
            "to_tsquery",
            "phraseto_tsquery",
            "websearch_to_tsquery",
        ]

        if not v.strip():
            return "plainto_tsquery"

        if not any(x == v for x in valid_values):
            raise RuntimeException(
                status_code=status.HTTP_400_BAD_REQUEST,
                message=f"parsing_function can be an empty string or a valid function from the list: {valid_values}",
            )
        return v
