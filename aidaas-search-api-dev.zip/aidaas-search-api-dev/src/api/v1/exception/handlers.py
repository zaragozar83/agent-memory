from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from src.api.v1.response import RestResponse
from src.application.exception import RuntimeException
from src.core.logging import log_request


def set_exception_handlers(app: FastAPI):
    @app.exception_handler(Exception)
    def base_exception_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=RestResponse(message=str(exc), success=False).model_dump(),
        )
        log_request(request, status.HTTP_500_INTERNAL_SERVER_ERROR, str(exc))
        return json_response

    @app.exception_handler(RuntimeException)
    def runtime_exception_handler(request: Request, exc: RuntimeException):
        json_response = JSONResponse(
            status_code=exc.status_code,
            headers={"Error-Message": exc.message},
            content=RestResponse(message=exc.message, success=False).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_405_METHOD_NOT_ALLOWED)
    def custom_405_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
            content=RestResponse(
                message=f"Method Not Allowed",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_404_NOT_FOUND)
    def custom_404_handler(request: Request, exc: RequestValidationError):
        json_response = JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content=RestResponse(
                message=exc.detail if exc.detail != "" else "Not Found",
                success=False,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_403_FORBIDDEN)
    def custom_403_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content=RestResponse(
                message=f"Not authenticated",
                success=True,
            ).model_dump(),
        )
        return json_response

    @app.exception_handler(status.HTTP_401_UNAUTHORIZED)
    def custom_401_handler(request: Request, exc: Exception):
        json_response = JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content=RestResponse(
                message=f"Not authenticated",
                success=True,
            ).model_dump(),
        )
        return json_response
