from typing import Optional

from pydantic import BaseModel


class DocumentResponse(BaseModel):
    chunk_id: str
    document: str
    score: float
    metadata: Optional[dict]
    cmetadata: Optional[dict]
    language: Optional[str]
    neighbors: Optional[dict]
