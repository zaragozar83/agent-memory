from typing import List

from pydantic import BaseModel


class SimilarChunk(BaseModel):
    document: str
    metadata: dict
    score: float


class GraphResponse(BaseModel):
    result: List[SimilarChunk]
