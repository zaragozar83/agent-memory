from typing import List

from src.api.v1.response.document import DocumentResponse
from src.application.dto.document import DocumentDto


class DocumentResponseFactory:
    @classmethod
    def response_from_dto(cls, document_dto: DocumentDto) -> DocumentResponse:
        filtered_metadata = {
            key: value
            for key, value in document_dto.metadata.items()
            if key.lower() != "permissions"
        }

        return DocumentResponse(
            chunk_id=document_dto.id,
            document=document_dto.document,
            score=document_dto.score,
            metadata=filtered_metadata,  # Exclude 'permissions' key
            cmetadata=document_dto.cmetadata,
            language=document_dto.language,
            neighbors=document_dto.neighbors,
        )

    @classmethod
    def responses_from_dtos(
        cls, document_dtos: List[DocumentDto]
    ) -> List[DocumentResponse]:
        return [cls.response_from_dto(document_dto) for document_dto in document_dtos]
