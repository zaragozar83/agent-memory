import json
import logging
import pathlib
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, List

import numpy as np
import psycopg2
from fastapi import status
from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    JSON,
    BinaryExpression,
    Column,
    ColumnElement,
    String,
    and_,
    case,
    cast,
    literal,
    or_,
)
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import REGCONFIG, TSVECTOR
from sqlalchemy.orm import Session, declarative_base
from sqlalchemy.sql import func

from src.application.dto.document import DocumentDto
from src.application.exception.runtime import RuntimeException
from src.application.utils.context import data_insights_var
from src.application.utils.languages_sql import get_language_sql
from src.application.utils.text_utils import text_to_md5
from src.core.environment_variables import EnvironmentVariables


class DocumentRepository:

    @classmethod
    def _get_table(cls, table_name: str, base):
        class DocumentModel(base):
            __tablename__ = table_name  # application_id

            id = Column(String, primary_key=True)
            dataset_id = Column(String, nullable=False)
            document = Column(String, nullable=False)
            embedding = Column(Vector, nullable=False)
            metadata_ = Column("metadata", JSON, nullable=False)
            cmetadata = Column(JSON, nullable=False)
            tsv_doc = Column(TSVECTOR, nullable=True)
            language = Column(String, nullable=True)
            space_key = Column(String, nullable=True)
            space_name = Column(String, nullable=True)

        return DocumentModel

    @classmethod
    def dto_from_model_and_score_and_neighbors(
        cls,
        document_model: Any,
        score: float,
        neighbors: dict | None = None,
    ) -> DocumentDto:
        return DocumentDto(
            id=document_model.id,
            dataset_id=document_model.dataset_id,
            document=document_model.document,
            score=score,
            metadata=document_model.metadata_,
            cmetadata=document_model.cmetadata,
            language=document_model.language,
            neighbors=neighbors,
        )

    @classmethod
    def vector_search(
        cls,
        db: Session,
        request_query_embeddings: List[float],
        dataset_id: str,
        application_id: str,
        vector_dims: int,
        datasource_name: str,
        distance_threshold: float = 0.5,
        distance_function: str = "cosine_distance",
        max_results: int = 100,
        metadata: dict | None = None,
        cmetadata: dict | None = None,
        language: str | None = None,
        include_neighbors: int = 0,
        hybrid_search: bool = False,
        ignore_indexes: bool = False,
        enable_space_column_filter: bool = False,
    ):
        if ignore_indexes:
            logging.warning(
                f"[vector-repository] Search will be conducted without indexes"
            )
        start_time = datetime.now()

        Base = declarative_base()

        # Get the table for the application_id
        DocumentModel = cls._get_table(application_id, Base)

        # choose distance based on the distance_function
        if distance_function == "cosine_distance":
            distance = (
                DocumentModel.embedding.cosine_distance(request_query_embeddings)
                if ignore_indexes
                else cast(DocumentModel.embedding, Vector(vector_dims)).cosine_distance(
                    request_query_embeddings
                )
            )
        elif distance_function == "l2_distance":
            distance = (
                DocumentModel.embedding.l2_distance(request_query_embeddings)
                if ignore_indexes
                else cast(DocumentModel.embedding, Vector(vector_dims)).l2_distance(
                    request_query_embeddings
                )
            )
        elif distance_function == "inner_product":
            distance = (
                DocumentModel.embedding.max_inner_product(request_query_embeddings)
                if ignore_indexes
                else cast(
                    DocumentModel.embedding, Vector(vector_dims)
                ).max_inner_product(request_query_embeddings)
            )
        else:
            logging.warning(
                f"[vector-repository] Invalid vector function {distance_function}"
            )

        # Query the database for the most similar vectors from the same dataset_id
        query = db.query(
            DocumentModel,
            distance.label("distance"),
        ).filter(DocumentModel.dataset_id == dataset_id)
        if metadata:
            # for each key-value pair in the Metadata dictionary, creates a filter condition that checks
            # if the value of the nested JSON key in the cmetadata column of the DocumentModel table is equal to the JSON-encoded value.
            metadata_filters = []
            for key, value in metadata.items():
                if key == "namespaces_operator":
                    continue
                if key == "namespaces":
                    query = query.filter(
                        cls._get_namespaces_filter(
                            metadata, DocumentModel, enable_space_column_filter
                        )
                    )
                    continue
                if key.lower() == "datasource_url" and not pathlib.Path(value).suffix:
                    # `->>` plus .like() or .ilike() is the key to partial string matching in pg sql json columns
                    filter = DocumentModel.metadata_.op("->>")(key).like(f"%{value}%")
                elif key.lower() == "permissions":
                    filter = (
                        DocumentModel.metadata_[key].op("@>")(func.to_jsonb([value[0]]))
                        | DocumentModel.metadata_[key].op("@>")(
                            func.to_jsonb([value[1]])
                        )
                        | DocumentModel.metadata_[key].op("@>")(
                            func.to_jsonb(["everyone"])
                        )
                    )
                else:
                    filter = DocumentModel.metadata_.op("->")(key) == json.dumps(
                        value
                    )  # The `->` operator is specific to PostgreSQL and allows accessing nested JSON values.

                metadata_filters.append(filter)

            query = query.filter(
                *metadata_filters
            )  # The * operator in this context is used to unpack a list or a tuple

        if cmetadata:
            # for each key-value pair in the Cmetadata dictionary, creates a filter condition that checks
            # if the value of the nested JSON key in the cmetadata column of the DocumentModel table is equal to the JSON-encoded value.
            cmetadata_filters = [
                DocumentModel.cmetadata.op("->")(key)
                == json.dumps(
                    value
                )  # The `->` operator is specific to PostgreSQL and allows accessing nested JSON values.
                for key, value in cmetadata.items()
            ]
            query = query.filter(
                *cmetadata_filters
            )  # The * operator in this context is used to unpack a list or a tuple
        if distance_threshold is not None:
            query = query.filter(distance <= distance_threshold)

        if language:
            query = query.filter(DocumentModel.language == language)

        db_query = query.statement.compile(dialect=postgresql.dialect())
        results = cls._duplicate_filter(query, distance, max_results)
        if include_neighbors > 0:
            results = cls._include_neighbor_chunks(
                db, DocumentModel, results, include_neighbors
            )
        # Convert the results to a list of DocumentDto objects
        document_dtos: List[DocumentDto] = []
        combined_chunk_indexes = set()
        dataset_object_ids = set()
        total_score = 0
        total_count = 0
        for result in results:
            document_dtos.append(cls.dto_from_model_and_score_and_neighbors(*result))
            dataset_object_ids.add(result[0].metadata_.get("dataset_object_id", ""))
            combined_chunk_indexes.add(
                result[0].metadata_.get("dataset_object_id", "")
                + "_"
                + text_to_md5(result[0].document)
            )
            total_score += result[1]
            total_count += 1
        average_score = total_score / total_count if total_count > 0 else 0
        if not hybrid_search:
            data_insight_logger_dict = data_insights_var.get()
            data_insight_logger_dict.update(
                {
                    "search_type": "Vector Search",
                    "dataset_id": dataset_id,
                    "application_id": application_id,
                    "dataset_object_ids": list(dataset_object_ids),
                    "combined_chunk_indexes": list(combined_chunk_indexes),
                    "datasource_name": datasource_name,
                    "average_retrieval_score": average_score,
                    "distance_function": distance_function,
                    "distance_threshold": distance_threshold,
                    "metadata": metadata,
                    "cmetadata": cmetadata,
                    "language": language,
                    "include_neighbors": include_neighbors,
                    "ignore_indexes": ignore_indexes,
                    "enable_space_column_filter": enable_space_column_filter,
                    "db_query": str(db_query),
                    "db_query_duration": (datetime.now() - start_time).total_seconds(),
                }
            )
            data_insights_var.set(data_insight_logger_dict)
        return document_dtos

    @classmethod
    def text_search(
        cls,
        db: Session,
        query: str,
        dataset_id: str,
        application_id: str,
        datasource_name: str,
        metadata: dict | None = None,
        cmetadata: dict | None = None,
        max_results: int = 10,
        hybrid_search: bool = False,
        parsing_function: str = "plainto_tsquery",
        include_cmetadata: bool = False,
    ):
        start_time = datetime.now()

        Base = declarative_base()

        # Get the table for the application_id
        DocumentModel = cls._get_table(application_id, Base)

        # Perform full-text search using SQLAlchemy ORM
        # Create the tsquery from the search text
        if parsing_function == "plainto_tsquery":
            ts_query = func.plainto_tsquery("english", query)
        elif parsing_function == "to_tsquery":
            ts_query = func.to_tsquery("english", query)
        elif parsing_function == "phraseto_tsquery":
            ts_query = func.phraseto_tsquery("english", query)
        elif parsing_function == "websearch_to_tsquery":
            ts_query = func.websearch_to_tsquery("english", query)
        else:
            raise RuntimeException(
                message="Invalid parsing function",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        # Query the database for the most similar vectors from the same dataset_id
        # applying normalization to the rank, so values are between 0 and 1
        rank = func.ts_rank_cd(DocumentModel.tsv_doc, ts_query, 32)

        if include_cmetadata:
            # simple-CASE expression (CASE language WHEN … THEN … ELSE … END)
            language_cfg = case(
                *get_language_sql(lang_col=DocumentModel.language),
                else_=literal("english"),
            ).cast(REGCONFIG)

            cmetadata_tsv = func.to_tsvector(language_cfg, DocumentModel.cmetadata)

            # Coalesce ts_rank_cd with 0.0 if cmetadata is empty
            cmetadata_rank = func.coalesce(
                func.ts_rank_cd(cmetadata_tsv, ts_query, 32), 0.0
            )
            # Root Mean Square between rank and cmetadata_rank
            score = func.sqrt(
                func.power(rank, 2) + func.power(cmetadata_rank, 2)
            ) / func.sqrt(2)
            query = (
                db.query(
                    DocumentModel,
                    score.label("score"),
                )
                .filter(DocumentModel.dataset_id == dataset_id)
                .filter(
                    or_(
                        DocumentModel.tsv_doc.op("@@")(ts_query),
                        cmetadata_tsv.op("@@")(ts_query),
                    )
                )
                .group_by(DocumentModel.id)
                .order_by(score.desc())
            )
        else:
            query = (
                db.query(
                    DocumentModel,
                    rank.label("rank"),
                )
                .filter(DocumentModel.dataset_id == dataset_id)
                .filter(DocumentModel.tsv_doc.op("@@")(ts_query))
                .order_by(rank.desc())
            )
        if metadata:
            # for each key-value pair in the Metadata dictionary, creates a filter condition that checks
            # if the value of the nested JSON key in the cmetadata column of the DocumentModel table is equal to the JSON-encoded value.
            metadata_filters = []
            for key, value in metadata.items():
                if key == "namespaces_operator":
                    continue
                if key == "namespaces":
                    query = query.filter(
                        cls._get_namespaces_filter(metadata, DocumentModel, False)
                    )
                    continue
                if key.lower() == "datasource_url" and not pathlib.Path(value).suffix:
                    # `->>` plus .like() or .ilike() is the key to partial string matching in pg sql json columns
                    filter = DocumentModel.metadata_.op("->>")(key).like(f"%{value}%")
                elif key.lower() == "permissions":
                    filter = (
                        DocumentModel.metadata_[key].op("@>")(func.to_jsonb([value[0]]))
                        | DocumentModel.metadata_[key].op("@>")(
                            func.to_jsonb([value[1]])
                        )
                        | DocumentModel.metadata_[key].op("@>")(
                            func.to_jsonb(["everyone"])
                        )
                    )
                else:
                    filter = DocumentModel.metadata_.op("->")(key) == json.dumps(
                        value
                    )  # The `->` operator is specific to PostgreSQL and allows accessing nested JSON values.

                metadata_filters.append(filter)

            query = query.filter(
                *metadata_filters
            )  # The * operator in this context is used to unpack a list or a tuple

        if cmetadata:
            # for each key-value pair in the Cmetadata dictionary, creates a filter condition that checks
            # if the value of the nested JSON key in the cmetadata column of the DocumentModel table is equal to the JSON-encoded value.
            cmetadata_filters = [
                DocumentModel.cmetadata.op("->")(key)
                == json.dumps(
                    value
                )  # The `->` operator is specific to PostgreSQL and allows accessing nested JSON values.
                for key, value in cmetadata.items()
            ]
            query = query.filter(
                *cmetadata_filters
            )  # The * operator in this context is used to unpack a list or a tuple

        # Query the database for the most similar vectors from the same dataset_id
        try:
            results = query.limit(max_results).all()
        except Exception as e:
            logging.error(e)
            if (
                hasattr(e, "orig")
                and isinstance(e.orig, psycopg2.errors.SyntaxError)
                and parsing_function == "to_tsquery"
            ):
                raise RuntimeException(
                    message=f"Failed to perform text search with the 'to_tsquery' parsing function and the provided query. Query must consist of single tokens separated by the tsquery operators & (AND), | (OR), ! (NOT), and <-> (FOLLOWED BY). For more information on using 'to_tsquery' please refer to https://www.postgresql.org/docs/current/textsearch-controls.html#TEXTSEARCH-PARSING-QUERIES",
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

            raise RuntimeException(
                message=f"Failed to perform text search in Database: {e}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        document_dtos: List[DocumentDto] = []
        dataset_object_ids = set()
        combined_chunk_indexes = set()
        total_score = 0
        total_count = 0

        for result in results:
            document_dtos.append(
                cls.dto_from_model_and_score_and_neighbors(
                    document_model=result[0],
                    score=result[1],
                )
            )
            dataset_object_ids.add(result[0].metadata_.get("dataset_object_id", ""))
            combined_chunk_indexes.add(
                result[0].metadata_.get("dataset_object_id", "")
                + "_"
                + text_to_md5(result[0].document)
            )
            total_score += result[1]
            total_count += 1
        average_score = total_score / total_count if total_count > 0 else 0
        if not hybrid_search:
            data_insight_logger_dict = data_insights_var.get()
            data_insight_logger_dict.update(
                {
                    "search_type": "Text Search",
                    "dataset_id": dataset_id,
                    "application_id": application_id,
                    "dataset_object_ids": list(dataset_object_ids),
                    "combined_chunk_indexes": list(combined_chunk_indexes),
                    "datasource_name": datasource_name,
                    "average_retrieval_score": average_score,
                    "metadata": metadata,
                    "cmetadata": cmetadata,
                    "parsing_function": parsing_function,
                    "include_cmetadata": include_cmetadata,
                    "db_query_duration": (datetime.now() - start_time).total_seconds(),
                }
            )
            data_insights_var.set(data_insight_logger_dict)

        return document_dtos

    @staticmethod
    def _get_namespaces_filter(
        metadata: dict, document_model, enable_space_column_filter: bool
    ) -> ColumnElement[bool]:
        if enable_space_column_filter:
            space_keys = []
            space_names = []
            for namespace in metadata["namespaces"]:
                if "space_key" in namespace:
                    space_keys.append(str(namespace["space_key"]))
                if "space_name" in namespace:
                    space_names.append(str(namespace["space_name"]))

            return (
                document_model.space_key.in_(space_keys)
                if space_keys
                else document_model.space_name.in_(space_names)
            )

        conditions = []
        operator = metadata.get("namespaces_operator", "and")
        for namespace in metadata["namespaces"]:
            filter = [
                func.jsonb_contains(
                    document_model.metadata_,
                    json.dumps({"namespaces": [{k: v}]}),
                )
                for k, v in namespace.items()
            ]
            conditions.extend(filter)

        return and_(*conditions) if operator == "and" else or_(*conditions)

    @staticmethod
    def _duplicate_filter(
        query: Any, distance: BinaryExpression, max_results: int
    ) -> List[Any]:

        fetch_k_times = EnvironmentVariables.FETCH_K_TIMES

        # Fetch the ranked results with possible duplicates
        results = query.order_by(distance).limit(fetch_k_times * max_results).all()

        # Filter results when documents and embeddings are duplicated
        duplicated_documents = set()
        duplicated_embeddings = []
        filtered_results = []

        for result in results:
            is_doc_duplicated = result[0].document in duplicated_documents
            is_embedding_duplicated = any(
                np.array_equal(result[0].embedding, vec)
                for vec in duplicated_embeddings
            )
            if is_doc_duplicated and is_embedding_duplicated:
                continue

            filtered_results.append(result)
            duplicated_documents.add(result[0].document)
            duplicated_embeddings.append(result[0].embedding)

        filtered_results_count = len(filtered_results)
        results_count = len(results)

        if filtered_results_count < results_count:
            logging.debug(
                f"Duplicated documents: {results_count - len(duplicated_documents)}. Duplicated embeddings: {results_count - len(duplicated_embeddings)}"
            )
            logging.info(
                f"Vector search fetched {filtered_results_count}/{results_count} unique results truncated to top {max_results} results. Found {results_count - filtered_results_count} duplicated results"
            )

        return filtered_results[:max_results]

    @staticmethod
    def _include_neighbor_chunks(db, DocumentModel, results, n) -> List[Any]:
        def get_previous_next_chunk(current_chunk) -> List[Any]:
            # Get current chunk index
            current_chunk_index = current_chunk.metadata_["chunk_index"]
            dataset_id = current_chunk.dataset_id

            # Create base query to database
            query = db.query(DocumentModel).filter(
                DocumentModel.dataset_id == dataset_id,
                DocumentModel.metadata_.op("->>")("dataset_object_id")
                == current_chunk.metadata_["dataset_object_id"],
            )

            # Add OR clauses
            or_clauses = []
            for i in range(1, n + 1):
                or_clauses.append(
                    DocumentModel.metadata_.op("->>")("chunk_index")
                    == str(current_chunk_index - i)
                )
                or_clauses.append(
                    DocumentModel.metadata_.op("->>")("chunk_index")
                    == str(current_chunk_index + i)
                )
            query = query.filter(or_(*or_clauses))

            # Run query
            neighbor_chunks = query.all()

            # Organize results
            previous_dict = {}
            next_dict = {}
            for neighbor_chunk in neighbor_chunks:
                neighbor_chunk_distance = (
                    neighbor_chunk.metadata_["chunk_index"] - current_chunk_index
                )
                if neighbor_chunk_distance < 0:
                    previous_dict[neighbor_chunk_distance] = neighbor_chunk.document
                elif neighbor_chunk_distance > 0:
                    next_dict[neighbor_chunk_distance] = neighbor_chunk.document

            return {
                "previous": [
                    previous_dict[index]
                    for index in sorted(previous_dict.keys(), reverse=True)
                ],
                "next": [next_dict[index] for index in sorted(next_dict.keys())],
            }

        if len(results) == 0:
            return results

        start_time = datetime.now()

        with ThreadPoolExecutor(
            max_workers=EnvironmentVariables.DEFAULT_THREADS
        ) as executor:
            neighbor_chunks = list(
                executor.map(get_previous_next_chunk, [result[0] for result in results])
            )

        new_results = [
            (*result, neighbors) for result, neighbors in zip(results, neighbor_chunks)
        ]
        logging.debug(
            f"Include neighbor chunks completed in {datetime.now() - start_time}"
        )
        return new_results
