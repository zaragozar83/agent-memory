from typing import List, Optional

from src.application.facade.embeddings_api import EmbeddingsApiFacade
from src.application.utils import constants
from src.domain.database.neo4j_config import Neo4jHandler


class GraphRepository:

    @classmethod
    def search_graph_documents(
        cls,
        request_query: str,
        dataset_id: str,
        score_threshold: float,
        embeddings: EmbeddingsApiFacade,
        entities: List[str],
        relationships: List[str],
        embedded_node_label: Optional[str] = None,
        chunks: List[str] | None = None,
        max_results: int = 10,
    ):
        embedded_node_label = embedded_node_label or ""

        filter_entities_cmd = ""
        if entities:
            filter_entities_cmd = "WHERE " + " OR ".join(
                "e:" + entity for entity in entities
            )

        include_relationships_cmd = ""
        exclude_relationships_cmd = ""
        if relationships:
            include_relationships_cmd = ",".join(
                f'"{relation}"' for relation in relationships
            )
        else:
            exclude_relationships_cmd = ",".join(['"HAS_ENTITY"', '"PART_OF"'])

        filter_chunks_cmd = ""
        if chunks:
            # remove empty chunk strings
            chunks = [chunk for chunk in chunks if chunk != ""]
            if len(chunks) > 0:
                # build list of comma separated chunks for IN clause
                filter_chunks_cmd = ", ".join(f'"{chunk}"' for chunk in chunks)

        query_embedded = str(embeddings.embed_query(request_query))

        retrieval_query = (
            constants.GRAPH_SEARCH_QUERY.replace("{query_embedded}", query_embedded)
            .replace("{dataset_id}", dataset_id)
            .replace("{score_threshold}", str(score_threshold))
            .replace("{filter_entities_cmd}", filter_entities_cmd)
            .replace("{embedded_node_label}", embedded_node_label)
            .replace("{include_relationships_cmd}", include_relationships_cmd)
            .replace("{exclude_relationships_cmd}", exclude_relationships_cmd)
            .replace("{max_results}", str(max_results))
            .replace("{filter_chunks_cmd}", filter_chunks_cmd)
        )

        with Neo4jHandler.get_neo4j_session() as session:
            results = session.run(retrieval_query).data()

        return results
