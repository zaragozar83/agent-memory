from src.domain.repository.document import DocumentRepository
from src.domain.repository.graph import GraphRepository

__all__ = ["DocumentRepository", "GraphRepository"]
