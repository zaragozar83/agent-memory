from neo4j import Address, GraphDatabase, Session

from src.core.environment_variables import EnvironmentVariables


class Neo4jHandler:
    def __init__(self):
        self._uri = EnvironmentVariables.NEO4J_URI
        self._database = EnvironmentVariables.NEO4J_DATABASE
        self._username = EnvironmentVariables.NEO4J_USERNAME
        self._password = EnvironmentVariables.NEO4J_PASSWORD

        self._driver = GraphDatabase.driver(
            self._uri,
            auth=(self._username, self._password),
            resolver=self._custom_resolver,
            connection_timeout=EnvironmentVariables.NEO4J_DRIVER_TIMEOUT,
        )

    @staticmethod
    def _custom_resolver(socket_address):
        """
        Resolves the address of the Neo4j server.
        """

        server_addresses = EnvironmentVariables.NEO4J_ADDRESS_MAP

        for server_address in server_addresses:
            yield Address([server_address, EnvironmentVariables.NEO4J_PORT])

        raise OSError("[neo4j driver] Could not resolve any socket addresses.")

    def close(self):
        if self._driver:
            self._driver.close()

    def get_session(self):
        return self._driver.session(database=self._database)

    def get_neo4j_session() -> Session:
        handler = Neo4jHandler()
        try:
            return handler.get_session()
        finally:
            handler.close()
