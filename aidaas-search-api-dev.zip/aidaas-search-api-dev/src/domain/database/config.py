from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from src.core.environment_variables import EnvironmentVariables

# Sqlite in-memory database used for local development or testing
# Postgres database used for development or production environments
engine = (
    create_engine(
        EnvironmentVariables.PGVECTOR_DB_URL,
        echo=False,
        pool_pre_ping=True,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    if "sqlite" in EnvironmentVariables.PGVECTOR_DB_URL
    else create_engine(
        EnvironmentVariables.PGVECTOR_DB_URL,
        echo=False,
        pool_pre_ping=True,
        pool_size=16,
        max_overflow=16,
    )
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
