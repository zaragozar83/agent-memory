from dataclasses import dataclass
from typing import Optional


@dataclass
class DatasetDto:
    dataset_id: str
    enable_file_level_permissions: bool
    application_id: Optional[str]
    model: Optional[str]
    dimension: Optional[int]
    is_graph_enabled: Optional[bool]
    datasource_name: Optional[str]
