from dataclasses import dataclass


@dataclass
class IntentSpaceDto:
    space_id: str
    score: float
