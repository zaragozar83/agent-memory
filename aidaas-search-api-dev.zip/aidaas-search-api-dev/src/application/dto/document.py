from dataclasses import dataclass
from typing import Optional


@dataclass
class DocumentDto:
    id: str
    dataset_id: str
    document: str
    score: float
    metadata: dict
    cmetadata: dict
    language: str
    neighbors: Optional[dict] = None
