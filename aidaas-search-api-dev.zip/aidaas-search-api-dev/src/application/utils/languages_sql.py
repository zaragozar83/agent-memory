from sqlalchemy import literal


def get_language_sql(lang_col):
    return [
        (lang_col == "ar", literal("arabic")),
        (lang_col == "hy", literal("armenian")),
        (lang_col == "eu", literal("basque")),
        (lang_col == "ca", literal("catalan")),
        (lang_col == "da", literal("danish")),
        (lang_col == "nl", literal("dutch")),
        (lang_col == "en", literal("english")),
        (lang_col == "fi", literal("finnish")),
        (lang_col == "fr", literal("french")),
        (lang_col == "de", literal("german")),
        (lang_col == "el", literal("greek")),
        (lang_col == "hi", literal("hindi")),
        (lang_col == "hu", literal("hungarian")),
        (lang_col == "id", literal("indonesian")),
        (lang_col == "ga", literal("irish")),
        (lang_col == "it", literal("italian")),
        (lang_col == "lt", literal("lithuanian")),
        (lang_col == "ne", literal("nepali")),
        (lang_col == "no", literal("norwegian")),
        (lang_col == "pt", literal("portuguese")),
        (lang_col == "ro", literal("romanian")),
        (lang_col == "ru", literal("russian")),
        (lang_col == "sr", literal("serbian")),
        (lang_col == "es", literal("spanish")),
        (lang_col == "sv", literal("swedish")),
        (lang_col == "ta", literal("tamil")),
        (lang_col == "tr", literal("turkish")),
        (lang_col == "yi", literal("yiddish")),
    ]
