import hashlib


def text_to_md5(text):
    # Encode the text to bytes, required by hashlib
    encoded_text = str(text).encode("utf-8")

    # Create an MD5 hash object
    md5_hash = hashlib.md5(encoded_text)

    # Return the hexadecimal digest of the hash
    return md5_hash.hexdigest()
