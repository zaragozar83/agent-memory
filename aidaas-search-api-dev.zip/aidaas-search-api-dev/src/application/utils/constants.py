# URI Schemes
HTTP_SCHEME: str = "http://"
HTTPS_SCHEME: str = "https://"

# Http Config
HTTP_REQUEST_MAX_RETRIES: int = 3
HTTP_REQUEST_TIMEOUT: int = 30

VECTOR_GRAPH_SEARCH_ENTITY_LIMIT = 25

GRAPH_SEARCH_QUERY = """
// get the document
CALL {
    MATCH (node)
    WHERE node.embedding IS NOT NULL 
    AND node.dataset_id = "{dataset_id}"
    AND ( '{embedded_node_label}' IN labels(node) OR '{embedded_node_label}' = '' )
    AND (
            ( node.chunk_id IS NOT NULL AND (node.chunk_id IN [{filter_chunks_cmd}] OR size([{filter_chunks_cmd}]) = 0 ))
            OR ( node:Chunk AND ((node.id IS NOT NULL AND node.id IN [{filter_chunks_cmd}]) OR size([{filter_chunks_cmd}]) = 0 ))
            )
    WITH node, vector.similarity.cosine({query_embedded}, node.embedding) AS score
    // Filter by score threshold
    WHERE score >= {score_threshold} 
    RETURN node, score
    ORDER BY score DESC
    LIMIT {max_results}
}

// get the entities
OPTIONAL MATCH (node)-[r]-(e)
{filter_entities_cmd}
WITH node, score, collect(DISTINCT r) AS rels, collect(e) as nodeslist

CALL{
    // find the relationships between the entities related to the document
    WITH node, nodeslist
    OPTIONAL MATCH (e1)-[r]-(e2)
    WHERE (e1 IN nodeslist)
        AND 'Chunk' IN labels(node)
        AND (type(r) IN [{include_relationships_cmd}] OR size([{include_relationships_cmd}]) = 0)
        AND (NOT type(r) IN [{exclude_relationships_cmd}] OR size([{exclude_relationships_cmd}]) = 0)
    RETURN collect(DISTINCT r) AS secondLevelRels    
}

WITH node, score, rels + coalesce(secondLevelRels, []) AS allRels

// Format the relationships
WITH node, score,
    		[ rel IN allRels | {
			    node: labels(endNode(rel))[0],
			    relationship: apoc.text.join(
				    [item IN [
					    labels(startNode(rel))[0],
					    toString(startNode(rel).id),
					    type(rel),
					    labels(endNode(rel))[0]
				    ] WHERE item <> ""], " "),
			properties: apoc.map.fromPairs(
                            [key IN keys(endNode(rel)) 
                            WHERE apoc.meta.cypher.type(endNode(rel)[key]) IN ["STRING", "INTEGER", "FLOAT"]
                            | [key, endNode(rel)[key]]
                            ]),
			summary: apoc.text.join([
			            item IN[
			            labels(startNode(rel))[0], 
			            COALESCE(toString(startNode(rel).id)), 
			            type(rel), 
			            labels(endNode(rel))[0], 
			            apoc.text.join([key IN keys(endNode(rel)) 
                            WHERE apoc.meta.cypher.type(endNode(rel)[key]) IN ["STRING", "INTEGER", "FLOAT"]
                        | key + ": " + toString(endNode(rel)[key])], "; ")
		            ] WHERE item <>""], " ")
            }]as kg

RETURN
    node.document as document,
    score,
    {
        chunk_id: COALESCE(node.chunk_id, node.id),
        chunk_index: node.chunk_index,
        dataset_object_id: node.dataset_object_id,
        related_entities: kg
    } AS metadata
"""

CHAT_SEARCH_KWARG_SCORE_THRESHOLD = 0.1
QUESTION_TRANSFORM_TEMPLATE = "Given the below conversation, generate a search query to look up in order to get information relevant to the conversation. Only respond with the query, nothing else."
CHAT_DOC_SPLIT_SIZE = 200
CHAT_EMBEDDING_FILTER_SCORE_THRESHOLD = 0.10
CONTENT_TYPE: str = "Content-Type"
APPLICATION_JSON: str = "application/json"
AUTHORIZATION: str = "Authorization"
AUTHORIZATION_BEARER: str = "Bearer"
