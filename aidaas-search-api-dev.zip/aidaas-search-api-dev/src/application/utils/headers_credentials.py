import logging
from typing import List, Optional

from fastapi.exceptions import HTTPException
from fastapi.openapi.models import HTTPBearer as HTTPBearerModel
from fastapi.security.http import HTTPBase
from fastapi.security.utils import get_authorization_scheme_param
from pydantic import BaseModel
from starlette.requests import Request
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_403_FORBIDDEN
from typing_extensions import Annotated, Doc

from src.application.exception.runtime import RuntimeException
from src.application.facade.auth_api import AuthApiFacade


class HTTPAIAAuthorizationCredentials(BaseModel):
    """
    The HTTP authorization credentials in the result of using `HTTPBearer` or
    `HTTPDigest` in a dependency.

    The HTTP authorization header value is split by the first space.

    The first part is the `scheme`, the second part is the `credentials`.

    For example, in an HTTP Bearer token scheme, the client will send a header
    like:

    ```
    Authorization: Bearer deadbeef12346
    ```

    In this case:

    * `scheme` will have the value `"Bearer"`
    * `credentials` will have the value `"deadbeef12346"`
    * `api_key` will have the api key of the user`
    * `principals` will have the nt_id, email and the assoicated ad groups of the user separated by commas`
    """

    scheme: Annotated[
        str | None,
        Doc(
            """
            The HTTP authorization scheme extracted from the header value.
            """
        ),
    ] = None
    credentials: Annotated[
        str | None,
        Doc(
            """
            The HTTP authorization credentials extracted from the header value.
            """
        ),
    ] = None
    principals: Annotated[
        List[str] | None,
        Doc(
            """
            The list of principals extracted from Authorization Bearer Token
            """
        ),
    ] = None
    api_key: Annotated[
        str | None,
        Doc(
            """
            The API key associated with the validated client, retrieved from the
            service binding after token verification.
            """
        ),
    ] = None

    def __eq__(self, other):
        """
        Two instances are equal if their attributes are equal.

        Note:
            The `principals` attribute is compared as a set.

        """
        if not isinstance(other, HTTPAIAAuthorizationCredentials):
            return False
        if self.scheme != other.scheme:
            return False
        if self.credentials != other.credentials:
            return False

        if self.principals is None and other.principals is None:
            return True
        elif self.principals is None or other.principals is None:
            return False
        else:
            return tuple(self.principals) == tuple(other.principals)

    def __hash__(self) -> int:
        if self.principals is None:
            hash_value = hash((self.scheme, self.credentials))
        else:
            hash_value = hash((self.scheme, self.credentials, tuple(self.principals)))
        return hash_value


class HTTPAIAAuthorization(HTTPBase):
    """
    HTTP Bearer token authentication.

    ## Usage

    Create an instance object and use that object as the dependency in `Depends()`.

    The dependency result will be an `HTTPAuthorizationCredentials` object containing
    the `scheme` and the `credentials`.

    ## Example

    ```python
    from typing import Annotated

    from fastapi import Depends, FastAPI
    from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

    app = FastAPI()

    security = HTTPBearer()


    @app.get("/users/me")
    def read_current_user(
        credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)]
    ):
        return {"scheme": credentials.scheme, "credentials": credentials.credentials}
    ```
    """

    def __init__(
        self,
        *,
        bearerFormat: Annotated[Optional[str], Doc("Bearer token format.")] = None,
        scheme_name: Annotated[
            Optional[str],
            Doc(
                """
                Security scheme name.

                It will be included in the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                Security scheme description.

                It will be included in the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
    ):
        self.model = HTTPBearerModel(bearerFormat=bearerFormat, description=description)
        self.scheme_name = scheme_name or self.__class__.__name__

    async def __call__(
        self, request: Request
    ) -> Optional[HTTPAIAAuthorizationCredentials]:
        authorization = request.headers.get("Authorization")

        # Enable X-AIA-Principals support during the transition period
        principals_header = request.headers.get("X-AIA-Principals")
        if principals_header:
            principals = principals_header.split(",")
            return HTTPAIAAuthorizationCredentials(principals=principals)

        scheme, credentials = get_authorization_scheme_param(authorization)
        if not (authorization and scheme and credentials):
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN, detail="Not authenticated"
            )
        if scheme.lower() != "bearer":
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN,
                detail="Invalid authentication credentials",
            )

        # Determine whether the provided credential is a JWT or an API key,
        # and validate accordingly.
        try:
            if self.is_jwt_token(credentials):
                logging.info("Validating Kong JWT token.")
                validation_result = AuthApiFacade.validate_token(credentials)
                return HTTPAIAAuthorizationCredentials(
                    scheme=scheme,
                    credentials=credentials,
                    api_key=validation_result.get("api_key"),
                    principals=[
                        p
                        for p in [
                            validation_result.get("nt_id"),
                            validation_result.get("email"),
                            ",".join(validation_result.get("ad_groups") or []),
                        ]
                        if p  # filters out None values
                    ],
                )
            else:
                logging.info(f"Validating legacy API key: {credentials}")
                return HTTPAIAAuthorizationCredentials(
                    scheme=scheme,
                    credentials=credentials,
                    api_key=credentials,
                )

        except RuntimeException as e:
            raise HTTPException(status_code=e.status_code, detail=e.message)

        except Exception as ex:
            logging.exception("Unexpected error during token validation.")
            raise HTTPException(
                status_code=HTTP_401_UNAUTHORIZED,
                detail=f"Token validation failed: {str(ex)}",
            )

    @classmethod
    def is_jwt_token(cls, token: str) -> bool:
        """
        Determine whether a given token appears to be a JWT.

        A simple heuristic is used:
        JWTs contain exactly two dots ('.') separating the header, payload, and signature.
        Example: header.payload.signature
        """
        return token.count(".") == 2
