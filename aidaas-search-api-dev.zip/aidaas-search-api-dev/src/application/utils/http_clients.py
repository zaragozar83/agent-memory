import httpx
import requests

from src.application.utils.context import correlation_id_var


class SessionWithCorrelationId(requests.Session):
    def request(self, method, url, **kwargs):
        # Inject the correlation ID into the headers
        correlation_id = correlation_id_var.get()
        if "headers" not in kwargs:
            kwargs["headers"] = {}
        kwargs["headers"]["X-Correlation-ID"] = correlation_id

        # Call the original session request
        return super().request(method, url, **kwargs)


class ClientWithCorrelationId(httpx.Client):
    def send(self, request: httpx.Request, **kwargs):
        # Inject the correlation ID into the headers
        correlation_id = correlation_id_var.get()
        if correlation_id:
            request.headers["X-Correlation-ID"] = correlation_id

        # Call the original send method
        return super().send(request, **kwargs)
