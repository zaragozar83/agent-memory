from dataclasses import dataclass, field
from typing import Mapping

from src.application.utils.model_prompt_config import ModelPromptConfig


@dataclass(frozen=True)
class EmbeddingsServiceConfig:
    model_prompt_map: Mapping[str, ModelPromptConfig] = field(
        default_factory=lambda: {
            # From EmbeddingGemma model card (prompt instructions)
            "embeddinggemma-300m": ModelPromptConfig(
                query_prefix="task: search result | query: ",
            ),
            # Nomic v1 / v1.5 (RAG prefixes)
            "nomic-embed-text-v1": ModelPromptConfig(
                query_prefix="search_query: ",
            ),
            "nomic-embed-text-v1.5": ModelPromptConfig(
                query_prefix="search_query: ",
            ),
        }
    )
    default_model: str | None = None
