from contextvars import ContextVar

# Define the correlation ID context variable
correlation_id_var: ContextVar[str] = ContextVar("correlation_id", default=None)
data_insights_var: ContextVar[dict] = ContextVar("data_insights_var", default={})
