from dataclasses import dataclass


@dataclass(frozen=True)
class ModelPromptConfig:
    """Per-model prompt policy for preparing inputs client-side."""

    query_prefix: str | None = None  # prepend to queries
