import re
from typing import List


def validate_principals_format_for_file_level_permissions(
    principals: List[str],
) -> bool:
    """
    Validates that the given list of principals is a list with second parameter that matches an email-like pattern.
    A valid email-like string should contain a substring with a '@' in the middle and a '.' at the end.

    Args:
        principals (List[str]): A list of strings representing the principals.

    Returns:
        bool: True if the list is valid, False otherwise.
    """
    if not isinstance(principals, list) or len(principals) < 2:
        return False

    email_pattern = r"[^@]+@[^@]+\.[^@]+"
    if not re.match(email_pattern, principals[1].lower()):
        return False

    return True
