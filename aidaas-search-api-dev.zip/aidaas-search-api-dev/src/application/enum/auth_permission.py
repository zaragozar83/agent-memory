from enum import StrEnum


class AuthPermission(StrEnum):
    admin = "Admin"
    read = "Read"
    write = "Write"
