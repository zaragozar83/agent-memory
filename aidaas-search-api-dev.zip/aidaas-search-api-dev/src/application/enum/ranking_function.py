from enum import Enum


class RankingFunctionEnum(Enum):
    RRF_ALGORITHM = "reciprocal_rank_fusion"
    WEIGHTED_AVERAGE = "weighted_average"
