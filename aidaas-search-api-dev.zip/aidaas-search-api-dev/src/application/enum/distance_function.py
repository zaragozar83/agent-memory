from enum import Enum


class DistanceFunctionEnum(Enum):
    COSINE_DISTANCE = "cosine_distance"
    L2_DISTANCE = "l2_distance"
    INNER_PRODUCT = "inner_product"
