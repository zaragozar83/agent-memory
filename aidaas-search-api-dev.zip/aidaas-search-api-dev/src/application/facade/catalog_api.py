import logging
from http import HTTPStatus
from urllib.parse import urljoin

from cachetools import TTLCache, cached
from fastapi import status
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from src.application.dto.dataset import DatasetDto
from src.application.exception import RuntimeException
from src.application.utils import constants
from src.application.utils.http_clients import SessionWithCorrelationId
from src.core import EnvironmentVariables
from src.core.environment_variables import EnvironmentVariables


class CatalogApiFacade:
    _session: Session = SessionWithCorrelationId()
    _session.mount(
        constants.HTTP_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )
    _session.mount(
        constants.HTTPS_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )

    _catalog_api_url = EnvironmentVariables.CATALOG_API_URL
    _catalog_api_url = urljoin(
        EnvironmentVariables.CATALOG_API_URL,
        EnvironmentVariables.CATALOG_API_FIND_DATASET,
    )

    _headers = {"Content-Type": "application/json"}
    _catalog_cache = TTLCache(maxsize=100, ttl=EnvironmentVariables.CATALOG_CACHE_TTL)
    _timeout = EnvironmentVariables.CATALOG_API_TIMEOUT

    @classmethod
    @cached(cache=_catalog_cache)
    def get_dataset_info(cls, dataset_id: str) -> DatasetDto:
        get_dataset_by_id = urljoin(cls._catalog_api_url + "/", dataset_id)
        response = cls._session.get(
            get_dataset_by_id,
            headers=cls._headers,
            timeout=cls._timeout,
        )

        if response.status_code == HTTPStatus.OK:
            response_data = response.json()
            data = response_data.get("data")
            graph_parameters = data.get("graph_parameters")
            return DatasetDto(
                dataset_id=data.get("id"),
                enable_file_level_permissions=data.get("enable_file_level_permissions"),
                application_id=data.get("application_id"),
                model=data.get("embedding_parameters").get("model"),
                dimension=data.get("embedding_parameters").get("dimension"),
                is_graph_enabled=graph_parameters
                and graph_parameters.get("is_graph_enabled", False),
                datasource_name=data.get("datasource_name", None),
            )

        if response.status_code == HTTPStatus.NOT_FOUND:
            logging.warning(f"[catalog-api] Dataset {dataset_id} not found.")
            raise RuntimeException(
                message=f"Error to get dataset {dataset_id}",
                status_code=HTTPStatus.NOT_FOUND,
            )

        logging.error(
            f"[catalog-api] Error to get the dataset {dataset_id}. Response status: {response.status_code} Response body: {response.text}"
        )
        raise RuntimeException(
            message=f"Error to get dataset {dataset_id}",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
