import logging
from http import HTTPStatus
from typing import List
from urllib.parse import urljoin

from fastapi import status
from requests import RequestException, Session
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from src.application.enum.auth_permission import AuthPermission
from src.application.exception.auth_api import AuthApiException
from src.application.exception.runtime import RuntimeException
from src.application.utils import constants
from src.application.utils.http_clients import SessionWithCorrelationId
from src.core.environment_variables import EnvironmentVariables


class AuthApiFacade:
    AUTH_API_VERSION = "v1"
    _session: Session = SessionWithCorrelationId()
    _session.mount(
        constants.HTTP_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )
    _session.mount(
        constants.HTTPS_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )
    _authorization_url = urljoin(
        EnvironmentVariables.AUTH_API_URL,
        EnvironmentVariables.AUTH_API_AUTHORIZATION_PATH,
    )
    _headers = {"Content-Type": "application/json"}
    _timeout = EnvironmentVariables.AUTH_API_TIMEOUT

    @classmethod
    def authorize(
        cls,
        dataset_id: str,
        permission: AuthPermission,
        daas_api_key: str | None,
        principals: List[str] | None,
    ) -> bool:
        payload = {
            "dataset_id": dataset_id,
            "permission": permission,
        }

        if daas_api_key:
            payload["api_key"] = daas_api_key
        elif principals:
            payload["principals"] = principals

        response = cls._session.post(
            cls._authorization_url,
            headers=cls._headers,
            json=payload,
            timeout=cls._timeout,
        )

        if response.ok:
            return True

        if response.status_code == status.HTTP_401_UNAUTHORIZED:
            return False

        logging.error(
            f"[auth-api] Error authorizing credentials on requested dataset_id {dataset_id}. Response status: {response.status_code} Response body: {response.text}"
        )
        raise RuntimeException(
            message="Error authorizing credentials",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

    @classmethod
    def get_api_key_by_dataset_id(cls, dataset_id: str):
        headers = {
            constants.CONTENT_TYPE: constants.APPLICATION_JSON,
            constants.AUTHORIZATION: f"{constants.AUTHORIZATION_BEARER} {EnvironmentVariables.ADMIN_KEY}",
        }
        params = {"dataset_id": dataset_id}
        logging.info(
            f"[auth-api] Retrieving api key for dataset id '{dataset_id}' from Auth API"
        )
        auth_api_url = (
            f"{EnvironmentVariables.AUTH_API_URL}/{cls.AUTH_API_VERSION}/api_key"
        )

        try:
            response = cls._session.get(
                url=auth_api_url,
                headers=headers,
                params=params,
                timeout=constants.HTTP_REQUEST_TIMEOUT,
            )

            if response.status_code == HTTPStatus.OK:
                logging.info(f"Api key and client id retrieved successfully")
                data = response.json().get("data")
                api_key = data.get("api_key")
                client_id = data.get("client_id")
                return api_key, client_id
        except RequestException as e:
            raise AuthApiException(
                f"[auth-api] Error retrieving api key from auth api. Dataset id:{dataset_id}. Status code: {response.status_code}"
            )

    @classmethod
    def get_access_token(cls):
        headers = {
            constants.CONTENT_TYPE: constants.APPLICATION_JSON,
            constants.AUTHORIZATION: f"{constants.AUTHORIZATION_BEARER} {EnvironmentVariables.ADMIN_KEY}",
        }
        logging.info(f"Retrieving access token from Auth API")
        auth_api_url = f"{EnvironmentVariables.AUTH_API_URL}/{cls.AUTH_API_VERSION}/token/access_token"

        try:
            response = cls._session.get(
                url=auth_api_url,
                headers=headers,
                timeout=constants.HTTP_REQUEST_TIMEOUT,
            )

            if response.status_code == HTTPStatus.OK:
                logging.info(f"Access token retrieved successfully")
                data = response.json().get("data")
                access_token = data.get("access_token")
                expiry = data.get("expiry")
                return access_token, expiry

        except RequestException as e:
            raise AuthApiException(
                f"[auth-api] Error retrieving access token from auth api. Details: {str(e)}"
            )

    @classmethod
    def validate_token(cls, credentials: str):
        """
        Validate the provided id/access token via the internal Auth API.

        Args:
            credentials (str): The Bearer token (id/access token) from the request header.

        Returns:
            dict: access token - Parsed validation data (client_id, api_key, etc.) if successful.
            dict: id token - Parsed validation data (nt_id, email, ad_groups, etc.) if successful.

        Raises:
            RuntimeException: If the token is invalid, expired, or validation fails.
            AuthApiException: If there is a network or request-level failure.
        """

        headers = {
            constants.CONTENT_TYPE: constants.APPLICATION_JSON,
            constants.AUTHORIZATION: f"{constants.AUTHORIZATION_BEARER} {credentials}",
        }

        auth_api_url = (
            f"{EnvironmentVariables.AUTH_API_URL}/{cls.AUTH_API_VERSION}/token/validate"
        )
        logging.info("Validating token via Auth API...")

        try:
            response = cls._session.post(
                auth_api_url,
                headers=headers,
                timeout=constants.HTTP_REQUEST_TIMEOUT,
            )

            if response.status_code == HTTPStatus.OK:
                logging.info("Token validated successfully.")
                return response.json().get("data", {})

            elif response.status_code == HTTPStatus.UNAUTHORIZED:
                logging.warning("Unauthorized: invalid or expired token.")
                raise RuntimeException(
                    message="Unauthorized: invalid or expired token.",
                    status_code=HTTPStatus.UNAUTHORIZED,
                )

            else:
                logging.error(
                    f"Auth API returned unexpected status {response.status_code}: {response.text}"
                )
                raise RuntimeException(
                    message="Unexpected error occurred when validating the token.",
                    status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                )

        except RequestException as e:
            logging.exception("Network or connection error when calling Auth API.")
            raise AuthApiException(f"Failed to validate token: {e}")

        except RuntimeException:
            raise  # Let it bubble up untouched RuntimeExceptions

        except Exception as e:
            logging.exception("Unhandled error during token validation.")
            raise RuntimeException(
                message=f"Unexpected error during token validation: {e}",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
