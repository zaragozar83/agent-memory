import logging
from typing import List
from urllib.parse import urljoin

from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from src.application.dto.intent_space import IntentSpaceDto
from src.application.utils import constants
from src.application.utils.http_clients import SessionWithCorrelationId
from src.core.environment_variables import EnvironmentVariables


class IntentApiFacade:
    _session: Session = SessionWithCorrelationId()
    _session.mount(
        constants.HTTP_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )
    _session.mount(
        constants.HTTPS_SCHEME,
        HTTPAdapter(max_retries=Retry(total=constants.HTTP_REQUEST_MAX_RETRIES)),
    )
    _intent_search_url = urljoin(
        EnvironmentVariables.INTENT_API_URL,
        EnvironmentVariables.INTENT_API_SEARCH_PATH,
    )
    _headers = {"Content-Type": "application/json"}
    _timeout = EnvironmentVariables.INTENT_API_TIMEOUT

    @classmethod
    def search(
        cls,
        query: str,
        dataset_id: str,
        limit: int,
    ) -> List[IntentSpaceDto]:
        payload = {
            "query": query,
            "dataset_id": dataset_id,
            "limit": limit,
        }

        try:
            response = cls._session.post(
                cls._intent_search_url,
                headers=cls._headers,
                json=payload,
                timeout=cls._timeout,
            )

            if response.ok:
                data = response.json().get("data")
                return [
                    IntentSpaceDto(space.get("space_id"), space.get("score"))
                    for space in data
                ]

            if response.status_code == 404:
                logging.warning(f"[intent-api] Dataset {dataset_id} not found.")
            else:
                logging.error(
                    f"[intent-api] Error when searching intent spaces for dataset {dataset_id}. Response status: {response.status_code} Response body: {response.text}"
                )
        except Exception as e:
            logging.error(
                f"[intent-api] Error when searching intent spaces for dataset {dataset_id}. Exception: {e}"
            )
        return []
