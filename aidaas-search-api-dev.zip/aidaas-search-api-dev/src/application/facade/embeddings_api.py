import logging
from datetime import datetime
from typing import List

from fastapi import status
from langchain_core.embeddings import Embeddings
from openai import OpenAI

from src.application.exception import RuntimeException
from src.application.utils.embedings_service_config import EmbeddingsServiceConfig
from src.application.utils.http_clients import ClientWithCorrelationId


class EmbeddingsApiFacade(Embeddings):
    _cfg: EmbeddingsServiceConfig = EmbeddingsServiceConfig()

    def __init__(self, url, model_name, client_id, access_token):
        self._url = url
        self.model_name = model_name
        self.client_id = client_id
        self.access_token = access_token
        self._client = self._build_client()

    def _build_client(self):

        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "X-AIA-CLIENT-ID": self.client_id,
        }

        return OpenAI(
            base_url=self._url,
            http_client=ClientWithCorrelationId(),
            api_key="",  # required placeholder to satisfy OpenAI SDK, this gets overridden via headers
            default_headers=headers,
        )

    def construct_prompt_prefixes(
        self, model_name: str, input_texts: List[str]
    ) -> List[str]:
        """Constructs the prompt prefix for a given model and input texts."""

        # Retrieve the model's prompt policy from the configuration
        model_prompt_policy = self._cfg.model_prompt_map.get(model_name)

        # If no policy is found, return the input texts as-is
        if model_prompt_policy is None:
            return input_texts

        # Construct the prompt prefixes by concatenating the policy's query prefix with input text
        text_with_prefixes = [
            f"{model_prompt_policy.query_prefix}{text}" for text in input_texts
        ]

        return text_with_prefixes

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed search docs."""
        try:
            # Retrieve the model's prompt policy
            prompt_prefixes = self.construct_prompt_prefixes(self.model_name, texts)

            resp = self._client.embeddings.create(
                model=self.model_name, input=prompt_prefixes
            )
            return [a.embedding for a in resp.data]

        except Exception as exc:
            logging.error(f"Unexpected error during document embedding: {exc}")
            raise RuntimeException(
                message="Unexpected error embedding documents",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def embed_query(self, text: str) -> List[float]:
        """Embed query text."""
        return self.embed_documents([text])[0]

    def get_embeddings(self, query: str) -> List[float]:
        try:
            start_time = datetime.now()

            # Retrieve the model's prompt policy
            query_with_prompt_prefixes = self.construct_prompt_prefixes(
                self.model_name, [query]
            )

            embeddings = self._client.embeddings.create(
                model=self.model_name, input=query_with_prompt_prefixes
            )
            return embeddings.data[0].embedding

        except Exception as exc:
            error_message = (
                f"Embeddings retrieval failed in {datetime.now() - start_time}. {exc}"
            )
            logging.error(error_message)
            raise RuntimeException(
                message="Error retrieving embeddings",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
