from sqlalchemy.orm import Session

from src.domain.repository.document import DocumentRepository


class TextSearchService:

    @staticmethod
    def text_search(
        db: Session,
        dataset_id: str,
        query: str,
        application_id: str,
        datasource_name: str,
        metadata: dict | None = None,
        cmetadata: dict | None = None,
        max_results: int = 10,
        hybrid_search: bool = False,
        parsing_function: str = "plainto_tsquery",
        include_cmetadata: bool = False,
    ):

        document_dtos = DocumentRepository.text_search(
            db=db,
            query=query,
            dataset_id=dataset_id,
            application_id=application_id,
            datasource_name=datasource_name,
            metadata=metadata,
            cmetadata=cmetadata,
            max_results=max_results,
            hybrid_search=hybrid_search,
            parsing_function=parsing_function,
            include_cmetadata=include_cmetadata,
        )

        return document_dtos
