import logging

from src.api.v1.request.graph import GraphRequest
from src.api.v1.response.graph import GraphResponse
from src.application.dto.dataset import DatasetDto
from src.application.exception.runtime import RuntimeException
from src.application.facade.embeddings_api import EmbeddingsApiFacade
from src.application.service.auth import AuthService
from src.application.utils.context import data_insights_var
from src.application.utils.text_utils import text_to_md5
from src.core.environment_variables import EnvironmentVariables
from src.domain.repository.graph import GraphRepository


class GraphSearchService:

    @classmethod
    def graph_search(
        cls,
        graph_request: GraphRequest,
        max_results: int = 10,
        dataset_info: DatasetDto = None,
    ) -> GraphResponse:
        logging.info(
            f"Performing graph search for dataset_id: {graph_request.dataset_id}."
        )
        request_query = graph_request.query
        if not dataset_info.is_graph_enabled:
            raise RuntimeException(
                status_code=400,
                message=f"Graph search is not enabled for dataset_id: {graph_request.dataset_id}",
            )
        _, client_id = AuthService.get_api_key_by_dataset_id(dataset_info.dataset_id)
        access_token, _ = AuthService.get_access_token()
        embeddings = EmbeddingsApiFacade(
            url=EnvironmentVariables.GEN_AI_GATEWAY_URL,
            model_name=dataset_info.model,
            client_id=client_id,
            access_token=access_token,
        )
        result = GraphRepository.search_graph_documents(
            request_query=request_query,
            dataset_id=graph_request.dataset_id,
            score_threshold=graph_request.score_threshold,
            embeddings=embeddings,
            entities=graph_request.entities,
            relationships=graph_request.relationships,
            embedded_node_label=graph_request.embedded_node_label,
            chunks=graph_request.chunks,
            max_results=max_results,
        )
        dataset_object_ids = set()
        combined_chunk_indexes = set()
        total_score = 0
        total_count = 0
        if len(result) == 0:
            return GraphResponse(result=result)
        sorted_result = sorted(result, key=lambda x: x["score"], reverse=True)
        final_result = sorted_result[:max_results]
        for res in final_result:
            dataset_object_ids.add(res.get("metadata").get("dataset_object_id", ""))
            combined_chunk_indexes.add(
                res.get("metadata").get("dataset_object_id", "")
                + "_"
                + text_to_md5(res.get("document", ""))
            )
            total_score += res.get("score", 0)
            total_count += 1
        average_score = total_score / total_count if total_count > 0 else 0
        data_insight_logger_dict = data_insights_var.get()
        data_insight_logger_dict.update(
            {
                "search_type": "Graph Search",
                "dataset_id": graph_request.dataset_id,
                "application_id": dataset_info.application_id,
                "dataset_object_ids": list(dataset_object_ids),
                "combined_chunk_indexes": list(combined_chunk_indexes),
                "datasource_name": dataset_info.datasource_name,
                "average_retrieval_score": average_score,
            }
        )
        data_insights_var.set(data_insight_logger_dict)
        return GraphResponse(result=final_result)


def add_unique_dict(existing_list, new_dict):
    new_id = new_dict["metadata"].get("document_object_id")

    # Check if any dictionary in the existing list has the same ID
    for d in existing_list:
        if d["metadata"].get("document_object_id") == new_id:
            return existing_list

    # If ID does not exist, append the new dictionary to the list
    existing_list.append(new_dict)
    return existing_list
