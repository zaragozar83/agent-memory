import logging

from cachetools import TTLCache, cached
from fastapi import HTTPException, status

from src.application.enum.auth_permission import AuthPermission
from src.application.exception.runtime import RuntimeException
from src.application.facade.auth_api import AuthApiFacade
from src.application.utils.file_level_permission_principals import (
    validate_principals_format_for_file_level_permissions,
)
from src.application.utils.headers_credentials import HTTPAIAAuthorizationCredentials
from src.core.environment_variables import EnvironmentVariables


class AuthService:

    _auth_cache = TTLCache(maxsize=100, ttl=EnvironmentVariables.AUTH_CACHE_TTL)

    logging.debug(
        "AuthService starting authentication and authorization process using auth_cache..."
    )

    @classmethod
    @cached(
        _auth_cache,
        key=lambda cls, credentials, dataset_id, permission=AuthPermission.read: (
            credentials,
            dataset_id,
            permission,
        ),
    )
    def authorize(
        cls,
        credentials: HTTPAIAAuthorizationCredentials,
        dataset_id: str,
        permission: AuthPermission = AuthPermission.read,
    ) -> None:
        daas_api_key = credentials.api_key
        principals = credentials.principals

        if not AuthApiFacade.authorize(
            dataset_id,
            permission,
            daas_api_key=daas_api_key,
            principals=principals,
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
            )

    @classmethod
    @cached(_auth_cache)
    def get_api_key_by_dataset_id(cls, dataset_id: str):
        return AuthApiFacade.get_api_key_by_dataset_id(dataset_id)

    @classmethod
    @cached(_auth_cache)
    def get_access_token(cls):
        return AuthApiFacade.get_access_token()

    @classmethod
    def authorize_file_level_permissions(
        cls, credentials: HTTPAIAAuthorizationCredentials
    ) -> str:
        if not validate_principals_format_for_file_level_permissions(
            credentials.principals
        ):
            raise RuntimeException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                message=f"Unauthorized. Invalid Principals: {credentials.principals}",
            )
        return [credentials.principals[0].lower(), credentials.principals[1].lower()]
