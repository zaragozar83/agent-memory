import concurrent
import logging
from datetime import datetime
from typing import List

import psycopg2
from fastapi import status
from requests import Session

from src.api.v1.request.hybrid import HybridRequest
from src.application.dto.document import DocumentDto
from src.application.enum.distance_function import DistanceFunctionEnum
from src.application.enum.ranking_function import RankingFunctionEnum
from src.application.exception.runtime import RuntimeException
from src.application.service.text_search import TextSearchService
from src.application.service.vector_search import VectorSearchService
from src.application.utils.context import data_insights_var
from src.application.utils.text_utils import text_to_md5


class HybridSearchService:

    @classmethod
    def normalize_vector_search_results_scores(
        cls, vector_search_results: List[DocumentDto], distance_function
    ):
        for document_dto in vector_search_results:
            score = document_dto.score
            normalized_score = None

            if distance_function == DistanceFunctionEnum.COSINE_DISTANCE:
                normalized_score = 1 - score
            elif distance_function == DistanceFunctionEnum.L2_DISTANCE:
                normalized_score = 1 - (1 / (1 + score))
            elif distance_function == DistanceFunctionEnum.INNER_PRODUCT:
                inner_product_scores = [abs(r.score) for r in vector_search_results]
                normalized_score = 1 - (abs(score) / max(inner_product_scores))

            document_dto.score = normalized_score

        return vector_search_results

    @classmethod
    def reciprocal_rank_fusion_algorithm(
        cls,
        vector_search_results,
        text_search_results,
        vector_weight,
        text_search_weight,
        k=60,
    ):
        """
        The reciprocal rank fusion algorithm is based on Langchain's function.
        Langchain Function - https://github.com/langchain-ai/langchain/blob/master/templates/rag-fusion/rag_fusion/chain.py
        Research Paper - https://plg.uwaterloo.ca/~gvcormac/cormacksigir09-rrf.pdf
        """
        scores = {}
        documents = {}

        # Hybrid Search results and the weight associated with the algorithm
        hybrid_search_list = [
            {"results": vector_search_results, "weight": vector_weight},
            {"results": text_search_results, "weight": text_search_weight},
        ]

        # The loop ranks the documents based on the RRF algorithm and the hybrid search weights.
        for hybrid_search in hybrid_search_list:
            for rank, document in enumerate(hybrid_search["results"], start=1):
                document_id = document.id
                weight = hybrid_search["weight"]

                # Checks if the document was present in the scores dictionary
                score = 0 if document_id not in scores else scores[document_id]

                # Applies the RRF formula to calculate the score
                score += weight / (k + rank)

                # Assigns the score back to the document
                document.score = score
                scores[document_id] = score
                documents[document_id] = document

        # Sorts the results based on their score
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)

        # Formats the reranked documents and the metadata
        reranked_results = [
            documents[document_id] for (document_id, score) in sorted_scores
        ]

        return reranked_results

    @classmethod
    def weighted_ranking_algorithm(
        cls,
        vector_search_results,
        text_search_results,
        vector_weight,
        text_search_weight,
    ):
        # Combine the results and calculate combined scores
        hybrid_results: List[DocumentDto] = []

        # Create a dictionary from text_search_results for fast lookup by ID
        text_search_results_dict = {item.id: item for item in text_search_results}

        # Iterate over the vector_search_results and check if the id is in the text_ids set
        for vector_item in vector_search_results:
            # Set the score considering the weights
            vector_item.score = round(vector_item.score * vector_weight, 5)

            # Action for items where the id matches
            if vector_item.id in text_search_results_dict:
                # Combine the scores if IDs match
                text_item = text_search_results_dict[vector_item.id]
                combined_score = round(
                    vector_item.score + (text_item.score * text_search_weight), 5
                )
                vector_item.score = combined_score
                text_search_results.remove(text_item)

            # Add the item to the hybrid results
            hybrid_results.append(vector_item)

        # Process remaining text search results
        for text_item in text_search_results:
            final_score = round(text_item.score * text_search_weight, 5)
            text_item.score = final_score
            hybrid_results.append(text_item)

        # Sort the combined results based on the combined scores
        hybrid_results.sort(key=lambda x: x.score, reverse=True)

        return hybrid_results

    @classmethod
    def rerank(
        cls,
        vector_search_results: List[DocumentDto],
        text_search_results: List[DocumentDto],
        vector_weight: float,
        distance_function: DistanceFunctionEnum,
        ranking_function: RankingFunctionEnum,
        max_results,
        k: int = 60,
    ):
        # Get weights to the results
        text_search_weight = round(float(1 - vector_weight), 5)
        vector_search_results = cls.normalize_vector_search_results_scores(
            vector_search_results, distance_function
        )

        if ranking_function == RankingFunctionEnum.WEIGHTED_AVERAGE:
            hybrid_results = cls.weighted_ranking_algorithm(
                vector_search_results,
                text_search_results,
                vector_weight,
                text_search_weight,
            )
        elif ranking_function == RankingFunctionEnum.RRF_ALGORITHM:
            hybrid_results = cls.reciprocal_rank_fusion_algorithm(
                vector_search_results,
                text_search_results,
                vector_weight,
                text_search_weight,
                k=k,
            )
        else:
            hybrid_results = []

        # Get the final results considering the max_results
        return hybrid_results[:max_results]

    @classmethod
    def run_searches(
        cls,
        db: Session,
        hybrid_request: HybridRequest,
        application_id: str,
        datasource_name: str,
        model: str,
        dimension: int,
        max_results: int,
    ):
        try:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                vector_search_future = executor.submit(
                    VectorSearchService.similarity_search,
                    db=db,
                    query=hybrid_request.query,
                    application_id=application_id,
                    model=model,
                    dimension=dimension,
                    datasource_name=datasource_name,
                    max_results=max_results,
                    dataset_id=hybrid_request.dataset_id,
                    distance_function=hybrid_request.distance_function,
                    distance_threshold=hybrid_request.distance_threshold,
                    metadata=hybrid_request.metadata,
                    cmetadata=hybrid_request.cmetadata,
                    hybrid_search=True,
                )

                text_search_future = executor.submit(
                    TextSearchService.text_search,
                    db=db,
                    dataset_id=hybrid_request.dataset_id,
                    query=hybrid_request.query,
                    application_id=application_id,
                    datasource_name=datasource_name,
                    metadata=hybrid_request.metadata,
                    cmetadata=hybrid_request.cmetadata,
                    max_results=max_results,
                    hybrid_search=True,
                    parsing_function=hybrid_request.parsing_function,
                    include_cmetadata=hybrid_request.include_cmetadata,
                )

            vector_search_results = vector_search_future.result()
            full_text_search_results = text_search_future.result()
        except Exception as e:
            if (
                hasattr(e, "orig")
                and isinstance(e.orig, psycopg2.errors.InFailedSqlTransaction)
                and hybrid_request.parsing_function == "to_tsquery"
            ):
                logging.error(e)
                raise RuntimeException(
                    message=f"Failed to perform hybrid search with the 'to_tsquery' parsing function and the provided query. Query must consist of single tokens separated by the tsquery operators & (AND), | (OR), ! (NOT), and <-> (FOLLOWED BY). For more information on using 'to_tsquery' please refer to https://www.postgresql.org/docs/current/textsearch-controls.html#TEXTSEARCH-PARSING-QUERIES",
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )
            raise RuntimeException(
                message=f"Failed to perform hybrid search in Database.",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return vector_search_results, full_text_search_results

    @classmethod
    def hybrid_search(
        cls,
        db: Session,
        hybrid_request: HybridRequest,
        max_results: int,
        application_id: str,
        datasource_name: str,
        model: str,
        dimension: int,
    ):
        start_time = datetime.now()

        vector_search_results, full_text_search_results = cls.run_searches(
            db,
            hybrid_request,
            application_id,
            datasource_name,
            model,
            dimension,
            max_results,
        )

        final_results = cls.rerank(
            vector_search_results=vector_search_results,
            text_search_results=full_text_search_results,
            vector_weight=hybrid_request.vector_weight,
            distance_function=hybrid_request.distance_function,
            ranking_function=hybrid_request.ranking_function,
            max_results=max_results,
            k=hybrid_request.k,
        )
        dataset_object_ids = set()
        combined_chunk_indexes = set()
        total_score = 0
        total_count = 0
        for result in final_results:
            dataset_object_ids.add(result.metadata.get("dataset_object_id", ""))
            combined_chunk_indexes.add(
                result.metadata.get("dataset_object_id", "")
                + "_"
                + text_to_md5(result.document)
            )
            total_score += result.score
            total_count += 1
        average_score = total_score / total_count if total_count > 0 else 0
        data_insight_logger_dict = data_insights_var.get()
        data_insight_logger_dict.update(
            {
                "search_type": "Hybrid Search",
                "dataset_id": hybrid_request.dataset_id,
                "application_id": application_id,
                "dataset_object_ids": list(dataset_object_ids),
                "combined_chunk_indexes": list(combined_chunk_indexes),
                "datasource_name": datasource_name,
                "average_retrieval_score": average_score,
                "ranking_function": hybrid_request.ranking_function.value,
                "distance_function": hybrid_request.distance_function.value,
                "distance_threshold": hybrid_request.distance_threshold,
                "vector_weight": hybrid_request.vector_weight,
                "metadata": hybrid_request.metadata,
                "cmetadata": hybrid_request.cmetadata,
                "parsing_function": hybrid_request.parsing_function,
                "k": hybrid_request.k,
                "ignore_indexes": hybrid_request.ignore_indexes,
                "include_cmetadata": hybrid_request.include_cmetadata,
            }
        )
        data_insights_var.set(data_insight_logger_dict)

        logging.info(
            f"Hybrid search for dataset_id: {hybrid_request.dataset_id} completed in {datetime.now() - start_time}."
        )

        return final_results
