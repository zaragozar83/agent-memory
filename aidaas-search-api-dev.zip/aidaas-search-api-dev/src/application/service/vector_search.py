import logging
from concurrent.futures import Future, ThreadPoolExecutor
from typing import List, Optional

from requests import Session

from src.application.dto.document import DocumentDto
from src.application.dto.intent_space import IntentSpaceDto
from src.application.enum.distance_function import DistanceFunctionEnum
from src.application.facade import EmbeddingsApiFacade, IntentApiFacade
from src.application.service.auth import AuthService
from src.core.environment_variables import EnvironmentVariables
from src.domain.repository.document import DocumentRepository


class VectorSearchService:

    @classmethod
    def similarity_search(
        cls,
        db: Session,
        query: str,
        application_id: str,
        model: str,
        dimension: int,
        datasource_name: str,
        max_results: int,
        dataset_id: str,
        distance_function: DistanceFunctionEnum,
        include_neighbors: int = 0,
        distance_threshold: float | None = 0.5,
        metadata: Optional[dict] = None,
        cmetadata: Optional[dict] = None,
        language: Optional[str] = None,
        hybrid_search: bool = False,
        ignore_indexes: Optional[bool] = False,
        intent_spaces_limit: Optional[int] = None,
    ) -> List[DocumentDto]:

        _, client_id = AuthService.get_api_key_by_dataset_id(dataset_id)
        access_token, _ = AuthService.get_access_token()
        embeddings = EmbeddingsApiFacade(
            url=EnvironmentVariables.GEN_AI_GATEWAY_URL,
            model_name=model,
            client_id=client_id,
            access_token=access_token,
        )

        future_intent_spaces = None
        with ThreadPoolExecutor() as executor:
            future_request_query_embeddings = executor.submit(
                embeddings.get_embeddings, query
            )

            if intent_spaces_limit:
                future_intent_spaces = executor.submit(
                    IntentApiFacade.search,
                    query,
                    dataset_id,
                    intent_spaces_limit,
                )

        request_query_embeddings = future_request_query_embeddings.result()
        if intent_spaces_limit:
            metadata = cls.add_intent_spaces(
                query, dataset_id, future_intent_spaces, metadata
            )

        document_dtos = DocumentRepository.vector_search(
            db=db,
            request_query_embeddings=request_query_embeddings,
            dataset_id=dataset_id,
            application_id=application_id,
            vector_dims=dimension,
            datasource_name=datasource_name,
            distance_threshold=distance_threshold,
            distance_function=distance_function.value,
            max_results=max_results,
            metadata=metadata,
            cmetadata=cmetadata,
            language=language,
            include_neighbors=include_neighbors,
            hybrid_search=hybrid_search,
            ignore_indexes=ignore_indexes,
            enable_space_column_filter=bool(
                dataset_id in EnvironmentVariables.DATASETS_TO_USE_SPACE_COLUMNS
                or intent_spaces_limit
            ),
        )

        return document_dtos

    @staticmethod
    def add_intent_spaces(
        query: str,
        dataset_id: str,
        future_intent_spaces: Future[List[IntentSpaceDto]],
        metadata: Optional[dict] = None,
    ) -> dict:
        if not future_intent_spaces or not future_intent_spaces.result():
            logging.info(f"[{dataset_id}] No intent spaces found for query {query}.")
            return

        namespaces = [
            {"space_key": intent_space.space_id}
            for intent_space in future_intent_spaces.result()
        ]
        metadata = metadata or {}
        metadata.update({"namespaces_operator": "or", "namespaces": namespaces})
        logging.info(
            f"[{dataset_id}] Using {len(namespaces)} intent spaces to filter results."
        )
        return metadata
