from dataclasses import dataclass


@dataclass
class RuntimeException(Exception):
    status_code: int
    message: str
