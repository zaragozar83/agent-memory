from src.application.exception.runtime import RuntimeException

__all__ = [
    "RuntimeException",
]
