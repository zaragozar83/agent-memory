from unittest.mock import MagicMock, Mock, patch

import pytest
from neo4j import Session
from src.core.environment_variables import EnvironmentVariables
from src.domain.database.neo4j_config import Neo4jHandler


@pytest.fixture
def set_env():
    EnvironmentVariables.NEO4J_URI = "neo4j://host:1"
    EnvironmentVariables.NEO4J_DATABASE = "test_database"
    EnvironmentVariables.NEO4J_USERNAME = "test_username"
    EnvironmentVariables.NEO4J_PASSWORD = "test_password"


def test_init_sets_attributes(set_env):
    # Act
    neo4j_handler = Neo4jHandler()

    # Assert
    assert "neo4j://host:1" == neo4j_handler._uri
    assert "test_database" == neo4j_handler._database
    assert "test_username" == neo4j_handler._username
    assert "test_password" == neo4j_handler._password


def test_init_calls_driver_with_correct_arguments(set_env):

    with patch("neo4j._sync.driver.GraphDatabase.driver") as mock_driver:
        neo4j_handler = Neo4jHandler()
        mock_driver.assert_called_once_with(
            "neo4j://host:1",
            auth=("test_username", "test_password"),
            resolver=neo4j_handler._custom_resolver,
            connection_timeout=EnvironmentVariables.NEO4J_DRIVER_TIMEOUT,
        )


def test_custom_resolver_returns_address_when_server_address_found():
    # Arrange

    EnvironmentVariables.NEO4J_ADDRESS_MAP = ["neo4j://host:1"]

    resolver = Neo4jHandler._custom_resolver("neo4j://host:1")

    for a in resolver:
        if a.host in EnvironmentVariables.NEO4J_ADDRESS_MAP:
            break

    with pytest.raises(
        OSError, match=r"\[neo4j driver\] Could not resolve any socket addresses."
    ):
        next(resolver)


def test_custom_resolver_raises_service_unavailable_when_server_address_not_found():
    # Arrange
    EnvironmentVariables.NEO4J_ADDRESS_MAP = []

    # Act & Assert
    with pytest.raises(OSError):
        list(Neo4jHandler._custom_resolver(None))


def test_close_driver_when_driver_is_not_none(set_env):
    # Arrange
    neo4j_handler = Neo4jHandler()
    neo4j_handler._driver = MagicMock()
    # Act
    neo4j_handler.close()
    # Assert
    assert neo4j_handler._driver.close.is_called_once()


def test_get_session(set_env):

    neo4j_handler = Neo4jHandler()

    with patch.object(neo4j_handler, "_driver", Mock()) as mock_driver:
        neo4j_handler._driver.session.return_value = "mock_session"

        # Act
        result = neo4j_handler.get_session()

        # Assert
        mock_driver.session.assert_called_once_with(database=neo4j_handler._database)

        assert result == "mock_session"


def test_get_neo4j_session_returns_session_and_closes(set_env):

    # Arrange
    with patch.object(Neo4jHandler, "get_session") as mock_handler, patch.object(
        Neo4jHandler, "close"
    ) as mock_close:
        mock_neo4j_session = MagicMock(spec=Session)
        mock_handler.return_value = mock_neo4j_session

        # Act
        result = Neo4jHandler.get_neo4j_session()
        with result:

            # Assert
            mock_handler.assert_called_once()
            assert mock_neo4j_session == result

    mock_close.assert_called_once()
