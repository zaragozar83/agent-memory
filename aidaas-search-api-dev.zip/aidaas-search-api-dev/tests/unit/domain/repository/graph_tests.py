from unittest.mock import MagicMock, Mock, patch

import pytest
from neo4j import Session
from src.application.facade.embeddings_api import EmbeddingsApiFacade
from src.domain.database.neo4j_config import Neo4jHandler
from src.domain.repository.graph import GraphRepository


@pytest.fixture
def mock_graph_request():
    return {
        "query": "some query",
        "dataset_id": "test_dataset_id",
        "score_threshold": 0.5,
        "entities": ["entity1", "entity2"],
        "relationships": ["relation1", "relation2"],
        "embedded_node_label": "some_label",
    }


def test_search_graph_documents_golden_case_query_contains_all_filters(
    mock_graph_request,
):
    # Arrange
    mock_neo4j_session = MagicMock(spec=Session)
    embeddings = Mock(spec=EmbeddingsApiFacade)

    with patch.object(
        Neo4jHandler, "get_neo4j_session"
    ) as mock_session_maker, patch.object(
        embeddings, "embed_query", return_value="query_embeddings"
    ) as embed_query:

        mock_session_maker.return_value.__enter__.return_value = mock_neo4j_session

        # Act
        result = GraphRepository.search_graph_documents(
            request_query=mock_graph_request["query"],
            dataset_id=mock_graph_request["dataset_id"],
            score_threshold=mock_graph_request["score_threshold"],
            embeddings=embeddings,
            entities=mock_graph_request["entities"],
            relationships=mock_graph_request["relationships"],
            embedded_node_label=mock_graph_request["embedded_node_label"],
        )

    # Assert
    assert result
    mock_session_maker.assert_called_once()
    mock_neo4j_session.run.assert_called_once()

    query = mock_neo4j_session.run.call_args[0][0]

    # Entity filter added
    assert "WHERE e:entity1 OR e:entity2" in query

    # Relationship filter added
    assert 'type(r) IN ["relation1","relation2"] ' in query

    # Query embeddings generated and added to query
    embed_query.assert_called_once_with("some query")
    assert "query_embeddings" in query

    # Label filter added to query
    assert "'some_label' IN labels(node)" in query


def test_search_graph_documents_no_entities_no_entity_filter_in_query(
    mock_graph_request,
):
    # Arrange
    mock_neo4j_session = MagicMock(spec=Session)
    embeddings = Mock(spec=EmbeddingsApiFacade)

    with patch.object(Neo4jHandler, "get_neo4j_session") as mock_session_maker:

        mock_session_maker.return_value.__enter__.return_value = mock_neo4j_session

        # Act
        GraphRepository.search_graph_documents(
            request_query=mock_graph_request["query"],
            dataset_id=mock_graph_request["dataset_id"],
            score_threshold=mock_graph_request["score_threshold"],
            embeddings=embeddings,
            entities=None,
            relationships=mock_graph_request["relationships"],
            embedded_node_label=mock_graph_request["embedded_node_label"],
        )

    # Assert
    query = mock_neo4j_session.run.call_args[0][0]
    assert "WHERE e:" not in query


def test_search_graph_documents_no_relationships_no_relationship_filter_in_query(
    mock_graph_request,
):
    # Arrange
    mock_neo4j_session = MagicMock(spec=Session)
    embeddings = Mock(spec=EmbeddingsApiFacade)

    with patch.object(Neo4jHandler, "get_neo4j_session") as mock_session_maker:

        mock_session_maker.return_value.__enter__.return_value = mock_neo4j_session

        # Act
        GraphRepository.search_graph_documents(
            request_query=mock_graph_request["query"],
            dataset_id=mock_graph_request["dataset_id"],
            score_threshold=mock_graph_request["score_threshold"],
            embeddings=embeddings,
            entities=mock_graph_request["entities"],
            relationships=None,
            embedded_node_label=mock_graph_request["embedded_node_label"],
        )

    # Assert
    query = mock_neo4j_session.run.call_args[0][0]
    assert (
        "OPTIONAL MATCH p=(e1)-[r:`relation1`&`relation2`]-(e2)\nWHERE e1 in nodeslist OR e2 in nodeslist"
        not in query
    )


def test_search_graph_documents_no_embedded_node_label(mock_graph_request):
    # Arrange
    mock_neo4j_session = MagicMock(spec=Session)
    embeddings = Mock(spec=EmbeddingsApiFacade)

    with patch.object(Neo4jHandler, "get_neo4j_session") as mock_session_maker:

        mock_session_maker.return_value.__enter__.return_value = mock_neo4j_session

        # Act
        GraphRepository.search_graph_documents(
            request_query=mock_graph_request["query"],
            dataset_id=mock_graph_request["dataset_id"],
            score_threshold=mock_graph_request["score_threshold"],
            embeddings=embeddings,
            entities=mock_graph_request["entities"],
            relationships=mock_graph_request["relationships"],
        )

    # Assert
    query = mock_neo4j_session.run.call_args[0][0]
    assert "'' IN labels(node) OR '' = ''" in query


def test_search_graph_documents_null_embedded_node_label(mock_graph_request):
    # Arrange
    mock_neo4j_session = MagicMock(spec=Session)
    embeddings = Mock(spec=EmbeddingsApiFacade)

    with patch.object(Neo4jHandler, "get_neo4j_session") as mock_session_maker:

        mock_session_maker.return_value.__enter__.return_value = mock_neo4j_session

        # Act
        GraphRepository.search_graph_documents(
            request_query=mock_graph_request["query"],
            dataset_id=mock_graph_request["dataset_id"],
            score_threshold=mock_graph_request["score_threshold"],
            embeddings=embeddings,
            entities=mock_graph_request["entities"],
            relationships=mock_graph_request["relationships"],
            embedded_node_label=None,
        )

    # Assert
    query = mock_neo4j_session.run.call_args[0][0]
    assert "'' IN labels(node) OR '' = ''" in query
