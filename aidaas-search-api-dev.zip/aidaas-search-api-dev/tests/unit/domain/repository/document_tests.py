from unittest.mock import MagicMock, Mock, patch

import numpy as np
import pytest
from sqlalchemy.dialects import postgresql
from sqlalchemy.ext.declarative import declarative_base
from src.application.dto.document import DocumentDto
from src.domain.repository.document import DocumentRepository


@pytest.fixture
def document_model():
    base = declarative_base()

    return DocumentRepository._get_table("app12345", base)


def test__get_table_class_created():
    # Arange
    table_name = "table_name"
    base = declarative_base()

    # Act
    document_model = DocumentRepository._get_table(table_name, base)

    # Assert
    assert document_model.__tablename__ == table_name
    assert hasattr(document_model, "id")
    assert hasattr(document_model, "dataset_id")
    assert hasattr(document_model, "document")
    assert hasattr(document_model, "embedding")
    assert hasattr(document_model, "metadata_")
    assert hasattr(document_model, "cmetadata")
    assert hasattr(document_model, "tsv_doc")
    assert hasattr(document_model, "language")


def test_dto_from_model_and_score_and_neighbors_dto_created():

    # Arrange
    document_model = Mock()
    document_model.id = "doc_id"
    document_model.dataset_id = "dataset_id"
    document_model.document = "doc_text"
    document_model.embedding = Mock()
    document_model.metadata_ = {"metadata": "metadata_value"}
    document_model.cmetadata = {"cmetadata": "cmetadata_value"}
    document_model.tsv_doc = "tsv_doc_value"
    document_model.language = "en"
    score = 0.7
    neighbors = {"neighbor1": 0.1, "neighbor2": 0.2}

    # Act
    result = DocumentRepository.dto_from_model_and_score_and_neighbors(
        document_model, score, neighbors
    )

    # Assert
    expected_result = DocumentDto(
        id="doc_id",
        dataset_id="dataset_id",
        document="doc_text",
        score=score,
        metadata={"metadata": "metadata_value"},
        cmetadata={"cmetadata": "cmetadata_value"},
        language="en",
        neighbors=neighbors,
    )
    assert result == expected_result


def test_get_namespaces_filter_filter_conditions_match_with_space_columns():
    metadata = {
        "namespaces": [
            {"space_key": 123},
            {"space_key": "value2"},
        ]
    }
    document_model = DocumentRepository._get_table("app12345", declarative_base())

    filter = DocumentRepository._get_namespaces_filter(metadata, document_model, True)

    str_filter = str(
        filter.compile(
            dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True}
        )
    )
    assert "app12345.space_key IN ('123', 'value2')" == str_filter


def test_get_namespaces_filter_filter_conditions_match():
    metadata = {
        "namespaces": [
            {"space_key": 123},
            {"space_key": "value2"},
        ]
    }
    document_model = DocumentRepository._get_table("app12345", declarative_base())

    filter = DocumentRepository._get_namespaces_filter(metadata, document_model, False)

    str_filter = str(
        filter.compile(
            dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True}
        )
    )
    assert (
        'jsonb_contains(app12345.metadata, \'{"namespaces": [{"space_key": 123}]}\') AND jsonb_contains(app12345.metadata, \'{"namespaces": [{"space_key": "value2"}]}\')'
        == str_filter
    )


def test_duplicate_filter_with_no_duplicates(document_model):
    # Arrange
    query = MagicMock()
    distance = MagicMock()
    max_results = 10
    results = [
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.1),
        (document_model(document="doc2", embedding=np.array([4, 5, 6])), 0.2),
        (document_model(document="doc3", embedding=np.array([7, 8, 9])), 0.3),
    ]
    query.order_by.return_value.limit.return_value.all.return_value = results

    # Act
    filtered_results = DocumentRepository._duplicate_filter(
        query, distance, max_results
    )

    # Assert
    assert len(filtered_results) == len(results)
    assert filtered_results == results


def test_duplicate_filter_with_duplicated_documents(document_model):
    # Arrange
    query = MagicMock()
    distance = MagicMock()
    max_results = 10
    results = [
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.1),
        (document_model(document="doc1", embedding=np.array([4, 5, 6])), 0.2),
        (document_model(document="doc2", embedding=np.array([7, 8, 9])), 0.3),
    ]
    query.order_by.return_value.limit.return_value.all.return_value = results

    # Act
    filtered_results = DocumentRepository._duplicate_filter(
        query, distance, max_results
    )

    # Assert
    assert len(filtered_results) == 3
    assert filtered_results == results


def test_duplicate_filter_with_duplicated_embeddings(document_model):
    # Arrange
    query = MagicMock()
    distance = MagicMock()
    max_results = 10
    results = [
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.1),
        (document_model(document="doc2", embedding=np.array([1, 2, 3])), 0.2),
        (document_model(document="doc3", embedding=np.array([7, 8, 9])), 0.3),
    ]
    query.order_by.return_value.limit.return_value.all.return_value = results

    # Act
    filtered_results = DocumentRepository._duplicate_filter(
        query, distance, max_results
    )

    # Assert
    assert len(filtered_results) == 3
    assert filtered_results == results


def test_duplicate_filter_with_duplicated_documents_and_embeddings(document_model):
    # Arrange
    query = MagicMock()
    distance = MagicMock()
    max_results = 10
    results = [
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.1),
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.2),
        (document_model(document="doc2", embedding=np.array([4, 5, 6])), 0.3),
    ]
    query.order_by.return_value.limit.return_value.all.return_value = results

    # Act
    filtered_results = DocumentRepository._duplicate_filter(
        query, distance, max_results
    )

    # Assert
    assert len(filtered_results) == 2
    assert filtered_results == [results[0], results[2]]


def test_duplicate_filter_with_max_results(document_model):
    # Arrange
    query = MagicMock()
    distance = MagicMock()
    max_results = 2
    results = [
        (document_model(document="doc1", embedding=np.array([1, 2, 3])), 0.1),
        (document_model(document="doc2", embedding=np.array([1, 2, 3])), 0.2),
        (document_model(document="doc3", embedding=np.array([7, 8, 9])), 0.3),
        (document_model(document="doc4", embedding=np.array([4, 4, 4])), 0.3),
    ]
    query.order_by.return_value.limit.return_value.all.return_value = results

    # Act
    filtered_results = DocumentRepository._duplicate_filter(
        query, distance, max_results
    )

    # Assert
    assert len(filtered_results) == max_results
    assert filtered_results == results[:max_results]


def test_include_neighbor_chunks_with_no_results(document_model):
    db = Mock()
    results = []
    n = 1
    expected_results = []

    result = DocumentRepository._include_neighbor_chunks(db, document_model, results, n)

    assert result == expected_results


def test_include_neighbor_chunks_with_results(document_model):

    db = MagicMock()
    results = [
        (
            MagicMock(
                metadata_={"chunk_index": 1, "dataset_object_id": "obj1"},
                dataset_id="dataset1",
            ),
        ),
        (
            MagicMock(
                metadata_={"chunk_index": 2, "dataset_object_id": "obj1"},
                dataset_id="dataset1",
            ),
        ),
    ]
    n = 2

    db.query(
        document_model
    ).filter.return_value.filter.return_value.all.return_value = [
        MagicMock(
            metadata_={"chunk_index": 0, "dataset_object_id": "obj1"}, document="doc0"
        ),
        MagicMock(
            metadata_={"chunk_index": 3, "dataset_object_id": "obj1"}, document="doc3"
        ),
    ]

    # Act
    new_results = DocumentRepository._include_neighbor_chunks(
        db, document_model, results, n
    )

    # Assert
    assert len(new_results) == 2
    assert new_results[0][1]["previous"] == ["doc0"]
    assert new_results[0][1]["next"] == ["doc3"]
    assert new_results[1][1]["previous"] == ["doc0"]
    assert new_results[1][1]["next"] == ["doc3"]


def test_text_search_golden_path(document_model):
    db = MagicMock()
    query = "test query"
    dataset_id = "dataset1"
    application_id = "app12345"
    datasource_name = "datasource1"
    metadata = {"key": "value"}
    cmetadata = {"ckey": "cvalue"}
    max_results = 10
    hybrid_search = False

    # return a list of 10 mock items from db
    db.query(
        document_model
    ).filter.return_value.filter.return_value.order_by.return_value.filter.return_value.filter.return_value.limit.return_value.all.return_value = [
        MagicMock(rank=i) for i in range(1, 11)
    ]

    # Act
    results = DocumentRepository.text_search(
        db,
        query,
        dataset_id,
        application_id,
        datasource_name,
        metadata,
        cmetadata,
        max_results,
        hybrid_search,
    )

    # Assert
    assert len(results) == max_results

    # dataset filter applied
    assert str(document_model.dataset_id == dataset_id) == str(
        db.query(document_model).filter.call_args[0][0]
    )


def test_text_search_no_results(document_model):
    db = MagicMock()
    query = "test query"
    dataset_id = "dataset1"
    application_id = "app1"
    datasource_name = "datasource1"
    metadata = {"key": "value"}
    cmetadata = {"ckey": "cvalue"}
    max_results = 10
    hybrid_search = False

    db.query(
        document_model
    ).filter.return_value.filter.return_value.filter.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = (
        []
    )

    # Act
    results = DocumentRepository.text_search(
        db,
        query,
        dataset_id,
        application_id,
        datasource_name,
        metadata,
        cmetadata,
        max_results,
        hybrid_search,
    )

    # Assert
    assert len(results) == 0


def test_text_search_no_metadata():
    db = MagicMock()
    query = "test query"
    dataset_id = "dataset1"
    application_id = "app1"
    datasource_name = "datasource1"
    max_results = 10
    hybrid_search = False

    # return a list of 10 mock items from db
    db.query(
        document_model
    ).filter.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = [
        MagicMock(rank=i) for i in range(1, 11)
    ]

    # Act
    results = DocumentRepository.text_search(
        db,
        query,
        dataset_id,
        application_id,
        datasource_name,
        None,
        None,
        max_results,
        hybrid_search,
    )

    # Assert
    assert len(results) == max_results


def test_vector_search_valid_inputs_cosine_distance(document_model):
    # Mock the necessary dependencies
    db = Mock()
    request_query_embeddings = [1, 2, 3]
    dataset_id = "test_dataset"
    application_id = "test_application"
    vector_dims = 3
    datasource_name = "test_datasource"
    distance_threshold = 0.5
    distance_function = "cosine_distance"
    max_results = 100
    metadata = {"key": "value"}
    cmetadata = {"key": "value"}
    language = "en"
    include_neighbors = 0
    hybrid_search = False

    filtered_result = [MagicMock() for i in range(1, 4)]

    with patch.object(
        DocumentRepository, "_duplicate_filter", return_value=filtered_result
    ):
        with patch.object(
            DocumentRepository,
            "dto_from_model_and_score_and_neighbors",
            return_value=MagicMock(),
        ):

            # Call the function
            document_dtos = DocumentRepository.vector_search(
                db,
                request_query_embeddings,
                dataset_id,
                application_id,
                vector_dims,
                datasource_name,
                distance_threshold,
                distance_function,
                max_results,
                metadata,
                cmetadata,
                language,
                include_neighbors,
                hybrid_search,
            )

        # Assert the expected output
        assert len(document_dtos) == 3
