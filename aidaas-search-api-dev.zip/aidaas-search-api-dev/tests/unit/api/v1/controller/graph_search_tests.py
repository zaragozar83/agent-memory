from unittest import mock
from unittest.mock import patch

import pytest
from assertpy import assert_that
from fastapi import HTTPException, status
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient
from src.api.v1.controller.search import router
from src.api.v1.response.graph import GraphResponse
from src.application.dto.dataset import DatasetDto
from src.application.exception.runtime import RuntimeException
from src.application.service.auth import AuthService
from src.application.utils.headers_credentials import HTTPAIAAuthorizationCredentials

client = TestClient(router)


class TestGraphSearch:

    def test_graph_search_when_success(
        self,
        mock_graphsearch_response: GraphResponse,
        mock_graph_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the success scenario of the graph_search function.

        This test verifies that a status code of 200 (Success)
        is raised when the client sends a request to the graph_search endpoint.


        """
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), patch(
            "src.application.service.graph_search.GraphSearchService.graph_search",
            return_value=mock_graphsearch_response,
        ):

            response = client.post(
                "/graph",
                json=mock_graph_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_200_OK

    def test_graph_search_when_missing_required_fields(
        self,
        mock_graph_required_fields_validation_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the missing required field scenario of the graph_search function.

        This test verifies that an HTTPException with a status code of
        422 (Unprocessable entity) is raised when the client sends a request to
        the graph_search endpoint without a required field.

        """
        with mock.patch(
            "src.api.v1.controller.search.graph_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RequestValidationError
        ):
            response = client.post(
                "/graph",
                json=mock_graph_required_fields_validation_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_graph_search_empty_query_string(
        self,
        mock_graph_request_query_empty: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the empty query string case of the graph_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the hybrid_search endpoint with empty query string.


        """
        with mock.patch(
            "src.api.v1.controller.search.graph_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RuntimeException
        ):
            response = client.post(
                "/graph",
                json=mock_graph_request_query_empty,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_graph_search_invalid_api_key(self):
        """
        Test the unauthorized case of the graph_search function.

        This test verifies that an HTTPException with a status code of
        401 (Unauthorized) is raised when the client sends a request to
        the graph_search endpoint without a valid API key.

        """
        # Arrange
        mock_dataset_id = "dfjkhajcfewkhqrljw"
        mock_scheme = "Bearer"
        mock_api_key = "api_key"

        mock_credentials = HTTPAIAAuthorizationCredentials(
            scheme=mock_scheme, credentials=mock_api_key
        )

        # Act
        mock_is_valid = False
        with mock.patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=mock_is_valid,
        ):
            with pytest.raises(HTTPException) as exc_info:
                AuthService.authorize(
                    credentials=mock_credentials,
                    dataset_id=mock_dataset_id,
                )
            assert exc_info.value.status_code == status.HTTP_403_FORBIDDEN

    def test_graph_search_invalid_principal(self):
        """
        Test the unauthorized case of the graph_search function.

        This test verifies that an HTTPException with a status code of
        401 (Unauthorized) is raised when the client sends a request to
        the graph_search endpoint without a valid API key.

        """
        # Arrange
        mock_dataset_id = "dfjkhajcfewkhqrljw"
        mock_principals = ["userName", "Group1"]

        mock_credentials = HTTPAIAAuthorizationCredentials(principals=mock_principals)

        # Act
        mock_is_valid = False
        with mock.patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=mock_is_valid,
        ):
            with pytest.raises(HTTPException) as exc_info:
                AuthService.authorize(
                    credentials=mock_credentials,
                    dataset_id=mock_dataset_id,
                )
            assert exc_info.value.status_code == status.HTTP_403_FORBIDDEN

    def test_graph_search_without_api_key(self):
        """
        Test the unauthorized case of the graph_search function.

        This test verifies that an HTTPException with a status code of
        403 (Forbidden) is raised when the client sends a request to
        the graph_search endpoint without a valid API key.

        """
        mock_max_results = 3

        with pytest.raises(HTTPException) as e:
            client.post(
                f"/graph/?maxResults={mock_max_results}",
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "score_threshold": 0.7,
                },
            )

            # Assert:
            assert_that(e.value).is_instance_of(HTTPException)
            assert_that(e.value.status_code).is_equal_to(403)

    def test_graph_search_valid_api_key_without_dataset_id(
        self, mock_validate_access_token_response
    ):
        """
        Test the graph search API endpoint with valid authentication credentials.

        This test verifies that the /graph endpoint can be accessed
        with valid authentication credentials.

        """
        mock_max_results = 1

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ):
            with pytest.raises(RuntimeException) as e:
                client.post(
                    f"/graph/?maxResults={mock_max_results}",
                    headers={"Authorization": "Bearer valid_token"},
                    json={
                        "query": "overview",
                        "dataset_id": "",
                        "score_threshold": 0.7,
                    },
                )

        # Assert:
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(400)

    def test_graph_search_service_is_down(self, mock_validate_access_token_response):
        """
        Test the graph search API endpoint with valid authentication credentials.
        """
        mock_max_results = 1

        # Act: Patch the validate method of the auth_api class to return the mock return value

        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.embed_documents",
            return_value=[],
        ) as mocked_embeddings, patch(
            "src.application.service.graph_search.GraphSearchService.graph_search",
            side_effect=HTTPException(status_code=403, detail="Forbidden"),
        ) as mock_db:

            with pytest.raises(HTTPException) as e:
                client.post(
                    f"/graph/?maxResults={mock_max_results}",
                    headers={"Authorization": "Bearer valid_token"},
                    json={
                        "query": "overview",
                        "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                        "score_threshold": 0.7,
                    },
                )

            # Assert:
            assert_that(e.value).is_instance_of(HTTPException)
            assert_that(e.value.status_code).is_equal_to(403)

    def test_graph_search_score_threshold_validation(
        self,
        mock_graph_search_score_threshold_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the invalid score threshold of the graph_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the graph_search API endpoint with score threshold not between 0 to 1.


        """
        with patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(RequestValidationError):
            response = client.post(
                "/graph",
                json=mock_graph_search_score_threshold_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_graph_search_dataset_id_does_not_exist(
        self, mock_validate_access_token_response
    ):
        """
        Test the graph endpoint when dataset_id does not exist.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/graph/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "score_threshold": 0.7,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(404)

    def test_graph_search_when_api_key_success(
        self,
        mock_graphsearch_response: GraphResponse,
        mock_graph_request: dict,
    ):
        """
        Test the success scenario of the graph_search function.

        This test verifies that a status code of 200 (Success)
        is raised when the client sends a request to the graph_search endpoint.


        """
        headers = {"Authorization": "Bearer xxxx"}
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), patch(
            "src.application.service.graph_search.GraphSearchService.graph_search",
            return_value=mock_graphsearch_response,
        ):

            response = client.post("/graph", json=mock_graph_request, headers=headers)
            assert response.status_code == status.HTTP_200_OK
