from typing import List
from unittest import mock
from unittest.mock import MagicMock, patch

import pytest
from assertpy import assert_that
from fastapi import HTTPException, status
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from src.api.v1.controller.search import router
from src.api.v1.factory.document_response import DocumentResponseFactory
from src.application.dto.dataset import DatasetDto
from src.application.dto.document import DocumentDto
from src.application.enum.distance_function import DistanceFunctionEnum
from src.application.enum.ranking_function import RankingFunctionEnum
from src.application.exception.runtime import RuntimeException
from src.application.service.hybrid_search import HybridSearchService
from src.domain.repository.document import DocumentRepository

client = TestClient(router)


class TestHybridSearch:

    def test_hybrid_search_when_success(
        self,
        mock_search_response: List[DocumentDto],
        mock_vector_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the success scenario of the hybrid_search function.

        This test verifies that a status code of 200 (Success)
        is raised when the client sends a request to the hybrid_search endpoint.


        """
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), mock.patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), mock.patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.hybrid_search.HybridSearchService.rerank",
            return_value=mock_search_response,
        ):
            response = client.post(
                "/hybrid", json=mock_vector_request, headers=mock_bearer_token
            )
        assert response.status_code == status.HTTP_200_OK

    def test_hybrid_search_when_missing_required_fields(
        self,
        mock_vector_required_fields_validation_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the missing required field scenario of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        422 (Unprocessable entity) is raised when the client sends a request to
        the hybrid_search endpoint without a required field.

        """
        with mock.patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RequestValidationError
        ):
            response = client.post(
                "/hybrid",
                json=mock_vector_required_fields_validation_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_hybrid_search_empty_query_string(
        self,
        mock_vector_request_query_empty: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the empty query string case of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the hybrid_search endpoint with empty query string.


        """
        with mock.patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RuntimeException
        ):
            response = client.post(
                "/hybrid",
                json=mock_vector_request_query_empty,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_hybrid_search_when_distance_function_is_different(
        self,
        mock_vector_distance_function_validation_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the different distance function case of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        422 (Unprocessable entity) is raised when the client sends a request to
        the hybrid_search endpoint with distance function other than cosine distance, l2_distance and innner_product.


        """
        with mock.patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RequestValidationError
        ):
            response = client.post(
                "/hybrid",
                json=mock_vector_distance_function_validation_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_hybrid_search_valid_search_for_cosine_distance(
        self,
        mock_search_response: List[DocumentDto],
        mock_vector_request: dict,
        mock_document_responses: List[dict],
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the Cosine distance function for the hybrid_search function.

        This test verifies that a status code of 200 (Ok) is raised when the client sends a request to
        the hybrid_search endpoint with Cosine distance function.


        """
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), mock.patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), mock.patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.hybrid_search.HybridSearchService.rerank",
            return_value=mock_search_response,
        ):
            response = client.post(
                "/hybrid", json=mock_vector_request, headers=mock_bearer_token
            )
        assert response.status_code == status.HTTP_200_OK

        response_data = response.json().get("data")
        assert response_data == mock_document_responses

    def test_hybrid_search_valid_search_for_l2_distance(
        self,
        mock_search_response: List[DocumentDto],
        mock_document_responses: List[dict],
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the l2_distance function for the hybrid_search function.

        This test verifies that a status code of 200 (Ok) is raised when the client sends a request to
        the hybrid_search endpoint with l2_distance function.


        """
        mock_max_results = 2
        distance_function = "l2_distance"

        with mock.patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), mock.patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), mock.patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.hybrid_search.HybridSearchService.rerank",
            return_value=mock_search_response,
        ):
            response = client.post(
                f"/hybrid?maxResults={mock_max_results}",
                headers=mock_bearer_token,
                json={
                    "query": "giant dell Michael",
                    "dataset_id": "bf15353c-df2d-4480-bfe7-1ef24db725e7",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )
        assert response.status_code == status.HTTP_200_OK
        assert response.json().get("data") == mock_document_responses

    def test_hybrid_search_valid_search_for_inner_product(
        self,
        mock_search_response: List[DocumentDto],
        mock_document_responses: List[dict],
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the inner product distance function for the hybrid_search function.

        This test verifies that a status code of 200 (Ok) is raised when the client
        sends a request to the hybrid_search endpoint with l2_distance function.


        """
        mock_max_results = 2
        distance_function = "inner_product"

        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), mock.patch(
            "src.application.service.auth.AuthService.authorize",
            return_value=True,
        ), mock.patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response,
        ), mock.patch(
            "src.application.service.hybrid_search.HybridSearchService.rerank",
            return_value=mock_search_response,
        ):
            response = client.post(
                f"/hybrid?maxResults={mock_max_results}",
                headers=mock_bearer_token,
                json={
                    "query": "giant dell Michael",
                    "dataset_id": "bf15353c-df2d-4480-bfe7-1ef24db725e7",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )
        assert response.status_code == status.HTTP_200_OK
        assert response.json().get("data") == mock_document_responses

    def test_hybrid_search_invalid_api_key(self, mock_validate_access_token_response):
        """
        Test the unauthorized case of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        401 (Unauthorized) is raised when the client sends a request to
        the hybrid_search endpoint without a valid API key.

        """
        # Arrange: Create a Mock the maxResults query parameter
        mock_max_results = 1
        distance_function = "cosine_distance"
        mock_is_valid = False

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=mock_is_valid,
        ) as mock_validate, pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/hybrid?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer invalid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )
        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(status.HTTP_403_FORBIDDEN)
        assert_that(mock_validate.call_count).is_equal_to(1)

    def test_hybrid_search_without_api_key(self):
        """
        Test the unauthorized case of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        403 (Forbidden) is raised when the client sends a request to
        the hybrid_search endpoint without a valid API key.

        """
        # Arrange: Create a Mock the maxResults query parameter
        #
        # The mock_max_results variable is used to simulate the maxResults query parameter sent in the request.
        mock_max_results = 1
        distance_function = "cosine_distance"

        # Act: Here we make a request to the hybrid_search endpoint without sending a valid API key.
        with pytest.raises(HTTPException) as e:
            # Make a request to the hybrid_search endpoint without sending a valid API key
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "similarity_weight": "0.5",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(status.HTTP_403_FORBIDDEN)

    def test_hybrid_search_valid_api_key_without_dataset_id(
        self, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /hybrid endpoint can be accessed
        with valid authentication credentials.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), pytest.raises(
            RuntimeException
        ) as e:
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(400)

    def test_hybrid_search_embbedings_api_is_down(
        self, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.
        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.get_embeddings",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ) as mocked_embeddings, pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(403)
        assert_that(e.value.detail).is_equal_to("Forbidden")

    def test_hybrid_search_catalog_api_is_down(
        self, mock_validate_access_token_response
    ):
        """
        test the vector endpoint with valid authentication credentials.
        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.get_embeddings",
            return_value=[],
        ) as mocked_embeddings, patch(
            "src.domain.repository.document.DocumentRepository.vector_search",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ), pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(403)

    def test_hybrid_search_vector_weight_validation(
        self,
        mock_hybrid_vector_weight_validation_request: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the invalid vector weight case of the hybrid_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the hybrid_search endpoint with vector weight not between 0 to 1.


        """
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), mock.patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), pytest.raises(
            RequestValidationError
        ):
            response = client.post(
                "/hybrid",
                json=mock_hybrid_vector_weight_validation_request,
                headers=mock_bearer_token,
            )
            assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_perform_full_text_search(self):
        # Create a mock Session object
        db = MagicMock(spec=Session)

        # Create some test data
        query = "example query"
        dataset_id = "example dataset id"
        application_id = "example application id"
        max_results = 10

        # Call the method under test
        results = DocumentRepository.text_search(
            db,
            query=query,
            dataset_id=dataset_id,
            application_id=application_id,
            datasource_name="ecs",
            metadata=None,
            cmetadata=None,
            max_results=max_results,
        )

        assert_that(results).is_instance_of(list)

    def test_full_text_search_service(self, mock_full_text_search_results):
        # Mock dependencies
        db = MagicMock()
        hybrid_request = MagicMock()
        max_results = 10
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), mock.patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=mock_full_text_search_results,
        ):
            # Call the method under test
            from src.application.service.text_search import TextSearchService

            result = TextSearchService.text_search(
                db=db,
                dataset_id=hybrid_request.dataset_id,
                query=hybrid_request.query,
                application_id="application_id",
                datasource_name="ecs",
                metadata=hybrid_request.metadata,
                cmetadata=hybrid_request.cmetadata,
                max_results=max_results,
            )

        assert_that(result).is_instance_of(list)

    @pytest.mark.parametrize(
        "distance_function",
        [
            DistanceFunctionEnum.COSINE_DISTANCE,
            DistanceFunctionEnum.L2_DISTANCE,
            DistanceFunctionEnum.INNER_PRODUCT,
        ],
    )
    def test_normalize_vector_search_results_scores_func(self, distance_function):
        # Mock dependencies

        vector_search_results = [
            DocumentDto(
                id="doc1",
                dataset_id="dataset1",
                document="sample document",
                score=0.7,
                metadata={},
                cmetadata={},
                language="en",
            )
        ]

        distance_function = distance_function
        # Call the method under test
        results = HybridSearchService.normalize_vector_search_results_scores(
            vector_search_results, distance_function
        )
        assert_that(results).is_instance_of(list)

    def test_weighted_average_rerank(self, mock_hybrid_request):
        vector_search_results = [
            DocumentDto(
                id="doc1",
                dataset_id="dataset1",
                document="sample document",
                score=0.7,
                metadata={},
                cmetadata={},
                language="en",
            ),
            DocumentDto(
                id="doc2",
                dataset_id="dataset2",
                document="sample document sample sample",
                score=0.4,
                metadata={},
                cmetadata={},
                language="en",
            ),
        ]

        full_text_search_results = [
            DocumentDto(
                id="doc1",
                dataset_id="dataset1",
                document="sample document",
                score=0.7,
                metadata={},
                cmetadata={},
                language="en",
            ),
            DocumentDto(
                id="doc4",
                dataset_id="dataset4",
                document="another sample document",
                score=0.3,
                metadata={},
                cmetadata={},
                language="en",
            ),
        ]

        max_results = 10
        # Call the method under test
        result = HybridSearchService.rerank(
            vector_search_results,
            full_text_search_results,
            mock_hybrid_request.vector_weight,
            mock_hybrid_request.distance_function,
            RankingFunctionEnum.WEIGHTED_AVERAGE,
            max_results,
        )
        assert_that(result).is_instance_of(list)

    def test_rrf_rerank(self, mock_hybrid_request):
        vector_search_results = [
            DocumentDto(
                id="doc1",
                dataset_id="dataset1",
                document="sample document",
                score=0.7,
                metadata={},
                cmetadata={},
                language="en",
            ),
            DocumentDto(
                id="doc2",
                dataset_id="dataset2",
                document="sample document sample sample",
                score=0.4,
                metadata={},
                cmetadata={},
                language="en",
            ),
        ]

        full_text_search_results = [
            DocumentDto(
                id="doc1",
                dataset_id="dataset1",
                document="sample document",
                score=0.7,
                metadata={},
                cmetadata={},
                language="en",
            ),
            DocumentDto(
                id="doc4",
                dataset_id="dataset4",
                document="another sample document",
                score=0.3,
                metadata={},
                cmetadata={},
                language="en",
            ),
        ]

        max_results = 10
        # Call the method under test
        result = HybridSearchService.rerank(
            vector_search_results,
            full_text_search_results,
            mock_hybrid_request.vector_weight,
            mock_hybrid_request.distance_function,
            RankingFunctionEnum.RRF_ALGORITHM,
            max_results,
        )
        assert_that(result).is_instance_of(list)

    def test_hybrid_search_dataset_id_does_not_exist(
        self, mock_validate_access_token_response
    ):
        """
        Test the hybrid endpoint when dataset_id does not exist.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(404)

    def test_hybrid_search_skip_auth_with_file_level_permissions_enabled(
        self,
        mock_search_response_with_permissions,
        mock_document_responses_without_permissions,
        mock_bearer_token,
        mock_validate_id_token_response,
    ):
        """
        Test the hybrid search functionality when file level permissions are enabled.

        This test verifies that the hybrid search functionality works correctly when file level
        permissions are enabled. It mocks the necessary dependencies and sends a POST request to the
        /hybrid endpoint with the required payload. The test asserts that the response status code
        is 200 and the response data matches the expected mocked document responses.

        Parameters:
        - mock_search_response_with_permissions: The mocked search response.
        - mock_document_responses_without_permissions: The mocked document responses.

        Returns:
        None
        """

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), mock.patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response_with_permissions,
        ), mock.patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response_with_permissions,
        ), mock.patch(
            "src.application.service.hybrid_search.HybridSearchService.rerank",
            return_value=mock_search_response_with_permissions,
        ):
            # Make a POST request to the /text endpoint with a valid authorization header
            response = client.post(
                f"/text",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "vector_weight": "0.5",
                    "metadata": {
                        "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
                        "embedding_model": "bge-m3",
                    },
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert (
                response.json().get("data")
                == mock_document_responses_without_permissions
            )
            response_data = response.json().get("data")
            assert (
                "permissions" not in response_data[0]["metadata"]
            ), "Permissions field is still present!"

    def test_hybrid_search_invalid_principals_with_file_level_permissions_enabled(
        self,
        mock_bearer_token,
        mock_validate_id_token_response_with_invalid_principals,
    ):
        """
        Test the invalid principals case of the hybrid_search function.

        This test verifies that a RuntimeException is raised when the client sends a request to
        the /hybrid endpoint with invalid authorization header.

        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.utils.file_level_permission_principals.validate_principals_format_for_file_level_permissions",
            return_value=False,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response_with_invalid_principals,
        ), pytest.raises(
            RuntimeException
        ) as e:
            client.post(
                f"/hybrid/?maxResults={mock_max_results}",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "vector_weight": "0.5",
                },
            )

        # Assert:
        assert (
            str(e.value.message)
            == "Unauthorized. Invalid Principals: ['mock_invalid_nt_id', 'mock_invalid_email']"
        )
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(401)
