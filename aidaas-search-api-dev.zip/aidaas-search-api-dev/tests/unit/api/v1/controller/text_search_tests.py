import os
from http import HTTPStatus
from ssl import create_default_context
from unittest.mock import patch

import pytest
from assertpy import assert_that
from fastapi import HTTPException
from fastapi.testclient import TestClient
from src.api.v1.controller.search import router
from src.application.dto.dataset import DatasetDto
from src.application.exception.runtime import RuntimeException

client = TestClient(router)


@pytest.fixture()
def ssl_client(base_url):
    """
    Fixture for creating a TestClient with SSL enabled.
    """
    # Create a default SSL context
    ssl_context = create_default_context()

    # Load the CA certificates from the file
    ssl_context.load_verify_locations(
        cafile=os.path.join(base_url, "/etc/ssl/certs/ca-certificates.crt")
    )

    # Create a TestClient with the SSL context
    client = TestClient(router, base_url=base_url)

    return client


class TestTextSearch:
    def test_text_search_invalid_api_key(self, mock_validate_access_token_response):
        """
        Test the unauthorized case of the text_search function.

        This test verifies that an HTTPException with a status code of
        401 (Unauthorized) is raised when the client sends a request to
        the text_search endpoint without a valid API key.

        """
        # Arrange: Create a Mock the maxResults query parameter
        mock_max_results = 1
        mock_is_valid = False

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=mock_is_valid,
        ) as mock_validate, pytest.raises(
            HTTPException
        ) as e:

            client.post(
                f"/text/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer invalid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(HTTPStatus.FORBIDDEN)
        assert_that(mock_validate.call_count).is_equal_to(1)

    def test_text_search_without_api_key(self):
        """
        Test the unauthorized case of the text_search function.

        This test verifies that an HTTPException with a status code of
        403 (Forbidden) is raised when the client sends a request to
        the text_search endpoint without a valid API key.

        """
        # Arrange: Create a Mock the maxResults query parameter
        #
        # The mock_max_results variable is used to simulate the maxResults query parameter sent in the request.
        mock_max_results = 1

        # Act: Here we make a request to the text_search endpoint without sending a valid API key.
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), pytest.raises(HTTPException) as e:
            # Make a request to the text_search endpoint without sending a valid API key
            client.post(
                f"/text/?maxResults={mock_max_results}",
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(HTTPStatus.FORBIDDEN)

    def test_text_search_empty_query_string(
        self,
        mock_text_request_query_empty: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the empty query string case of the text_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the text_search endpoint with empty query string.


        """
        with patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RuntimeException
        ):
            response = client.post(
                "/text", json=mock_text_request_query_empty, headers=mock_bearer_token
            )
            assert response.status_code == HTTPStatus.BAD_REQUEST

    def test_text_search_empty_dataset(
        self,
        mock_text_request_dataset_empty: dict,
        mock_validate_access_token_response,
        mock_bearer_token,
    ):
        """
        Test the empty query string case of the text_search function.

        This test verifies that an HTTPException with a status code of
        400 (Bad request) is raised when the client sends a request to
        the text_search endpoint with empty query string.


        """
        with patch(
            "src.domain.repository.document.DocumentRepository.text_search",
            return_value=None,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RuntimeException
        ):
            response = client.post(
                "/text", json=mock_text_request_dataset_empty, headers=mock_bearer_token
            )
            assert response.status_code == HTTPStatus.BAD_REQUEST

    def test_text_search_valid_search(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the text endpoint with valid authentication credentials.

        This test verifies that the /text endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response,
        ):

            # Make a POST request to the /text endpoint with a valid authorization header
            response = ssl_client.post(
                f"/text/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "7637d8a4-17b0-4316-bc06-3c6446e70368",
                },
            )

        # Assert:
        assert_that(response.status_code).is_equal_to(200)
        assert response.json().get("data") == mock_document_responses

    def test_text_search_dataset_id_does_not_exist(
        self, mock_validate_access_token_response
    ):
        """
        Test the text endpoint when dataset_id does not exist.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            HTTPException
        ) as e:
            client.post(
                f"/text/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(404)

    def test_text_search_skip_auth_with_file_level_permissions_enabled(
        self,
        ssl_client,
        mock_search_response_with_permissions,
        mock_document_responses_without_permissions,
        mock_bearer_token,
        mock_validate_id_token_response,
    ):
        """
        Test the text search functionality when file level permissions are enabled.

        This test verifies that the text search functionality works correctly when file level
        permissions are enabled. It mocks the necessary dependencies and sends a POST request to the
        /text endpoint with the required payload. The test asserts that the response status code
        is 200 and the response data matches the expected mocked document responses.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.
        - mock_search_response_with_permissions: The mocked search response.
        - mock_document_responses_without_permissions: The mocked document responses.

        Returns:
        None
        """

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.service.text_search.TextSearchService.text_search",
            return_value=mock_search_response_with_permissions,
        ) as mock_service:

            # Make a POST request to the /text endpoint with a valid authorization header
            response = ssl_client.post(
                f"/text",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "metadata": {
                        "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
                        "embedding_model": "bge-m3",
                    },
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert (
                response.json().get("data")
                == mock_document_responses_without_permissions
            )
            response_data = response.json().get("data")
            assert (
                "permissions" not in response_data[0]["metadata"]
            ), "Permissions field is still present!"

    def test_text_search_invalid_principals_with_file_level_permissions_enabled(
        self,
        ssl_client,
        mock_bearer_token,
        mock_validate_id_token_response_with_invalid_principals,
    ):
        """
        Test the invalid principals case of the text_search function.

        This test verifies that a RuntimeException is raised when the client sends a request to
        the /text endpoint with invalid authorization header.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.utils.file_level_permission_principals.validate_principals_format_for_file_level_permissions",
            return_value=False,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response_with_invalid_principals,
        ), pytest.raises(
            RuntimeException
        ) as e:
            ssl_client.post(
                f"/text/?maxResults={mock_max_results}",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert (
            str(e.value.message)
            == "Unauthorized. Invalid Principals: ['mock_invalid_nt_id', 'mock_invalid_email']"
        )
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(401)
