import os
from ssl import create_default_context
from unittest.mock import patch

import pytest
from assertpy import assert_that
from fastapi import HTTPException, status
from fastapi.testclient import TestClient
from pgvector.sqlalchemy import Vector
from sqlalchemy import cast
from sqlalchemy.sql import visitors
from src.api.v1.controller.search import router
from src.application.dto.dataset import DatasetDto
from src.application.dto.intent_space import IntentSpaceDto
from src.application.exception.runtime import RuntimeException

client = TestClient(router)


@pytest.fixture()
def ssl_client(base_url):
    """
    Fixture for creating a TestClient with SSL enabled.
    """
    # Create a default SSL context
    ssl_context = create_default_context()

    # Load the CA certificates from the file
    ssl_context.load_verify_locations(
        cafile=os.path.join(base_url, "/etc/ssl/certs/ca-certificates.crt")
    )

    # Create a TestClient with the SSL context
    client = TestClient(router, base_url=base_url)

    return client


@pytest.fixture
def mock_embeddings():
    return [
        -0.05015056,
        0.0017048348,
        -0.033215865,
        -0.061601363,
        0.08910603,
        0.0677956,
        0.06717049,
        0.09126549,
        -0.038017817,
        -0.04159797,
        -0.042592455,
        0.022674304,
        -0.011138254,
        0.03071544,
        0.03173834,
        0.048388895,
        0.056316376,
        0.01190543,
        -0.0075083766,
        -0.047735374,
        0.026822735,
        -0.07080747,
        0.023469893,
        0.04924131,
        -0.09819848,
        0.018241731,
        0.021296227,
        0.014547924,
        0.049269725,
        -0.031994067,
        -0.07006871,
        0.10206278,
        0.08154793,
        -0.050065316,
        -0.0010939357,
        -0.03426718,
        -0.04892876,
        -0.020827398,
        -0.043615356,
        0.011479221,
        -0.008339483,
        -0.036767602,
        -0.012367155,
        0.015016753,
        0.010996184,
        -0.037620023,
        -0.0053418158,
        -0.019804498,
        0.014420061,
        0.029323159,
        -0.069784574,
        -0.07489908,
        -0.030005092,
        -0.06995505,
        0.012530535,
        -0.05591858,
        0.007586515,
        0.006030853,
        -0.016835244,
        -0.03912596,
        0.03972265,
        -0.03529008,
        -0.010200595,
        0.006918788,
        0.083366424,
        0.031908825,
        -0.050349455,
        -0.0134184705,
        -0.11899747,
        0.06898898,
        -0.07683122,
        0.029294744,
        0.029024811,
        -0.00070324435,
        -0.004286949,
        0.048104756,
        0.043643773,
        -0.03367049,
        -0.09001528,
        -0.0794453,
        0.01727566,
        0.035091184,
        -0.040773965,
        0.031596273,
        0.00011720739,
        -0.027874049,
        -0.045405433,
        -0.019946568,
        0.007899068,
        0.0047948477,
        0.0033990145,
        -0.020941054,
        0.02824343,
        0.003296014,
        0.040773965,
        0.015712894,
        -0.0588168,
        -0.117974564,
        -0.024237068,
        0.006904581,
        0.07387617,
        0.03244869,
        0.028087154,
        -0.018540079,
        -0.09228839,
        -0.042734526,
        -0.06449958,
        0.023697203,
        0.0024222862,
        0.045519087,
        -0.054497886,
        -0.03304538,
        -0.027561495,
        -0.0142637845,
        -0.04924131,
        -0.09001528,
        0.041484315,
        -0.050718836,
        0.18491775,
        -0.1004716,
        0.06285158,
        0.017446144,
        -0.0018966288,
        0.0010939357,
        -0.056941483,
        -0.031994067,
        -0.041200176,
        0,
        -0.083480075,
        0.01997498,
        -0.059441905,
        0.032477103,
        -0.0051855394,
        -0.018838424,
        -0.026339697,
        -0.057055138,
        -0.07649025,
        0.036994915,
        0.077001706,
        0.11473538,
        0.044524603,
        0.09331129,
        0.019889738,
        -0.047138683,
        -0.042507213,
        0.12854454,
        -0.01807125,
        -0.021580366,
        -0.061089914,
        0.009731765,
        0.022731131,
        0.04566116,
        0.025032658,
        -0.036682364,
        0.016494276,
        -0.036994915,
        -0.0052494705,
        0.007941688,
        -0.004148431,
        -0.03892706,
        0.052622568,
        -0.076149285,
        -0.018810011,
        0.05583334,
        -0.0925157,
        -0.11967941,
        0.072853275,
        0.03847244,
        -0.072739616,
        -0.0014420061,
        0.029806195,
        0.04631468,
        0.04225149,
        0.10365395,
        -0.0068584085,
        0.012942538,
        0.002070664,
        0.0068406495,
        -0.018341182,
        0.034949113,
        0.069898225,
        -0.07694488,
        0.05256574,
        -0.078877024,
        -0.01778711,
        0.0088722445,
        0.07018237,
        0.035119597,
        -0.078649715,
        0.089503825,
        -0.049269725,
        -0.075921975,
        -0.09797117,
        0.090810865,
        -0.022304922,
        0.017616626,
        -0.0022624577,
        0.0019676634,
        -0.037847333,
        0.013567643,
        0.015002546,
        -0.008758589,
        0.03929644,
        -0.012260604,
        -0.04813317,
        0.051002976,
        0.06512469,
        -0.0874012,
        -0.04188211,
        -0.055350304,
        0.025515694,
        -0.009376591,
        -0.11229178,
        -0.051656496,
        0.018639527,
        -0.07847923,
        -0.025970317,
        0.020060223,
        0.050349455,
        0.09870993,
        -0.018326974,
        0.12081596,
        0.01825594,
        0,
        -0.015627652,
        -0.006563614,
        0.015897585,
        0.041683212,
        -0.02040119,
        0.027050046,
        -0.06807974,
        -0.0027419426,
        0.045519087,
        -0.018738976,
        0.0185827,
        0.030942751,
        -0.05634479,
        0.021694023,
        -0.042677697,
        -0.0018469044,
        7.1034783e-06,
        -0.022532234,
        -0.012885709,
        -0.016963106,
        0.120474994,
        0.09888042,
        -0.05321926,
        -0.009348177,
        -0.093765914,
        0.031937238,
        0.007870654,
        -0.123430036,
        0.04844572,
        -0.051429182,
        -0.077456325,
        -0.063874476,
        -0.047365993,
        -0.009390798,
        0.009483144,
        -0.0069614085,
        0.041768454,
        -0.053986434,
        0.039154373,
        0.0022162853,
        0.04196735,
        -0.0011933844,
        0.027533082,
        0.008595209,
        -0.038301956,
        0.015201444,
        0.028044533,
        0.01045632,
        0.098141655,
        0.068363875,
        -0.05836218,
        -0.032846484,
        0.06927312,
        -0.07035285,
        -0.019122563,
        -0.069784574,
        0.05989653,
        -0.069443606,
        0.069898225,
        0.042336732,
        -0.00049014,
        0.09677779,
        0.00179718,
        -0.037847333,
        0.031823583,
        -0.03034606,
        -0.005242367,
        -0.02072795,
        0.01811387,
        0.022063404,
        -0.014576337,
        0.05699831,
        -0.030800682,
        -0.10126719,
        0.013624472,
        0.0255299,
        0.052253187,
        0.061374053,
        -0.026069766,
        -0.033215865,
        0.04668406,
        0.031113235,
        0.054128505,
        0.043814253,
        -0.060805775,
        0.041683212,
        -0.04196735,
        0.0044467775,
        -0.024961622,
        -0.023896102,
        -0.040205687,
        0.06359034,
        0.046826128,
        0.07444445,
        0.02240437,
        -1.3873981e-08,
        0.0058319555,
        0.026169214,
        0.05191222,
        -0.02432231,
        -0.057452932,
        -0.031198477,
        0.0037932575,
        0.123316385,
        -0.03244869,
        0.03835878,
        0.05614589,
        -0.04029093,
        -0.048076343,
        0.08092283,
        0.027476255,
        0.0629084,
        -0.022120232,
        0.035318494,
        -0.02142409,
        -0.04117176,
        0.011877016,
        0.07506956,
        0.05438423,
        0.037136983,
        -0.021509333,
        0.045860056,
        0.008581002,
        0.04159797,
        0.035346907,
        -0.008062447,
        -0.011514738,
        0.04182528,
        0.010953563,
        0.0072135823,
        0.04568957,
        -0.027604116,
        -0.053844366,
        0.063760825,
        0.03071544,
        0.051741738,
        -0.11638339,
        0.0024862173,
        -0.047110267,
        0.027618324,
        0.030232403,
        0.021154158,
        -0.056458447,
        -0.014334819,
        -0.15207127,
        0.042421974,
        -0.010214802,
        -0.102176435,
        0.03486387,
        0.054924093,
        0.048246823,
        -0.008929072,
        -0.009262935,
        -0.0218503,
        0.032278206,
        0.047025025,
        0.080865994,
        0.056657344,
        0.01993236,
        0.1266124,
    ]


@pytest.fixture(autouse=True)
def ssl_environment_variables():
    """
    Set environment variables for SSL.
    """
    with patch.dict(
        "os.environ",
        {
            "SSL_CERT_FILE": "/etc/ssl/certs/ca-certificates.crt",
            "CURL_CA_BUNDLE": "/etc/ssl/certs/ca-certificates.crt",
            "REQUESTS_CA_BUNDLE": "/etc/ssl/certs/ca-certificates.crt",
        },
    ):
        yield


class TestSearchController:

    def test_vector_search_invalid_api_key(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        Test the unauthorized case of the vector_search function.

        This test verifies that an HTTPException with a status code of
        401 (Unauthorized) is raised when the client sends a request to
        the vector_search endpoint without a valid API key.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """
        # Arrange: Create a Mock the maxResults query parameter
        mock_max_results = 1
        distance_function = "cosine_distance"
        mock_is_valid = False

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=mock_is_valid,
        ) as mock_validate, pytest.raises(
            HTTPException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer invalid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(status.HTTP_403_FORBIDDEN)
        assert_that(mock_validate.call_count).is_equal_to(1)

    def test_vector_search_without_api_key(self):
        """
        Test the unauthorized case of the vector_search function.

        This test verifies that an HTTPException with a status code of
        403 (Forbidden) is raised when the client sends a request to
        the vector_search endpoint without a valid API key.

        """
        # Arrange: Create a Mock the maxResults query parameter
        #
        # The mock_max_results variable is used to simulate the maxResults query parameter sent in the request.
        mock_max_results = 1
        distance_function = "cosine_distance"

        # Act: Here we make a request to the vector_search endpoint without sending a valid API key.
        with pytest.raises(HTTPException) as e:
            # Make a request to the vector_search endpoint without sending a valid API key
            client.post(
                f"/vector/?maxResults={mock_max_results}",
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(status.HTTP_403_FORBIDDEN)

    def test_vector_search_valid_search_for_cosine_distance(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ):

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "bf15353c-df2d-4480-bfe7-1ef24db725e7",
                    "distance_function": distance_function,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_search_for_l2_distance(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "l2_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "bf15353c-df2d-4480-bfe7-1ef24db725e7",
                    "distance_function": distance_function,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_search_for_inner_product(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "inner_product"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ):

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "bf15353c-df2d-4480-bfe7-1ef24db725e7",
                    "distance_function": distance_function,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_api_key_with_distance_threshold(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "distance_threshold": 0.8,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_api_key_with_metadata(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid metadata.

        This test verifies that the /vector endpoint can use metadata
        to retrieve the results.
        """

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "metadata": {
                        "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
                        "embedding_model": "bge-m3",
                    },
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_search_with_neighbors(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials and include neighbors

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"
        include_neighbors = 2

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "include_neighbors": include_neighbors,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_valid_api_key_without_dataset_id(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), pytest.raises(
            RuntimeException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "",
                    distance_function: distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(400)

    def test_vector_search_valid_api_key_and_valid_dataset_id_and_without_dataset_id_without_permission(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), pytest.raises(
            HTTPException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(403)

    def test_vector_search_valid_search_but_result_is_empty(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.

        This test verifies that the /vector endpoint can be accessed
        with valid authentication credentials.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ) as mock_authorize, patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=[],
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(response.status_code).is_equal_to(200)
        assert_that(response.json().get("data")).is_equal_to([])

    def test_vector_search_embbedings_api_is_down(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        Test the vector endpoint with valid authentication credentials.
        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.get_embeddings",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ) as mocked_embeddings, pytest.raises(
            HTTPException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(403)
        assert_that(e.value.detail).is_equal_to("Forbidden")

    def test_vector_search_catalog_api_is_down(
        self, ssl_client, mock_validate_access_token_response
    ):
        """
        test the vector endpoint with valid authentication credentials.
        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.get_embeddings",
            return_value=[],
        ) as mocked_embeddings, patch(
            "src.domain.repository.document.DocumentRepository.vector_search",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ) as mock_db, pytest.raises(
            HTTPException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(403)

    def test_vector_search_dataset_id_does_not_exist(
        self,
        ssl_client,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint when dataset_id does not exist.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """

        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            side_effect=HTTPException(status_code=404, detail="Not Found"),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ) as mock_authorize, patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=[],
        ) as mock_service, pytest.raises(
            HTTPException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(HTTPException)
        assert_that(e.value.status_code).is_equal_to(404)

    def test_vector_search_valid_search_without_language(
        self,
        ssl_client,
        mock_search_response,
        mock_document_responses,
        mock_validate_access_token_response,
    ):
        """
        Test the vector endpoint when dataset_id does not exist.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="dataset_id",
                enable_file_level_permissions=False,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                    "distance_threshold": 0.8,
                    "vector_weight": 0.5,
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert response.json().get("data") == mock_document_responses

    def test_vector_search_skip_auth_with_file_level_permissions_enabled(
        self,
        ssl_client,
        mock_search_response_with_permissions,
        mock_document_responses_without_permissions,
        mock_bearer_token,
        mock_validate_id_token_response,
    ):
        """
        Test the vector search functionality when file level permissions are enabled.

        This test verifies that the vector search functionality works correctly when file level
        permissions are enabled. It mocks the necessary dependencies and sends a POST request to the
        /vector endpoint with the required payload. The test asserts that the response status code
        is 200 and the response data matches the expected mocked document responses.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.
        - mock_search_response_with_permissions: The mocked search response.
        - mock_document_responses_without_permissions: The mocked document responses.

        Returns:
        None
        """

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.service.vector_search.VectorSearchService.similarity_search",
            return_value=mock_search_response_with_permissions,
        ) as mock_service:

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "metadata": {
                        "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
                        "embedding_model": "bge-m3",
                    },
                },
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert (
                response.json().get("data")
                == mock_document_responses_without_permissions
            )
            response_data = response.json().get("data")
            assert (
                "permissions" not in response_data[0]["metadata"]
            ), "Permissions field is still present!"

    def test_vector_search_invalid_principals_with_file_level_permissions_enabled(
        self,
        ssl_client,
        mock_bearer_token,
        mock_validate_id_token_response_with_invalid_principals,
    ):
        """
        Test the invalid principals case of the vector_search function.

        This test verifies that a RuntimeException is raised when the client sends a request to
        the /vector endpoint with invalid authorization header.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.

        """
        # simulate the maxResults query parameter sent in the request.
        mock_max_results = 2
        distance_function = "cosine_distance"

        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.utils.file_level_permission_principals.validate_principals_format_for_file_level_permissions",
            return_value=False,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response_with_invalid_principals,
        ), pytest.raises(
            RuntimeException
        ) as e:
            ssl_client.post(
                f"/vector/?maxResults={mock_max_results}",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": distance_function,
                },
            )

        # Assert:
        assert (
            str(e.value.message)
            == "Unauthorized. Invalid Principals: ['mock_invalid_nt_id', 'mock_invalid_email']"
        )
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(401)

    def test_vector_search_uses_nt_and_email_with_file_level_permissions_enabled(
        self,
        ssl_client,
        mock_database_document_model_response,
        mock_bearer_token,
        mock_validate_id_token_response,
    ):
        """
        Test the vector search functionality when file level permissions are enabled.

        This test verifies that the vector search functionality works correctly when file level
        permissions are enabled. It mocks the necessary dependencies and sends a POST request to the
        /vector endpoint with the required payload. The test asserts that the response status code
        is 200 and the database call included both the user NT_id and email.

        Parameters:
        - ssl_client: The TestClient instance with SSL enabled.
        - mock_search_response_with_permissions: The mocked search response.
        - mock_database_document_model_response: The mocked document responses.

        Returns:
        None
        """

        # Act: Patch the validate method of the auth_api class to return the mock return value
        with patch(
            "src.application.facade.catalog_api.CatalogApiFacade.get_dataset_info",
            return_value=DatasetDto(
                dataset_id="6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                enable_file_level_permissions=True,
                application_id="application_id",
                model="model",
                dimension=1024,
                is_graph_enabled=False,
                datasource_name="ecs",
            ),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_id_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=False,
        ), patch(
            "src.application.facade.embeddings_api.EmbeddingsApiFacade.get_embeddings",
            return_value=cast([1, 2, 3, 4], Vector(4)),
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.get_api_key_by_dataset_id",
            return_value={"test-api-key", "test-client-id"},
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.get_access_token",
            return_value={"test-access-token", "test-expiry"},
        ), patch(
            "src.application.facade.intent_api.IntentApiFacade.search",
            return_value=[IntentSpaceDto(score=0.5, space_id="space_id")],
        ), patch(
            "src.domain.repository.document.DocumentRepository._duplicate_filter",
            return_value=mock_database_document_model_response,
        ) as mock_db_call:
            mock_nt = ("mock_nt_id",)
            mock_email = "mock_email@example.com"

            # Make a POST request to the /vector endpoint with a valid authorization header
            response = ssl_client.post(
                f"/vector",
                headers=mock_bearer_token,
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "metadata": {
                        "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
                        "embedding_model": "bge-m3",
                    },
                },
            )

            # Get DB query params
            db_query = mock_db_call.call_args[0][0]
            db_query_params = []
            visitors.traverse(
                db_query.statement.whereclause,
                {},
                {"bindparam": lambda param: db_query_params.append(str(param.value))},
            )

            # Assert:
            assert_that(response.status_code).is_equal_to(200)
            assert str([mock_nt[0]]) in db_query_params
            assert str([mock_email.lower()]) in db_query_params

    def test_vector_search_invalid_namespaces_operator(
        self, ssl_client, mock_validate_access_token_response
    ):
        metadata = {
            "namespaces": [{"space_key": "DSX"}, {"space_key": "DF"}],
            "namespaces_operator": "invalid",
        }

        with patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), pytest.raises(
            RuntimeException
        ) as e:
            ssl_client.post(
                f"/vector/",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "metadata": metadata,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(400)
        assert_that(e.value.message).is_equal_to(
            "Namespaces operator in metadata must be 'and' or 'or'"
        )

    def test_vector_search_invalid_intent_spaces_limit(
        self, ssl_client, mock_validate_access_token_response
    ):
        with patch(
            "src.application.facade.auth_api.AuthApiFacade.validate_token",
            return_value=mock_validate_access_token_response,
        ), patch(
            "src.application.facade.auth_api.AuthApiFacade.authorize",
            return_value=True,
        ), pytest.raises(
            RuntimeException
        ) as e:
            ssl_client.post(
                f"/vector/",
                headers={"Authorization": "Bearer valid_token"},
                json={
                    "query": "overview",
                    "dataset_id": "6e0b8651-b959-49fe-9df2-f620b4e5beb4",
                    "distance_function": "cosine_distance",
                    "intent_spaces_limit": 16,
                },
            )

        # Assert:
        assert_that(e.value).is_instance_of(RuntimeException)
        assert_that(e.value.status_code).is_equal_to(400)
        assert_that(e.value.message).is_equal_to(
            "Number of intent spaces must be between 0 and 15"
        )
