import os
from ssl import create_default_context

import pytest
from assertpy import assert_that
from fastapi.testclient import TestClient
from src.api.v1.controller.health import UP_MESSAGE, UP_STATUS, router

client = TestClient(router)


@pytest.fixture()
def ssl_client(base_url):
    """
    Fixture for creating a TestClient with SSL enabled.

    """
    # Create a default SSL context
    ssl_context = create_default_context()

    # Load the CA certificates from the file
    ssl_context.load_verify_locations(
        cafile=os.path.join(base_url, "/etc/ssl/certs/ca-certificates.crt")
    )

    # Create a TestClient with the SSL context
    client = TestClient(router, base_url=base_url)

    return client


class TestHealthController:

    def test_health_endpoint(self):
        """
        Test the health endpoint.

        Makes a GET request to the /health endpoint and checks
        that the response is a JSON object with the expected
        status and message.
        """
        # Act
        response = client.get("/health")

        # Assert
        assert_that(response.status_code).is_equal_to(200)
        assert_that(response.json()).contains_entry({"data": {"status": UP_STATUS}})
        assert_that(response.json()).contains_entry({"message": UP_MESSAGE})
