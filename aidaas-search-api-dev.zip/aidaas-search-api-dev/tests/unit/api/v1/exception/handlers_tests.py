from unittest.mock import ANY, patch

import pytest
from fastapi import FastAPI, HTTPException, status
from fastapi.testclient import TestClient
from src.api.v1.exception.handlers import set_exception_handlers
from src.application.exception import RuntimeException
from src.core.logging import log_request


@pytest.fixture
def app_api():
    app = FastAPI()
    set_exception_handlers(app)
    return app


@pytest.fixture
def client(app_api):
    return TestClient(app_api)


@patch("src.api.v1.exception.handlers.log_request")
def test_exception_handler_for_exception_s(mock_log, client, app_api):

    @app_api.get("/")
    async def error_endpoint():
        raise Exception("Test exception")

    with pytest.raises(Exception):
        client.get("/")

    mock_log.assert_called_with(
        ANY, status.HTTP_500_INTERNAL_SERVER_ERROR, "Test exception"
    )


def test_exception_handler_for_exception(client, app_api):

    @app_api.get("/")
    async def throes_internal_server_error():
        raise RuntimeException(
            message="Test exception", status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

    response = client.get("/")

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert response.json() == {
        "data": None,
        "errors": None,
        "meta": None,
        "message": "Test exception",
        "success": False,
    }


def test_exception_handler_for_runtime_exception(client, app_api):

    @app_api.get("/")
    async def throws_internal_server_error():
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

    response = client.get("/")
    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert response.json() == {
        "detail": "Internal Server Error",
    }


def test_exception_handler_for_method_not_allowed(client, app_api):

    @app_api.get("/")
    async def throws_method_not_allowed():
        raise HTTPException(status_code=status.HTTP_405_METHOD_NOT_ALLOWED)

    response = client.get("/")
    assert response.status_code == status.HTTP_405_METHOD_NOT_ALLOWED
    assert response.json() == {
        "data": None,
        "errors": None,
        "meta": None,
        "message": "Method Not Allowed",
        "success": False,
    }


def test_exception_handler_for_not_found(client, app_api):

    @app_api.get("/")
    async def throws_not_found():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    response = client.get("/")
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json() == {
        "data": None,
        "errors": None,
        "meta": None,
        "message": "Not Found",
        "success": False,
    }


def test_exception_handler_for_forbidden(client, app_api):

    @app_api.get("/")
    async def throws_forbidden():
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)

    response = client.get("/")

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert response.json() == {
        "data": None,
        "errors": None,
        "meta": None,
        "message": "Not authenticated",
        "success": True,
    }


def test_exception_handler_for_unauthorized(client, app_api):

    @app_api.get("/")
    async def throws_unauthorized():
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    response = client.get("/")

    assert response.status_code == status.HTTP_401_UNAUTHORIZED
    assert response.json() == {
        "data": None,
        "errors": None,
        "meta": None,
        "message": "Not authenticated",
        "success": True,
    }
