import uuid

from fastapi import FastAPI
from fastapi.testclient import TestClient
from src.application.utils.correlation_middleware import add_correlation_id_middleware

# Setup

app = FastAPI()
client = TestClient(app)
app.middleware("http")(add_correlation_id_middleware)


@app.get("/")
async def root():
    return {"message": "Hello World"}


def test_add_correlation_id_middleware_no_guid():
    # Test without X-Correlation-ID header
    response = client.get("/")
    assert "X-Correlation-ID" in response.headers
    assert uuid.UUID(response.headers["X-Correlation-ID"])


def test_add_correlation_id_middleware():
    # Test with X-Correlation-ID header
    test_correlation_id = str(uuid.uuid4())
    response = client.get("/", headers={"X-Correlation-ID": test_correlation_id})
    assert response.headers["X-Correlation-ID"] == test_correlation_id
