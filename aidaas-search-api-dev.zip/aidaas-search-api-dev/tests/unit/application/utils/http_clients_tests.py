import os
import uuid
from unittest.mock import Mock, patch

import httpx
import pytest
import requests
from fastapi import FastAPI
from fastapi.testclient import TestClient
from src.application.utils.context import correlation_id_var
from src.application.utils.correlation_middleware import add_correlation_id_middleware
from src.application.utils.http_clients import (
    ClientWithCorrelationId,
    SessionWithCorrelationId,
)


def handler(request):
    return httpx.Response(200)


def test_client_with_correlation_id():
    # Arrange
    test_correlation_id = str(uuid.uuid4())
    correlation_id_var.set(test_correlation_id)

    # Use MockTransport to avoid real http requests
    client_with_correlation_id = ClientWithCorrelationId(
        transport=httpx.MockTransport(handler)
    )

    # Act
    request = httpx.Request("GET", "http://example.com")
    response = client_with_correlation_id.send(request)

    # Assert
    assert response.request.headers["X-Correlation-ID"] == test_correlation_id


def test_session_with_correlation_id():
    # Arrange
    test_correlation_id = str(uuid.uuid4())
    correlation_id_var.set(test_correlation_id)

    with patch.object(requests.Session, "request") as mock_super_request:
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.text = "mocked response"
        mock_super_request.return_value = mock_response

        client = SessionWithCorrelationId()

        # Act
        response = client.get("https://example.com")

        # Assert
        assert response.status_code == 200
        assert response.text == "mocked response"
        mock_super_request.assert_called_once_with(
            "GET",
            "https://example.com",
            allow_redirects=True,
            headers={"X-Correlation-ID": correlation_id_var.get()},
        )
