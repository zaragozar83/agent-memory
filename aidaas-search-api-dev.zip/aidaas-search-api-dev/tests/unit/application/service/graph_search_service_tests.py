from unittest.mock import MagicMock, patch

import pytest
from src.application.service.graph_search import (
    DatasetDto,
    EmbeddingsApiFacade,
    GraphRepository,
    GraphRequest,
    GraphResponse,
    GraphSearchService,
    RuntimeException,
)


def test_graph_search():
    # Mock the dependencies
    mock_graph_request = MagicMock(spec=GraphRequest)
    mock_graph_request.query = "test query"
    mock_graph_request.dataset_id = "test_dataset_id"
    mock_graph_request.score_threshold = 0.5
    mock_graph_request.entities = []
    mock_graph_request.relationships = []
    mock_graph_request.embedded_node_label = "test_label"
    mock_graph_request.chunks = []

    mock_dataset_info = MagicMock(spec=DatasetDto)
    mock_dataset_info.is_graph_enabled = True
    mock_dataset_info.model = "test_model"
    mock_dataset_info.application_id = "test_application_id"
    mock_dataset_info.datasource_name = "test_datasource_name"
    mock_dataset_info.dataset_id = "test_dataset_id"

    mock_embeddings = MagicMock(spec=EmbeddingsApiFacade)
    mock_embeddings.embed_documents.return_value = [[0.1, 0.2, 0.3]]

    mock_result = [
        {
            "document": "doc1",
            "score": 0.9,
            "metadata": {"dataset_object_id": "id1", "chunk_index": 1},
        },
        {
            "document": "doc1",
            "score": 0.8,
            "metadata": {"dataset_object_id": "id2", "chunk_index": 2},
        },
    ]

    with patch.object(
        GraphRepository, "search_graph_documents", return_value=mock_result
    ):
        with patch.object(EmbeddingsApiFacade, "__init__", return_value=None):
            with patch.object(
                EmbeddingsApiFacade, "embed_documents", return_value=[[0.1, 0.2, 0.3]]
            ), patch(
                "src.application.facade.auth_api.AuthApiFacade.get_api_key_by_dataset_id",
                return_value={"test-api-key", "test-client-id"},
            ), patch(
                "src.application.facade.auth_api.AuthApiFacade.get_access_token",
                return_value={"test-access-token", "test-expiry"},
            ):
                response = GraphSearchService.graph_search(
                    mock_graph_request, max_results=2, dataset_info=mock_dataset_info
                )

                assert isinstance(response, GraphResponse)
                assert len(response.result) == 2
                assert response.result[0].score == 0.9
                assert response.result[1].score == 0.8


def test_graph_search_no_results():
    # Mock the dependencies
    mock_graph_request = MagicMock(spec=GraphRequest)
    mock_graph_request.query = "test query"
    mock_graph_request.dataset_id = "test_dataset_id"
    mock_graph_request.score_threshold = 0.5
    mock_graph_request.entities = []
    mock_graph_request.relationships = []
    mock_graph_request.embedded_node_label = "test_label"
    mock_graph_request.chunks = []

    mock_dataset_info = MagicMock(spec=DatasetDto)
    mock_dataset_info.is_graph_enabled = True
    mock_dataset_info.model = "test_model"
    mock_dataset_info.application_id = "test_application_id"
    mock_dataset_info.dataset_id = "test_dataset_id"

    mock_result = []

    with patch.object(
        GraphRepository, "search_graph_documents", return_value=mock_result
    ), patch(
        "src.application.facade.auth_api.AuthApiFacade.get_api_key_by_dataset_id",
        return_value={"test-api-key", "test-client-id"},
    ), patch(
        "src.application.facade.auth_api.AuthApiFacade.get_access_token",
        return_value={"test-access-token", "test-expiry"},
    ):
        response = GraphSearchService.graph_search(
            mock_graph_request, max_results=2, dataset_info=mock_dataset_info
        )

        assert isinstance(response, GraphResponse)
        assert len(response.result) == 0


def test_graph_search_disabled():

    # Arrange
    mock_graph_request = MagicMock(spec=GraphRequest)
    mock_graph_request.query = "test query"
    mock_graph_request.dataset_id = "test_dataset_id"

    mock_dataset_info = MagicMock(spec=DatasetDto)
    mock_dataset_info.is_graph_enabled = False

    # Act
    with pytest.raises(RuntimeException) as excinfo:
        GraphSearchService.graph_search(
            mock_graph_request, dataset_info=mock_dataset_info
        )

    # Assert
    assert excinfo.value.status_code == 400
    assert (
        str(excinfo.value.message)
        == "Graph search is not enabled for dataset_id: test_dataset_id"
    )
