from http import HTTPStatus
from unittest.mock import MagicMock, patch

import pytest
from requests.exceptions import RequestException
from src.application.exception.auth_api import AuthApiException
from src.application.facade.auth_api import AuthApiFacade, RuntimeException
from src.application.utils import constants
from src.core.environment_variables import EnvironmentVariables


#
# get_api_key_by_dataset_id() tests
#
@patch("src.application.facade.auth_api.AuthApiFacade._session.get")
@patch("src.application.facade.auth_api.EnvironmentVariables")
def test_get_api_key_by_dataset_id(mock_env_vars, mock_get):
    """
    GIVEN valid environment variables and a valid response from the auth API
    WHEN get api key is called
    THEN it should return the api key
    """
    # given
    EnvironmentVariables.AUTH_API_URL = "http://fake.url"
    mock_env_vars.AUTH_API_URL = "http://fake.url"

    fake_dataset_id = "fake_dataset_id"

    mock_response = MagicMock()
    mock_response.status_code = HTTPStatus.OK
    mock_response.json.return_value = {
        "data": {"api_key": "test-api-key", "client_id": "test-client-id"}
    }
    mock_get.return_value = mock_response

    # when
    result = AuthApiFacade.get_api_key_by_dataset_id(dataset_id=fake_dataset_id)

    # then
    assert result == ("test-api-key", "test-client-id")
    assert mock_get.call_count == 1


@patch("src.application.facade.auth_api.AuthApiFacade._session.get")
def test_get_access_token_success(mock_get):
    """
    GIVEN valid environment variables and a valid response from the auth API
    WHEN get_access_token is called
    THEN it should return the access token and expiry
    """
    with (
        patch.object(EnvironmentVariables, "AUTH_API_URL", "http://fake.url"),
        patch.object(EnvironmentVariables, "ADMIN_KEY", "fake-admin-key"),
    ):

        mock_response = MagicMock()
        mock_response.status_code = HTTPStatus.OK
        mock_response.json.return_value = {
            "data": {"access_token": "fake-token", "expiry": "9999-12-31T23:59:59Z"}
        }
        mock_get.return_value = mock_response

        # when
        result = AuthApiFacade.get_access_token()

        # then
        assert result == ("fake-token", "9999-12-31T23:59:59Z")

        # check call details more flexibly
        mock_get.assert_called_once()
        _, kwargs = mock_get.call_args
        assert kwargs["url"] == "http://fake.url/v1/token/access_token"
        assert kwargs["timeout"] == constants.HTTP_REQUEST_TIMEOUT
        assert kwargs["headers"][constants.CONTENT_TYPE] == constants.APPLICATION_JSON
        assert (
            kwargs["headers"][constants.AUTHORIZATION]
            == f"{constants.AUTHORIZATION_BEARER} fake-admin-key"
        )


@patch("src.application.facade.auth_api.AuthApiFacade._session.get")
@patch("src.application.facade.auth_api.EnvironmentVariables")
def test_get_access_token_non_200_response(mock_env_vars, mock_get):
    """
    GIVEN the auth API returns a non-200 status code
    WHEN get_access_token is called
    THEN it should return None (no token)
    """
    # given
    mock_env_vars.AUTH_API_URL = "http://fake.url"
    mock_env_vars.ADMIN_KEY = "fake-admin-key"

    mock_response = MagicMock()
    mock_response.status_code = HTTPStatus.UNAUTHORIZED
    mock_response.json.return_value = {}
    mock_get.return_value = mock_response

    # when
    result = AuthApiFacade.get_access_token()

    # then
    assert result is None
    mock_get.assert_called_once()


@patch("src.application.facade.auth_api.AuthApiFacade._session.get")
@patch("src.application.facade.auth_api.EnvironmentVariables")
def test_get_access_token_request_exception(mock_env_vars, mock_get):
    """
    GIVEN the auth API request raises RequestException
    WHEN get_access_token is called
    THEN it should raise AuthApiException
    """
    # given
    mock_env_vars.AUTH_API_URL = "http://fake.url"
    mock_env_vars.ADMIN_KEY = "fake-admin-key"
    mock_get.side_effect = RequestException("Connection error")

    # when / then
    with pytest.raises(AuthApiException) as exc_info:
        AuthApiFacade.get_access_token()

    assert "Error retrieving access token" in str(exc_info.value)
    mock_get.assert_called_once()


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_access_token_success(mock_post):
    """
    GIVEN a valid token and Auth API returning 200 OK
    WHEN validate_token is called
    THEN it should return the token validation data including JWT and client info
    """
    with (
        patch.object(EnvironmentVariables, "AUTH_API_URL", "http://fake.url"),
        patch.object(EnvironmentVariables, "ADMIN_KEY", "fake-admin-key"),
    ):
        mock_response = MagicMock()
        mock_response.status_code = HTTPStatus.OK
        mock_response.json.return_value = {
            "data": {
                "type": "access_token",
                "token": "fake_access_token",
                "client_id": "fake_client_id",
                "api_key": "fake_api_key",
            }
        }
        mock_post.return_value = mock_response

        credentials = "valid_token"
        result = AuthApiFacade.validate_token(credentials)

        # Assert that the returned data matches the mocked response
        expected_data = {
            "type": "access_token",
            "token": "fake_access_token",
            "client_id": "fake_client_id",
            "api_key": "fake_api_key",
        }
        assert result == expected_data

        # Ensure headers are correctly set in the request
        mock_post.assert_called_once()
        _, kwargs = mock_post.call_args
        assert (
            kwargs["headers"][constants.AUTHORIZATION]
            == f"{constants.AUTHORIZATION_BEARER} {credentials}"
        )


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_id_token_success(mock_post):
    """
    GIVEN a valid token and Auth API returning 200 OK
    WHEN validate_token is called
    THEN it should return the token validation data including JWT and client info
    """
    with (
        patch.object(EnvironmentVariables, "AUTH_API_URL", "http://fake.url"),
        patch.object(EnvironmentVariables, "ADMIN_KEY", "fake-admin-key"),
    ):
        mock_response = MagicMock()
        mock_response.status_code = HTTPStatus.OK
        mock_response.json.return_value = {
            "data": {
                "type": "id_token",
                "token": "fake_id_token",
                "nt_id": "fake_nt_id",
                "email": "fake_email@example.com",
                "ad_groups": ["fake_group"],
            }
        }
        mock_post.return_value = mock_response

        credentials = "valid_token"
        result = AuthApiFacade.validate_token(credentials)

        # Assert that the returned data matches the mocked response
        expected_data = {
            "type": "id_token",
            "token": "fake_id_token",
            "nt_id": "fake_nt_id",
            "email": "fake_email@example.com",
            "ad_groups": ["fake_group"],
        }
        assert result == expected_data

        # Ensure headers are correctly set in the request
        mock_post.assert_called_once()
        _, kwargs = mock_post.call_args
        assert (
            kwargs["headers"][constants.AUTHORIZATION]
            == f"{constants.AUTHORIZATION_BEARER} {credentials}"
        )


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_token_unauthorized(mock_post):
    """
    GIVEN an token that is invalid/expired
    WHEN validate_token is called
    THEN it should raise RuntimeException with 401 status
    """
    mock_response = MagicMock()
    mock_response.status_code = HTTPStatus.UNAUTHORIZED
    mock_response.text = "Unauthorized"
    mock_post.return_value = mock_response

    credentials = "invalid_token"

    with pytest.raises(RuntimeException) as exc_info:
        AuthApiFacade.validate_token(credentials)

    assert exc_info.value.status_code == HTTPStatus.UNAUTHORIZED
    assert "Unauthorized" in exc_info.value.message


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_token_non_200_response(mock_post):
    """
    GIVEN the Auth API returns a status code other than 200/401
    WHEN validate_token is called
    THEN it should raise RuntimeException with 500 status
    """
    mock_response = MagicMock()
    mock_response.status_code = HTTPStatus.BAD_REQUEST
    mock_response.text = "Bad Request"
    mock_post.return_value = mock_response

    credentials = "some_token"

    with pytest.raises(RuntimeException) as exc_info:
        AuthApiFacade.validate_token(credentials)

    assert exc_info.value.status_code == HTTPStatus.INTERNAL_SERVER_ERROR
    assert "Unexpected error" in exc_info.value.message


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_token_request_exception(mock_post):
    """
    GIVEN the Auth API request raises RequestException
    WHEN validate_token is called
    THEN it should raise AuthApiException
    """
    mock_post.side_effect = RequestException("Connection error")
    credentials = "any_token"

    with pytest.raises(AuthApiException) as exc_info:
        AuthApiFacade.validate_token(credentials)

    "Failed to validate token" in str(exc_info.value)
    mock_post.assert_called_once()


@patch("src.application.facade.auth_api.AuthApiFacade._session.post")
def test_validate_token_unhandled_exception(mock_post):
    """
    GIVEN the Auth API raises an unexpected exception
    WHEN validate_token is called
    THEN it should raise RuntimeException with 500 status
    """
    mock_post.side_effect = ValueError("Some unexpected error")
    credentials = "any_token"

    with pytest.raises(RuntimeException) as exc_info:
        AuthApiFacade.validate_token(credentials)

    assert exc_info.value.status_code == HTTPStatus.INTERNAL_SERVER_ERROR
    assert "Unexpected error" in exc_info.value.message
