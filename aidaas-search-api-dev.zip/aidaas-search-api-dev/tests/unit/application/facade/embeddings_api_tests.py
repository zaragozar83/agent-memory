from unittest.mock import MagicMock

import pytest
from src.application.exception import RuntimeException
from src.application.facade.embeddings_api import EmbeddingsApiFacade


def test_embed_documents_emeddings_returned(embeddings_api_facade):
    # Arrange
    mock_client = MagicMock()
    mock_client.embeddings.create.return_value = MagicMock(
        data=[MagicMock(embedding=[0.1, 0.2, 0.3])]
    )

    embeddings_api_facade._client = mock_client

    # Act
    texts = ["test text"]
    embeddings = embeddings_api_facade.embed_documents(texts)

    # Assert
    assert embeddings == [[0.1, 0.2, 0.3]]


def test_embed_query_embed_documents_called(embeddings_api_facade):
    # Arrange

    embeddings_api_facade.embed_documents = MagicMock(return_value=[[0.1, 0.2, 0.3]])

    # Act
    embedding = embeddings_api_facade.embed_query("test query")

    # Assert
    embeddings_api_facade.embed_documents.assert_called_once_with(["test query"])
    assert embedding == [0.1, 0.2, 0.3]


def test_get_embeddings(embeddings_api_facade):
    # Mock the OpenAI client and datetime
    mock_client = MagicMock()
    mock_client.embeddings.create.return_value = MagicMock(
        data=[MagicMock(embedding=[0.1, 0.2, 0.3])]
    )

    embeddings_api_facade._client = mock_client
    query = "test query"

    # Act
    embeddings = embeddings_api_facade.get_embeddings(query)

    # Assert
    assert mock_client.embeddings.create.call_count == 1
    mock_client.embeddings.create.assert_called_once_with(
        model="test-model", input=[query]
    )


def test_get_embeddings_openapi_exception_runtimeexception_thrown(
    embeddings_api_facade,
):
    # Arrange
    mock_client = MagicMock()
    mock_client.embeddings.create.side_effect = Exception("API error")

    embeddings_api_facade._client = mock_client

    # Act/ Assert
    query = "test query"
    with pytest.raises(RuntimeException):
        embeddings_api_facade.get_embeddings(query)


def test_construct_prompt_prefixes_model_without_prefix(embeddings_api_facade):
    # Arrange
    mock_client = MagicMock()
    mock_client.embeddings.create.return_value = MagicMock(
        data=[MagicMock(embedding=[0.1, 0.2, 0.3])]
    )
    embeddings_api_facade._client = mock_client
    query = "test query"

    # Act
    prompt_prefixes = embeddings_api_facade.construct_prompt_prefixes(
        "test-model", [query]
    )

    # Assert
    assert prompt_prefixes[0] == "test query"


def test_construct_prompt_prefixes_model_with_prefix():
    # Arrange
    mock_client = MagicMock()
    mock_client.embeddings.create.return_value = MagicMock(
        data=[MagicMock(embedding=[0.1, 0.2, 0.3])]
    )
    facade = EmbeddingsApiFacade(
        url="https://api.openai.com",
        model_name="test-model",
        client_id="test-client-id",
        access_token="test-access-token",
    )
    facade._client = mock_client
    query = "test query"

    # Act
    prompt_prefixes = facade.construct_prompt_prefixes("embeddinggemma-300m", [query])

    # Assert
    assert prompt_prefixes[0] == "task: search result | query: test query"
