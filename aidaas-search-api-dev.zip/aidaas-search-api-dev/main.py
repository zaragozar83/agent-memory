import logging
import time

import uvicorn
from fastapi import FastAPI, Request

from src.api import routers as routers_dict
from src.api.v1.exception.handlers import set_exception_handlers
from src.application.utils.correlation_middleware import \
    add_correlation_id_middleware
from src.core.environment_variables import EnvironmentVariables
from src.core.logging import get_logging_config, log_request
from src.application.utils.context import data_insights_var

app = FastAPI(
    title="AI DaaS - Search API",
    version="3.2.1",
    root_path="/aidaas/search",
    redirect_slashes=False,
)


for version, routers in routers_dict.items():
    for router in routers:
        app.include_router(router, prefix=f"/{version}")

set_exception_handlers(app)
logging.config.dictConfig(get_logging_config(EnvironmentVariables.LOG_LEVEL))


@app.middleware("http")
# For more information regarding middleware see https://fastapi.tiangolo.com/tutorial/middleware/
async def logging_middleware(request: Request, call_next):
    start_time = time.time()

    # update request headers with request start time
    headers = dict(request.scope["headers"])
    headers[b"request-start-time"] = str(start_time).encode()
    request.scope["headers"] = [(k, v) for k, v in headers.items()]

    response = await call_next(request)
    log_request(request, response.status_code, response.headers.get("Error-Message"))
    
    # Clear data insights after request to avoid context leakage
    data_insights_var.get().clear()
    return response


# Middleware to extract and set the correlation ID
@app.middleware("http")
async def correlation_id_middleware(request, call_next):
    return await add_correlation_id_middleware(request, call_next)


if __name__ == "__main__":
    uvicorn.run("main:app", reload=True, port=8080)
