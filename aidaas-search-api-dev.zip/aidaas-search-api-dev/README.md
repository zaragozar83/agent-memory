# Searching for DaaS-Ingested Data in Vector Database
This page will discuss how best to search for DaaS-ingested data stored in vector database (and in the future graph database too)

# Similarity Search
What is Vector Similarity Search? Vector similarity search is a method used to find similar vectors or data points in a high-dimensional space. It's commonly applied in information retrieval.
Notice that in order to perform a query in the embeddings is necessary to convert the word in embeddings too. This way can compare both using only embeddings. For that we use the genai-api to facilitate to convert the query into embeddings.

### Vector Representations (Embeddings)
It transforms data into numerical representations called vectors or embeddings. Each data object (e.g., text, image, audio) is mapped to a high-dimensional vector using techniques like GloVe, Word2Vec, or BERT. These embeddings capture patterns and context within the data.

### Distance Functions
It relies on mathematical functions (distance or similarity metrics) to measure how similar or closely related two vectors are. Common metrics include Euclidean distance (l2_distance), cosine similarity(cosine_distance), and Dot Product (inner_product).

### Search Algorithms
Algorithms like K-Nearest Neighbors (KNN) are used to find vectors similar to a given query. Given an input query vector, KNN identifies the K most similar vectors in a dataset.

# Full Text Search
Full-text search using tsvector and tsquery is primarily focused on searching and matching textual content based on keywords, linguistic rules, and language-specific configurations. It allows you to perform text-based searches, such as finding documents that contain specific words or phrases. Full text searching in PostgresSQL is based on the match operator which returns true if a tsvector (document) matches a tsquery (query). It doesn't matter which data type is written first:

As the below example suggests, a tsquery is not just raw text, any more than a tsvector is. A tsquery contains search terms, which must be already-normalized lexemes, and may combine multiple terms using AND, OR, NOT, and FOLLOWED BY operators. There are functions to_tsquery, plainto_tsquery, and phraseto_tsquery that are helpful in converting user-written text into a proper tsquery, primarily by normalizing words appearing in the text. Similarly, to_tsvector is used to parse and normalize a document string.

```
SELECT to_tsvector('fat cats ate fat rats') @@ to_tsquery('fat & rat');
```


### Why is Vector Similarity Search Important?
Efficient Retrieval:
Vector similarity search efficiently identifies relevant vectors from large datasets. By associating similar mathematical representations of data, it enables swift and accurate searches.

### Semantic Relationships:
Instead of exact matches, vector search considers semantic relationships. It finds data representations closest to a query vector, known as nearest neighbors.

### Scalability:
It enables the handling of large datasets by leveraging optimized data structures and algorithms designed for high-dimensional similarity search.

### Data Deduplication:
Identifies and removes duplicate data entries by comparing vector representations.

# Re-Ranking using Reciprocal Rank Fusion algorithm for Hybrid Search

The Reciprocal Rank Fusion (RRF) algorithm is a technique used in information retrieval, particularly in the context of hybrid search systems, to combine the results from different search strategies or engines to produce a more effective ranking of search results. The RRF algorithm assigns a score to each document based on its ranking positions across multiple result lists and then merges these lists into a single, consolidated ranking.

The core idea behind the RRF algorithm is to give higher weight to documents that are consistently ranked highly across different search strategies rather than those that may appear at the top of one list but are absent from others. This approach is based on the reciprocal rank, which is the inverse of the rank position. For a document that appears at rank k, the reciprocal rank is 1/k.

**The algorithm for Reciprocal Rank Fusion can be formalized as follows:**


`RRF = 1 / (k + rank)`

where `rank` is the rank position of the document in a result list, and k is a constant that can be tuned to control the level of fusion. A common choice for k is 60, as suggested by the original authors of the RRF method.

**To apply RRF in a hybrid search system, we are performing the following steps:**

1. Retrieve separate result lists from the different search strategies.
2. For each document in each result list, calculate its RRF score using the formula above.
3. Sum the RRF scores for each document across all result lists.
4. Sort the documents by their total RRF scores in descending order to produce the final fused ranking.

The RRF algorithm is particularly useful in scenarios where different search strategies are complementary to each other, as it can leverage the strengths of each to improve the overall search performance. It is a simple yet effective method for combining multiple sources of evidence in information retrieval tasks.

# Re-Ranking logic for vector search in Hybrid Search API:
We can use normalization for score based on distance function and then do combine:

## Cosine Distance:
Initial Scores: The cosine distance scores range from 0 to 1, with 0 indicating perfect similarity and 1 indicating no similarity.

### Full-text Search:
Initial Scores: The full-text search scores are already within the range of 0 to 1, so no further normalization is required.

### Normalization:
To normalize the cosine distance scores, you can subtract each score from 1. This transformation ensures that higher scores indicate higher relevance. Example: Initial Scores: [0.2, 0.5, 0.8] Normalized Scores: [0.8, 0.5, 0.2]

## L2 Distance:
Initial Scores: The L2 distance scores can have any positive value, with lower values indicating higher similarity.

### Normalization:
To normalize the L2 distance scores, you can use the formula normalized_score = (1 - 1 / (1 + l2_distance_score)). This transformation ensures that lower scores indicate higher relevance. Example: Initial Scores: [2.5, 1.8, 3.2] Normalized Scores: [0.29, 0.36, 0.24]

## Inner Product:
Initial Scores: The inner product scores can be positive or negative, and their magnitude or sign may need adjustment for meaningful similarity scores.

### Normalization:
To normalize the inner product scores, you can take the absolute value of each score and divide it by the maximum absolute value among all scores. This transformation ensures that the normalized scores range from 0 to 1. Example: Initial Scores: [-0.5, 0.8, -0.3] Normalized Scores: [0.625, 1.0, 0.375]

## How to Use Similarity Search API?
To perform a similarity search, a call can be made to POST /v1/vector with the VectorRequest body The result array will contain a list of data objects that best match the query by perform similarity search at the vector database. 

Users can also limit the amount of objects returned by query string maxResults.i.e. POST /v1/vector/search?maxResults=5 will only return 5 objects. 

# Use Hybrid Search API
API for performing hybrid search using vector search and full-text search.To perform a hybrid search, a call can be made to POST /v1/hybrid?maxResults=5 with the HybridRequest body. The result array will contain a list of data objects that best match the query by perform hybrid search at the pgvector database.



## VectorRequest
```
{
  "query": "string",
  "dataset_id": "string",
  "distance_function": "cosine_distance"
  "distance_threshold": null,
  "metadata": {},
  "cmetadata" : {}, 
}
```
## HybridRequest
```
{
"query": "string",
"dataset_id": "string",
"distance_function": "cosine_distance"
"distance_threshold": null,
"vector_weight": 1
}
```


The response will come in the form of the following:

## VectorResponse/HybridResponse
```
{
  "data": [
    {
      "document": "string"
	  "score": 0.00,
      "metadata": {
        "key": "value",
        "key": "value"
      },
      "cmetadata": {
        "key": "value",
        "key": "value"
      }
    },
    {
      "document": "string"
	  "score": 0.00,
      "metadata": {
        "key": "value",
        "key": "value"
      },
      "cmetadata": {
        "key": "value",
        "key": "value"
      }
    }
  ],
  "errors": null,
  "meta": null,
  "success": true,
  "message": null
}
```

## Combined Vector and Full Text Search
To make things easier for users, DaaS has also included a search that combined both vector and graph search into one call POST /v1/hybrid. The request body is exactly the same as the vector similarity search:

```
{
  "query": "string",
  "dataset_id": "string",
  "distance_function": "cosine_distance"
  "distance_threshold": null,
  "vector_weight": "string"
}
```

Notice that the vector_weight is a value from 0 to 1 that represents the porcentage of similarity search that you want to use to perform the search combined with the full-text search.
This is the recommended search for most use cases. 

# What Is a Knowledge Graph?

A knowledge graph is a structured representation of real-world entities and their interrelationships, typically stored within a graph database. It facilitates intuitive data visualization and querying, enhancing the understanding of data connections.

## Key Concepts

- **Entities:** Represent objects, events, situations, or concepts within the graph.
- **Relationships:** Define how entities are connected, providing context and meaning.
- **Organizing Principles:** Frameworks or schemas that structure entities and relationships to facilitate deeper insights.

## How Knowledge Graphs Work

Knowledge graphs organize information into networks of entities and relationships. For example, Google's Knowledge Graph enhances search functionality by structuring facts about people, places, and things into a network, thereby improving the relevance and context of search results.

## Labeled Property Graph Key Characteristics
1. **Nodes:** Represent an entity or object within the graph. We break nodes into two types: Primary and secondary nodes.
    - **Primary nodes** Represent the nodes that were used to embed the data into vector to use them with similarity search.
    - **Secondary nodes** Represent the nodes that were not embedded but that are still important data to connect primary nodes with.
2. **Entities:** Represent the all the nodes inside a knowledge graph. For unstructured data, entities are the most important objects from the graph suggested from the LLM model for each chunk.
3. **Relationships** Represent the connections between the entities/nodes.
3. **Labels:** Represent the Types of a subset of values
4. **Properties:** Represent the attributes of a node. These could be different types of data as string, int, double.. etc.


## AIDaaS Key Characteristics

The primary nodes are used to do similarity search and AIDaaS structure looks like this:
1. **dataset** Represent the subset of data that is part of your team
2. **dataset_object_id** Represent a file that was already ingested
3. **document** represent the chunk (part of the data that was parsed)
4. **embedding** represent the vector created for each parsed data. Is the same as *document* but used for the database to do similarity search algorithms


## How Graph Data Retrieval Works

When you are retriving Labeled Property Graphs. Similarity Search is applied from the query to match all **primary nodes** (that contain all AIDaaS Key characteristics). The **secondary nodes** will be extracted from each ranked **primary node** to complement the data.
1. Define how many results you want to retrieve, **max_results**
2. Need to define the question or **query** you need to answer using the knowledge graph
3. Apply a mandatory filter using your **dataset_id**
4. The results are ranked making the most relevant to be the first result but you can reduce the size of your results using **score_threshold** with 0.6 or similar. This filter excludes any scores lower than the selected value. 
5. In the request there are two lists: **entities** and **relationships**  (defined by the user or dynamically found from the LLM) are used only to filter Unstructured results.
6. **Chunks** filter is used to reduce the context of the results of the query. The list of chunks could be extracted after running a Cypher query in the Graph API. 


## GraphRequest
```
{
  "query": "string",
  "dataset_id": "string",
  "score_threshold": 0.6,
  "embedded_node_label": "string",
  "entities": [
    "string"
  ],
  "relationships": [
    "string"
  ],
  "chunks": [
    "string"
  ]
}
```

## GraphResponse
```
{
  "data": [
    {
      "document": "content of the matched vector matched using similarity search ranked with the higher score",
      "metadata": {
        "chunk_index": null,
        "dataset_object_id": "string",
        "related_entities": [
          "'primary node value1' RELATIONSHIP_EXAMPLE1 'secondary node Type1' 'secondary node value1'",
          "'primary node value2' RELATIONSHIP_EXAMPLE2 'secondary node Type2' 'secondary node value2'"
        ],
        "chunk_id": "string"
      },
      "score": 0.8843481540679932
    },{...},{...}, etc
  ],
  "errors": null,
  "meta": null,
  "success": true,
  "message": "Chunks Retrieved"
}
```

## Fetch documents based on user query

Upon receiving the user query, we will convert it into embeddings and execute a Neo4j query to perform the following tasks:

- **Document and Chunk Retrieval:** Find the document node associated with each user query embedding, and gather details about each chunk node, including its similarity to the user query embedding.

- **Entity Extraction:** Identify entities connected to the chunks and limit the results to the most relevant ones based on their similarity scores.

- **Relationship Expansion:** Expand the search to discover related entities and relationships, performing either a one-step or two-step expansion depending on the similarity threshold.

- **Text and Metadata Generation:** Format and sort the gathered data into text summaries, including details on entities and relationships. Create metadata for a comprehensive overview.

- **Result Compilation:** Combine the text and metadata into a single response, providing a detailed and organized view of the relevant data.

Once we retrieve the documents, we pass the response as a JSON object.

Other searches
The DaaS team is also in the process of implementing new types of searches to would yield better result for various use cases, including hybrid search and cross-table searches. Please stay tune for more information. 

# Installation

- Clone git repository: ```git clone git@gitlab.dell.com:1007241/aidaas-search-api.git```
- Navigate to the project directory: 'cd repo-name'
- Create a virtual env

To install, simply run:
```
> pip install virtualenv
```

Once finished, you can create the virtual env:
```
> cd <your_repo_clone_path>/data_services
> python -m virtualenv .venv
```

To activate the `VENV`
```
> .venv\Scripts\activate
```

You can use the requirements file to install all dependencies:
```
> pip install -r requirements.txt
```

## Features roadmap
- [x] Health check endpoint (used for Monitoring)
- [x] Authentication with the Auth API before performing search actions
- [x] Vector Search to perform similarity search at PGVector
- [x] Hybrid Search to perform similarity search combined with full-text search at PGVector
- [x] Graph Search to perform queries in Neo4j
- [x] CICD standards (automated testing & automated deployment)
    - [x] Vector, Hybrid and Graph unit tests
    - [x] Triggering E2E Testing as part of the CICD pipeline
- [x] Kubernetes configuration files to Deploy on KOB (infra)
- [x] Non-root Dockerfile (scanned on security checks)
- [x] Automated documentation (swagger and redoc)
    - [x] README.md integrated with Confluence using gitlab api
- [x] Scaffolding baseline
  - [x] API layer (controller, request, response)
  - [x] Application layer (service, facade, exception, dto)
  - [x] Domain layer
- [x] Domain-Driven Design (improved code readability and maintainability)
- [x] Logging standard (used for Observability)
- [ ] Use cache to speed-up search endpoints



