# AIDaaS Agent Memory – Architecture & Flow Diagrams

This document captures the end-to-end flows supported by the **aidaas-agent-memory** service. Each flow is presented as a Mermaid diagram followed by key notes. The final section summarises the underlying storage structures.

---

## 1. Long-Term Memory (LTM)

### 1.0 Component Overview
```mermaid
flowchart LR
    subgraph ClientTier[Client]
        C[Agent / API Caller]
    end
    subgraph ServiceTier[AIDaaS Agent Memory]
        API[/AIDaaSAgentMemory API Router/]
        Service[LTMService]
        Session["LangMemClientSession\n(per client)"]
    end
    subgraph LangMemStack[LangMem + LangChain]
        LM[langmem.create_memory_manager]
        LLM["Configured LLM<br/>(Dell GenAI)"]
        Embed["Configured Embedding Model"]
    end
    subgraph Storage[Persistent Stores]
        PG[(PostgreSQL + pgvector)]
    end

    C -->|REST calls| API --> Service --> Session
    Session -->|"invoke()"| LM
    LM --> LLM
    Session -->|embed_documents/embed_query| Embed
    Session -->|insert/search/update| PG
```
**Key ideas**
- `LangMemClientSession` orchestrates LangMem extraction, embeddings, and pgvector persistence. Each `client_id` owns an isolated cached session and dedicated PostgreSQL table.
- LangMem participates only during ingestion (`/ltm/memories`) to transform transcripts into structured memories, guided by per-client instructions and field definitions. Retrieval queries hit pgvector directly.
- Successful tool calls or JSON payloads populate dedicated columns and `metadata.structured_fields`; fallbacks keep the raw conversation and are tagged with `metadata.extraction_method="fallback"`.
- Embedding problems store diagnostic metadata and a zero vector so the write path never fails silently.
- `/ltm/configure` now accepts optional `instructions` plus an ordered list of `fields` (name + description). Provisioning dynamically adds columns while keeping the schema framework agnostic.
- Table names are derived from the sanitised `client_id` without additional prefixes (e.g., `123_memories`, `f84b668b_2907_4d6a_a585_f42eacc03416_memories`) inside the shared `MEMORY_SCHEMA`.

### 1.1 Configure Client Memory
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/configure
    participant Service as LTMService
    participant Manager as MemoryManager
    participant Repo as PostgreSQL (pgvector)

    Client->>API: POST client_id, api_key, llm_model, embedder_model,<br/>instructions?, fields[]
    API->>Service: configure(request)
    Service->>Manager: build_runtime_config(request)
    Manager->>Repo: table_exists(schema, table)
    Repo-->>Manager: true/false
    alt table not found
        Manager->>Repo: ensure_client_store(runtime.fields)
        Repo-->>Manager: table created
    else already exists
        Manager->>Repo: ensure field columns exist
    end
    Manager-->>Service: LangMemClientSession refreshed
    Service-->>API: Configuration result (table_created flag)
    API-->>Client: 200 OK
```
**Key notes** 
- Table names are derived from the sanitised `client_id` and suffixed with `_memories` (no `client_` prefix). Examples:
  - `client_id = "1234567"` → `agent_memory_dev."1234567_memories"`
  - `client_id = "f84b668b-2907-4d6a-a585-f42eacc03416"` → `agent_memory_dev.f84b668b_2907_4d6a_a585_f42eacc03416_memories`
- Custom `fields` add TEXT columns idempotently. Re-running configure for an existing client ensures newly requested fields are present without dropping data.
- The session cache is refreshed on configure so updated instructions, models, or API keys take effect on the next ingestion call.
- LangMem resources (LLM client, embedding client, memory manager) are initialised lazily the first time ingestion occurs; configure simply records the runtime settings.
- Field definitions are declared as objects with `name` and `description`. Names are sanitised to lowercase snake_case column names (e.g., `"Suggested Product"` → `suggested_product`). Descriptions steer extraction and are surfaced to LangMem as parameter docs.

#### Field Definition Format & Provisioning Rules
- `fields` accepts an array of structured field definitions. Example:
  ```json
  {
    "fields": [
      { "name": "user_ask", "description": "One-line summary of what the user requested" },
      { "name": "suggested_product_name", "description": "Product model the agent recommends" }
    ]
  }
  ```
- Sanitisation removes unsupported characters, forces lowercase, and guards against collisions with reserved columns (`id`, `client_id`, `memory`, `metadata`, etc.). Duplicate logical names are resolved automatically by suffixing the generated column.
- All dynamic columns are created as `TEXT`. Reconfiguring an existing client adds any newly requested columns idempotently without altering existing data.
- Instructions can reference business concepts rather than column identifiers. LangMem sees the generated Pydantic schema (with descriptions) and maps extracted values back to the requested fields.
- Every `/ltm/memories` call must supply at least one of `user_id`, `agent_id`, or `run_id` so stored rows remain attributable.

### 1.2 Add Memories
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/memories
    participant Service as LTMService.add_memory
    participant Session as LangMemClientSession
    participant Langmem
    participant Embeds as Embedding API
    participant Repo as PostgreSQL

    Client->>API: POST messages + identifiers + metadata<br/>X-Client-ID header
    API->>Service: add_memory(client_id, ...)
    Service->>Session: _require_session(client_id)
    alt session not cached
        Service->>Manager: get_memory_instance(client_config)
        Manager->>Repo: ensure_client_store()
    end
    Service->>Langmem: invoke({messages})
    alt Langmem tool call or JSON memory
        Langmem-->>Service: structured entries
    else Langmem empty/error
        Service-->>Service: fallback to raw message content<br/>metadata.extraction_method="fallback"
    end
    Service->>Embeds: embed_documents(contents)
    alt Embedding ok
        Embeds-->>Service: vectors
    else Embedding fails
        Service-->>Service: use zero-vector<br/>metadata.embedding_status set
    end
    Service->>Repo: insert_memories(table, payloads)
    Repo-->>Service: committed records
    Service-->>API: results[]
    API-->>Client: 200 OK (with inserted memories)
```

**LangMem usage**
- `Session._get_langmem_manager()` spins up LangMem lazily with the client’s API key, model choices, and custom instructions; caches are cleared whenever `/ltm/configure` is called.
- `manager.invoke({"messages": messages, "existing": prior_profile})` generates structured records aligned with the configured `fields`. Missing values become `NULL`, while unexpected keys land only in metadata.
- When LangMem ignores the tool because of caller-supplied system prompts, the session automatically retries with those prompts downgraded to user messages before emitting a fallback record.
- The service accepts canonical tool calls and JSON payloads emitted in the final assistant message. Only when no structured payload exists after the retry do we fabricate fallback entries, marking them with `metadata.extraction_method="fallback"`.
- Structured rows populate both dedicated columns (e.g., `user_ask`, `suggested_product_name`) and `metadata.structured_fields`, keeping SQL and API consumers in sync.

### 1.2.1 Structured vs fallback memories
- **Structured (`extraction_method="langmem"`)**: LangMem emitted a tool call/JSON payload. We persist a concise sentence in `memory`, store field values in their respective columns, and mirror the mapping under `metadata.structured_fields`.
- **Fallback (`extraction_method="fallback"`)**: LangMem returned nothing useful. We capture raw user/assistant content so no context is lost; structured columns remain `NULL`, but identifiers and metadata still populate for later reprocessing.

### 1.2.2 Example Flow – `client_id = "1234567"`
```mermaid
sequenceDiagram
    participant Client
    participant Configure as POST /ltm/configure
    participant Memories as POST /ltm/memories
    participant Search as POST /ltm/search
    participant Repo as agent_memory_dev."1234567_memories"

    Client->>Configure: instructions + fields[user_ask, suggested_product_name, product_specs]
    Configure-->>Client: 200 OK (table_created?)

    Client->>Memories: messages (user asks for GPU laptop, agent recommends Inspiron)
    Memories->>Repo: INSERT memory + user_ask=“GPU laptop”, suggested_product_name=“Dell Inspiron 5000”, product_specs=“32GB RAM, i5 10th gen, NVIDIA H100 GPU”
    Repo-->>Memories: committed id + metadata.extraction_method="langmem"
    Memories-->>Client: structured_fields echoed in response

Client->>Search: query "GPU laptop recommendation", filters client_id=1234567
Search->>Repo: vector search + optional column filters
Repo-->>Search: ranked rows incl. structured_fields & metadata
Search-->>Client: results array ready for downstream agents
```

### 1.2.3 Provision → Ingest → Search (Numbered Trace)
```mermaid
sequenceDiagram
    participant Client as Client / Agent Platform
    participant API as 1️⃣ /ltm/configure
    participant Service as 2️⃣ LTMService
    participant Repo as 3️⃣ PostgreSQL (per-client table)
    participant Session as 4️⃣ LangMemClientSession
    participant LM as 5️⃣ LangMem + Embeddings

    Client->>API: 1. POST configure (client_id, instructions, fields[])
    API->>Service: 2. build_runtime_config()
    Service->>Repo: 3. ensure_client_store(schema, table, dynamic columns)
    Service->>Session: 4. refresh cached session
    Service-->>Client: 1.a configuration OK

    Client->>API: 6. POST /ltm/memories (messages, identifiers, metadata)
    API->>Service: 7. add_memory(client_id,…)
    Service->>Session: 8. _require_session()
    Session->>LM: 9. invoke LangMem tool (custom schema)
    alt Structured output
        LM-->>Session: 10. structured field payload
    else Needs retry
        Session->>LM: 9.a retry without caller system prompts
        LM-->>Session: 10.a structured payload or empty
    end
    Session->>LM: 11. embed_documents(structured content)
    Session->>Repo: 12. insert_memories(id, memory, metadata, dynamic columns)
    Repo-->>Session: 13. commit acknowledged
    Session-->>Service: 14. MemoryRecord list
    Service-->>Client: 15. response (structured_fields + metadata)

    Client->>API: 16. POST /ltm/search (query + filters)
    API->>Service: 17. search_memories()
    Service->>Session: 18. reuse cached session
    Session->>LM: 19. embed_query(query)
    Session->>Repo: 20. pgvector search + filters
    Repo-->>Session: 21. rows + distances
    Session-->>Service: 22. MemoryRecord results
    Service-->>Client: 23. ranked payload
```

### 1.3 Semantic Search
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/search
    participant Service as LTMService.search_memories
    participant Session as LangMemClientSession
    participant Embeds as Embedding API
    participant Repo as PostgreSQL

    Client->>API: POST query, filters, X-Client-ID
    API->>Service: search_memories(client_id, ...)
    Service->>Session: _require_session(client_id)
    Service->>Embeds: embed_query(query)
    alt Embedding ok
        Embeds-->>Service: query vector
    else Embedding fails
        Service-->>Service: use zero-vector<br/>metadata logged
    end
    Service->>Repo: search_memories(query_embedding,...)
    Repo-->>Service: rows + distances
    Service-->>API: results with scores (normalised, NaN guarded)
    API-->>Client: 200 OK
```

**LangMem usage**
- LangMem is not called during retrieval. Searches operate solely on stored text, structured columns, metadata, and vectors.
- The only dependency on the LLM stack is the embedding model, which must match the one used at ingestion time. Both document and query embeddings go through the same embedding client so distances stay comparable.

### 1.3.1 LangMem Decision Path (Add Memories)
```mermaid
stateDiagram-v2
    [*] --> InvokeLangMem: Invoke LangMem manager with conversation messages
    InvokeLangMem --> ExtractionSuccess: Structured memories returned
    InvokeLangMem --> ExtractionFailure: Exception / invalid response
    InvokeLangMem --> ExtractionEmpty: Empty list / None

    ExtractionSuccess --> EmbeddingRequest: Tool call or JSON memory captured
    ExtractionFailure --> FallbackRaw
    ExtractionEmpty --> FallbackRaw

    FallbackRaw --> EmbeddingRequest: Build MemoryExtractionResult per message (is_fallback)

    EmbeddingRequest --> EmbeddingSuccess: embed_documents/embed_query
    EmbeddingRequest --> EmbeddingFailure: Exception during embedding

    EmbeddingSuccess --> Persist: insert_memories() with embeddings
    EmbeddingFailure --> ZeroVectorFallback: Use zero vector + embedding_status
    ZeroVectorFallback --> Persist
    Persist --> [*]
```
**What happens**
- Regardless of LangMem output, the session produces at least one `MemoryExtractionResult`. We first look for a tool call; if none exist we examine the assistant messages for JSON payloads. Only when neither is present do we create fallback entries from the raw messages.
- Results feed the embedding API; only after embeddings are available do we write to PostgreSQL.
- Metadata tracks both extraction path (`langmem` vs `fallback`) and embedding status so downstream analytics can filter or retry. Structured rows also include `structured_fields` in both the API payload and the `metadata` JSON column. Fallback rows still carry `agent_id`, `user_id`, and any custom metadata so they can be reprocessed later.
- Tables are per-client, so even when LangMem falls back the data remains isolated.

### 1.3.2 Retrieval Filter Matrix
```mermaid
flowchart TD
    Q["Search request (client_id + query + filters)"] --> EmbedQuery
    EmbedQuery["Generate query embedding (OpenAIEmbeddings.embed_query)"] --> RepoQuery
    RepoQuery[LongTermMemoryRepository.search_memories] -->|pgvector distance| Rank
    Rank --> Response

    subgraph MetadataFilters
        F1[user_id]
        F2[agent_id]
        F3[run_id]
        F4[metadata JSONB filters]
    end

    Q --> F1 --> RepoQuery
    Q --> F2 --> RepoQuery
    Q --> F3 --> RepoQuery
    Q --> F4 --> RepoQuery
```
**Notes**
- The repository builds SQL that filters by `user_id`, `agent_id`, `run_id`, explicit structured columns, and arbitrary JSONB conditions in `metadata`. JSON filters must reference top-level keys exactly as they are stored (e.g., `"priority": "P2"`). LangMem identifiers (`metadata.langmem_id`) make it easy to deduplicate extractions.
- Because each client has its own table, we avoid cross-tenant scans and keep pgvector indexes compact.

### 1.4 Reset Client Memory
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/reset
    participant Service as LTMService.reset_memory
    participant Session as LangMemClientSession
    participant Repo as PostgreSQL

    Client->>API: POST, X-Client-ID
    API->>Service: reset_memory(client_id)
    Service->>Session: _require_session(client_id)
    Service->>Repo: reset_client_store(table)
    Repo-->>Service: table truncated
    Service-->>API: "All memories reset"
    API-->>Client: 200 OK
```

---
## 2. Short-Term Memory (STM)

### 2.1 Session Lifecycle
```mermaid
flowchart TD
    A[POST /sessions] -->|client_id, agent_id, user_id| B(session created<br/>session_id returned)
    C[GET /sessions] -->|query params| D[list of sessions]
    E[POST /sessions/end] -->|client_id + session_id| F[session marked closed]
```

### 2.2 Add Messages & Automatic Summarisation
```mermaid
sequenceDiagram
    participant Client
    participant API as /stm/memory
    participant Service as STMService.add_messages
    participant Redis as Redis (Chat History)
    participant Summarizer as Summarisation (LangChain + LLM)

    Client->>API: POST client_id, agent_id, user_id, session_id, messages[]
    API->>Service: add_messages(...)
    Service->>Redis: store messages
    alt batch size reaches MEMORY_BATCH_SIZE
        Service->>Summarizer: summarise(history)
        Summarizer-->>Service: summary message
        Service->>Redis: replace history with summary + tail
    end
    Service-->>API: success
    API-->>Client: 200 OK
```

### 2.3 Retrieve / Delete / Manual Summarise
```mermaid
sequenceDiagram
    participant Client
    participant GetAPI as GET /stm/memory
    participant DelAPI as DELETE /stm/memory
    participant SumAPI as POST /stm/memory/summarize
    participant Service as STMService
    participant Redis

    Client->>GetAPI: GET params
    GetAPI->>Service: get_memory(...)
    Service->>Redis: fetch history
    Redis-->>Service: messages + summaries
    Service-->>GetAPI: message list
    GetAPI-->>Client: 200 OK

    Client->>SumAPI: POST params
    SumAPI->>Service: manual_summarize(...)
    Service->>Redis: load history
    Service->>Summariser: summarise(history)
    Summariser-->>Service: summary
    Service->>Redis: replace content
    SumAPI-->>Client: 200 OK

    Client->>DelAPI: DELETE params
    DelAPI->>Service: delete_memory(...)
    Service->>Redis: delete keys
    DelAPI-->>Client: 200 OK
```

---

## 3. Storage Structures

### 3.1 PostgreSQL (Per-Client LTM table)
| Column         | Type              | Notes / Indexes                                    |
|----------------|-------------------|----------------------------------------------------|
| `id`           | `UUID`            | Primary key                                        |
| `client_id`    | `TEXT`            | Stored redundantly for metadata queries            |
| `user_id`      | `TEXT`            | Filter index (`btree`)                             |
| `agent_id`     | `TEXT`            | Filter index (`btree`)                             |
| `run_id`       | `TEXT`            | Optional run identifier                            |
| `memory`       | `TEXT`            | Human-readable memory content                      |
| `embedding`    | `vector(d)`       | pgvector column (dimension inferred from embedder) |
| `metadata`     | `JSONB`           | Arbitrary metadata. GIN index created              |
| `created_at`   | `TIMESTAMPTZ`     | Defaults to `NOW()`                                |
| `updated_at`   | `TIMESTAMPTZ`     | Automatically updated on write                     |
| `…custom fields…` | `TEXT`         | Optional columns created from `/ltm/configure`     |

**Additional indexes**
- `GIN(metadata)` for attribute filters (`metadata @> {...}`).
- `btree(agent_id)` and `btree(user_id)` to speed up selective queries.

Whenever a client provisions custom fields via `/ltm/configure`, each field adds a `TEXT` column to this table (e.g., `user_ask`, `suggested_product_name`). Values extracted by LangMem are stored both in these dedicated columns and in `metadata.structured_fields`, ensuring you can query them through SQL **and** the JSON API. Fallback rows leave the structured columns `NULL` and keep the raw dialogue in the `memory` column.

```mermaid
classDiagram
    class sanitized_client_id_memories {
        +UUID id
        +TEXT client_id
        +TEXT user_id
        +TEXT agent_id
        +TEXT run_id
        +TEXT memory
        +vector embedding
        +JSONB metadata
        +TIMESTAMPTZ created_at
        +TIMESTAMPTZ updated_at
        +TEXT ...custom_fields
    }
```

### 3.2 Redis (STM)
- **Key pattern**: `memory:{client_id}:{agent_id}:{user_id}:{session_id}`
- **Structure**: List of messages; summaries replace older messages once thresholds are crossed.
- **TTL**: controlled via `REDIS_TTL`. SSL options are honoured (`REDIS_SSL_CERT_REQS`, `REDIS_SSL_CHECK_HOSTNAME`).

---

These diagrams represent the current implementation. Any new behaviour (e.g., new LTM endpoints, additional metadata, the update on LTM to replace client_id with client_id, or the integration wuth auth-api) should be reflected here to keep architectural documentation aligned with the codebase.
- **Example – Dell Laptop Recommendation Agent**

    ```json
    {
      "client_id": "1234567",
      "api_key": "******",
      "llm_model": "gpt-oss-20b",
      "embedder_model": "embeddinggemma-300m",
      "instructions": "Extract a concise user ask, the recommended product name, and its specs.",
      "fields": [
        {"name": "user_ask", "description": "One-line summary of what the user requested"},
        {"name": "suggested_product_name", "description": "Product model the agent recommends"},
        {"name": "product_specs", "description": "Key specs or features mentioned"}
      ]
    }
    ```

    Provisioning this payload yields table `agent_memory_dev."1234567_memories"` with the standard columns plus `user_ask`, `suggested_product_name`, and `product_specs`.
