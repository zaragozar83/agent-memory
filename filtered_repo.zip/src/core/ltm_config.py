"""
Core configuration module for the Agentic Memory API long-term memory service.

This module defines the user-facing configuration objects, system defaults,
and helper utilities required to provision client-scoped memory storage that
is compatible with langmem while remaining framework agnostic at the
database layer.
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass
from typing import Optional, List
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator

from src.core.environment_variables import EnvironmentVariables

# Load environment variables so defaults are available everywhere
load_dotenv()

# PostgreSQL imposes a 63 character limit on identifiers
MAX_IDENTIFIER_LENGTH = 63
MEMORY_TABLE_SUFFIX = "memories"


class FieldDefinition(BaseModel):
    """Client supplied definition for a structured field."""

    name: str = Field(..., description="Logical name for the field (e.g. user_ask)")
    description: str = Field(
        default="",
        description="Textual description that guides LangMem extraction",
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("Field name cannot be empty")
        return trimmed


class ClientConfig(BaseModel):
    """Configuration supplied by API consumers for a given client_id."""

    client_id: str = Field(
        ...,
        description="Unique client identifier used for table-level memory isolation",
    )
    api_key: str = Field(..., description="API key used for LLM and embedding providers")
    llm_model: str = Field(
        default="gpt-oss-20b", description="LLM model used for memory extraction"
    )
    embedder_model: str = Field(
        default="embeddinggemma-300m",
        description="Embedding model used for semantic search",
    )
    instructions: Optional[str] = Field(
        default=None,
        description="Optional custom instructions passed to LangMem for extraction",
    )
    fields: List[FieldDefinition] = Field(
        default_factory=list,
        description="Optional structured field definitions to map extracted memories",
    )

    @field_validator("client_id")
    @classmethod
    def validate_client_id(cls, value: str) -> str:
        """Ensure client identifiers are non-empty after trimming whitespace."""
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("client_id cannot be empty or whitespace")
        return trimmed

    @property
    def sanitized_client_id(self) -> str:
        """Return a sanitized identifier suitable for SQL objects."""
        return sanitize_identifier(self.client_id)

    @property
    def table_name(self) -> str:
        """Return the fully qualified table name (without schema)."""
        return build_client_table_name(self.client_id)


@dataclass(frozen=True)
class ClientRuntimeConfig:
    """
    Derived runtime configuration for a given client_id.

    Attributes:
        client_id: Original client identifier supplied by the caller.
        sanitized_client_id: Identifier sanitized for use in SQL objects.
        table_name: Final table name (without schema) for the client memory store.
        embedding_dims: Embedding dimension inferred from the embedder model.
        system: Snapshot of system configuration values.
    """

    client_id: str
    sanitized_client_id: str
    table_name: str
    embedding_dims: int
    system: "SystemConfig"
    fields: List["RuntimeField"]


@dataclass(frozen=True)
class RuntimeField:
    """Runtime representation of a structured field."""

    name: str
    column_name: str
    description: str


class SystemConfig:
    """System-wide configuration sourced from environment variables."""

    # PostgreSQL settings
    POSTGRES_HOST: str = EnvironmentVariables.POSTGRES_HOST
    POSTGRES_PORT: int = EnvironmentVariables.POSTGRES_PORT
    POSTGRES_DB: str = EnvironmentVariables.POSTGRES_DB
    POSTGRES_USER: str = EnvironmentVariables.POSTGRES_USER
    POSTGRES_PASSWORD: str = EnvironmentVariables.POSTGRES_PASSWORD

    # Dedicated schema to hold all client tables
    MEMORY_SCHEMA: str = EnvironmentVariables.MEMORY_SCHEMA

    # LLM settings
    LLM_TEMPERATURE: float = 0.2
    LLM_BASE_URL: str = EnvironmentVariables.LLM_BASE_URL
    LLM_MAX_TOKENS: int = 2000

    # Embedding settings
    EMBEDDER_BASE_URL: str = EnvironmentVariables.EMBEDDER_BASE_URL
    _DEFAULT_CA_CANDIDATES = (
        "/etc/ssl/certs/ca-certificates.crt",
        "/etc/pki/tls/certs/ca-bundle.crt",
    )

    TLS_CA_BUNDLE: Optional[str] = os.environ.get("TLS_CA_BUNDLE") or os.environ.get("OPENAI_CA_BUNDLE") or os.environ.get("REQUESTS_CA_BUNDLE")
    if not TLS_CA_BUNDLE:
        for candidate in _DEFAULT_CA_CANDIDATES:
            if Path(candidate).exists():
                TLS_CA_BUNDLE = candidate
                break

    # FastAPI settings (left intact for backwards compatibility)
    APP_NAME = "Agentic Memory API"
    APP_VERSION = "1.0.0"
    DEBUG = os.environ.get("DEBUG", "false").lower() == "true"
    HOST = "0.0.0.0"
    PORT = int(os.environ.get("PORT", "8000"))


def get_system_config() -> SystemConfig:
    """Return a new snapshot of the system configuration."""
    return SystemConfig()


def build_client_runtime(config: ClientConfig) -> ClientRuntimeConfig:
    """
    Build a runtime configuration for the provided client configuration.

    Args:
        config: Client-supplied settings

    Returns:
        ClientRuntimeConfig with derived values used across the service layer.
    """
    system = get_system_config()
    schema = sanitize_identifier(system.MEMORY_SCHEMA, fallback_prefix="ltm")
    system.MEMORY_SCHEMA = schema
    sanitized = sanitize_identifier(config.client_id)
    table_name = build_client_table_name(config.client_id)
    embedding_dims = get_embedding_dimensions(config.embedder_model)

    runtime_fields: List[RuntimeField] = []
    seen_columns = set()
    for field in config.fields:
        raw_name = field.name.strip()
        column = sanitize_identifier(raw_name, fallback_prefix="field")
        # Avoid collisions with existing columns or duplicate field names
        base_column = column
        suffix = 1
        while column in seen_columns or column in {
            "id",
            "client_id",
            "user_id",
            "agent_id",
            "run_id",
            "memory",
            "embedding",
            "metadata",
            "created_at",
            "updated_at",
        }:
            column = f"{base_column}_{suffix}"
            suffix += 1
        seen_columns.add(column)
        runtime_fields.append(
            RuntimeField(
                name=raw_name,
                column_name=column,
                description=field.description or "",
            )
        )

    return ClientRuntimeConfig(
        client_id=config.client_id,
        sanitized_client_id=sanitized,
        table_name=table_name,
        embedding_dims=embedding_dims,
        system=system,
        fields=runtime_fields,
    )


def sanitize_identifier(raw_value: str, *, fallback_prefix: str = "client") -> str:
    """
    Sanitize arbitrary input for safe use in SQL identifiers.

    - Removes unsupported characters
    - Ensures the first character is alphabetic or an underscore
    - Normalizes to lowercase
    - Truncates and appends a hash if the result exceeds PostgreSQL's identifier limit
    """
    normalized = re.sub(r"[^0-9a-zA-Z_]+", "_", raw_value).strip("_")
    if not normalized:
        normalized = fallback_prefix

    normalized = normalized.lower()

    if len(normalized) <= MAX_IDENTIFIER_LENGTH:
        return normalized

    digest = hashlib.sha1(raw_value.encode("utf-8")).hexdigest()[:8]
    available = MAX_IDENTIFIER_LENGTH - len(digest) - 1  # account for underscore
    truncated = normalized[:available] if available > 0 else fallback_prefix
    return f"{truncated}_{digest}"


def build_client_table_name(client_id: str) -> str:
    """
    Construct the memory table name for a client.

    Naming rules:
        - Replace unsupported characters with underscores
        - Append `_memories`
        - Ensure final name respects PostgreSQL's identifier length limit
    """
    sanitized = sanitize_identifier(client_id)
    base_name = f"{sanitized}_{MEMORY_TABLE_SUFFIX}"

    if len(base_name) <= MAX_IDENTIFIER_LENGTH:
        return base_name

    digest = hashlib.sha1(client_id.encode("utf-8")).hexdigest()[:8]
    suffix = f"_{MEMORY_TABLE_SUFFIX}"
    available = MAX_IDENTIFIER_LENGTH - len(digest) - len(suffix) - 1
    truncated = sanitized[:available] if available > 0 else sanitize_identifier(
        client_id, fallback_prefix="mem_client"
    )
    return f"{truncated}_{digest}{suffix}"


def get_embedding_dimensions(model_name: str) -> int:
    """
    Infer embedding dimensionality from the embedder model identifier.

    Defaults to 1024 if the model is unknown.
    """
    mapping = {
        "bge-large-en-v1-5": 1024,
        "bge-base-en-v1-5": 768,
        "bge-m3": 1024,
        "gemini_embedding_001": 768,
        "gte-large": 1024,
        "bge-small-en-v1-5": 384,
        "text-embedding-3-large": 3072,
        "text-embedding-3-small": 1536,
        "embeddinggemma-300m": 768,
    }

    for key, dims in mapping.items():
        if key in model_name:
            return dims

    return 1024


def optional_url(value: Optional[str]) -> Optional[str]:
    """
    Normalize environment-controlled URLs so placeholder defaults like 'changeme'
    are treated as `None`.
    """
    if not value:
        return None

    lowered = value.strip()
    if not lowered or lowered.lower() in {"changeme", "none"}:
        return None
    return lowered
