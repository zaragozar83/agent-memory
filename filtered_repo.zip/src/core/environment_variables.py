import os

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class EnvironmentVariables:
    """
    Environment variables used across the application.
    """

    APP_NAME: str = os.environ.get("APP_NAME", "aidaas-agent-memory")
    APP_VERSION: str = os.environ.get("APP_VERSION", "1.0.0")

    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO")
    # API Configuration
    API_HOST = os.getenv("API_HOST", "127.0.0.1")
    API_PORT = int(os.getenv("API_PORT", "8000"))
    API_RELOAD = os.getenv("API_RELOAD", "True").lower() == "true"

    MEMORY_SCHEMA: str = os.environ.get("MEMORY_SCHEMA", "").strip()
    if not MEMORY_SCHEMA:
        raise ValueError(
            "MEMORY_SCHEMA environment variable must be set (e.g., agent_memory_dev)."
        )

    # Redis Configuration
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_TTL = int(os.getenv("REDIS_TTL", "3600"))
    REDIS_SSL_CERT_REQS = os.getenv("REDIS_SSL_CERT_REQS", "required")
    REDIS_SSL_CHECK_HOSTNAME = (
        os.getenv("REDIS_SSL_CHECK_HOSTNAME", "true").lower() == "true"
    )

    # Memory Service Configuration
    MEMORY_BATCH_SIZE = int(os.getenv("MEMORY_BATCH_SIZE", "10"))

    # OpenAI Configuration
    API_URL = os.getenv("API_URL", "")
    API_KEY = os.getenv("API_KEY", "")
    LLM_MODEL = os.getenv("LLM_MODEL", "gpt-oss-20b")

    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "embeddinggemma-300m")
    LTM_LLM_MODEL = os.getenv("LTM_LLM_MODEL", "gpt-oss-20b")
    LTM_DATABASE_URL = os.getenv("LTM_DATABASE_URL", "")
    EMBEDDER_BASE_URL = os.environ.get("EMBEDDER_BASE_URL", "changeme")
    LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "changeme")
    POSTGRES_HOST = os.environ.get("POSTGRES_HOST", "localhost")
    POSTGRES_PORT = int(os.environ.get("POSTGRES_PORT", "5432"))
    POSTGRES_DB = os.environ.get("POSTGRES_DB", "postgres")
    POSTGRES_USER = os.environ.get("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD = os.environ.get("POSTGRES_PASSWORD", "password")

    @classmethod
    def get_all_variables(cls):
        """
        Returns all environment variables as a dictionary.
        Private variables (starting with _) are excluded.
        """
        return {
            key: value
            for key, value in cls.__dict__.items()
            if not key.startswith("_") and key.isupper()
        }

    @classmethod
    def print_all_variables(cls):
        """
        Prints all environment variables and their values.
        Private variables (starting with _) are excluded.
        Sensitive variables (containing KEY, SECRET, PASSWORD, TOKEN) are masked.
        """
        sensitive_keys = ["KEY", "SECRET", "PASSWORD", "TOKEN"]

        for key, value in cls.get_all_variables().items():
            # Mask sensitive values
            if any(s in key for s in sensitive_keys) and value:
                masked_value = (
                    f"{value[:3]}{'*' * (len(value) - 6)}{value[-3:]}"
                    if len(value) > 6
                    else "***"
                )
                print(f"{key}: {masked_value}")
            else:
                print(f"{key}: {value}")
