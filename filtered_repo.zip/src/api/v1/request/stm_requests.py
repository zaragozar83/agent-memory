from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class Message(BaseModel):
    role: str  # 'user' or 'ai'
    content: str
    created_at: Optional[str] = None  # Timestamp
    additional_kwargs: Optional[Dict[str, Any]] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None  # For AI messages only


class AddMemoryRequest(BaseModel):
    application_id: str
    agent_id: str
    user_id: str
    session_id: str
    messages: List[Message]


class DeleteMemoryRequest(BaseModel):
    application_id: str
    agent_id: str
    user_id: str
    session_id: str


class SummarizeRequest(BaseModel):
    application_id: str
    agent_id: str
    user_id: str
    session_id: str
