"""
Request models for the long-term memory API.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, ConfigDict


class Message(BaseModel):
    """Message model for conversation history."""

    role: str = Field(..., description="Role of the message (user or assistant)")
    content: str = Field(..., description="Message content")


class MemoryCreateRequest(BaseModel):
    """Request model for creating memories."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    messages: List[Message] = Field(..., description="List of messages to store")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )


class SearchRequest(BaseModel):
    """Request model for searching memories."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    query: str = Field(..., description="Search query")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    filters: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional search filters"
    )


class UpdateMemoryRequest(BaseModel):
    """Request model for updating a memory."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    updated_memory: str = Field(..., description="Updated memory content")


class StructuredFieldConfig(BaseModel):
    """Schema definition supplied when provisioning structured memories."""

    name: str = Field(
        ...,
        description=
        "Logical field name. It is sanitised to a lowercase SQL-safe column name (e.g."
        " 'User Ask' → 'user_ask').",
        examples=["user_ask", "issue_summary", "subject"],
    )
    description: Optional[str] = Field(
        default=None,
        description=
        "Short instruction that tells LangMem what to extract for this field.",
        examples=[
            "One-line summary of what the user requested",
            "Issue category (network, infra, etc.)",
        ],
    )


class ConfigureRequest(BaseModel):
    """Request payload for provisioning per-client long-term memory."""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "client_id": "1234567",
                "api_key": "demo-api-key",
                "llm_model": "gpt-oss-20b",
                "embedder_model": "embeddinggemma-300m",
                "instructions": "Extract a concise user ask, the recommended product name, and its specs.",
                "fields": [
                    {
                        "name": "user_ask",
                        "description": "One-line summary of what the user requested"
                    },
                    {
                        "name": "suggested_product_name",
                        "description": "Product model the agent recommends"
                    },
                    {
                        "name": "product_specs",
                        "description": "Key specs or features mentioned"
                    }
                ],
            }
        }
    )

    client_id: str = Field(
        ...,
        description=
        "Unique identifier for the client/use-case. Determines the dedicated"
        " PostgreSQL table name (sanitised + suffixed with '_memories').",
    )
    api_key: str = Field(
        ...,
        description="API key used for both the LLM (LangMem extraction) and embedding APIs",
    )
    llm_model: str = Field(
        default="gpt-oss-20b",
        description=
        "LLM model routed through LangMem to extract structured memories."
        " Override as needed per environment.",
    )
    embedder_model: str = Field(
        default="bge-m3",
        description="Embedding model used to vectorise stored memories for semantic search",
    )
    instructions: Optional[str] = Field(
        default=None,
        description=
        "Optional system prompt that steers LangMem. Often references the logical"
        " fields (e.g. 'Extract user_ask, suggested_product_name, product_specs').",
        examples=[
            "Extract a concise user ask, the recommended product name, and its specs.",
            "Always populate reported_by, issue_summary, agent_solution, category, impact_level.",
        ],
    )
    fields: List[StructuredFieldConfig] = Field(
        default_factory=list,
        description=
        "Optional structured schema. Each entry adds a dedicated TEXT column and"
        " instructs LangMem which values to extract when /ltm/memories is called."
        " Leave empty for raw text memories only.",
    )


class GetMemoriesRequest(BaseModel):
    """Request model for getting memories."""

    client_id: str = Field(..., description="Client identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")


class DeleteMemoriesRequest(BaseModel):
    """Request model for deleting all memories."""

    client_id: str = Field(..., description="Client identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
