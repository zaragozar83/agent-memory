from typing import Dict, List

from pydantic import BaseModel


class StatusResponse(BaseModel):
    status: str


class SessionCreateResponse(BaseModel):
    session_id: str
    status: str
    created_at: str
