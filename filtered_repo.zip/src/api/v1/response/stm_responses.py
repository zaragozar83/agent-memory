from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class MessageContent(BaseModel):
    content: str
    additional_kwargs: Dict[str, Any] = Field(default_factory=dict)
    response_metadata: Dict[str, Any] = Field(default_factory=dict)
    type: str  # 'human' or 'ai'
    name: Optional[str] = None
    id: Optional[str] = None
    example: bool = False
    tool_calls: List[Dict[str, Any]] = Field(
        default_factory=list
    )  # For AI messages only


class MemoryResponse(BaseModel):
    memory: List[MessageContent]
