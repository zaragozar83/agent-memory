import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from fastapi.responses import JSONResponse

from src.api.v1.request.stm_requests import (
    AddMemoryRequest,
    DeleteMemoryRequest,
    SummarizeRequest,
)
from src.api.v1.response.common import RestResponse
from src.api.v1.response.session import StatusResponse
from src.api.v1.response.stm_responses import MemoryResponse, MessageContent
from src.application.exception import RuntimeException
from src.application.service.stm_memory_service import (
    add_messages,
    delete_memory,
    get_memory,
    manual_summarize,
)
from src.domain.redis import redis_client

router = APIRouter(
    tags=["Short-Term Memory"],
)


@router.post(
    "/stm/memory",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[StatusResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
        422: {"model": RestResponse},
    },
    response_class=JSONResponse,
)
def add_memory(req: AddMemoryRequest):
    """
    Add multiple messages to the agent's memory.
    """
    try:
        add_messages(
            req.application_id, req.agent_id, req.user_id, req.session_id, req.messages
        )
        return RestResponse(
            data=StatusResponse(status="added"),
            message=f"Added {len(req.messages)} messages successfully for user {req.user_id}, session {req.session_id}",
        )
    except Exception as e:
        logging.error(
            f"Add memory error for user {req.user_id}, session {req.session_id}: {e}"
        )
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to add memory for user {req.user_id}",
        )


@router.get(
    "/stm/memory",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[MemoryResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_404_NOT_FOUND: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
    },
)
def get_memory_api(
    application_id: str = Query(..., description="Application identifier"),
    agent_id: str = Query(..., description="Agent identifier"),
    user_id: str = Query(..., description="User identifier"),
    session_id: str = Query(..., description="Session identifier"),
):
    """
    Retrieve memory items for a specific session.
    """
    try:
        # Verify session exists
        session_key = f"session:{application_id}:{agent_id}:{user_id}:{session_id}"
        if not redis_client.exists(session_key):
            raise RuntimeException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {session_id} not found for user {user_id}",
                message=f"Session not found for user {user_id}",
            )

        langchain_messages = get_memory(application_id, agent_id, user_id, session_id)

        # Convert LangChain message objects to dictionaries for Pydantic
        memory_items = []
        for msg in langchain_messages:
            # Convert LangChain message to dict
            msg_dict = msg.dict()
            # Map _type to type for Pydantic model
            if hasattr(msg, "_type"):
                msg_dict["type"] = msg._type
            # Add to memory list
            memory_items.append(msg_dict)

        return RestResponse(
            data=MemoryResponse(memory=memory_items),
            message=f"Memory retrieved successfully for user {user_id}, session {session_id} - {len(memory_items)} items",
        )
    except RuntimeException:
        raise
    except Exception as e:
        logging.error(f"Get memory error for user {user_id}, session {session_id}: {e}")
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to retrieve memory for user {user_id}",
        )


@router.delete(
    "/stm/memory",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[StatusResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_404_NOT_FOUND: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
    },
)
def delete_memory_api(
    application_id: str = Query(..., description="Application identifier"),
    agent_id: str = Query(..., description="Agent identifier"),
    user_id: str = Query(..., description="User identifier"),
    session_id: str = Query(..., description="Session identifier"),
):
    """
    Delete all memory items for a specific session.
    """
    try:
        # Verify session exists
        session_key = f"session:{application_id}:{agent_id}:{user_id}:{session_id}"
        if not redis_client.exists(session_key):
            raise RuntimeException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {session_id} not found for user {user_id}",
                message=f"Session not found for user {user_id}",
            )

        delete_memory(application_id, agent_id, user_id, session_id)
        return RestResponse(
            data=StatusResponse(status="deleted"),
            message=f"Memory deleted successfully for user {user_id}, session {session_id}",
        )
    except RuntimeException:
        raise
    except Exception as e:
        logging.error(
            f"Delete memory error for user {user_id}, session {session_id}: {e}"
        )
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to delete memory for user {user_id}",
        )


@router.post(
    "/stm/memory/summarize",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[StatusResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_404_NOT_FOUND: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
    },
)
def summarize_api(req: SummarizeRequest):
    """
    Manually trigger a summarization of memory items.
    """
    try:
        # Verify session exists
        session_key = f"session:{req.application_id}:{req.agent_id}:{req.user_id}:{req.session_id}"
        if not redis_client.exists(session_key):
            raise RuntimeException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {req.session_id} not found for user {req.user_id}",
                message=f"Session not found for user {req.user_id}",
            )

        manual_summarize(req.application_id, req.agent_id, req.user_id, req.session_id)
        return RestResponse(
            data=StatusResponse(status="summarized"),
            message=f"Memory summarized successfully for user {req.user_id}, session {req.session_id}",
        )
    except RuntimeException:
        raise
    except Exception as e:
        logging.error(
            f"Summarize error for user {req.user_id}, session {req.session_id}: {e}"
        )
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to summarize memory for user {req.user_id}",
        )
