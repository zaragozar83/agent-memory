from fastapi import APIRouter, status

from src.api.v1.response.common import RestResponse
from src.api.v1.response.health import HealthResponse

router = APIRouter(
    prefix="/health",
    tags=["health"],
)


@router.get(
    "",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[HealthResponse],
)
def health():
    """
    Health check endpoint to verify the API is up and running
    """
    return RestResponse(
        data=HealthResponse(status="up"),
        message="API is up and running.",
    )
