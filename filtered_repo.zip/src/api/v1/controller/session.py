import logging
import uuid
from datetime import datetime, timezone
from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from fastapi.responses import JSONResponse

from src.api.v1.request.session import SessionCreateRequest, SessionEndRequest
from src.api.v1.response.common import RestResponse
from src.api.v1.response.session import SessionCreateResponse, StatusResponse
from src.application.exception import RuntimeException
from src.core.environment_variables import EnvironmentVariables
from src.domain.redis import redis_client

router = APIRouter(
    prefix="/session",
    tags=["sessions"],
)


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=RestResponse[SessionCreateResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
        422: {"model": RestResponse},
    },
    response_class=JSONResponse,
    summary="Create a new session",
    description="Create a new session for the given application ID, agent ID, and user ID.",
)
def create_session(request: SessionCreateRequest):
    """Create a new session."""
    try:
        session_id = uuid.uuid4().hex
        session_key = f"session:{request.application_id}:{request.agent_id}:{request.user_id}:{session_id}"

        session_data = {
            "session_id": session_id,
            "application_id": request.application_id,
            "agent_id": request.agent_id,
            "user_id": request.user_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": "active",
        }

        redis_client.hset(session_key, mapping=session_data)
        redis_client.expire(session_key, EnvironmentVariables.REDIS_TTL)

        return RestResponse(
            data=SessionCreateResponse(
                session_id=session_id,
                status="active",
                created_at=session_data["created_at"],
            ),
            message=f"Session {session_id} created successfully for user {request.user_id}",
        )
    except Exception as e:
        logging.error(f"Create session error for user {request.user_id}: {e}")
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to create session for user {request.user_id}",
        )


@router.get(
    "s",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse,
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
    },
    response_class=JSONResponse,
    summary="List sessions",
    description="Get all active sessions for an agent.",
)
def list_sessions(
    application_id: str = Query(..., description="Application identifier"),
    agent_id: str = Query(..., description="Agent identifier"),
    user_id: str = Query(..., description="User identifier"),
):
    """
    List all active sessions for a user's agent.
    """
    try:
        pattern = f"session:{application_id}:{agent_id}:{user_id}:*"
        keys = redis_client.keys(pattern)
        session_ids = [k.split(":")[-1] for k in keys]
        return RestResponse(
            data={"sessions": session_ids},
            message=f"Sessions retrieved successfully for user {user_id} - {len(session_ids)} active sessions",
        )
    except Exception as e:
        logging.error(f"List sessions error for user {user_id}: {e}")
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to retrieve sessions for user {user_id}",
        )


@router.delete(
    "/end",
    status_code=status.HTTP_200_OK,
    response_model=RestResponse[StatusResponse],
    responses={
        status.HTTP_400_BAD_REQUEST: {"model": RestResponse},
        status.HTTP_404_NOT_FOUND: {"model": RestResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": RestResponse},
        422: {"model": RestResponse},
    },
    response_class=JSONResponse,
    summary="End a session",
    description="End an active session and clean up its resources.",
)
def end_session(request: SessionEndRequest):
    """End a session."""
    try:
        session_key = f"session:{request.application_id}:{request.agent_id}:{request.user_id}:{request.session_id}"
        memory_key = f"memory:{request.application_id}:{request.agent_id}:{request.user_id}:{request.session_id}"

        # Check if session exists
        session_exists = redis_client.exists(session_key)
        if not session_exists:
            raise RuntimeException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {request.session_id} not found",
                message="Session not found",
            )

        # Delete the session (ending it completely)
        redis_client.delete(session_key)

        # Also clean up memory associated with this session
        redis_client.delete(memory_key)

        return RestResponse(
            data=StatusResponse(status="ended"),
            message=f"Session {request.session_id} ended successfully for user {request.user_id}",
        )
    except RuntimeException:
        raise
    except Exception as e:
        logging.error(
            f"End session error for user {request.user_id}, session {request.session_id}: {e}"
        )
        raise RuntimeException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
            message=f"Failed to end session for user {request.user_id}",
        )
