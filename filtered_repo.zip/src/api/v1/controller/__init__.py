from src.api.v1.controller.health import router as health_router
from src.api.v1.controller.ltm_controller import router as ltm_router
from src.api.v1.controller.session import router as session_router
from src.api.v1.controller.stm_controller import router as stm_router

routers = [session_router, stm_router, ltm_router, health_router]

__all__ = [
    "routers",
    "session_router",
    "stm_router",
    "ltm_router",
    "health_router",
]
