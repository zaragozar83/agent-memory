from typing import Optional

from fastapi import HTTPException, status


class RuntimeException(HTTPException):
    """
    Custom exception class for application-specific runtime errors.
    Extends FastAPI's HTTPException to provide consistent error handling.
    """

    def __init__(
        self,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail: str = "An internal server error occurred",
        message: str = "An error occurred",
        headers: Optional[dict] = None,
    ):
        super().__init__(status_code=status_code, detail=detail, headers=headers)
        self.message = message
