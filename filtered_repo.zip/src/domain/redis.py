import ssl
from urllib.parse import urlparse

import redis

from src.core.environment_variables import EnvironmentVariables

# Parse the Redis URL from environment variables using urllib for full URL support
redis_url = EnvironmentVariables.REDIS_URL
parsed_redis_url = urlparse(redis_url)
REDIS_HOST = parsed_redis_url.hostname or "localhost"
REDIS_PORT = parsed_redis_url.port or 6379
REDIS_DB = int((parsed_redis_url.path or "/0").lstrip("/"))

connection_kwargs = {"decode_responses": True}

if parsed_redis_url.scheme == "rediss":
    cert_mode = EnvironmentVariables.REDIS_SSL_CERT_REQS.lower()
    cert_map = {
        "none": ssl.CERT_NONE,
        "optional": ssl.CERT_OPTIONAL,
        "required": ssl.CERT_REQUIRED,
    }
    connection_kwargs["ssl_cert_reqs"] = cert_map.get(cert_mode, ssl.CERT_REQUIRED)
    connection_kwargs["ssl_check_hostname"] = (
        EnvironmentVariables.REDIS_SSL_CHECK_HOSTNAME
    )

redis_client = redis.from_url(redis_url, **connection_kwargs)
