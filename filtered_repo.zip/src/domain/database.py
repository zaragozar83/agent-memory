"""
PostgreSQL database utilities for client-scoped long-term memory storage.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator

try:  # pragma: no cover - optional dependency during tests
    import psycopg2
    from psycopg2 import sql

    _POSTGRES_AVAILABLE = True
except ImportError:  # pragma: no cover - handled at runtime
    psycopg2 = None  # type: ignore
    sql = None  # type: ignore
    _POSTGRES_AVAILABLE = False

try:  # pragma: no cover - optional dependency during tests
    from pgvector.psycopg2 import register_vector
except ImportError:  # pragma: no cover - handled at runtime
    register_vector = None  # type: ignore

from src.core.ltm_config import SystemConfig


class PostgreSQLManager:
    """PostgreSQL connection manager with schema and extension helpers."""

    def __init__(self):
        self.config = SystemConfig()

    def get_connection_params(self) -> dict:
        """Return the parameters required to establish a new connection."""
        return {
            "host": self.config.POSTGRES_HOST,
            "port": self.config.POSTGRES_PORT,
            "dbname": self.config.POSTGRES_DB,
            "user": self.config.POSTGRES_USER,
            "password": self.config.POSTGRES_PASSWORD,
        }

    @contextmanager
    def get_connection(self) -> Iterator["psycopg2.extensions.connection"]:
        """
        Context manager that yields a psycopg2 connection with pgvector registered.
        """
        if not _POSTGRES_AVAILABLE:
            raise RuntimeError(
                "psycopg2 is not installed. Install database extras to enable PostgreSQL access."
            )

        params = self.get_connection_params()
        conn = None
        try:
            conn = psycopg2.connect(**params)

            if register_vector is not None:
                register_vector(conn)
                conn.commit()

            yield conn
        except Exception as exc:  # pragma: no cover - logging path
            logging.error("PostgreSQL connection error: %s", exc)
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                conn.close()

    def ensure_schema(self, schema: str) -> None:
        """Create the schema if it does not already exist."""
        with self.get_connection() as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT schema_name
                    FROM information_schema.schemata
                    WHERE schema_name = %s
                    """,
                    (schema,),
                )
                exists = cur.fetchone() is not None
                if not exists:
                    cur.execute(
                        sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(schema))
                    )

    def table_exists(self, schema: str, table: str) -> bool:
        """Return True if the fully qualified table exists."""
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT EXISTS (
                        SELECT 1
                        FROM information_schema.tables
                        WHERE table_schema = %s AND table_name = %s
                    )
                    """,
                    (schema, table),
                )
                exists = cur.fetchone()
                return bool(exists[0]) if exists else False

    def drop_table(self, schema: str, table: str) -> None:
        """Drop the specified table if it exists."""
        with self.get_connection() as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(
                    sql.SQL("DROP TABLE IF EXISTS {}.{} CASCADE").format(
                        sql.Identifier(schema), sql.Identifier(table)
                    )
                )


# Global PostgreSQL manager instance
_postgresql_manager: PostgreSQLManager | None = None


def get_postgresql_manager() -> PostgreSQLManager:
    """Return the shared PostgreSQL manager singleton."""
    global _postgresql_manager
    if _postgresql_manager is None:
        _postgresql_manager = PostgreSQLManager()
    return _postgresql_manager
