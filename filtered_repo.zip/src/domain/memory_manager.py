"""
Langmem-backed memory manager that provisions client-specific PostgreSQL tables.
"""

from __future__ import annotations

import logging
import json
import uuid
from dataclasses import dataclass, field as dataclass_field
from typing import Any, Dict, List, Optional, Sequence

import typing as _typing

try:  # pragma: no cover - required for Python < 3.11
    _typing.NotRequired  # type: ignore[attr-defined]
except AttributeError:  # pragma: no cover
    from typing_extensions import NotRequired

    _typing.NotRequired = NotRequired  # type: ignore

import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from langmem.knowledge.extraction import Memory
from trustcall import create_extractor
from pydantic import Field as PydanticField, create_model

from src.core.ltm_config import (
    ClientConfig,
    ClientRuntimeConfig,
    build_client_runtime,
    optional_url,
)
from src.domain.ltm_repository import (
    LongTermMemoryRepository,
    MemoryInsert,
    MemoryRecord,
)

logger = logging.getLogger(__name__)


@dataclass
class MemoryExtractionResult:
    """Internal representation of a memory extracted via langmem."""

    langmem_id: str
    content: str
    structured: Dict[str, Any] = dataclass_field(default_factory=dict)
    column_values: Dict[str, Any] = dataclass_field(default_factory=dict)
    is_fallback: bool = False


def _deserialize_langmem_result(item: Any) -> Optional[MemoryExtractionResult]:
    """
    Normalize the output of langmem.create_memory_manager() into MemoryExtractionResult.
    """
    if item is None:
        return None

    if isinstance(item, MemoryExtractionResult):
        return item

    if isinstance(item, tuple) and len(item) == 2:
        langmem_id, payload = item
        if hasattr(payload, "content"):
            return MemoryExtractionResult(langmem_id=str(langmem_id), content=payload.content)
        return MemoryExtractionResult(langmem_id=str(langmem_id), content=str(payload))

    if hasattr(item, "content") and hasattr(item, "id"):
        return MemoryExtractionResult(langmem_id=str(item.id), content=item.content)

    if isinstance(item, dict):
        langmem_id = str(item.get("id", uuid.uuid4()))
        content = item.get("content") or item.get("memory")
        if content:
            return MemoryExtractionResult(langmem_id=langmem_id, content=str(content))

    if isinstance(item, str):
        return MemoryExtractionResult(langmem_id=str(uuid.uuid4()), content=item)

    logger.debug("Unsupported langmem extraction format: %s (%s)", item, type(item))
    return None


class LangMemClientSession:
    """Encapsulates langmem processing and storage for a single client."""

    def __init__(
        self,
        client_config: ClientConfig,
        runtime: ClientRuntimeConfig,
        repository: LongTermMemoryRepository,
    ):
        self.client_config = client_config
        self.runtime = runtime
        self.repository = repository
        self._memory_extractor = None
        self._embedder = None
        self._http_client: Optional[httpx.Client] = None
        self._structured_model: Optional[Any] = None

    # ------------------------------------------------------------------ helpers
    def ensure_store(self) -> bool:
        """Ensure the client's table exists, returning True if newly created."""
        return self.repository.ensure_client_store(self.runtime)

    def _get_memory_extractor(self):
        if self._memory_extractor is None:
            chat_model = self._build_chat_model()
            tools: List[Any] = []
            tool_choice: Optional[str] = None

            if self.runtime.fields:
                field_definitions: Dict[str, tuple] = {}
                for field_cfg in self.runtime.fields:
                    field_definitions[field_cfg.column_name] = (
                        Optional[str],
                        PydanticField(
                            default=None,
                            description=field_cfg.description or field_cfg.name,
                        ),
                    )
                sanitized_label = self.runtime.sanitized_client_id.strip("_")
                if not sanitized_label:
                    sanitized_label = "client"
                if not sanitized_label[0].isalpha():
                    sanitized_label = f"client_{sanitized_label}"
                camel_label = "".join(part.capitalize() for part in sanitized_label.split("_"))
                schema_name = f"{camel_label}StructuredMemory"
                StructuredModel = create_model(schema_name, **field_definitions)
                StructuredModel.__doc__ = (
                    self.client_config.instructions
                    or "Extract structured memory fields defined by the client."
                )
                tools.append(StructuredModel)
                self._structured_model = StructuredModel
                tool_choice = StructuredModel.__name__
            else:
                self._structured_model = None
                tools.append(Memory)

            self._memory_extractor = create_extractor(
                chat_model,
                tools=tools,
                tool_choice=tool_choice,
                enable_inserts=True,
                enable_updates=False,
                enable_deletes=False,
                existing_schema_policy=False,
            )
        return self._memory_extractor

    def _get_embedder(self):
        if self._embedder is None:
            self._embedder = self._build_embedder()
        return self._embedder

    def _get_http_client(self) -> Optional[httpx.Client]:
        if not self.runtime.system.TLS_CA_BUNDLE:
            return None

        if self._http_client is None:
            self._http_client = httpx.Client(
                verify=self.runtime.system.TLS_CA_BUNDLE,
            )
        return self._http_client

    def _build_chat_model(self) -> ChatOpenAI:
        kwargs: Dict[str, Any] = {
            "model": self.client_config.llm_model,
            "api_key": self.client_config.api_key,
            "temperature": self.runtime.system.LLM_TEMPERATURE,
            "max_tokens": self.runtime.system.LLM_MAX_TOKENS,
        }
        base_url = optional_url(self.runtime.system.LLM_BASE_URL)
        if base_url:
            kwargs["base_url"] = base_url
        http_client = self._get_http_client()
        if http_client is not None:
            kwargs["http_client"] = http_client
        return ChatOpenAI(**kwargs)

    def _build_embedder(self) -> OpenAIEmbeddings:
        kwargs: Dict[str, Any] = {
            "model": self.client_config.embedder_model,
            "api_key": self.client_config.api_key,
        }
        base_url = optional_url(self.runtime.system.EMBEDDER_BASE_URL)
        if base_url:
            kwargs["base_url"] = base_url
        http_client = self._get_http_client()
        if http_client is not None:
            kwargs["http_client"] = http_client
        return OpenAIEmbeddings(**kwargs)
    def _build_system_prompt(self) -> str:
        if self.runtime.fields:
            base_instruction = self.client_config.instructions or (
                "Extract the following fields from the dialogue and provide concise, factual values."
            )
            field_lines = "\n".join(
                f"- {field.name}: {field.description or 'Provide a concise value.'}"
                for field in self.runtime.fields
            )
            return (
                f"{base_instruction}\n\n"
                "When you respond, call the structured memory tool exactly once and supply every field.\n"
                "If a field is not mentioned, return null.\n"
                "Fields:\n"
                f"{field_lines}"
            )
        return self.client_config.instructions or (
            "You distill durable knowledge from the dialogue. When you find a memory worth persisting, "
            "call the Memory tool with a concise statement."
        )

    def _compose_structured_content(self, structured: Dict[str, Any]) -> str:
        parts = [f"{name}: {value}" for name, value in structured.items() if value]
        if parts:
            return " | ".join(parts)
        return ""



    # ------------------------------------------------------------------ operations
    def add_memories(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[MemoryRecord]:
        """Process conversation messages and persist extracted memories."""
        extractor = self._get_memory_extractor()
        payload_messages: List[Dict[str, Any]] = []
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role")
                content = msg.get("content")
                if role and content:
                    payload_messages.append({"role": role, "content": content})
            elif isinstance(msg, (list, tuple)) and len(msg) >= 2:
                role, content = msg[0], msg[1]
                if isinstance(role, str) and isinstance(content, str):
                    payload_messages.append({"role": role, "content": content})
        if not payload_messages:
            logger.warning(
                "No valid conversation messages provided for client_id=%s",
                self.client_config.client_id,
            )
            return []

        def _invoke_extraction(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
            prepared = [
                {"role": "system", "content": self._build_system_prompt()},
                *messages,
            ]
            try:
                return extractor.invoke({"messages": prepared, "max_steps": 3})
            except Exception as exc:  # pragma: no cover - remote failure path
                logger.error(
                    "Langmem extraction failed for client_id=%s: %s",
                    self.client_config.client_id,
                    exc,
                )
                response = getattr(exc, "response", None)
                if response is not None:
                    status = getattr(response, "status_code", None) or getattr(
                        response, "status", None
                    )
                    try:
                        body = response.json()
                    except Exception:
                        body = getattr(response, "text", None) or str(response)
                    logger.error(
                        "Langmem extraction HTTP response status=%s body=%s",
                        status,
                        body,
                    )
                return {"responses": [], "response_metadata": [], "messages": []}

        def _process_extraction(
            extraction_payload: Dict[str, Any],
            source_messages: List[Dict[str, Any]],
        ) -> List[MemoryExtractionResult]:
            results: List[MemoryExtractionResult] = []
            responses = extraction_payload.get("responses", [])
            metadata_entries = extraction_payload.get("response_metadata", [])
            messages_with_tools = extraction_payload.get("messages", [])

            structured_model = self._structured_model
            structured_tool_name = getattr(structured_model, "__name__", None)

            def _append_result(
                content: Optional[str],
                meta: Optional[Dict[str, Any]] = None,
                *,
                structured: Optional[Dict[str, Any]] = None,
                column_values: Optional[Dict[str, Any]] = None,
                fallback: bool = False,
            ) -> None:
                structured = structured or {}
                column_values = column_values or {}
                combined_meta = dict(meta or {})
                if structured and "structured_fields" not in combined_meta:
                    combined_meta["structured_fields"] = structured
                langmem_id = (
                    combined_meta.get("json_doc_id")
                    or combined_meta.get("id")
                    or combined_meta.get("tool_call_id")
                    or str(uuid.uuid4())
                )
                rendered = content or self._compose_structured_content(structured)
                if not rendered:
                    rendered = " \u2022 ".join(
                        msg.get("content", "") for msg in source_messages if msg.get("content")
                    )
                results.append(
                    MemoryExtractionResult(
                        langmem_id=str(langmem_id),
                        content=rendered,
                        structured=structured,
                        column_values=column_values or {},
                        is_fallback=fallback,
                    )
                )

            def _structured_from_payload(
                payload: Dict[str, Any],
                meta: Optional[Dict[str, Any]] = None,
            ) -> bool:
                if not self.runtime.fields:
                    return False
                column_values: Dict[str, Any] = {}
                structured: Dict[str, Any] = {}
                for field_cfg in self.runtime.fields:
                    value = payload.get(field_cfg.column_name)
                    structured[field_cfg.name] = value
                    column_values[field_cfg.column_name] = value
                if any(value not in (None, "", []) for value in column_values.values()):
                    _append_result(
                        None,
                        meta,
                        structured=structured,
                        column_values=column_values,
                    )
                    return True
                return False

            for idx, response in enumerate(responses):
                meta = metadata_entries[idx] if idx < len(metadata_entries) else {}
                if structured_model and isinstance(response, structured_model):
                    payload = response.model_dump()  # type: ignore[attr-defined]
                    _structured_from_payload(payload, meta)
                    continue
                if isinstance(response, Memory):
                    _append_result(response.content, meta)
                    continue
                if hasattr(response, "content"):
                    _append_result(getattr(response, "content", None), meta)
                    continue
                if isinstance(response, dict):
                    if structured_model and _structured_from_payload(response, meta):
                        continue
                    _append_result(response.get("content"), meta)

            if not results and messages_with_tools:
                for message in messages_with_tools:
                    tool_calls = getattr(message, "tool_calls", None)
                    if not tool_calls:
                        content_str = getattr(message, "content", None)
                        if isinstance(content_str, str):
                            try:
                                parsed_payload = json.loads(content_str)
                            except json.JSONDecodeError:
                                parsed_payload = None
                            if isinstance(parsed_payload, dict):
                                if not _structured_from_payload(parsed_payload):
                                    _append_result(parsed_payload.get("content"), {})
                        continue

                    for call in tool_calls:
                        name = None
                        raw_args = None
                        if isinstance(call, dict):
                            name = call.get("name")
                            raw_args = call.get("args")
                            function_block = call.get("function")
                            if isinstance(function_block, dict):
                                name = function_block.get("name", name)
                                raw_args = function_block.get("arguments", raw_args)
                        else:
                            name = getattr(call, "name", None)
                            raw_args = getattr(call, "args", None)

                        parsed_args: Optional[Dict[str, Any]] = None
                        if isinstance(raw_args, dict):
                            parsed_args = raw_args
                        elif isinstance(raw_args, str):
                            try:
                                parsed_args = json.loads(raw_args)
                            except json.JSONDecodeError:
                                parsed_args = None

                        if not parsed_args:
                            continue

                        call_meta: Dict[str, Any] = {}
                        call_id = (
                            call.get("id") if isinstance(call, dict) else getattr(call, "id", None)
                        )
                        if call_id:
                            call_meta["tool_call_id"] = call_id

                        handled = False
                        if structured_model:
                            if name == structured_tool_name:
                                handled = _structured_from_payload(parsed_args, call_meta)
                            else:
                                handled = _structured_from_payload(parsed_args, call_meta)
                        if handled:
                            continue

                        _append_result(parsed_args.get("content"), meta=call_meta)

            if not results and responses:
                for item in responses:
                    result = _deserialize_langmem_result(item)
                    if result:
                        results.append(result)

            return results

        extraction = _invoke_extraction(payload_messages)
        extracted = _process_extraction(extraction, payload_messages)

        if (
            not extracted
            and self.runtime.fields
            and any(msg.get("role") == "system" for msg in payload_messages)
        ):
            logger.info(
                "LangMem structured extraction retry without caller system prompts for client_id=%s",
                self.client_config.client_id,
            )
            sanitized_messages = [
                msg
                if msg.get("role") != "system"
                else {"role": "user", "content": msg.get("content")}
                for msg in payload_messages
            ]
            secondary = _invoke_extraction(sanitized_messages)
            retry_results = _process_extraction(secondary, sanitized_messages)
            if retry_results:
                extracted = retry_results

        if not extracted:
            logger.warning(
                "LangMem extractor returned no structured outputs for client_id=%s; falling back to raw messages.",
                self.client_config.client_id,
            )
            combined_content = " \u2022 ".join(
                msg.get("content", "") for msg in payload_messages if msg.get("content")
            )
            if not combined_content:
                combined_content = "Raw conversation unavailable"
            extracted = [
                MemoryExtractionResult(
                    langmem_id=str(uuid.uuid4()),
                    content=combined_content,
                    structured={},
                    column_values={},
                    is_fallback=True,
                )
            ]

        normalized = extracted

        embedder = self._get_embedder()
        contents = [item.content for item in normalized]
        embedding_error_message: Optional[str] = None
        try:
            embeddings = embedder.embed_documents(contents)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding generation failed for client_id=%s: %s",
                self.client_config.client_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding HTTP response status=%s body=%s",
                    status,
                    body,
                )
            embedding_error_message = str(exc)
            zero_vector = [0.0] * self.runtime.embedding_dims
            embeddings = [zero_vector for _ in contents]

        inserts: List[MemoryInsert] = []
        for item, vector in zip(normalized, embeddings):
            record_metadata = dict(metadata or {})
            record_metadata.setdefault("langmem_id", item.langmem_id)
            if item.is_fallback:
                record_metadata.setdefault("extraction_method", "fallback")
            else:
                record_metadata.setdefault("extraction_method", "langmem")
            if embedding_error_message:
                record_metadata.setdefault("embedding_status", embedding_error_message)
            if item.structured and "structured_fields" not in record_metadata:
                record_metadata["structured_fields"] = item.structured
            if agent_id:
                record_metadata.setdefault("agent_id", agent_id)
            if user_id:
                record_metadata.setdefault("user_id", user_id)
            if run_id:
                record_metadata.setdefault("run_id", run_id)

            record = MemoryRecord(
                id=str(uuid.uuid4()),
                client_id=self.client_config.client_id,
                content=item.content,
                metadata=record_metadata,
                structured=item.structured,
                agent_id=agent_id,
                user_id=user_id,
                run_id=run_id,
            )
            inserts.append(
                MemoryInsert(
                    record=record,
                    embedding=vector,
                    field_values=item.column_values,
                )
            )

        return self.repository.insert_memories(self.runtime, inserts)

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 10,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemoryRecord]:
        """Semantic search for memories using vector similarity."""
        embedder = self._get_embedder()
        try:
            query_vector = embedder.embed_query(query)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding query failed for client_id=%s: %s",
                self.client_config.client_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding query HTTP response status=%s body=%s",
                    status,
                    body,
                )
            query_vector = [0.0] * self.runtime.embedding_dims
        return self.repository.search_memories(
            self.runtime,
            query_embedding=query_vector,
            limit=limit,
            user_id=user_id,
            agent_id=agent_id,
            run_id=run_id,
            filters=filters,
        )

    def list_memories(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[MemoryRecord]:
        """Return all memories filtered by identifiers."""
        return self.repository.list_memories(
            self.runtime, user_id=user_id, agent_id=agent_id, run_id=run_id
        )

    def get_memory(self, memory_id: str) -> Optional[MemoryRecord]:
        return self.repository.fetch_memory(self.runtime, memory_id)

    def update_memory(self, memory_id: str, content: str) -> bool:
        embedder = self._get_embedder()
        try:
            vector = embedder.embed_query(content)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding update failed for client_id=%s memory_id=%s: %s",
                self.client_config.client_id,
                memory_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding update HTTP response status=%s body=%s",
                    status,
                    body,
                )
            vector = [0.0] * self.runtime.embedding_dims
        return self.repository.update_memory(
            self.runtime, memory_id, content=content, embedding=vector
        )

    def delete_memory(self, memory_id: str) -> bool:
        return self.repository.delete_memory(self.runtime, memory_id)

    def reset(self) -> None:
        self.repository.reset_client_store(self.runtime)


class MemoryManager:
    """Caches langmem sessions keyed by client_id."""

    def __init__(self, repository: Optional[LongTermMemoryRepository] = None):
        self._sessions: Dict[str, LangMemClientSession] = {}
        self._repository = repository or LongTermMemoryRepository()

    def get_memory_instance(self, client_config: ClientConfig) -> LangMemClientSession:
        """
        Get or create a memory session for the given client configuration.
        """
        client_id = client_config.client_id
        if client_id in self._sessions:
            return self._sessions[client_id]

        runtime = build_client_runtime(client_config)
        session = LangMemClientSession(client_config, runtime, self._repository)
        session.ensure_store()

        self._sessions[client_id] = session
        logger.info("Provisioned langmem session for client_id=%s", client_id)
        return session

    def check_client_exists(self, client_id: str) -> bool:
        """Check if a client store already exists."""
        temp_config = ClientConfig(client_id=client_id, api_key="")
        runtime = build_client_runtime(temp_config)
        return self._repository.client_store_exists(runtime)

    def remove_memory_instance(self, client_id: str) -> None:
        """Remove cached session for the given client."""
        if client_id in self._sessions:
            del self._sessions[client_id]


# Global memory manager instance
_memory_manager: Optional[MemoryManager] = None


def get_memory_manager() -> MemoryManager:
    """Return the global memory manager singleton."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
