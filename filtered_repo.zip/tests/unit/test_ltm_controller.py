import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from src.api.v1.controller import ltm_controller as ltm_ctrl


class FakeLTMService:
    def __init__(self):
        self.configure_calls = []
        self.add_calls = []
        self.list_calls = []
        self.search_calls = []
        self.update_calls = []
        self.delete_calls = []
        self.reset_calls = []

    def configure(self, client_config):
        self.configure_calls.append(client_config)
        return {
            "message": "Configuration set successfully",
            "client_id": client_config.client_id,
            "table_created": True,
        }

    def add_memory(self, **kwargs):
        self.add_calls.append(kwargs)
        return {"results": [{"id": "mem-1", "content": "created", "metadata": {}}]}

    def search_memories(self, **kwargs):
        self.search_calls.append(kwargs)
        return {
            "results": [
                {"id": "res-1", "content": "found", "metadata": {}, "score": 0.9}
            ]
        }

    def get_all_memories(self, **kwargs):
        self.list_calls.append(kwargs)
        return {"results": [{"id": "mem-1", "content": "stored", "metadata": {}}]}

    def get_memory(self, client_id, memory_id):
        return {"result": {"id": memory_id, "content": "stored", "metadata": {}}}

    def update_memory(self, **kwargs):
        self.update_calls.append(kwargs)
        return {"result": "Memory updated successfully"}

    def delete_memory(self, client_id, memory_id):
        self.delete_calls.append((client_id, memory_id))
        return {"result": "Memory deleted successfully"}

    def reset_memory(self, client_id):
        self.reset_calls.append(client_id)
        return {"result": "All memories reset"}


@pytest.fixture
def ltm_client(monkeypatch):
    service = FakeLTMService()
    monkeypatch.setattr(ltm_ctrl, "get_ltm_service", lambda: service)

    app = FastAPI()
    app.include_router(ltm_ctrl.router, prefix="/api/v1")
    return TestClient(app), service


def test_configure_memory_returns_payload(ltm_client):
    client, service = ltm_client
    body = {
        "client_id": "new-client",
        "api_key": "key",
        "llm_model": "model",
        "embedder_model": "embed",
    }

    response = client.post("/api/v1/ltm/configure", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload["data"]["client_id"] == "new-client"
    assert payload["data"]["table_created"] is True
    assert payload.get("message") == "Configuration set successfully"
    assert service.configure_calls[0].client_id == "new-client"


def test_create_memories_requires_identifier(ltm_client):
    client, _ = ltm_client
    body = {
        "messages": [{"role": "user", "content": "hi"}],
    }

    response = client.post(
        "/api/v1/ltm/memories",
        json=body,
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 400
    detail = response.json().get("detail")
    assert isinstance(detail, str)
    assert "identifier" in detail.lower()


def test_create_memories_happy_path(ltm_client):
    client, service = ltm_client
    body = {
        "messages": [{"role": "user", "content": "hello"}],
        "user_id": "u-1",
        "metadata": {"topic": "greeting"},
    }

    response = client.post(
        "/api/v1/ltm/memories",
        json=body,
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    results = payload["data"]["results"]
    assert results[0]["id"] == "mem-1"
    assert service.add_calls[0]["user_id"] == "u-1"
    assert service.add_calls[0]["client_id"] == "client-1"


def test_get_memories_returns_data(ltm_client):
    client, service = ltm_client

    response = client.get(
        "/api/v1/ltm/memories",
        params={"user_id": "u-1", "run_id": "run"},
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    results = payload["data"]["results"]
    assert results[0]["id"] == "mem-1"
    assert "content" in results[0]
    assert service.list_calls[0]["client_id"] == "client-1"


def test_get_all_memories_for_client(ltm_client):
    client, service = ltm_client

    response = client.get(
        "/api/v1/ltm/memories",
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    results = payload["data"]["results"]
    assert results[0]["id"] == "mem-1"
    assert service.list_calls[-1]["client_id"] == "client-1"


def test_get_memory_returns_result(ltm_client):
    client, _ = ltm_client
    response = client.get(
        "/api/v1/ltm/memories/mem-1",
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    result = payload["data"]["result"]
    assert result["id"] == "mem-1"


def test_search_memories_invokes_service(ltm_client):
    client, service = ltm_client
    body = {"query": "hello"}

    response = client.post(
        "/api/v1/ltm/search",
        json=body,
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    results = payload["data"]["results"]
    assert results[0]["id"] == "res-1"
    assert service.search_calls[0]["query"] == "hello"
    assert service.search_calls[0]["client_id"] == "client-1"


def test_update_memory_success(ltm_client):
    client, service = ltm_client
    body = {
        "updated_memory": "new",
        "client_id": "client-1",
    }

    response = client.put("/api/v1/ltm/memories/mem-1", json=body)
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("message") == "Memory updated successfully"
    assert service.update_calls[0]["memory_id"] == "mem-1"
    assert service.update_calls[0]["client_id"] == "client-1"


def test_delete_memory_success(ltm_client):
    client, service = ltm_client
    response = client.delete(
        "/api/v1/ltm/memories/mem-1",
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("message") == "Memory deleted successfully"
    assert service.delete_calls[0] == ("client-1", "mem-1")


def test_reset_memories_returns_message(ltm_client):
    client, service = ltm_client
    response = client.post(
        "/api/v1/ltm/reset",
        headers={"X-Client-ID": "client-1"},
    )
    assert response.status_code == 200, response.text

    payload = response.json()
    assert payload.get("message") == "All memories reset"
    assert service.reset_calls[0] == "client-1"
