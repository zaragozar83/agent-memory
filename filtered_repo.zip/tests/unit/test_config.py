import pytest

from src.core.ltm_config import (
    ClientConfig,
    FieldDefinition,
    build_client_runtime,
    get_embedding_dimensions,
    get_system_config,
)


@pytest.mark.parametrize(
    "embedder,expected_dims",
    [
        ("text-embedding-3-small", 1536),
        ("bge-large-en-v1-5", 1024),
        ("bge-base-en-v1-5", 768),
        ("bge-m3", 1024),
        ("gte-large", 1024),
        ("bge-small-en-v1-5", 384),
        ("gemini_embedding_001", 768),
        ("embeddinggemma-300m", 768),
        ("unknown-model", 1024),
    ],
)
def test_get_embedding_dimensions(embedder, expected_dims):
    assert get_embedding_dimensions(embedder) == expected_dims


def test_build_client_runtime_sanitizes_identifiers():
    config = ClientConfig(
        client_id="My Client-123",
        api_key="fake",
        embedder_model="text-embedding-3-small",
        fields=[
            FieldDefinition(name="User Ask", description="summary of the user request"),
            FieldDefinition(name="suggested_product_name", description="product name"),
        ],
    )

    runtime = build_client_runtime(config)

    assert runtime.client_id == "My Client-123"
    assert runtime.sanitized_client_id == "my_client_123"
    assert runtime.table_name == "my_client_123_memories"
    assert runtime.embedding_dims == 1536
    assert runtime.system.MEMORY_SCHEMA == "agent_memory_dev"
    assert [field.name for field in runtime.fields] == ["User Ask", "suggested_product_name"]
    assert [field.column_name for field in runtime.fields] == ["user_ask", "suggested_product_name"]


def test_build_client_runtime_allows_numeric_client_id():
    config = ClientConfig(
        client_id="123",
        api_key="fake",
    )

    runtime = build_client_runtime(config)

    assert runtime.sanitized_client_id == "123"
    assert runtime.table_name == "123_memories"


def test_get_system_config_returns_values():
    system = get_system_config()
    # Ensures essential values are present
    assert isinstance(system.POSTGRES_HOST, str)
    assert isinstance(system.POSTGRES_PORT, int)
