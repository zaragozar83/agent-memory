import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from src.api.v1.exception.handlers import set_exception_handlers
from src.application.exception import RuntimeException


@pytest.fixture
def exception_app():
    app = FastAPI()
    set_exception_handlers(app)

    @app.get("/runtime")
    def runtime_route():
        raise RuntimeException(
            status_code=418, message="Runtime error", detail="detail"
        )

    @app.get("/general")
    def general_route():
        raise ValueError("boom")

    @app.get("/unauthorized")
    def unauthorized_route():
        raise HTTPException(status_code=401)

    @app.get("/forbidden")
    def forbidden_route():
        raise HTTPException(status_code=403)

    @app.get("/bad")
    def bad_route():
        raise HTTPException(status_code=400, detail="Nope")

    @app.post("/method")
    def method_route():
        return {"ok": True}

    return app


@pytest.fixture
def exception_client(exception_app):
    return TestClient(exception_app, raise_server_exceptions=False)


def test_runtime_exception_handler(exception_client):
    response = exception_client.get("/runtime")
    assert response.status_code == 418
    body = response.json()
    assert body["success"] is False
    assert body["message"] == "Runtime error"


def test_general_exception_handler(exception_client):
    response = exception_client.get("/general")
    assert response.status_code == 500
    assert "Internal Server Error" in response.json()["message"]


def test_custom_401_handler(exception_client):
    response = exception_client.get("/unauthorized")
    assert response.status_code == 401
    assert response.json()["message"] == "Not Authorized"


def test_custom_403_handler(exception_client):
    response = exception_client.get("/forbidden")
    assert response.status_code == 403
    assert response.json()["message"] == "Not authenticated"


def test_custom_400_handler(exception_client):
    response = exception_client.get("/bad")
    assert response.status_code == 400
    assert response.json()["message"] == "Nope"


def test_custom_404_handler(exception_client):
    response = exception_client.get("/missing")
    assert response.status_code == 404
    assert response.json()["message"] == "Not Found"


def test_custom_405_handler(exception_client):
    response = exception_client.post("/method")
    assert response.status_code == 200
    bad_response = exception_client.get("/method")
    assert bad_response.status_code == 405
    assert bad_response.json()["message"] == "Method Not Allowed"
