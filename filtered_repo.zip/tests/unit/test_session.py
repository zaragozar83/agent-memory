import uuid

import pytest


@pytest.mark.usefixtures("fake_redis")
def test_session_lifecycle(client):
    application_id = "app"
    agent_id = "agent"
    user_id = "user"

    create_resp = client.post(
        "/api/v1/session",
        json={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
        },
    )
    assert create_resp.status_code == 201
    create_body = create_resp.json()
    assert create_body["success"] is True
    session_id = create_body["data"]["session_id"]
    assert uuid.UUID(session_id)

    list_resp = client.get(
        "/api/v1/sessions",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
        },
    )
    assert list_resp.status_code == 200
    list_body = list_resp.json()
    assert session_id in list_body["data"]["sessions"]

    end_resp = client.request(
        "DELETE",
        "/api/v1/session/end",
        json={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "session_id": session_id,
        },
    )
    assert end_resp.status_code == 200
    end_body = end_resp.json()
    assert end_body["success"] is True
    assert end_body["data"]["status"] == "ended"

    post_end_list = client.get(
        "/api/v1/sessions",
        params={
            "application_id": application_id,
            "agent_id": agent_id,
            "user_id": user_id,
        },
    )
    assert post_end_list.status_code == 200
    assert post_end_list.json()["data"]["sessions"] == []


def test_end_session_not_found(client, fake_redis):
    payload = {
        "application_id": "app",
        "agent_id": "agent",
        "user_id": "user",
        "session_id": "missing",
    }

    end_resp = client.request("DELETE", "/api/v1/session/end", json=payload)
    assert end_resp.status_code == 404
    body = end_resp.json()
    assert body["success"] is False
    assert "not found" in body["message"].lower()


@pytest.mark.usefixtures("fake_redis")
def test_create_session_handles_redis_errors(client, monkeypatch):
    def boom(*_args, **_kwargs):
        raise RuntimeError("redis down")

    from src.api.v1.controller import session as session_ctrl

    monkeypatch.setattr(session_ctrl.redis_client, "hset", boom)

    resp = client.post(
        "/api/v1/session",
        json={"application_id": "app", "agent_id": "agent", "user_id": "user"},
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to create session" in body["message"].lower()


@pytest.mark.usefixtures("fake_redis")
def test_list_sessions_handles_redis_errors(client, monkeypatch):
    def boom(*_args, **_kwargs):
        raise RuntimeError("redis down")

    from src.api.v1.controller import session as session_ctrl

    monkeypatch.setattr(session_ctrl.redis_client, "keys", boom)

    resp = client.get(
        "/api/v1/sessions",
        params={"application_id": "app", "agent_id": "agent", "user_id": "user"},
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to retrieve sessions" in body["message"].lower()


def test_end_session_reports_unknown_errors(client, fake_redis, monkeypatch):
    key = "session:app:agent:user:session"
    fake_redis.set(key, "active")

    def boom(*_args, **_kwargs):
        raise RuntimeError("redis delete failed")

    from src.api.v1.controller import session as session_ctrl

    monkeypatch.setattr(session_ctrl.redis_client, "delete", boom)

    resp = client.request(
        "DELETE",
        "/api/v1/session/end",
        json={
            "application_id": "app",
            "agent_id": "agent",
            "user_id": "user",
            "session_id": "session",
        },
    )

    assert resp.status_code == 500
    body = resp.json()
    assert body["success"] is False
    assert "failed to end session" in body["message"].lower()
