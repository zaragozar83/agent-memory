import importlib

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def main_module(monkeypatch):
    module = importlib.import_module("main")
    # Reload to ensure patches apply cleanly in tests that follow
    importlib.reload(module)
    return module


def test_app_registers_versioned_routes(main_module):
    routes = {route.path for route in main_module.app.routes}
    assert "/api/v1/health" in routes
    assert "/api/v1/sessions" in routes


def test_logging_middleware_emits_request_start_header(monkeypatch, main_module):
    captured = {}

    def fake_log_request(request, status_code, error_message=None):
        captured["status"] = status_code
        captured["header"] = request.headers.get("request-start-time")
        captured["error"] = error_message

    monkeypatch.setattr(main_module, "log_request", fake_log_request, raising=False)

    client = TestClient(main_module.app)
    response = client.get("/api/v1/health")

    assert response.status_code == 200
    assert captured["status"] == 200
    assert captured["header"] is not None
    assert captured["error"] is None
