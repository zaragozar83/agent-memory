import os
import sys
import types
import uuid
from pathlib import Path

os.environ.setdefault("MEMORY_SCHEMA", "agent_memory_dev")

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

ROOT_DIR = Path(__file__).resolve().parents[2]
SRC_DIR = ROOT_DIR / "src"
for path in (ROOT_DIR, SRC_DIR):
    str_path = str(path)
    if str_path not in sys.path:
        sys.path.insert(0, str_path)

from src.api.v1.controller import health as health_ctrl
from src.api.v1.controller import session as session_ctrl
from src.api.v1.controller import stm_controller as memory_ctrl
from src.api.v1.exception.handlers import set_exception_handlers
from src.application import service as svc_pkg
from src.application.service import stm_memory_service
from src.core import environment_variables as env_mod
from src.domain import redis as redis_mod

_FAKE_CHAT_HISTORY_STORE = {}


class FakeRedis:
    def __init__(self):
        self._kv = {}

    def set(self, key, value, ex=None):
        self._kv[key] = value
        return True

    def get(self, key):
        return self._kv.get(key)

    def exists(self, key):
        return 1 if key in self._kv else 0

    def delete(self, key):
        self._kv.pop(key, None)
        return 1

    def keys(self, pattern):
        if pattern.endswith("*"):
            prefix = pattern[:-1]
            return [k for k in self._kv.keys() if k.startswith(prefix)]
        return [k for k in self._kv.keys() if k == pattern]

    def hset(self, key, mapping=None, **kwargs):
        if mapping:
            if key not in self._kv:
                self._kv[key] = {}
            if isinstance(self._kv[key], dict):
                self._kv[key].update(mapping)
            else:
                self._kv[key] = mapping
        return True

    def expire(self, key, seconds):
        # For testing, we'll just ignore expiration
        return True


class _BaseMsg:
    def __init__(self, content, **kwargs):
        self.content = content
        self.type = (
            kwargs.get("type", getattr(self, "_type", None))
            or self.__class__.__name__.replace("Message", "").lower()
            or "system"
        )
        for k, v in kwargs.items():
            setattr(self, k, v)

    def dict(self):
        d = {"content": self.content, "type": self.type}
        for k, v in self.__dict__.items():
            if k not in d and k not in ("content", "type"):
                d[k] = v
        return d


class HumanMessage(_BaseMsg):
    _type = "human"


class AIMessage(_BaseMsg):
    _type = "ai"


class SystemMessage(_BaseMsg):
    _type = "system"


class FakeChatHistory:
    def __init__(self, session_id):
        self.session_id = session_id
        self.messages = []

    def add_user_message(self, content):
        self.messages.append(HumanMessage(content=content))

    def add_ai_message(self, content, **kwargs):
        self.messages.append(AIMessage(content=content, **kwargs))

    def add_message(self, msg):
        self.messages.append(msg)

    def clear(self):
        self.messages = []


def _fake_get_chat_history(application_id, agent_id, user_id, session_id):
    sid = f"memory:{application_id}:{agent_id}:{user_id}:{session_id}"
    if sid not in _FAKE_CHAT_HISTORY_STORE:
        _FAKE_CHAT_HISTORY_STORE[sid] = FakeChatHistory(session_id=sid)
    return _FAKE_CHAT_HISTORY_STORE[sid]


@pytest.fixture(autouse=True)
def patch_env_vars(monkeypatch):
    monkeypatch.setattr(
        env_mod.EnvironmentVariables, "MEMORY_BATCH_SIZE", 3, raising=False
    )
    monkeypatch.setattr(
        env_mod.EnvironmentVariables,
        "REDIS_URL",
        "redis://localhost:6379/0",
        raising=False,
    )
    monkeypatch.setattr(
        env_mod.EnvironmentVariables,
        "REDIS_SSL_CERT_REQS",
        "required",
        raising=False,
    )
    monkeypatch.setattr(
        env_mod.EnvironmentVariables,
        "REDIS_SSL_CHECK_HOSTNAME",
        True,
        raising=False,
    )
    monkeypatch.setattr(env_mod.EnvironmentVariables, "REDIS_TTL", 3600, raising=False)
    monkeypatch.setattr(env_mod.EnvironmentVariables, "API_KEY", "", raising=False)
    monkeypatch.setattr(env_mod.EnvironmentVariables, "API_URL", "", raising=False)
    yield


@pytest.fixture
def fake_redis(monkeypatch):
    r = FakeRedis()
    monkeypatch.setattr(redis_mod, "redis_client", r, raising=True)
    monkeypatch.setattr(session_ctrl, "redis_client", r, raising=True)
    monkeypatch.setattr(memory_ctrl, "redis_client", r, raising=True)
    return r


@pytest.fixture
def patch_chat_history(monkeypatch):
    monkeypatch.setattr(
        stm_memory_service, "get_chat_history", _fake_get_chat_history, raising=True
    )
    monkeypatch.setattr(stm_memory_service, "HumanMessage", HumanMessage, raising=True)
    monkeypatch.setattr(stm_memory_service, "AIMessage", AIMessage, raising=True)
    monkeypatch.setattr(
        stm_memory_service, "SystemMessage", SystemMessage, raising=True
    )
    yield
    _FAKE_CHAT_HISTORY_STORE.clear()


@pytest.fixture
def app(fake_redis):
    app = FastAPI(title="test-app")
    prefix = "/api/v1"
    app.include_router(health_ctrl.router, prefix=prefix)
    app.include_router(session_ctrl.router, prefix=prefix)
    app.include_router(memory_ctrl.router, prefix=prefix)
    set_exception_handlers(app)
    return app


@pytest.fixture
def client(app):
    return TestClient(app)
