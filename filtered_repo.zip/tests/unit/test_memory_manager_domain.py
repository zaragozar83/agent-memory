import pytest

from src.core.ltm_config import ClientConfig
from src.domain import memory_manager as mm


class FakeRepository:
    def __init__(self):
        self.created = set()
        self.ensure_calls = []
        self.exists_queries = []

    def ensure_client_store(self, runtime):
        self.ensure_calls.append(runtime.table_name)
        self.created.add(runtime.table_name)
        return True

    def client_store_exists(self, runtime):
        self.exists_queries.append(runtime.table_name)
        return runtime.table_name in self.created


@pytest.fixture
def manager(monkeypatch):
    repo = FakeRepository()
    monkeypatch.setattr(mm, "_memory_manager", None)
    mgr = mm.MemoryManager(repository=repo)
    return mgr, repo


def test_get_memory_instance_creates_and_caches(manager):
    mgr, repo = manager
    config = ClientConfig(
        client_id="client-A",
        api_key="secret",
        embedder_model="bge-base-en-v1-5",
    )

    session = mgr.get_memory_instance(config)
    assert session.client_config.client_id == "client-A"
    assert repo.ensure_calls == ["client_a_memories"]

    again = mgr.get_memory_instance(config)
    assert again is session
    assert repo.ensure_calls == ["client_a_memories"]


def test_check_client_exists_uses_repository(manager):
    mgr, repo = manager
    repo.created.add("client_b_memories")

    assert mgr.check_client_exists("client-b") is True
    assert repo.exists_queries == ["client_b_memories"]


def test_remove_memory_instance(manager):
    mgr, repo = manager
    config = ClientConfig(client_id="client-c", api_key="secret")

    mgr.get_memory_instance(config)
    mgr.remove_memory_instance("client-c")

    assert "client-c" not in mgr._sessions
