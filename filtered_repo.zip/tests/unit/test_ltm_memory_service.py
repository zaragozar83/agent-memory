import pytest

from src.application.exception import RuntimeException
from src.application.service import ltm_memory_service as ltm_module
from src.core.ltm_config import ClientConfig
from src.domain.ltm_repository import MemoryRecord


class FakeSession:
    def __init__(self):
        self.add_calls = []
        self.search_calls = []
        self.list_calls = []
        self.get_calls = []
        self.update_calls = []
        self.delete_calls = []
        self.reset_called = False

        self.memories = [
            MemoryRecord(
                id="mem-1",
                client_id="client",
                content="stored",
                metadata={"foo": "bar"},
                score=0.9,
            ),
            MemoryRecord(
                id="mem-2",
                client_id="client",
                content="other",
                metadata={},
                score=0.2,
            ),
        ]

    def add_memories(self, messages, **kwargs):
        self.add_calls.append((messages, kwargs))
        return self.memories[:1]

    def search_memories(self, query, **kwargs):
        self.search_calls.append((query, kwargs))
        return self.memories

    def list_memories(self, **kwargs):
        self.list_calls.append(kwargs)
        return self.memories

    def get_memory(self, memory_id):
        self.get_calls.append(memory_id)
        return next((m for m in self.memories if m.id == memory_id), None)

    def update_memory(self, memory_id, content):
        self.update_calls.append((memory_id, content))
        return memory_id == "mem-1"

    def delete_memory(self, memory_id):
        self.delete_calls.append(memory_id)
        return memory_id == "mem-1"

    def reset(self):
        self.reset_called = True


class FakeMemoryManager:
    def __init__(self, session):
        self.session = session
        self.known_clients = set()

    def get_memory_instance(self, client_config):
        self.known_clients.add(client_config.client_id)
        return self.session

    def check_client_exists(self, client_id):
        return client_id in self.known_clients


@pytest.fixture
def service_components(monkeypatch):
    fake_session = FakeSession()
    fake_manager = FakeMemoryManager(fake_session)
    monkeypatch.setattr(ltm_module, "get_memory_manager", lambda: fake_manager)
    monkeypatch.setattr(ltm_module, "_ltm_service", None)
    service = ltm_module.LTMService()
    return service, fake_session, fake_manager


def _configure_default(service):
    return service.configure(
        ClientConfig(
            client_id="client-123",
            api_key="sk-test",
            llm_model="gpt-test",
            embedder_model="embed-test",
        )
    )


def test_configure_sets_current_session(service_components):
    service, _, manager = service_components
    result = _configure_default(service)

    assert result == {
        "message": "Configuration set successfully",
        "client_id": "client-123",
        "table_created": True,
    }
    assert manager.check_client_exists("client-123")


def test_add_memory_returns_serialized_records(service_components):
    service, session, _ = service_components
    _configure_default(service)

    payload = [{"role": "user", "content": "hello"}]
    result = service.add_memory(
        client_id="client-123",
        messages=payload,
        metadata={"topic": "greeting"},
        run_id="run-1",
        agent_id="agent-1",
        user_id="user-5",
    )

    assert result["results"] == [
        {"id": "mem-1", "content": "stored", "metadata": {"foo": "bar"}}
    ]
    messages, kwargs = session.add_calls[-1]
    assert messages == payload
    assert kwargs["agent_id"] == "agent-1"
    assert kwargs["run_id"] == "run-1"
    assert kwargs["user_id"] == "user-5"
    assert kwargs["metadata"] == {"topic": "greeting"}


def test_add_memory_requires_identifiers(service_components):
    service, _, _ = service_components
    _configure_default(service)

    with pytest.raises(RuntimeException):
        service.add_memory(
            client_id="client-123",
            messages=[{"role": "user", "content": "hi"}],
        )


def test_search_memories_formats_scores(service_components):
    service, session, _ = service_components
    _configure_default(service)

    result = service.search_memories(
        client_id="client-123", query="query", agent_id="agent-7"
    )
    assert result["results"][0]["score"] == pytest.approx(0.9, rel=1e-6)
    assert result["results"][1]["score"] == pytest.approx(0.2, rel=1e-6)
    query, kwargs = session.search_calls[-1]
    assert query == "query"
    assert kwargs["agent_id"] == "agent-7"


def test_get_all_memories_returns_records(service_components):
    service, session, _ = service_components
    _configure_default(service)

    result = service.get_all_memories(client_id="client-123")
    assert len(session.list_calls) == 1
    assert result["results"][0]["id"] == "mem-1"
    assert result["results"][1]["id"] == "mem-2"


def test_get_memory_requires_configuration(service_components):
    service, *_ = service_components
    with pytest.raises(RuntimeException):
        service.get_memory("client-123", "mem-1")


def test_get_memory_returns_result(service_components):
    service, session, _ = service_components
    _configure_default(service)

    result = service.get_memory("client-123", "mem-1")
    assert result["result"]["id"] == "mem-1"
    assert session.get_calls == ["mem-1"]


def test_update_memory_returns_message(service_components):
    service, session, _ = service_components
    _configure_default(service)

    response = service.update_memory(
        "client-123", "mem-1", data="updated"
    )
    assert response == {"result": "Memory updated successfully"}
    assert session.update_calls == [("mem-1", "updated")]


def test_update_memory_not_found(service_components):
    service, session, _ = service_components
    _configure_default(service)

    response = service.update_memory("client-123", "missing", data="updated")
    assert response == {"result": None}
    assert session.update_calls[-1] == ("missing", "updated")


def test_delete_memory_returns_message(service_components):
    service, session, _ = service_components
    _configure_default(service)

    response = service.delete_memory("client-123", "mem-1")
    assert response == {"result": "Memory deleted successfully"}
    assert session.delete_calls == ["mem-1"]


def test_delete_memory_not_found(service_components):
    service, session, _ = service_components
    _configure_default(service)

    response = service.delete_memory("client-123", "missing")
    assert response == {"result": None}
    assert session.delete_calls[-1] == "missing"


def test_reset_memory(service_components):
    service, session, _ = service_components
    _configure_default(service)

    response = service.reset_memory("client-123")
    assert response == {"result": "All memories reset"}
    assert session.reset_called is True
