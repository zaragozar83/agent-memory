# AIDaaS Agent Memory – Architecture & Flow Diagrams

This document captures the end-to-end flows supported by the **aidaas-agent-memory** service. Each flow is presented as a Mermaid diagram followed by key notes. The final section summarises the underlying storage structures.

---

## 1. Long-Term Memory (LTM)

### 1.1 Configure Client Memory
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/configure
    participant Service as LTMService
    participant Manager as MemoryManager
    participant Repo as PostgreSQL (pgvector)

    Client->>API: POST client_id, api_key, llm_model, embedder_model
    API->>Service: configure(request)
    Service->>Manager: check_client_exists(client_id)
    Manager->>Repo: table_exists(schema, table)
    Repo-->>Manager: true/false
    alt table not found
        Manager->>Repo: ensure_client_store()
        Repo-->>Manager: table created
    end
    Manager-->>Service: LangMemClientSession
    Service-->>API: Configuration result (table_created flag)
    API-->>Client: 200 OK
```
**Key notes**
- If the API process restarts and the client is not cached, the service rebuilds a `ClientConfig` using default values from `.env`.
- One table per `client_id` is provisioned inside `MEMORY_SCHEMA`.

### 1.2 Add Memories
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/memories
    participant Service as LTMService.add_memory
    participant Session as LangMemClientSession
    participant Langmem
    participant Embeds as Embedding API
    participant Repo as PostgreSQL

    Client->>API: POST messages + identifiers + metadata<br/>X-Client-ID header
    API->>Service: add_memory(client_id, ...)
    Service->>Session: _require_session(client_id)
    alt session not cached
        Service->>Manager: get_memory_instance(client_config)
        Manager->>Repo: ensure_client_store()
    end
    Service->>Langmem: invoke({messages})
    alt Langmem returns memories
        Langmem-->>Service: structured entries
    else Langmem empty/error
        Service-->>Service: fallback to raw message content<br/>metadata.extraction_method="fallback"
    end
    Service->>Embeds: embed_documents(contents)
    alt Embedding ok
        Embeds-->>Service: vectors
    else Embedding fails
        Service-->>Service: use zero-vector<br/>metadata.embedding_status set
    end
    Service->>Repo: insert_memories(table, payloads)
    Repo-->>Service: committed records
    Service-->>API: results[]
    API-->>Client: 200 OK (with inserted memories)
```

### 1.3 Semantic Search
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/search
    participant Service as LTMService.search_memories
    participant Session as LangMemClientSession
    participant Embeds as Embedding API
    participant Repo as PostgreSQL

    Client->>API: POST query, filters, X-Client-ID
    API->>Service: search_memories(client_id, ...)
    Service->>Session: _require_session(client_id)
    Service->>Embeds: embed_query(query)
    alt Embedding ok
        Embeds-->>Service: query vector
    else Embedding fails
        Service-->>Service: use zero-vector<br/>metadata logged
    end
    Service->>Repo: search_memories(query_embedding,...)
    Repo-->>Service: rows + distances
    Service-->>API: results with scores (normalised, NaN guarded)
    API-->>Client: 200 OK
```

### 1.4 Reset Client Memory
```mermaid
sequenceDiagram
    participant Client
    participant API as /ltm/reset
    participant Service as LTMService.reset_memory
    participant Session as LangMemClientSession
    participant Repo as PostgreSQL

    Client->>API: POST, X-Client-ID
    API->>Service: reset_memory(client_id)
    Service->>Session: _require_session(client_id)
    Service->>Repo: reset_client_store(table)
    Repo-->>Service: table truncated
    Service-->>API: "All memories reset"
    API-->>Client: 200 OK
```

---

## 2. Short-Term Memory (STM)

### 2.1 Session Lifecycle
```mermaid
flowchart TD
    A[POST /sessions] -->|application_id, agent_id, user_id| B(session created<br/>session_id returned)
    C[GET /sessions] -->|query params| D[list of sessions]
    E[POST /sessions/end] -->|application_id + session_id| F[session marked closed]
```

### 2.2 Add Messages & Automatic Summarisation
```mermaid
sequenceDiagram
    participant Client
    participant API as /stm/memory
    participant Service as STMService.add_messages
    participant Redis as Redis (Chat History)
    participant Summarizer as Summarisation (LangChain + LLM)

    Client->>API: POST application_id, agent_id, user_id, session_id, messages[]
    API->>Service: add_messages(...)
    Service->>Redis: store messages
    alt batch size reaches MEMORY_BATCH_SIZE
        Service->>Summarizer: summarise(history)
        Summarizer-->>Service: summary message
        Service->>Redis: replace history with summary + tail
    end
    Service-->>API: success
    API-->>Client: 200 OK
```

### 2.3 Retrieve / Delete / Manual Summarise
```mermaid
sequenceDiagram
    participant Client
    participant GetAPI as GET /stm/memory
    participant DelAPI as DELETE /stm/memory
    participant SumAPI as POST /stm/memory/summarize
    participant Service as STMService
    participant Redis

    Client->>GetAPI: GET params
    GetAPI->>Service: get_memory(...)
    Service->>Redis: fetch history
    Redis-->>Service: messages + summaries
    Service-->>GetAPI: message list
    GetAPI-->>Client: 200 OK

    Client->>SumAPI: POST params
    SumAPI->>Service: manual_summarize(...)
    Service->>Redis: load history
    Service->>Summariser: summarise(history)
    Summariser-->>Service: summary
    Service->>Redis: replace content
    SumAPI-->>Client: 200 OK

    Client->>DelAPI: DELETE params
    DelAPI->>Service: delete_memory(...)
    Service->>Redis: delete keys
    DelAPI-->>Client: 200 OK
```

---

## 3. Storage Structures

### 3.1 PostgreSQL (Per-Client LTM table)
| Column         | Type              | Notes / Indexes                                    |
|----------------|-------------------|----------------------------------------------------|
| `id`           | `UUID`            | Primary key                                        |
| `client_id`    | `TEXT`            | Stored redundantly for metadata queries            |
| `user_id`      | `TEXT`            | Filter index (`btree`)                             |
| `agent_id`     | `TEXT`            | Filter index (`btree`)                             |
| `run_id`       | `TEXT`            | Optional run identifier                            |
| `memory`       | `TEXT`            | Human-readable memory content                      |
| `embedding`    | `vector(d)`       | pgvector column (dimension driven by model)        |
| `metadata`     | `JSONB`           | Arbitrary metadata. GIN index created              |
| `created_at`   | `TIMESTAMPTZ`     | Defaults to `NOW()`                                |
| `updated_at`   | `TIMESTAMPTZ`     | Automatically updated on write                     |

**Additional indexes**
- `GIN(metadata)` for attribute filters (`metadata @> {...}`).
- `btree(agent_id)` and `btree(user_id)` to speed up selective queries.

```mermaid
classDiagram
    class client_id_specific_memories {
        +UUID id
        +TEXT client_id
        +TEXT user_id
        +TEXT agent_id
        +TEXT run_id
        +TEXT memory
        +vector embedding
        +JSONB metadata
        +TIMESTAMPTZ created_at
        +TIMESTAMPTZ updated_at
    }
```

### 3.2 Redis (STM)
- **Key pattern**: `memory:{application_id}:{agent_id}:{user_id}:{session_id}`
- **Structure**: List of messages; summaries replace older messages once thresholds are crossed.
- **TTL**: controlled via `REDIS_TTL`. SSL options are honoured (`REDIS_SSL_CERT_REQS`, `REDIS_SSL_CHECK_HOSTNAME`).

---

These diagrams represent the current implementation. Any new behaviour (e.g., new LTM endpoints, additional metadata) should be reflected here to keep architectural documentation aligned with the codebase.
