"""
Langmem-backed memory manager that provisions client-specific PostgreSQL tables.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import typing as _typing

try:  # pragma: no cover - required for Python < 3.11
    _typing.NotRequired  # type: ignore[attr-defined]
except AttributeError:  # pragma: no cover
    from typing_extensions import NotRequired

    _typing.NotRequired = NotRequired  # type: ignore

import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from langmem import create_memory_manager

from src.core.ltm_config import (
    ClientConfig,
    ClientRuntimeConfig,
    build_client_runtime,
    optional_url,
)
from src.domain.ltm_repository import (
    LongTermMemoryRepository,
    MemoryInsert,
    MemoryRecord,
)

logger = logging.getLogger(__name__)


@dataclass
class MemoryExtractionResult:
    """Internal representation of a memory extracted via langmem."""

    langmem_id: str
    content: str
    is_fallback: bool = False


def _deserialize_langmem_result(item: Any) -> Optional[MemoryExtractionResult]:
    """
    Normalize the output of langmem.create_memory_manager() into MemoryExtractionResult.
    """
    if item is None:
        return None

    if isinstance(item, MemoryExtractionResult):
        return item

    if isinstance(item, tuple) and len(item) == 2:
        langmem_id, payload = item
        if hasattr(payload, "content"):
            return MemoryExtractionResult(langmem_id=str(langmem_id), content=payload.content)
        return MemoryExtractionResult(langmem_id=str(langmem_id), content=str(payload))

    if hasattr(item, "content") and hasattr(item, "id"):
        return MemoryExtractionResult(langmem_id=str(item.id), content=item.content)

    if isinstance(item, dict):
        langmem_id = str(item.get("id", uuid.uuid4()))
        content = item.get("content") or item.get("memory")
        if content:
            return MemoryExtractionResult(langmem_id=langmem_id, content=str(content))

    if isinstance(item, str):
        return MemoryExtractionResult(langmem_id=str(uuid.uuid4()), content=item)

    logger.debug("Unsupported langmem extraction format: %s (%s)", item, type(item))
    return None


class LangMemClientSession:
    """Encapsulates langmem processing and storage for a single client."""

    def __init__(
        self,
        client_config: ClientConfig,
        runtime: ClientRuntimeConfig,
        repository: LongTermMemoryRepository,
    ):
        self.client_config = client_config
        self.runtime = runtime
        self.repository = repository
        self._memory_manager = None
        self._embedder = None
        self._http_client: Optional[httpx.Client] = None

    # ------------------------------------------------------------------ helpers
    def ensure_store(self) -> bool:
        """Ensure the client's table exists, returning True if newly created."""
        return self.repository.ensure_client_store(self.runtime)

    def _get_langmem_manager(self):
        if self._memory_manager is None:
            chat_model = self._build_chat_model()
            self._memory_manager = create_memory_manager(chat_model)
        return self._memory_manager

    def _get_embedder(self):
        if self._embedder is None:
            self._embedder = self._build_embedder()
        return self._embedder

    def _get_http_client(self) -> Optional[httpx.Client]:
        if not self.runtime.system.TLS_CA_BUNDLE:
            return None

        if self._http_client is None:
            self._http_client = httpx.Client(verify=self.runtime.system.TLS_CA_BUNDLE)
        return self._http_client

    def _build_chat_model(self) -> ChatOpenAI:
        kwargs: Dict[str, Any] = {
            "model": self.client_config.llm_model,
            "api_key": self.client_config.api_key,
            "temperature": self.runtime.system.LLM_TEMPERATURE,
            "max_tokens": self.runtime.system.LLM_MAX_TOKENS,
        }
        base_url = optional_url(self.runtime.system.LLM_BASE_URL)
        if base_url:
            kwargs["base_url"] = base_url
        http_client = self._get_http_client()
        if http_client is not None:
            kwargs["http_client"] = http_client
        return ChatOpenAI(**kwargs)

    def _build_embedder(self) -> OpenAIEmbeddings:
        kwargs: Dict[str, Any] = {
            "model": self.client_config.embedder_model,
            "api_key": self.client_config.api_key,
        }
        base_url = optional_url(self.runtime.system.EMBEDDER_BASE_URL)
        if base_url:
            kwargs["base_url"] = base_url
        http_client = self._get_http_client()
        if http_client is not None:
            kwargs["http_client"] = http_client
        return OpenAIEmbeddings(**kwargs)

    # ------------------------------------------------------------------ operations
    def add_memories(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[MemoryRecord]:
        """Process conversation messages and persist extracted memories."""
        manager = self._get_langmem_manager()
        try:
            extracted = manager.invoke({"messages": list(messages)})
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Langmem extraction failed for client_id=%s: %s",
                self.client_config.client_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Langmem extraction HTTP response status=%s body=%s",
                    status,
                    body,
                )
            extracted = []

        normalized: List[MemoryExtractionResult] = []
        if isinstance(extracted, (list, tuple)):
            for item in extracted:
                result = _deserialize_langmem_result(item)
                if result:
                    normalized.append(result)
        elif extracted:
            result = _deserialize_langmem_result(extracted)
            if result:
                normalized.append(result)

        if not normalized:
            # Fallback: persist user messages directly when no extraction occurs
            fallback = [
                MemoryExtractionResult(
                    langmem_id=str(uuid.uuid4()),
                    content=msg.get("content", ""),
                    is_fallback=True,
                )
                for msg in messages
                if isinstance(msg, dict) and msg.get("content")
            ]
            normalized.extend(fallback)
            if fallback and logger.isEnabledFor(logging.DEBUG):
                logger.debug(
                    (
                        "Langmem returned no extracted memories; falling back to %d raw"
                        " message(s) for client_id=%s"
                    ),
                    len(fallback),
                    self.client_config.client_id,
                )

        embedder = self._get_embedder()
        contents = [item.content for item in normalized]
        embedding_error_message: Optional[str] = None
        try:
            embeddings = embedder.embed_documents(contents)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding generation failed for client_id=%s: %s",
                self.client_config.client_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding HTTP response status=%s body=%s",
                    status,
                    body,
                )
            embedding_error_message = str(exc)
            zero_vector = [0.0] * self.runtime.embedding_dims
            embeddings = [zero_vector for _ in contents]

        inserts: List[MemoryInsert] = []
        for item, vector in zip(normalized, embeddings):
            record_metadata = dict(metadata or {})
            record_metadata.setdefault("langmem_id", item.langmem_id)
            if item.is_fallback:
                record_metadata.setdefault("extraction_method", "fallback")
            else:
                record_metadata.setdefault("extraction_method", "langmem")
            if embedding_error_message:
                record_metadata.setdefault("embedding_status", embedding_error_message)
            if agent_id:
                record_metadata.setdefault("agent_id", agent_id)
            if user_id:
                record_metadata.setdefault("user_id", user_id)
            if run_id:
                record_metadata.setdefault("run_id", run_id)

            record = MemoryRecord(
                id=str(uuid.uuid4()),
                client_id=self.client_config.client_id,
                content=item.content,
                metadata=record_metadata,
                agent_id=agent_id,
                user_id=user_id,
                run_id=run_id,
            )
            inserts.append(MemoryInsert(record=record, embedding=vector))

        return self.repository.insert_memories(self.runtime, inserts)

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 10,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemoryRecord]:
        """Semantic search for memories using vector similarity."""
        embedder = self._get_embedder()
        try:
            query_vector = embedder.embed_query(query)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding query failed for client_id=%s: %s",
                self.client_config.client_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding query HTTP response status=%s body=%s",
                    status,
                    body,
                )
            query_vector = [0.0] * self.runtime.embedding_dims
        return self.repository.search_memories(
            self.runtime,
            query_embedding=query_vector,
            limit=limit,
            user_id=user_id,
            agent_id=agent_id,
            run_id=run_id,
            filters=filters,
        )

    def list_memories(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[MemoryRecord]:
        """Return all memories filtered by identifiers."""
        return self.repository.list_memories(
            self.runtime, user_id=user_id, agent_id=agent_id, run_id=run_id
        )

    def get_memory(self, memory_id: str) -> Optional[MemoryRecord]:
        return self.repository.fetch_memory(self.runtime, memory_id)

    def update_memory(self, memory_id: str, content: str) -> bool:
        embedder = self._get_embedder()
        try:
            vector = embedder.embed_query(content)
        except Exception as exc:  # pragma: no cover - remote failure path
            logger.error(
                "Embedding update failed for client_id=%s memory_id=%s: %s",
                self.client_config.client_id,
                memory_id,
                exc,
            )
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None) or getattr(
                    response, "status", None
                )
                try:
                    body = response.json()
                except Exception:
                    body = getattr(response, "text", None) or str(response)
                logger.error(
                    "Embedding update HTTP response status=%s body=%s",
                    status,
                    body,
                )
            vector = [0.0] * self.runtime.embedding_dims
        return self.repository.update_memory(
            self.runtime, memory_id, content=content, embedding=vector
        )

    def delete_memory(self, memory_id: str) -> bool:
        return self.repository.delete_memory(self.runtime, memory_id)

    def reset(self) -> None:
        self.repository.reset_client_store(self.runtime)


class MemoryManager:
    """Caches langmem sessions keyed by client_id."""

    def __init__(self, repository: Optional[LongTermMemoryRepository] = None):
        self._sessions: Dict[str, LangMemClientSession] = {}
        self._repository = repository or LongTermMemoryRepository()

    def get_memory_instance(self, client_config: ClientConfig) -> LangMemClientSession:
        """
        Get or create a memory session for the given client configuration.
        """
        client_id = client_config.client_id
        if client_id in self._sessions:
            return self._sessions[client_id]

        runtime = build_client_runtime(client_config)
        session = LangMemClientSession(client_config, runtime, self._repository)
        session.ensure_store()

        self._sessions[client_id] = session
        logger.info("Provisioned langmem session for client_id=%s", client_id)
        return session

    def check_client_exists(self, client_id: str) -> bool:
        """Check if a client store already exists."""
        temp_config = ClientConfig(client_id=client_id, api_key="")
        runtime = build_client_runtime(temp_config)
        return self._repository.client_store_exists(runtime)

    def remove_memory_instance(self, client_id: str) -> None:
        """Remove cached session for the given client."""
        if client_id in self._sessions:
            del self._sessions[client_id]


# Global memory manager instance
_memory_manager: Optional[MemoryManager] = None


def get_memory_manager() -> MemoryManager:
    """Return the global memory manager singleton."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
