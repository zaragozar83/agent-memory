"""
PostgreSQL-backed repository for client-scoped long-term memory storage.
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence
import math

from pgvector import Vector
from psycopg2 import sql
from psycopg2.extras import execute_values

from src.core.ltm_config import ClientRuntimeConfig
from src.domain.database import PostgreSQLManager, get_postgresql_manager

logger = logging.getLogger(__name__)


@dataclass
class MemoryRecord:
    """Domain representation of a stored memory entry."""

    id: str
    client_id: str
    content: str
    metadata: Dict[str, Any]
    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    run_id: Optional[str] = None
    score: Optional[float] = None

    def to_response(self, include_score: bool = False) -> Dict[str, Any]:
        """Convert to API-friendly response payload."""
        payload: Dict[str, Any] = {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata or {},
        }
        if include_score:
            score_value = self.score if self.score is not None else 0.0
            if not math.isfinite(score_value):
                score_value = 0.0
            payload["score"] = round(score_value, 6)
        return payload


@dataclass
class MemoryInsert:
    """Descriptor for inserting a new memory record."""

    record: MemoryRecord
    embedding: Sequence[float]


def _distance_to_score(distance: Optional[float]) -> float:
    """Convert pgvector distance to a normalized similarity score."""
    if distance is None:
        return 0.0
    if distance < 0:
        return 0.0
    # Simple normalization: 1 / (1 + distance)
    return 1.0 / (1.0 + distance)


class LongTermMemoryRepository:
    """Repository encapsulating all PostgreSQL interactions for LTM."""

    def __init__(self, db_manager: Optional[PostgreSQLManager] = None):
        self._db = db_manager or get_postgresql_manager()

    # ------------------------------------------------------------------ helpers
    def _table_identifier(self, runtime: ClientRuntimeConfig) -> sql.Identifier:
        return sql.Identifier(runtime.system.MEMORY_SCHEMA, runtime.table_name)

    def _index_identifier(self, runtime: ClientRuntimeConfig, suffix: str) -> sql.Identifier:
        name = f"{runtime.table_name}_{suffix}"
        return sql.Identifier(name[:63])

    # ---------------------------------------------------------------- provisioning
    def ensure_client_store(self, runtime: ClientRuntimeConfig) -> bool:
        """
        Create the client's table if it does not exist.

        Returns True if a new table was created, False if it already existed.
        """
        schema = runtime.system.MEMORY_SCHEMA
        table_exists = self._db.table_exists(schema, runtime.table_name)
        if table_exists:
            return False

        self._db.ensure_schema(schema)

        with self._db.get_connection() as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                logger.info(
                    "Creating memory table %s.%s (dims=%s)",
                    schema,
                    runtime.table_name,
                    runtime.embedding_dims,
                )
                create_stmt = sql.SQL(
                    """
                    CREATE TABLE IF NOT EXISTS {table} (
                        id UUID PRIMARY KEY,
                        client_id TEXT NOT NULL,
                        user_id TEXT,
                        agent_id TEXT,
                        run_id TEXT,
                        memory TEXT NOT NULL,
                        embedding {vector_type} NOT NULL,
                        metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )
                    """
                ).format(
                    table=self._table_identifier(runtime),
                    vector_type=sql.SQL(f"vector({int(runtime.embedding_dims)})"),
                )
                cur.execute(create_stmt)

                metadata_idx = self._index_identifier(runtime, "metadata_idx")
                cur.execute(
                    sql.SQL(
                        "CREATE INDEX IF NOT EXISTS {index} ON {table} USING GIN (metadata)"
                    ).format(index=metadata_idx, table=self._table_identifier(runtime))
                )

                agent_idx = self._index_identifier(runtime, "agent_idx")
                cur.execute(
                    sql.SQL(
                        "CREATE INDEX IF NOT EXISTS {index} ON {table} (agent_id)"
                    ).format(index=agent_idx, table=self._table_identifier(runtime))
                )

                user_idx = self._index_identifier(runtime, "user_idx")
                cur.execute(
                    sql.SQL(
                        "CREATE INDEX IF NOT EXISTS {index} ON {table} (user_id)"
                    ).format(index=user_idx, table=self._table_identifier(runtime))
                )

        return True

    def client_store_exists(self, runtime: ClientRuntimeConfig) -> bool:
        """Check if the client's table already exists."""
        return self._db.table_exists(runtime.system.MEMORY_SCHEMA, runtime.table_name)

    def reset_client_store(self, runtime: ClientRuntimeConfig) -> None:
        """Delete all rows from the client table."""
        with self._db.get_connection() as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(
                    sql.SQL("TRUNCATE TABLE {table}").format(
                        table=self._table_identifier(runtime)
                    )
                )

    # ----------------------------------------------------------------- mutations
    def insert_memories(
        self, runtime: ClientRuntimeConfig, entries: Sequence[MemoryInsert]
    ) -> List[MemoryRecord]:
        """Insert a batch of memory entries."""
        if not entries:
            return []

        payloads = [
            (
                entry.record.id,
                entry.record.client_id,
                entry.record.user_id,
                entry.record.agent_id,
                entry.record.run_id,
                entry.record.content,
                Vector(entry.embedding),
                json.dumps(entry.record.metadata or {}),
            )
            for entry in entries
        ]

        insert_stmt = sql.SQL(
            """
            INSERT INTO {table} (
                id, client_id, user_id, agent_id, run_id,
                memory, embedding, metadata
            )
            VALUES %s
            """
        ).format(table=self._table_identifier(runtime))

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                execute_values(cur, insert_stmt.as_string(cur), payloads)
                conn.commit()

        return [entry.record for entry in entries]

    def update_memory(
        self,
        runtime: ClientRuntimeConfig,
        memory_id: str,
        *,
        content: str,
        embedding: Sequence[float],
    ) -> bool:
        """Update memory content and embedding."""
        update_stmt = sql.SQL(
            """
            UPDATE {table}
            SET memory = %s,
                embedding = %s,
                updated_at = NOW()
            WHERE id = %s
            """
        ).format(table=self._table_identifier(runtime))

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    update_stmt,
                    (content, Vector(embedding), memory_id),
                )
                conn.commit()
                return cur.rowcount > 0

    def delete_memory(
        self, runtime: ClientRuntimeConfig, memory_id: str
    ) -> bool:
        """Delete a memory by ID."""
        delete_stmt = sql.SQL(
            "DELETE FROM {table} WHERE id = %s"
        ).format(table=self._table_identifier(runtime))

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(delete_stmt, (memory_id,))
                conn.commit()
                return cur.rowcount > 0

    # -------------------------------------------------------------------- reads
    def fetch_memory(
        self, runtime: ClientRuntimeConfig, memory_id: str
    ) -> Optional[MemoryRecord]:
        """Retrieve a single memory by ID."""
        query = sql.SQL(
            """
            SELECT id, client_id, memory, metadata, agent_id, user_id, run_id
            FROM {table}
            WHERE id = %s
            """
        ).format(table=self._table_identifier(runtime))

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (memory_id,))
                row = cur.fetchone()

        if not row:
            return None

        return MemoryRecord(
            id=row[0],
            client_id=row[1],
            content=row[2],
            metadata=row[3] or {},
            agent_id=row[4],
            user_id=row[5],
            run_id=row[6],
        )

    def list_memories(
        self,
        runtime: ClientRuntimeConfig,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[MemoryRecord]:
        """Return all memories filtered by optional identifiers."""
        filters = []
        params: List[Any] = []

        if user_id:
            filters.append(sql.SQL("user_id = %s"))
            params.append(user_id)
        if agent_id:
            filters.append(sql.SQL("agent_id = %s"))
            params.append(agent_id)
        if run_id:
            filters.append(sql.SQL("run_id = %s"))
            params.append(run_id)

        where_clause = (
            sql.SQL("WHERE ") + sql.SQL(" AND ").join(filters) if filters else sql.SQL("")
        )

        query = sql.SQL(
            """
            SELECT id, client_id, memory, metadata, agent_id, user_id, run_id
            FROM {table}
            {where}
            ORDER BY created_at DESC
            """
        ).format(table=self._table_identifier(runtime), where=where_clause)

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, tuple(params))
                rows = cur.fetchall()

        return [
            MemoryRecord(
                id=row[0],
                client_id=row[1],
                content=row[2],
                metadata=row[3] or {},
                agent_id=row[4],
                user_id=row[5],
                run_id=row[6],
            )
            for row in rows
        ]

    def search_memories(
        self,
        runtime: ClientRuntimeConfig,
        *,
        query_embedding: Sequence[float],
        limit: int = 10,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemoryRecord]:
        """Semantic search using pgvector similarity."""
        conditions = [sql.SQL("TRUE")]
        params: List[Any] = [Vector(query_embedding)]

        if user_id:
            conditions.append(sql.SQL("user_id = %s"))
            params.append(user_id)
        if agent_id:
            conditions.append(sql.SQL("agent_id = %s"))
            params.append(agent_id)
        if run_id:
            conditions.append(sql.SQL("run_id = %s"))
            params.append(run_id)

        if filters:
            for key, value in filters.items():
                conditions.append(sql.SQL("metadata @> %s::jsonb"))
                params.append(json.dumps({key: value}))

        where_clause = sql.SQL(" AND ").join(conditions)

        query = sql.SQL(
            """
            SELECT
                id,
                client_id,
                memory,
                metadata,
                agent_id,
                user_id,
                run_id,
                embedding <=> %s AS distance
            FROM {table}
            WHERE {where}
            ORDER BY distance ASC
            LIMIT %s
            """
        ).format(table=self._table_identifier(runtime), where=where_clause)

        params.append(limit)

        with self._db.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, tuple(params))
                rows = cur.fetchall()

        results: List[MemoryRecord] = []
        for row in rows:
            record = MemoryRecord(
                id=row[0],
                client_id=row[1],
                content=row[2],
                metadata=row[3] or {},
                agent_id=row[4],
                user_id=row[5],
                run_id=row[6],
                score=_distance_to_score(row[7]),
            )
            results.append(record)

        return results
