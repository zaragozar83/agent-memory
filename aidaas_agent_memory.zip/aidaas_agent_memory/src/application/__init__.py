from src.application.exception import RuntimeException

__all__ = ["RuntimeException"]
