"""
Long-term memory service built on top of langmem and PostgreSQL.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from src.application.exception import RuntimeException
from src.core.environment_variables import EnvironmentVariables
from src.core.ltm_config import ClientConfig
from src.domain.memory_manager import LangMemClientSession, MemoryManager, get_memory_manager

logger = logging.getLogger(__name__)


class LTMService:
    """High-level service orchestrating long-term memory operations."""

    def __init__(self):
        self._memory_manager: MemoryManager = get_memory_manager()
        self._client_configs: Dict[str, ClientConfig] = {}

    # ---------------------------------------------------------------- configuration
    def configure(self, client_config: ClientConfig) -> Dict[str, Any]:
        """
        Configure memory for a client_id. Provisioning is idempotent.
        """
        try:
            table_existed = self._memory_manager.check_client_exists(client_config.client_id)
            session = self._memory_manager.get_memory_instance(client_config)
            self._client_configs[client_config.client_id] = client_config

            return {
                "message": "Configuration set successfully",
                "client_id": client_config.client_id,
                "table_created": not table_existed,
            }
        except Exception as exc:
            logger.exception(
                "Configuration error for client_id=%s: %s",
                client_config.client_id,
                exc,
            )
            raise

    # ---------------------------------------------------------------- assertions
    def _require_session(self, client_id: str) -> LangMemClientSession:
        if not client_id:
            raise RuntimeException(
                message="Client identifier missing.",
                detail="Provide client_id via header or request payload.",
                status_code=400,
            )

        client_config = self._client_configs.get(client_id)
        if not client_config:
            default_api_key = EnvironmentVariables.API_KEY
            if not default_api_key:
                raise RuntimeException(
                    message="Client is not provisioned.",
                    detail=f"Client {client_id} is not configured. Call /ltm/configure first.",
                    status_code=404,
                )

            client_config = ClientConfig(
                client_id=client_id,
                api_key=default_api_key,
                llm_model=EnvironmentVariables.LLM_MODEL,
                embedder_model=EnvironmentVariables.EMBEDDING_MODEL,
            )
            self._client_configs[client_id] = client_config

        return self._memory_manager.get_memory_instance(client_config)

    # ---------------------------------------------------------------- operations
    def add_memory(
        self,
        client_id: str,
        messages: List[Dict[str, Any]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Persist new memories extracted from conversation messages."""
        session = self._require_session(client_id)

        if not any([user_id, agent_id, run_id]):
            raise RuntimeException(
                status_code=400,
                detail="At least one identifier (user_id, agent_id, run_id) is required.",
            )

        try:
            records = session.add_memories(
                messages,
                user_id=user_id,
                agent_id=agent_id,
                run_id=run_id,
                metadata=metadata,
            )
            return {"results": [record.to_response() for record in records]}
        except Exception as exc:
            logger.exception("Add memory error: %s", exc)
            raise RuntimeException(
                message="Failed to create memories",
                status_code=500,
                detail=str(exc),
            )

    def search_memories(
        self,
        client_id: str,
        query: str,
        user_id: Optional[str] = None,
        run_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Semantic search for stored memories."""
        session = self._require_session(client_id)

        try:
            records = session.search_memories(
                query,
                user_id=user_id,
                agent_id=agent_id,
                run_id=run_id,
                filters=filters,
            )
            return {"results": [record.to_response(include_score=True) for record in records]}
        except Exception as exc:
            logger.exception("Search memories error: %s", exc)
            raise RuntimeException(
                message="Failed to search memories",
                status_code=500,
                detail=str(exc),
            )

    def get_all_memories(
        self,
        client_id: str,
        user_id: Optional[str] = None,
        run_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Return all stored memories for the provided identifiers."""
        session = self._require_session(client_id)

        try:
            records = session.list_memories(
                user_id=user_id, agent_id=agent_id, run_id=run_id
            )
            return {"results": [record.to_response() for record in records]}
        except Exception as exc:
            logger.exception("Get memories error: %s", exc)
            raise RuntimeException(
                message="Failed to fetch memories",
                status_code=500,
                detail=str(exc),
            )

    def get_memory(self, client_id: str, memory_id: str) -> Dict[str, Any]:
        """Retrieve a memory by ID."""
        session = self._require_session(client_id)

        try:
            record = session.get_memory(memory_id)
            if not record:
                return {"result": None}

            return {"result": record.to_response()}
        except Exception as exc:
            logger.exception("Get memory error: %s", exc)
            raise RuntimeException(
                message="Failed to fetch memory",
                status_code=500,
                detail=str(exc),
            )

    def update_memory(self, client_id: str, memory_id: str, data: str) -> Dict[str, Any]:
        """Update the content of an existing memory."""
        session = self._require_session(client_id)

        try:
            updated = session.update_memory(memory_id, data)
            if not updated:
                return {"result": None}
            return {"result": "Memory updated successfully"}
        except Exception as exc:
            logger.exception("Update memory error: %s", exc)
            raise RuntimeException(
                message="Error updating memory",
                status_code=500,
                detail=str(exc),
            )

    def delete_memory(self, client_id: str, memory_id: str) -> Dict[str, Any]:
        """Delete a memory by ID."""
        session = self._require_session(client_id)

        try:
            deleted = session.delete_memory(memory_id)
            if not deleted:
                return {"result": None}
            return {"result": "Memory deleted successfully"}
        except Exception as exc:
            logger.exception("Delete memory error: %s", exc)
            raise RuntimeException(
                message="Failed to delete memory",
                status_code=500,
                detail=str(exc),
            )

    def reset_memory(self, client_id: str) -> Dict[str, Any]:
        """Remove all memories for the configured client."""
        session = self._require_session(client_id)

        try:
            session.reset()
            return {"result": "All memories reset"}
        except Exception as exc:
            logger.exception("Reset memory error: %s", exc)
            raise RuntimeException(
                message="Failed to reset memories",
                status_code=500,
                detail=str(exc),
            )

    # ---------------------------------------------------------------- diagnostics
    def check_client_exists(self, client_id: str) -> bool:
        """Check if a client has been provisioned."""
        return self._memory_manager.check_client_exists(client_id)


# Global service instance
_ltm_service: Optional[LTMService] = None


def get_ltm_service() -> LTMService:
    """Get singleton instance of the long-term memory service."""
    global _ltm_service
    if _ltm_service is None:
        _ltm_service = LTMService()
    return _ltm_service
