"""
Request models for the long-term memory API.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Message(BaseModel):
    """Message model for conversation history."""

    role: str = Field(..., description="Role of the message (user or assistant)")
    content: str = Field(..., description="Message content")


class MemoryCreateRequest(BaseModel):
    """Request model for creating memories."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    messages: List[Message] = Field(..., description="List of messages to store")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )


class SearchRequest(BaseModel):
    """Request model for searching memories."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    query: str = Field(..., description="Search query")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
    filters: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional search filters"
    )


class UpdateMemoryRequest(BaseModel):
    """Request model for updating a memory."""

    client_id: Optional[str] = Field(
        default=None, description="Client identifier used for memory isolation"
    )
    updated_memory: str = Field(..., description="Updated memory content")


class ConfigureRequest(BaseModel):
    """Request model for configuring memory settings for a client."""

    client_id: str = Field(
        ..., description="Unique client identifier used for memory isolation"
    )
    api_key: str = Field(..., description="API key used for model and embeddings")
    llm_model: str = Field(default="gpt-4o", description="LLM model to use")
    embedder_model: str = Field(
        default="text-embedding-3-small", description="Embedding model to use"
    )


class GetMemoriesRequest(BaseModel):
    """Request model for getting memories."""

    client_id: str = Field(..., description="Client identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")


class DeleteMemoriesRequest(BaseModel):
    """Request model for deleting all memories."""

    client_id: str = Field(..., description="Client identifier")
    run_id: Optional[str] = Field(default=None, description="Run identifier")
    agent_id: Optional[str] = Field(default=None, description="Agent identifier")
