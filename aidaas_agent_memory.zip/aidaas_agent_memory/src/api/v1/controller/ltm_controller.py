"""
FastAPI controller for long-term memory endpoints.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Header, Query

from src.api.v1.request.ltm_requests import (
    ConfigureRequest,
    MemoryCreateRequest,
    SearchRequest,
    UpdateMemoryRequest,
)
from src.api.v1.response.common import RestResponse
from src.api.v1.response.ltm_responses import (
    ConfigureResponse,
    CreateMemoryResponse,
    GetMemoriesResponse,
    GetMemoryResponse,
    SearchMemoriesResponse,
    UpdateMemoryResponse,
)
from src.application.exception import RuntimeException
from src.application.service.ltm_memory_service import get_ltm_service
from src.core.ltm_config import ClientConfig

router = APIRouter(prefix="/ltm", tags=["Long-Term Memory"])
logger = logging.getLogger(__name__)


def _resolve_client_id(
    payload_client_id: Optional[str],
    header_client_id: Optional[str],
) -> str:
    client_id = payload_client_id or header_client_id
    if not client_id:
        raise RuntimeException(
            message="Client identifier is required.",
            detail="Provide client_id in the request payload/query or X-Client-ID header.",
            status_code=400,
        )
    return client_id


@router.post(
    "/configure",
    response_model=RestResponse[ConfigureResponse],
    summary="Configure client memory",
)
def configure_memory(request: ConfigureRequest):
    """
    Configure long-term memory for a client_id. Provisioning is idempotent.
    """
    try:
        ltm_service = get_ltm_service()
        client_config = ClientConfig(
            client_id=request.client_id,
            api_key=request.api_key,
            llm_model=request.llm_model,
            embedder_model=request.embedder_model,
        )

        result = ltm_service.configure(client_config)
        response = ConfigureResponse(
            client_id=result["client_id"],
            table_created=result["table_created"],
        )

        return RestResponse(
            data=response,
            message=result.get("message"),
            success=True,
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error in configure memory: %s", exc)
        raise RuntimeException(
            message="Error occurred in configure memory",
            status_code=500,
            detail=str(exc),
        )


@router.post(
    "/memories",
    response_model=RestResponse[CreateMemoryResponse],
    summary="Create memories",
)
def create_memories(
    request: MemoryCreateRequest,
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Store new memories from conversation messages."""
    try:
        ltm_service = get_ltm_service()
        messages = [message.model_dump() for message in request.messages]

        client_id = _resolve_client_id(request.client_id, x_client_id)

        if not any([request.user_id, request.agent_id, request.run_id]):
            raise RuntimeException(
                status_code=400,
                detail="At least one identifier (user_id, agent_id, run_id) is required.",
            )

        result = ltm_service.add_memory(
            client_id=client_id,
            messages=messages,
            user_id=request.user_id,
            agent_id=request.agent_id,
            run_id=request.run_id,
            metadata=request.metadata,
        )

        response = CreateMemoryResponse(results=result.get("results", []))
        message = (
            "Memories created successfully" if response.results else "No memories created"
        )

        return RestResponse(data=response, message=message)

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error creating memories: %s", exc)
        raise RuntimeException(
            message="Error occurred while creating memories",
            status_code=500,
            detail=str(exc),
        )


@router.get(
    "/memories",
    response_model=RestResponse[GetMemoriesResponse],
    summary="Get memories",
)
def get_memories(
    user_id: Optional[str] = Query(None, description="User identifier"),
    run_id: Optional[str] = Query(None, description="Run identifier"),
    agent_id: Optional[str] = Query(None, description="Agent identifier"),
    client_id: Optional[str] = Query(
        None, description="Client identifier (optional if provided as header)"
    ),
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Retrieve stored memories filtered by identifiers."""
    try:
        ltm_service = get_ltm_service()

        resolved_client_id = _resolve_client_id(client_id, x_client_id)

        result = ltm_service.get_all_memories(
            client_id=resolved_client_id,
            user_id=user_id,
            run_id=run_id,
            agent_id=agent_id,
        )

        response = GetMemoriesResponse(results=result.get("results", []))

        if not response.results:
            raise RuntimeException(
                message="No memories found",
                status_code=404,
                detail="No memories found",
            )

        return RestResponse(
            data=response,
            message="Memories retrieved successfully",
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error retrieving memories: %s", exc)
        raise RuntimeException(
            message="Error occurred while retrieving memories",
            status_code=500,
            detail=str(exc),
        )


@router.get(
    "/memories/{memory_id}",
    response_model=RestResponse[GetMemoryResponse],
    summary="Get a memory",
)
def get_memory(
    memory_id: str,
    client_id: Optional[str] = Query(
        None, description="Client identifier (optional if provided as header)"
    ),
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Retrieve a specific memory by ID."""
    try:
        ltm_service = get_ltm_service()
        resolved_client_id = _resolve_client_id(client_id, x_client_id)
        result = ltm_service.get_memory(resolved_client_id, memory_id)

        response = GetMemoryResponse(result=result.get("result"))

        if not response.result:
            raise RuntimeException(
                message="Memory not found",
                status_code=404,
                detail="Memory not found",
            )

        return RestResponse(
            data=response,
            message="Memory retrieved successfully",
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error retrieving memory: %s", exc)
        raise RuntimeException(
            message="Error occurred while retrieving memory",
            status_code=500,
            detail=str(exc),
        )


@router.post(
    "/search",
    response_model=RestResponse[SearchMemoriesResponse],
    summary="Search memories",
)
def search_memories(
    request: SearchRequest,
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Search for memories based on a query."""
    try:
        ltm_service = get_ltm_service()
        client_id = _resolve_client_id(request.client_id, x_client_id)
        result = ltm_service.search_memories(
            client_id=client_id,
            query=request.query,
            user_id=request.user_id,
            run_id=request.run_id,
            agent_id=request.agent_id,
            filters=request.filters,
        )

        response = SearchMemoriesResponse(results=result.get("results", []))

        if not response.results:
            raise RuntimeException(
                message="No memories found",
                status_code=404,
                detail="No memories found",
            )

        return RestResponse(
            data=response,
            message="Memories retrieved successfully",
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error searching memories: %s", exc)
        raise RuntimeException(
            message="Error occurred while searching memories",
            status_code=500,
            detail=str(exc),
        )


@router.put(
    "/memories/{memory_id}",
    response_model=RestResponse,
    summary="Update a memory",
)
def update_memory(
    memory_id: str,
    request: UpdateMemoryRequest,
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Update an existing memory with new content."""
    try:
        ltm_service = get_ltm_service()

        client_id = _resolve_client_id(request.client_id, x_client_id)

        result = ltm_service.update_memory(
            client_id=client_id,
            memory_id=memory_id,
            data=request.updated_memory,
        )

        response = UpdateMemoryResponse(
            result=result.get("result") if result.get("result") else ""
        )

        if not response.result:
            raise RuntimeException(
                message="Memory not found",
                status_code=404,
                detail="Memory not found",
            )

        return RestResponse(
            data=None,
            message="Memory updated successfully",
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error updating memory: %s", exc)
        raise RuntimeException(
            message="Error occurred while updating memory",
            status_code=500,
            detail=str(exc),
        )


@router.delete(
    "/memories/{memory_id}",
    response_model=RestResponse,
    summary="Delete a memory",
)
def delete_memory(
    memory_id: str,
    client_id: Optional[str] = Query(
        None, description="Client identifier (optional if provided as header)"
    ),
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Delete a specific memory by ID."""
    try:
        ltm_service = get_ltm_service()
        resolved_client_id = _resolve_client_id(client_id, x_client_id)

        result = ltm_service.delete_memory(resolved_client_id, memory_id)
        if not result.get("result"):
            raise RuntimeException(
                message="Memory not found",
                status_code=404,
                detail="Memory not found",
            )

        return RestResponse(
            data=None,
            message=result.get("result"),
        )

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error deleting memory: %s", exc)
        raise RuntimeException(
            message="Error occurred while deleting memory",
            status_code=500,
            detail=str(exc),
        )


@router.post(
    "/reset",
    response_model=RestResponse,
    summary="Reset all memories for a client",
)
def reset_memories(
    client_id: Optional[str] = Query(
        None, description="Client identifier (optional if provided as header)"
    ),
    x_client_id: Optional[str] = Header(None, alias="X-Client-ID"),
):
    """Completely reset stored memories for a client."""
    try:
        ltm_service = get_ltm_service()
        resolved_client_id = _resolve_client_id(client_id, x_client_id)
        result = ltm_service.reset_memory(resolved_client_id)

        return RestResponse(data=None, message=result.get("result"))

    except RuntimeException:
        raise
    except Exception as exc:
        logger.exception("Error resetting memories: %s", exc)
        raise RuntimeException(
            message="Error occurred while resetting memories",
            status_code=500,
            detail=str(exc),
        )
