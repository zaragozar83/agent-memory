import pytest
from src.core.environment_variables import EnvironmentVariables


@pytest.fixture
def restore_env_vars():
    original = EnvironmentVariables.get_all_variables()
    yield
    for key, value in original.items():
        setattr(EnvironmentVariables, key, value)


def test_get_all_variables_excludes_private(restore_env_vars):
    setattr(EnvironmentVariables, "_SECRET", "should_skip")
    variables = EnvironmentVariables.get_all_variables()
    assert "_SECRET" not in variables
    assert "API_HOST" in variables


def test_print_all_variables_masks_sensitive(capsys, restore_env_vars):
    EnvironmentVariables.API_KEY = "abcdefgh"
    EnvironmentVariables.API_HOST = "example.com"

    EnvironmentVariables.print_all_variables()
    out = capsys.readouterr().out

    assert "API_HOST: example.com" in out
    masked_line = next(line for line in out.splitlines() if line.startswith("API_KEY:"))
    assert not masked_line.endswith("abcdefgh")
    assert "*" in masked_line
