from types import SimpleNamespace

import pytest
from src.api.v1.request.stm_requests import Message
from src.application.service import stm_memory_service
from src.core import environment_variables as env_mod


class DummyRedisHistory:
    def __init__(self, session_id, redis_url, ttl):
        self.session_id = session_id
        self.redis_url = redis_url
        self.ttl = ttl
        self.messages = []


class RecordingHistory:
    def __init__(self):
        self.session_id = "sid"
        self.messages = []

    def add_message(self, msg):
        self.messages.append(msg)

    def add_user_message(self, content):
        self.messages.append(SimpleNamespace(type="human", content=content))

    def add_ai_message(self, content):
        self.messages.append(SimpleNamespace(type="ai", content=content))

    def clear(self):
        self.messages.clear()


@pytest.fixture(autouse=True)
def reset_env(monkeypatch):
    monkeypatch.setattr(env_mod.EnvironmentVariables, "API_KEY", "", raising=False)
    monkeypatch.setattr(
        env_mod.EnvironmentVariables, "API_URL", "http://local", raising=False
    )
    monkeypatch.setattr(
        env_mod.EnvironmentVariables, "LLM_MODEL", "test-model", raising=False
    )
    yield


def test_get_chat_history_uses_environment(monkeypatch):
    monkeypatch.setattr(
        env_mod.EnvironmentVariables,
        "REDIS_URL",
        "redis://example:1234/2",
        raising=False,
    )
    monkeypatch.setattr(env_mod.EnvironmentVariables, "REDIS_TTL", 900, raising=False)

    created = {}

    def fake_history(**kwargs):
        created.update(kwargs)
        return DummyRedisHistory(**kwargs)

    monkeypatch.setattr(stm_memory_service, "RedisChatMessageHistory", fake_history)

    history = stm_memory_service.get_chat_history("app", "agent", "user", "session")

    assert history.session_id == "memory:app:agent:user:session"
    assert created["redis_url"] == "redis://example:1234/2"
    assert created["ttl"] == 900


def test_add_message_uses_system_when_role_unknown(monkeypatch):
    history = RecordingHistory()

    def fake_get_chat_history(*_args):
        return history

    class DummySystemMessage:
        def __init__(self, content, **kwargs):
            self.content = content
            self.type = "system"
            self.extra = kwargs

    monkeypatch.setattr(stm_memory_service, "get_chat_history", fake_get_chat_history)
    monkeypatch.setattr(stm_memory_service, "SystemMessage", DummySystemMessage)

    message = Message(role="system", content="note", additional_kwargs={"foo": "bar"})
    stm_memory_service.add_message("app", "agent", "user", "session", message)

    stored = history.messages[-1]
    assert stored.content == "note"
    assert getattr(stored, "type", None) == "system"
    assert stored.extra == {"additional_kwargs": {"foo": "bar"}}


def test_summarize_and_replace_returns_early_with_single_message(monkeypatch):
    class MinimalHistory:
        def __init__(self):
            self.session_id = "sid"
            self.messages = [SimpleNamespace(type="human", content="hello")]
            self.cleared = False

        def clear(self):
            self.cleared = True

    history = MinimalHistory()
    monkeypatch.setattr(stm_memory_service, "get_chat_history", lambda *_: history)

    stm_memory_service.summarize_and_replace("app", "agent", "user", "session")

    assert history.cleared is False
    assert len(history.messages) == 1


def test_summarize_and_replace_retries_clear(monkeypatch):
    class StickyHistory:
        def __init__(self, name):
            self.session_id = name
            self.messages = [
                SimpleNamespace(type="human", content="hi"),
                SimpleNamespace(type="ai", content="hello"),
            ]
            self.clear_calls = 0

        def clear(self):
            self.clear_calls += 1
            # Do not modify messages to trigger retry

        def add_message(self, msg):
            self.messages.append(msg)

    class FreshHistory(StickyHistory):
        def __init__(self):
            super().__init__("sid-fresh")
            self.messages = []

        def clear(self):
            self.clear_calls += 1
            self.messages.clear()

    sticky = StickyHistory("sid")
    fresh = FreshHistory()
    histories = [sticky, fresh]

    def fake_get_chat_history(*_args, **_kwargs):
        return histories.pop(0)

    class DummySystemMessage:
        def __init__(self, content):
            self.content = content
            self.type = "system"

    monkeypatch.setattr(stm_memory_service, "get_chat_history", fake_get_chat_history)
    monkeypatch.setattr(stm_memory_service, "SystemMessage", DummySystemMessage)

    stm_memory_service.summarize_and_replace("app", "agent", "user", "session")

    assert sticky.clear_calls >= 1
    assert len(fresh.messages) == 1
    assert "Summary of" in fresh.messages[0].content


def test_summarize_and_replace_uses_llm_when_api_key(monkeypatch):
    class History:
        def __init__(self):
            self.session_id = "sid"
            self.messages = [
                SimpleNamespace(type="system", content="previous"),
                SimpleNamespace(type="human", content="ask"),
                SimpleNamespace(type="ai", content="answer"),
            ]
            self.cleared = False

        def clear(self):
            self.cleared = True
            self.messages = []

        def add_message(self, msg):
            self.messages.append(msg)

    history = History()

    def fake_get_chat_history(*_args, **_kwargs):
        return history

    class DummyLLM:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class DummyMemory:
        def __init__(self, llm, chat_memory, max_token_limit):
            self.llm = llm
            self.chat_memory = chat_memory
            self.max_token_limit = max_token_limit

        def predict_new_summary(self, messages, existing_summary):
            return f"summary:{existing_summary}:{len(messages)}"

    class DummySystemMessage:
        def __init__(self, content):
            self.content = content
            self.type = "system"

    monkeypatch.setattr(
        env_mod.EnvironmentVariables, "API_KEY", "live-key", raising=False
    )
    monkeypatch.setattr(stm_memory_service, "get_chat_history", fake_get_chat_history)
    monkeypatch.setattr(stm_memory_service, "ChatOpenAI", DummyLLM)
    monkeypatch.setattr(
        stm_memory_service, "ConversationSummaryBufferMemory", DummyMemory
    )
    monkeypatch.setattr(stm_memory_service, "SystemMessage", DummySystemMessage)

    stm_memory_service.summarize_and_replace("app", "agent", "user", "session")

    assert len(history.messages) == 1
    assert history.messages[0].content.startswith("summary:previous:3")


def test_get_memory_logs_message_types(monkeypatch):
    class History:
        def __init__(self):
            self.session_id = "sid"
            self.messages = [
                SimpleNamespace(type="human", content="hi"),
                SimpleNamespace(type="ai", content="hello"),
            ]

    history = History()
    monkeypatch.setattr(stm_memory_service, "get_chat_history", lambda *_: history)

    result = stm_memory_service.get_memory("app", "agent", "user", "session")

    assert result == history.messages


def test_delete_memory_handles_errors(monkeypatch):
    class History:
        def __init__(self):
            self.session_id = "sid"
            self.messages = []
            self.cleared = False

        def clear(self):
            raise RuntimeError("boom")

    monkeypatch.setattr(stm_memory_service, "get_chat_history", lambda *_: History())

    with pytest.raises(RuntimeError):
        stm_memory_service.delete_memory("app", "agent", "user", "session")
