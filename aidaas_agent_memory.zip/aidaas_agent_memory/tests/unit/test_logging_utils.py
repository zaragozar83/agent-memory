import logging
import time
from types import SimpleNamespace

from src.core.logging import get_logging_config, log_request


class DummyRequest:
    def __init__(self, method: str, path: str, start: float):
        self.method = method
        self.url = SimpleNamespace(path=path, query="")
        self.headers = {"request-start-time": str(start)}


def test_log_request_skips_health(caplog):
    caplog.set_level(logging.INFO)
    req = DummyRequest("GET", "/api/v1/health", time.time())
    log_request(req, 200)
    assert not caplog.records


def test_log_request_emits_entry(caplog):
    caplog.set_level(logging.INFO)
    req = DummyRequest("POST", "/api/v1/sessions", time.time() - 0.1)
    log_request(req, 201)
    assert any(
        '"path": "/api/v1/sessions"' in record.message for record in caplog.records
    )


def test_get_logging_config_structure():
    config = get_logging_config("DEBUG")
    assert config["handlers"]["console"]["level"] == "DEBUG"
    assert config["loggers"][""]["handlers"] == ["console"]
