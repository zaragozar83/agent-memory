import json

import pytest
from src.api.v1.request.stm_requests import Message
from src.application.service import stm_memory_service
from src.core import environment_variables as env_mod


class DummyRedis:
    def __init__(self):
        self.storage = {}

    def get(self, key):
        return self.storage.get(key)

    def set(self, key, value, ex=None):
        self.storage[key] = value
        return True

    def delete(self, key):
        self.storage.pop(key, None)
        return 1


@pytest.fixture
def dummy_backend():
    return DummyRedis()


@pytest.mark.usefixtures("fake_redis")
def test_get_chat_history_falls_back(monkeypatch, dummy_backend):
    class BoomHistory:
        def __init__(self, *args, **kwargs):
            raise stm_memory_service.RedisModuleVersionError("missing module")

    original_history_cls = stm_memory_service.SimpleRedisChatHistory

    def fake_simple_history(*args, **kwargs):
        kwargs["redis_backend"] = dummy_backend
        return original_history_cls(*args, **kwargs)

    monkeypatch.setattr(stm_memory_service, "RedisChatMessageHistory", BoomHistory)
    monkeypatch.setattr(
        stm_memory_service, "SimpleRedisChatHistory", fake_simple_history
    )

    history = stm_memory_service.get_chat_history("app", "agent", "user", "sid")
    assert isinstance(history, original_history_cls)
    assert history.ttl == env_mod.EnvironmentVariables.REDIS_TTL
    assert history._redis is dummy_backend


@pytest.mark.usefixtures("fake_redis")
def test_add_message_uses_fallback_storage(monkeypatch, dummy_backend):
    class BoomHistory:
        def __init__(self, *args, **kwargs):
            raise stm_memory_service.RedisModuleVersionError("missing module")

    original_history_cls = stm_memory_service.SimpleRedisChatHistory

    def fake_simple_history(*args, **kwargs):
        kwargs["redis_backend"] = dummy_backend
        return original_history_cls(*args, **kwargs)

    monkeypatch.setattr(stm_memory_service, "RedisChatMessageHistory", BoomHistory)
    monkeypatch.setattr(
        stm_memory_service, "SimpleRedisChatHistory", fake_simple_history
    )

    message = Message(role="user", content="hello")
    stm_memory_service.add_message("app", "agent", "user", "sid", message)

    stored = json.loads(dummy_backend.get("memory:app:agent:user:sid"))
    assert stored[0]["content"] == "hello"
    assert stored[0]["type"] == "human"
