# AIDAAS AGENT MEMORY (Service + Python SDK)
The Agent Memory is a core component of the AI Data-as-a-Service (AI-DaaS) ecosystem. It offers REST endpoints and a Python SDK to provision, manage, and query agent memory for AI applications. The service centralizes memory lifecycle, access control, and policy enforcement, while the SDK exposes a developer-friendly interface capabilities.

# Features roadmap
- [x] Scaffolding baseline
  - [x] API layer (controller, request, response)
  - [x] Application layer (service, facade, exception, dto)
  - [x] Domain layer
- [x] Domain-Driven Design (improved code readability and maintainability)
- [ ] Authentication
- [x] CICD standards (automated testing & automated deployment)
- [x] Logging standard (used for Observability)
- [x] Automated documentation (swagger and redoc)
- [x] Health check endpoint (used for Monitoring)
- [x] Non-root Dockerfile (scanned on security checks)
- [x] Kubernetes configuration files to Deploy on KOB (infra)
- [x] Sample unit tests
- [x] Sample of CRUD operations using REST
- [x] Sample of CRUD operations using a SQL Database

# Local development
From a Linux based environment, install the dependencies:
```bash
make install-dev
```

Run the API:
```bash
make run
```

# Testing
Unit tests:
```bash
make test-unit
```

Coverage tests:
```bash
make test-coverage
```

# Code style
The code was styled using the `isort` library for the organization of imports and `black` for formatting the code. It is recommended to configure the code editor so that the code is automatically formatted using these tools. Format the code using the following command:
```bash
make format
```

# Documentation
- Auto-generated interactive docs (Swagger UI): http://localhost:8000/docs
- Auto-generated alternative docs (ReDoc): http://localhost:8000/redoc

# Code structure & Design Patterns
The source code present in the `src` folder, has been organized following development best practices and design patterns.

### Domain-Driven Design
Project scaffolding with a basic directory structure and files for a new API project, following the Domain-Driven Design, so the business logic is independent from the layer where data is accessed, and the code is easier to read, maintain and test. This structure includes directories for source code, tests, configuration files, and other necessary files. 

### Service layer pattern
Service layer is an architectural pattern applied to organize the services into a set of logical layers. Services that are categorized into a particular layer share functionality. This helps to reduce the conceptual overhead related to managing the service inventory, as the services belonging to the same layer address a smaller set of activities.

### Facade patern
This pattern hides the complexities of the larger system and provides a simpler interface to the client. It typically involves a single wrapper class that contains a set of members required by the client. These members access the system on behalf of the facade client and hide the implementation details. Normally used for interaction with dependent systems/APIs.

### DTO (Data Transfer Objects)
This pattern benefit is the encapsulation of the serialization's logic (the mechanism that translates the object structure and data to a specific format that can be stored and transferred). It provides a single point of change in the serialization nuances. It decouples the domain models from the presentation layer, allowing both to change independently.

---

# Agent Short-Term Memory Service

A service for managing agent short-term memory using Redis and LangChain.

## Setup and Installation

### Prerequisites
- Python 3.8+
- Redis server (standalone or service)
- API key and API URL (for summarization)

### Environment Setup

1. Create and activate a virtual environment:

```bash
# Create virtual environment
python3 -m venv venv

# Activate on Linux/Mac
source venv/bin/activate

# Activate on Windows
# venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Configure environment variables:

Create or edit `.env` file in the project root with the following variables:

```
# API Configuration
API_HOST=127.0.0.1
API_PORT=8000
API_RELOAD=True

# Redis Configuration
REDIS_URL=redis://localhost:6379/0
REDIS_TTL=3600

# Memory Service Configuration
MEMORY_BATCH_SIZE=10

# OpenAI Configuration
API_KEY=your_openai_api_key_here
API_URL=your_api_url_to_access_dell_model
LLM_MODEL=gpt-oss-20b
```

### Key Configuration Options

- **MEMORY_BATCH_SIZE**: Number of messages before automatic summarization is triggered (default: 10)
- **REDIS_TTL**: Time-to-live for Redis keys in seconds (default: 3600)
- **API_KEY**: OpenAI API key for summarization (optional for development)
- **API_URL**: API endpoint URL for language model access
- **LLM_MODEL**: Language model to use for summarization

## Features

### Multi-User Architecture
The service supports complete user isolation with a 4-level key hierarchy:
- `client_id`: Partition key used to scope long-term memories
- `agent_id`: Specific agent within the client context  
- `user_id`: Individual user identifier
- `session_id`: Specific conversation session

### Intelligent Summarization
- **Boundary Crossing**: Automatic summarization when message count crosses `MEMORY_BATCH_SIZE` boundaries
- **Manual Trigger**: On-demand summarization via API endpoint
- **Context Preservation**: Summaries include previous summary context for continuity

### Message Processing
- **Flexible Message Addition**: Add single or multiple messages with `/stm/memory` endpoint
- **Tool Call Support**: Handle AI messages with function calls and metadata
- **Additional Metadata**: Support for custom attributes via `additional_kwargs`
- **Efficient Processing**: Optimized for both single message and batch operations

Or run directly:

```bash
# Activate environment first
source venv/bin/activate

# Run the service
python3 main.py
```

The API will be available at http://127.0.0.1:8000 (or the host/port specified in your environment).

## API Documentation

Once the service is running, access the interactive API documentation at:

- Swagger UI: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## Project Structure

```
aidaas_agent_memory/
├── src/                    # Source code
│   ├── api/                # API endpoints
│   │   └── v1/             # API version 1
│   │       ├── controller/ # API controllers
│   │       ├── exception/  # Exception handlers
│   │       ├── request/    # Request models
│   │       └── response/   # Response models
│   ├── application/        # Application logic
│   │   └── service/        # Services
│   └── core/               # Core functionality
│       ├── environment_variables.py  # Environment variables
│       └── logging.py      # Logging configuration
├── main.py                 # Application entry point
├── .env                    # Environment variables
├── requirements.txt        # Python dependencies
├── run.sh                  # Script to run the service
└── setup.sh                # Script to set up the environment
```

## Using the Memory Service

The service provides APIs for:

- **Multi-user session management**: Create and manage chat sessions for different users
- **Batch message processing**: Add multiple messages at once for better performance
- **Intelligent summarization**: Automatic summarization when crossing configurable batch boundaries
- **Manual summarization**: On-demand summarization trigger
- **Tool call support**: Handle AI messages with tool calls and additional metadata
- **Flexible message retrieval**: Get chat history including summaries and recent messages
- **User isolation**: Complete separation of memory between different users

### API Endpoints

All endpoints are available under the `/api/v1` prefix.

#### Session Management

- **POST** `/sessions` - Create a new session for a user
  - Request: `application_id`, `agent_id`, `user_id`
  - Response: Session details with generated `session_id`

- **GET** `/sessions` - List all sessions for a user
  - Query params: `application_id`, `agent_id`, `user_id`
  - Response: List of sessions

- **POST** `/sessions/end` - End a specific session
  - Request: `application_id`, `agent_id`, `user_id`, `session_id`
  - Response: Success confirmation

#### Memory Management

- **POST** `/stm/memory` - Add multiple messages to a session
  - Request: `application_id`, `agent_id`, `user_id`, `session_id`, `messages[]`
  - Response: Success confirmation
  - Note: Automatically triggers summarization when crossing batch boundaries

- **GET** `/stm/memory` - Retrieve all messages for a session
  - Query params: `application_id`, `agent_id`, `user_id`, `session_id`
  - Response: List of messages (including summaries)

- **DELETE** `/stm/memory` - Delete all memory for a session
  - Query params: `application_id`, `agent_id`, `user_id`, `session_id`
  - Response: Success confirmation

- **POST** `/stm/memory/summarize` - Manually trigger summarization
  - Request: `application_id`, `agent_id`, `user_id`, `session_id`
  - Response: Success confirmation

#### Health Endpoint

- **GET** `/health` - Check if the service is running
  - Response: `200 OK` with service status

### Example API Usage

```bash
# Create a session for a specific user
curl -X 'POST' \
  'http://127.0.0.1:8000/api/v1/sessions' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "application_id": "app1",
  "agent_id": "agent1",
  "user_id": "user123"
}'

# List all sessions for a user
curl -X 'GET' \
  'http://127.0.0.1:8000/api/v1/sessions?application_id=app1&agent_id=agent1&user_id=user123' \
  -H 'accept: application/json'

# End a session
curl -X 'POST' \
  'http://127.0.0.1:8000/api/v1/sessions/end' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "application_id": "app1",
  "agent_id": "agent1",
  "user_id": "user123",
  "session_id": "079af3fc-80b0-494f-9887-c31c63d1fdcd"
}'

# Add multiple messages at once
curl -X 'POST' \
  'http://127.0.0.1:8000/api/v1/stm/memory' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "application_id": "app1",
  "agent_id": "agent1",
  "user_id": "user123",
  "session_id": "afe9949e-fa60-453e-aa7a-1ce0a1410279",
  "messages": [
    {
      "role": "user",
      "content": "Hello, can you help me with a task?",
      "additional_kwargs": {
        "timestamp": "2025-10-09T10:30:00Z"
      }
    },
    {
      "role": "ai",
      "content": "Of course! I'"'"'d be happy to help you with your task.",
      "additional_kwargs": {
        "confidence": 0.95
      }
    }
  ]
}'

# Add a single message with tool calls (using the same endpoint with one message)
curl -X 'POST' \
  'http://127.0.0.1:8000/api/v1/stm/memory' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "application_id": "app1",
  "agent_id": "agent1",
  "user_id": "user123",
  "session_id": "afe9949e-fa60-453e-aa7a-1ce0a1410279",
  "messages": [
    {
      "role": "ai",
      "content": "Let me check the weather for you.",
      "tool_calls": [
        {
          "name": "get_weather",
          "id": "call_123",
          "args": {
            "location": "New York",
            "units": "celsius"
          }
        }
      ],
      "additional_kwargs": {
        "model": "gpt-4",
        "temperature": 0.7
      }
    }
  ]
}'

# Get all messages for a session
curl -X 'GET' \
  'http://127.0.0.1:8000/api/v1/stm/memory?application_id=app1&agent_id=agent1&user_id=user123&session_id=afe9949e-fa60-453e-aa7a-1ce0a1410279' \
  -H 'accept: application/json'

# Delete memory for a specific user session
curl -X 'DELETE' \
  'http://127.0.0.1:8000/api/v1/stm/memory?application_id=app1&agent_id=agent1&user_id=user123&session_id=afe9949e-fa60-453e-aa7a-1ce0a1410279' \
  -H 'accept: application/json'

# Manually trigger summarization for a user session
curl -X 'POST' \
  'http://127.0.0.1:8000/api/v1/stm/memory/summarize' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "application_id": "app1",
  "agent_id": "agent1",
  "user_id": "user123",
  "session_id": "afe9949e-fa60-453e-aa7a-1ce0a1410279"
}'

# Check service health
curl -X 'GET' \
  'http://127.0.0.1:8000/api/v1/health' \
  -H 'accept: application/json'
```

## Redis Setup

You can install Redis using one of the following methods:

### 1. Using apt (Ubuntu/Debian):
```bash
sudo apt update
sudo apt-get update
sudo apt install redis-server
sudo apt-get install redis-stack-server
sudo systemctl start redis-stack-server
sudo systemctl enable redis-stack-server
sudo systemctl start redis-stack-server
sudo systemctl enable redis-server
sudo systemctl start redis-server
redis-cli MODULE LIST - Should not be Null
```

### 2. Using homebrew (macOS):
```bash
brew install redis
brew services start redis
```

### 3. Using Docker:
```bash
docker run -d --name redis -p 6379:6379 redis:latest
```

After installation, verify Redis is running with:
```bash
redis-cli ping
```

You should see 'PONG' as the response.

---

# Agent Long-Term Memory Service

A service for managing agent long-term memory using langmem with PostgreSQL and pgvector for persistent, searchable memory storage.

## Setup and Installation

### Prerequisites
- Python 3.8+
- PostgreSQL with pgvector extension
- Dell models API key
- Docker and Docker Compose (optional, for easy setup)

### Environment Setup

1. Create and activate a virtual environment:

```bash
# Create virtual environment
python -m venv venv

# Activate on Linux/Mac
source venv/bin/activate

# Activate on Windows
# venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Configure environment variables:

Create or edit `.env` in the project root. Only the variables below are required for the service to start:

```
# API server
LOG_LEVEL=INFO
API_HOST=127.0.0.1
API_PORT=8080
API_RELOAD=True

# Model configuration (used when a client is not explicitly configured)
API_KEY="<your-genai-api-key>"
LLM_MODEL=gpt-oss-20b
EMBEDDER_MODEL=bge-m3
LLM_BASE_URL=https://genai-api-dev.dell.com/v1
EMBEDDER_BASE_URL=https://genai-api-dev.dell.com/v1

# PostgreSQL / pgvector
MEMORY_SCHEMA=agent_memory_dev
POSTGRES_HOST=<your-postgres-host>
POSTGRES_PORT=9432
POSTGRES_DB=pgvector
POSTGRES_USER=agentmemoryrw
POSTGRES_PASSWORD=<your-postgres-password>

# Redis (STM)
REDIS_URL=rediss://:password@host:443/0
REDIS_SSL_CERT_REQS=required
REDIS_SSL_CHECK_HOSTNAME=true
REDIS_TTL=3600

# Optional: trust store for outbound HTTPS (set if your environment uses a custom CA bundle)
# TLS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
```

## Architecture

See [`docs/architecture.md`](docs/architecture.md) for sequence diagrams covering the main long-term and short-term memory flows, as well as storage layouts.

## Running the Service

### Option 1: Using Docker Compose (Recommended)

1. Start PostgreSQL with pgvector:

```bash
docker compose up -d db
```

2. Run the service:

```bash
# Activate environment first
source venv/bin/activate

# Run the service
python main.py
```

### Option 2: Manual Setup

1. Install and setup PostgreSQL with pgvector extension
2. Create database and enable vector extension
3. Run the service:

```bash
# Activate environment first
source venv/bin/activate

# Run the service
python main.py
```

The API will be available at http://localhost:8000 (or the host/port specified in your environment).

## API Documentation

Once the service is running, access the interactive API documentation at:

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Project Structure

```
agentic-memory/
├── src/                    # Source code
│   ├── api/                # API endpoints
│   │   └── v1/             # API version 1
│   │       ├── controller/ # API controllers
│   │       │   ├── ltm_controller.py  # Long-term memory endpoints
│   │       │   └── stm_controller.py  # Short-term memory endpoints
│   │       ├── request/    # Request models (ltm_requests.py, stm_requests.py)
│   │       └── response/   # Response models (ltm_responses.py, stm_responses.py)
│   ├── application/        # Application logic
│   │   └── service/        # Services
│   │       ├── ltm_service.py  # LTM service
│   │       └── stm_service.py  # STM service
│   ├── domain/             # Domain layer
│   │   ├── memory_manager.py     # Memory orchestration with langmem
│   │   ├── ltm_repository.py     # PostgreSQL repository for memories
│   │   └── database.py           # Database connections
│   └── core/               # Core functionality
│       └── config.py       # Configuration management
├── main.py                 # Application entry point
├── docker-compose.yml      # Docker composition
├── init.sql               # Database initialization
├── .env                   # Environment variables
└── requirements.txt       # Python dependencies
```

## Using the Long-Term Memory Service

The LTM service provides APIs for:

- Configuring client-specific memory contexts with table-level isolation
- Adding memories from conversation messages
- Retrieving all memories for a client/agent/user context
- Semantic search across memories using vector embeddings
- Updating and deleting specific memories
- Bulk operations (reset all memories)

### Key Features

- **Client-scoped Isolation**: Each `client_id` gets its own PostgreSQL table inside a shared schema
- **Semantic Search**: Vector-based similarity search using OpenAI embeddings
- **Langmem Extraction**: Consistent memory extraction powered by langmem
- **Memory Persistence**: Long-term storage in PostgreSQL with pgvector
- **Metadata Tracking**: Store agent/user/run identifiers alongside custom metadata
- **Flexible Configuration**: Per-client API keys and model configurations

### API Endpoints

All LTM endpoints are available under the `/api/v1/ltm` prefix.

#### Configuration Endpoints

- **POST** `/ltm/configure` - Configure memory for a client
  - Body: `{ "client_id": "client123", "api_key": "sk-...", "llm_model": "gpt-oss-20b", "embedder_model": "bge-m3" }`
  - Response: `200 OK` with configuration status
  - Creates a dedicated table for the client if it does not exist

#### Memory Management Endpoints

- **POST** `/ltm/memories` - Add memories from conversation messages
  - Provide the client identifier via `X-Client-ID` header or include `"client_id"` in the payload
  - Body: `{ "messages": [{"role": "user", "content": "I love basketball"}], "user_id": "user123", "metadata": {} }` At least one among `user_id`, `agent_id`, `run_id` is required in the body.
  - Response: `200 OK` with created memory details
  - Requires valid OpenAI API key for processing

- **GET** `/ltm/memories?user_id=user123` - Get memories for the specified client
  - Provide the client identifier via header or query
  - Optional query params: `user_id`, `agent_id`, `run_id`
  - Response: `200 OK` with array of memories
  - Works with temporary configuration (no API key needed)

- **GET** `/ltm/memories/{memory_id}` - Get a specific memory by ID
  - Response: `200 OK` with memory details

- **PUT** `/ltm/memories/{memory_id}` - Update a specific memory
  - Provide the client identifier via header or include `client_id` in the body
  - Body: `{ "client_id": "client123", "updated_memory": "Updated memory content" }`
  - Response: `200 OK` with update status

- **DELETE** `/ltm/memories/{memory_id}` - Delete a specific memory
  - Response: `200 OK` with deletion status


- **POST** `/ltm/search` - Semantic search through memories
  - Provide the client identifier via header or include `client_id` in the body
  - Body: `{ "query": "basketball", "user_id": "user123", "limit": 10 }`
  - Response: `200 OK` with ranked search results including similarity scores
  - Requires proper client configuration with valid API key


- **POST** `/ltm/reset` - Reset all memories for the configured client
  - Provide the client identifier via header or query
  - Body: No body required
  - Response: `200 OK` with reset status


- **GET** `/ltm/health` - Check if the LTM service is running
  - Response: `200 OK` with service status

### Example API Usage

```bash
# Configure a client (required before adding memories or searching)
curl -X POST "http://localhost:8000/api/v1/ltm/configure" \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "client123",
    "api_key": "your-dell-api-key",
    "llm_model": "gpt-oss-20b",
    "embedder_model": "bge-m3"
  }'

# Add memories from conversation
curl -X POST "http://localhost:8000/api/v1/ltm/memories" \
  -H "Content-Type: application/json" \
  -H "X-Client-ID: client123" \
  -d '{
    "messages": [
      {"role": "user", "content": "I love playing basketball on weekends"},
      {"role": "assistant", "content": "That sounds like great exercise!"}
    ],
    "user_id": "user123"
  }'

# Get all memories for a user/run/agent (requires configured client)
curl -X GET "http://localhost:8000/api/v1/ltm/memories?user_id=user123" \
  -H "X-Client-ID: client123"

# Search memories semantically (requires configured client)
curl -X POST "http://localhost:8000/api/v1/ltm/search" \
  -H "Content-Type: application/json" \
  -H "X-Client-ID: client123" \
  -d '{
    "query": "sports and exercise",
    "user_id": "user123",
    "limit": 5
  }'

# Get a specific memory
curl -X GET "http://localhost:8000/api/v1/ltm/memories/memory-uuid-here" \
  -H "X-Client-ID: client123"

# Update a memory
curl -X PUT "http://localhost:8000/api/v1/ltm/memories/memory-uuid-here" \
  -H "Content-Type: application/json" \
  -H "X-Client-ID: client123" \
  -d '{
    "client_id": "client123",
    "updated_memory": "I love playing basketball and tennis on weekends"
  }'

# Delete a specific memory
curl -X DELETE "http://localhost:8000/api/v1/ltm/memories/memory-uuid-here" \
  -H "X-Client-ID: client123"

# Reset all memories for a client
curl -X POST "http://localhost:8000/api/v1/ltm/reset" \
  -H "X-Client-ID: client123"

# Check health
curl -X GET "http://localhost:8000/api/v1/ltm/health"

```

### Langmem fallback behaviour

Langmem occasionally returns no extracted memories (for example when the input is purely factual or the upstream model is saturated). In that case the service transparently stores the raw message text instead and tags the record with:

- `metadata.extraction_method = "fallback"`
- `metadata.embedding_status = "<error message>"` (only when the embedding API rejected the request)

The fallback log message now appears only when `LOG_LEVEL` is set to `DEBUG`, keeping production logs quiet while still preserving the underlying conversation.

### Swagger / OpenAPI

The interactive documentation (http://localhost:8000/docs) reflects the renamed modules (`ltm_controller`, `stm_controller`, etc.). Tag names map directly to the controller prefixes:

- **Long-Term Memory** → `/api/v1/ltm/*`
- **Short-Term Memory** → `/api/v1/stm/*`
- **Session** and **Health** remain unchanged

When using Swagger, always provide the `X-Client-ID` header in the “Headers” section for LTM endpoints, or include `client_id` in the request body.

## PostgreSQL Setup with pgvector

### Option 1: Using Docker (Recommended)

The provided `docker-compose.yml` automatically sets up PostgreSQL with pgvector:

```bash
docker compose up -d db
```

### Option 2: Manual Installation

#### On Ubuntu/Debian:
```bash
# Install PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Install pgvector extension
sudo apt install postgresql-16-pgvector

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and enable extension
sudo -u postgres psql -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

#### On macOS:
```bash
# Install PostgreSQL
brew install postgresql

# Install pgvector
brew install pgvector

# Start PostgreSQL
brew services start postgresql

# Create database and enable extension
psql postgres -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

### Database Configuration

The service automatically creates:
- A shared schema (default `agent_memory_dev`) for all long-term memory data
- Per-client memory tables suffixed with `_memories` (e.g., `agent_memory_dev.client123_memories`)
- Indexes for optimal metadata filtering and similarity search

Example table structure:
```sql
-- Memory table for client_id: client-123
CREATE TABLE agent_memory_dev.client_123_memories (
    id UUID PRIMARY KEY,
    client_id TEXT NOT NULL,
    user_id TEXT,
    agent_id TEXT,
    run_id TEXT,
    memory TEXT NOT NULL,
    embedding vector(1536) NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Metadata index
CREATE INDEX client_123_memories_metadata_idx ON agent_memory_dev.client_123_memories USING GIN (metadata);

-- Optional vector similarity index (requires pgvector >= 0.5.1)
CREATE INDEX client_123_memories_embedding_idx
  ON agent_memory_dev.client_123_memories
  USING hnsw (embedding vector_l2_ops);
```

## Security and Multi-tenancy

### Table Isolation
- Each client gets a dedicated PostgreSQL table (e.g., `agent_memory_dev.client_123_memories`)
- Complete data isolation between clients within a shared schema
- No cross-client data access possible

### API Key Management
- Search operations require valid OpenAI API keys
- Per-client configuration allows different API keys
- Temporary configurations for read-only operations

### Access Control
- Client must be configured before adding memories or searching
- Cross-client operations prevented by service-level checks
- Memory operations scoped to user/agent/run identifiers

## Performance Considerations

### Vector Search Optimization
- HNSW indexes for fast similarity search
- Configurable embedding dimensions
- Efficient PostgreSQL query patterns

### Connection Management
- Connection pooling for database connections
- Schema-aware query optimization
- Prepared statements for common operations

### Memory Management
- Efficient vector storage in PostgreSQL
- Lazy loading of vector store connections
- Optimized bulk operations

## Error Handling

The service provides comprehensive error handling:

- **400 Bad Request**: Invalid request parameters
- **404 Not Found**: Application or memory not found
- **500 Internal Server Error**: Configuration or processing errors

Example error responses:
```json
{
  "detail": "Search operations require proper configuration. Please call /configure with a valid API key before searching."
}
```

## Integration with Short-Term Memory

The service runs alongside the STM service, providing:
- Complementary memory storage (temporary vs. persistent)
- Shared API patterns and response formats
- Unified memory management across time horizons
- Seamless integration in agent architectures

## Monitoring and Observability

### Health Checks
- Service health endpoint for monitoring
- Database connection validation
- Vector extension availability checks

### Logging
- Structured logging for all operations
- Error tracking and debugging support
- Performance monitoring capabilities

### Metrics
- Memory operation counts
- Search performance metrics
- Application activity tracking
