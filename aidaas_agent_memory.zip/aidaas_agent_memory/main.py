"""
FastAPI main application for Agentic Memory API.
Provides long-term memory (LTM) and short-term memory (STM) endpoints.
"""

import logging
import logging.config
import time

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from src.api.v1.controller import routers
from src.api.v1.exception.handlers import set_exception_handlers
from src.core.environment_variables import EnvironmentVariables
from src.core.logging import get_logging_config, log_request

app = FastAPI(
    title="Aidaas Agent Memory",
    description="A REST API for managing long-term and short-term memories for AI Agents and Apps.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Add API versioning
api_prefix = "/api/v1"
for router in routers:
    app.include_router(router, prefix=api_prefix)

set_exception_handlers(app)
logging.config.dictConfig(get_logging_config(EnvironmentVariables.LOG_LEVEL))


@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    start_time = time.time()

    # update request headers with request start time
    headers = dict(request.scope["headers"])
    headers[b"request-start-time"] = str(start_time).encode()
    request.scope["headers"] = [(k, v) for k, v in headers.items()]

    response = await call_next(request)
    log_request(request, response.status_code, response.headers.get("Error-Message"))

    return response


if __name__ == "__main__":
    print("Starting application with the following environment:")
    EnvironmentVariables.print_all_variables()

    uvicorn.run(
        "main:app",
        host=EnvironmentVariables.API_HOST,
        port=EnvironmentVariables.API_PORT,
        reload=EnvironmentVariables.API_RELOAD,
    )
